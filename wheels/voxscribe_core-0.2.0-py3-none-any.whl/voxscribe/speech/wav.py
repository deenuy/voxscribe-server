"""Minimal WAV reading and writing for vectors, evaluation and tests.

Standard library `wave` plus numpy: 16-bit PCM only on write; 8, 16, 24 and
32-bit integer PCM on read, any channel count (averaged to mono). The
golden vectors are 16 kHz mono PCM16, and macOS `say` output (which puts a
padding chunk before the data) reads fine through `wave`.
"""

from __future__ import annotations

import wave
from pathlib import Path

import numpy as np

from .resample import to_mono_float32


def read_wav(path: str | Path) -> tuple[np.ndarray, int]:
    """Read a PCM WAV. Returns (float32 mono samples in -1..1, sample rate).

    Raises ValueError for compressed or float WAVs that `wave` cannot parse,
    and for sample widths other than 1, 2, 3 or 4 bytes.
    """
    with wave.open(str(path), "rb") as w:
        channels = w.getnchannels()
        width = w.getsampwidth()
        rate = w.getframerate()
        raw = w.readframes(w.getnframes())
    if width == 2:
        data = np.frombuffer(raw, dtype="<i2")
    elif width == 1:
        data = (np.frombuffer(raw, dtype=np.uint8).astype(np.int16) - 128) << 8
    elif width == 3:
        b = np.frombuffer(raw, dtype=np.uint8).reshape(-1, 3).astype(np.int32)
        data = (b[:, 0] | (b[:, 1] << 8) | (b[:, 2] << 16)).astype(np.int32)
        data = np.where(data >= 1 << 23, data - (1 << 24), data) << 8
    elif width == 4:
        data = np.frombuffer(raw, dtype="<i4")
    else:
        raise ValueError(f"unsupported WAV sample width {width} bytes in {path}")
    if channels > 1:
        data = data.reshape(-1, channels)
    return to_mono_float32(data), rate


def write_wav16(path: str | Path, samples: np.ndarray, rate: int) -> None:
    """Write float samples (-1..1, clipped) as 16-bit mono PCM."""
    x = np.clip(np.asarray(samples, dtype=np.float64), -1.0, 1.0)
    pcm = np.round(x * 32767.0).astype("<i2")
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(int(rate))
        w.writeframes(pcm.tobytes())
