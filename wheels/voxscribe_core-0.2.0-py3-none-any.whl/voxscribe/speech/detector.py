"""Layer 1 of the speech activity capability: the detector contract.

A detector turns PCM audio into one speech probability per hop. It is
stateful across the frames of one stream (a recurrent model keeps hidden
state, the heuristic keeps a learned room floor) and stateless across
products: nothing here knows what the probability will be used for. The
policy layer (`voxscribe.speech.policy`) turns probabilities into decisions.

Units used throughout the package:
  - audio is float32 mono in -1..1 at `sample_rate` Hz (16000 for every
    shipped detector; use `voxscribe.speech.resample` to get there)
  - time is milliseconds on the stream's own timeline: `end_ms` of a frame is
    the number of samples consumed since `reset()`, divided by the rate
  - probabilities are 0..1 where 1 means "certainly speech"

See docs/adr/0001-speech-activity.md for the decision and
docs/SPEECH-ACTIVITY.md for the spec that client ports are certified against.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Protocol, runtime_checkable

if TYPE_CHECKING:  # numpy is an optional dependency (listen or speech extra)
    import numpy as np


class SpeechDetectorUnavailable(RuntimeError):
    """Raised when a detector is constructed but its runtime is missing.

    Carries a plain-language reason (which import failed, or which file is
    missing) so a product can show it or fall back to another detector.
    Check `Detector.is_available()` first to avoid the exception.
    """


@dataclass(frozen=True)
class SpeechFeatures:
    """Explainable per-hop features, filled by detectors that compute them.

    All fields describe the hop that ends at `SpeechFrame.end_ms`.

      snr_db         voice-band (90 Hz to 4 kHz) energy above the learned room
                     floor, in dB. Negative when the hop is quieter than the
                     room. Unbounded, typically -10 to +40.
      floor_db       the learned room floor itself, dB relative to full scale
                     of the voice-band mean power. A level, not a ratio.
      flatness       spectral flatness of the voice band, 0..1. Speech is
                     peaky (about 0.05 to 0.3), white noise is flat (near 1).
      harmonicity    normalised autocorrelation at the best pitch lag, 0..1,
                     or None when the detector had no time-domain block long
                     enough for the pitch range. Voiced speech is about 0.6 to
                     0.95, broadband noise below 0.35.
      pitch_hz       pitch estimate at the best lag, Hz, in the detector's
                     search range (80 to 400 Hz), or 0.0 when unvoiced or when
                     harmonicity is None.
      modulation_db  standard deviation of voice-band energy (dB) over the
                     last few hundred milliseconds. Syllables swing by 10 dB or
                     more; a steady hum or held tone by under 1 dB.

    Model-based detectors (Silero) have no such decomposition and leave
    `SpeechFrame.features` as None.
    """

    snr_db: float
    floor_db: float
    flatness: float
    harmonicity: float | None
    pitch_hz: float
    modulation_db: float


@dataclass(frozen=True)
class SpeechFrame:
    """One detector decision for one hop of audio.

    end_ms       end of this hop on the stream's own timeline, in integer
                 milliseconds of samples consumed since reset(). With a
                 512-sample hop at 16 kHz the values are 32, 64, 96, ...
    probability  0..1, the detector's belief that the hop holds speech.
    features     explainable features when the detector has them, else None.
    """

    end_ms: int
    probability: float
    features: SpeechFeatures | None = None


@runtime_checkable
class SpeechDetector(Protocol):
    """Turns audio into a speech probability per hop.

    Attributes:
      name          short identifier used in events and logs: "silero",
                    "heuristic" or "fake".
      sample_rate   input rate the detector requires, Hz (16000 for all
                    shipped detectors). Callers resample before process().
      hop_samples   samples per decision (512 for all shipped detectors, which
                    is 32 ms at 16 kHz).

    `process()` accepts float32 mono samples of any length. The detector
    buffers a partial hop and returns one SpeechFrame per completed hop, so
    streaming in chunks of any size yields the same frames as one big call.
    `reset()` forgets all state, including the partial buffer and the timeline.
    """

    name: str
    sample_rate: int
    hop_samples: int

    def reset(self) -> None: ...

    def process(self, samples: np.ndarray) -> list[SpeechFrame]: ...
