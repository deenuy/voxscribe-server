"""Silero VAD v6 as a streaming `SpeechDetector`.

Uses the `silero_vad_v6.onnx` file that faster-whisper ships (located through
`faster_whisper.utils.get_assets_path()`, never a hard-coded path), so an
environment that runs ASR already has the model. onnxruntime runs it on the
CPU with one thread; the model is small enough that this is about 10 ms of
CPU per second of audio.

ONNX signature, introspected with onnxruntime 1.31 on faster-whisper 1.2.1:

    inputs   input  float32 [seq_len, 576]   64 context samples + 512 new
             h      float32 [1, 1, 128]      LSTM hidden state
             c      float32 [1, 1, 128]      LSTM cell state
    outputs  speech_probs float32 [seq_len]  one probability per 576 row
             hn     float32 [1, 1, 128]
             cn     float32 [1, 1, 128]

Each row of `input` is one hop: the 64 samples that preceded the hop
(zeros for the first hop of a stream) followed by the 512 samples of the hop.
Rows in one call are processed sequentially with the state threaded through,
and the result is bit-identical to feeding the rows one call at a time with
`hn`, `cn` carried (checked numerically before this wrapper was written).
This detector therefore keeps the recurrent state and the 64-sample context
explicitly across `process()` calls, buffers partial hops, and runs all
complete hops of a chunk in one session call: chunks of any size give the
same frames as one big call.

Limits: 16 kHz only (resample first); the probability is the model's raw
output with no smoothing, which the policy layer adds; the model was trained
on speech of many languages but any human voice, including a television,
scores as speech.
"""

from __future__ import annotations

import logging
import os
from typing import Any

from ..logging_config import get_logger, log_event
from .detector import SpeechDetectorUnavailable, SpeechFrame

log = get_logger("voxscribe.speech.silero")

MODEL_FILE = "silero_vad_v6.onnx"
SAMPLE_RATE = 16000
HOP_SAMPLES = 512
CONTEXT_SAMPLES = 64
STATE_SHAPE = (1, 1, 128)


def model_path() -> str:
    """Absolute path of the bundled model, via faster-whisper's asset helper.

    Raises `SpeechDetectorUnavailable` when faster-whisper is not installed or
    the file is missing from its assets.
    """
    try:
        from faster_whisper.utils import get_assets_path
    except ImportError as exc:  # pragma: no cover - depends on the environment
        raise SpeechDetectorUnavailable(
            "SileroDetector needs faster-whisper for the bundled model "
            "(pip install 'voxscribe-core[speech]')"
        ) from exc
    path = os.path.join(get_assets_path(), MODEL_FILE)
    if not os.path.isfile(path):
        raise SpeechDetectorUnavailable(f"Silero model not found at {path}")
    return path


def _load_runtime() -> Any:
    try:
        import onnxruntime
    except ImportError as exc:  # pragma: no cover - depends on the environment
        raise SpeechDetectorUnavailable(
            "SileroDetector needs onnxruntime (pip install 'voxscribe-core[speech]')"
        ) from exc
    return onnxruntime


class SileroDetector:
    """Streaming Silero VAD v6, 16 kHz, 512-sample (32 ms) hops.

    Construct with `SileroDetector()`; it raises `SpeechDetectorUnavailable`
    with a plain reason when numpy, onnxruntime, faster-whisper or the model
    file is missing. `is_available()` answers the same question without
    raising. `path` overrides the model location (tests, pinned copies).

    State across calls: the LSTM `h` and `c` tensors, the last 64 samples of
    the previous hop (context) and up to 511 buffered samples of a partial
    hop. `reset()` clears all of it and restarts the timeline at 0 ms.
    """

    name = "silero"
    sample_rate = SAMPLE_RATE
    hop_samples = HOP_SAMPLES

    @classmethod
    def is_available(cls) -> bool:
        """True when numpy, onnxruntime and the bundled model can all be loaded."""
        try:
            import numpy  # noqa: F401

            _load_runtime()
            model_path()
        except (SpeechDetectorUnavailable, ImportError):
            return False
        return True

    @classmethod
    def unavailable_reason(cls) -> str | None:
        """The reason `is_available()` is False, or None when it is True."""
        try:
            import numpy  # noqa: F401
        except ImportError:
            return "numpy is not installed"
        try:
            _load_runtime()
            model_path()
        except SpeechDetectorUnavailable as exc:
            return str(exc)
        return None

    def __init__(self, path: str | None = None, *, threads: int = 1) -> None:
        try:
            import numpy as np
        except ImportError as exc:  # pragma: no cover - depends on the environment
            raise SpeechDetectorUnavailable("SileroDetector needs numpy") from exc
        self._np = np
        ort = _load_runtime()
        self.path = path or model_path()
        if not os.path.isfile(self.path):
            raise SpeechDetectorUnavailable(f"Silero model not found at {self.path}")
        opts = ort.SessionOptions()
        opts.inter_op_num_threads = max(1, int(threads))
        opts.intra_op_num_threads = max(1, int(threads))
        opts.enable_cpu_mem_arena = False
        opts.log_severity_level = 4
        try:
            self._session = ort.InferenceSession(
                self.path, providers=["CPUExecutionProvider"], sess_options=opts
            )
        except Exception as exc:  # noqa: BLE001 - onnxruntime raises its own hierarchy
            raise SpeechDetectorUnavailable(
                f"onnxruntime could not load {self.path}: {type(exc).__name__}: {exc}"
            ) from exc
        inputs = {i.name for i in self._session.get_inputs()}
        if inputs != {"input", "h", "c"}:
            raise SpeechDetectorUnavailable(
                f"unexpected Silero ONNX inputs {sorted(inputs)}; expected input, h, c"
            )
        self.reset()
        log_event(
            log,
            "speech_detector_created",
            level=logging.INFO,
            detector=self.name,
            model_path=self.path,
            sample_rate=self.sample_rate,
            hop_samples=self.hop_samples,
            context_samples=CONTEXT_SAMPLES,
            onnxruntime=getattr(ort, "__version__", ""),
        )

    def reset(self) -> None:
        """Clear the LSTM state, the context, the partial hop and the timeline."""
        np = self._np
        self._h = np.zeros(STATE_SHAPE, dtype=np.float32)
        self._c = np.zeros(STATE_SHAPE, dtype=np.float32)
        self._context = np.zeros(CONTEXT_SAMPLES, dtype=np.float32)
        self._pending = np.zeros(0, dtype=np.float32)
        self._samples_done = 0

    def process(self, samples: Any) -> list[SpeechFrame]:
        """Consume float32 mono 16 kHz samples of any length.

        Returns one frame per completed 512-sample hop, in order, with
        `end_ms` on the stream timeline. Keeps a partial hop for next time.
        """
        np = self._np
        x = np.asarray(samples, dtype=np.float32).reshape(-1)
        if self._pending.shape[0]:
            x = np.concatenate([self._pending, x])
        n_hops = x.shape[0] // HOP_SAMPLES
        if n_hops == 0:
            self._pending = x
            return []
        used = n_hops * HOP_SAMPLES
        hops = x[:used].reshape(n_hops, HOP_SAMPLES)
        self._pending = x[used:].copy()

        # Prepend each hop with the 64 samples that preceded it.
        contexts = np.empty((n_hops, CONTEXT_SAMPLES), dtype=np.float32)
        contexts[0] = self._context
        if n_hops > 1:
            contexts[1:] = hops[:-1, -CONTEXT_SAMPLES:]
        batch = np.concatenate([contexts, hops], axis=1)
        probs, self._h, self._c = self._session.run(
            None, {"input": batch, "h": self._h, "c": self._c}
        )
        self._context = hops[-1, -CONTEXT_SAMPLES:].copy()
        probs = np.asarray(probs, dtype=np.float32).reshape(-1)

        frames: list[SpeechFrame] = []
        for i in range(n_hops):
            self._samples_done += HOP_SAMPLES
            end_ms = self._samples_done * 1000 // SAMPLE_RATE
            frames.append(SpeechFrame(end_ms=end_ms, probability=float(probs[i]), features=None))
        return frames
