"""Speech activity: one definition of "is someone speaking?" for every product.

Three layers (ADR 0001):

    PCM frames -> DETECTOR -> POLICY -> EVENTS
                  probability  decision   speech started / ended
                  per hop      and timing

Quick start::

    from voxscribe.speech import create_detector, SpeechActivityTracker, SEGMENTATION

    detector = create_detector("silero")          # or "heuristic", "fake"
    tracker = SpeechActivityTracker(SEGMENTATION, detector=detector.name)
    for chunk in audio_chunks_16k:                # float32 mono, any length
        for frame in detector.process(chunk):
            event = tracker.process(frame)
            if event is not None:
                emit(event.to_contract_dict())
    tracker.reset()                               # logs the stream summary

Detectors need numpy (the `listen` or `speech` extra); Silero also needs
onnxruntime and faster-whisper (the `speech` extra). Importing this package
never imports numpy; the detectors import it on construction.

SPEC_VERSION is the version of docs/SPEECH-ACTIVITY.md and of the golden
vectors' `vectors.json`; client ports report which spec version they pass.
"""

from __future__ import annotations

from typing import Any

from .detector import SpeechDetector, SpeechDetectorUnavailable, SpeechFeatures, SpeechFrame
from .events import EVENT_TYPE, SpeechEvent
from .policy import (
    BARGE_IN,
    DISPLAY,
    PRESETS,
    SEGMENTATION,
    TURN,
    NoiseProfile,
    SpeechActivityTracker,
    SpeechPolicy,
    preset,
)

SPEC_VERSION = 1

DETECTOR_NAMES = ("silero", "heuristic", "fake")

__all__ = [
    "BARGE_IN",
    "DETECTOR_NAMES",
    "DISPLAY",
    "EVENT_TYPE",
    "PRESETS",
    "SEGMENTATION",
    "SPEC_VERSION",
    "TURN",
    "NoiseProfile",
    "SpeechActivityTracker",
    "SpeechDetector",
    "SpeechDetectorUnavailable",
    "SpeechEvent",
    "SpeechFeatures",
    "SpeechFrame",
    "SpeechPolicy",
    "available_detectors",
    "create_detector",
    "preset",
]


def available_detectors() -> list[str]:
    """Names of the detectors that can be constructed in this environment.

    "fake" and "heuristic" need numpy; "silero" also needs onnxruntime and
    the model that faster-whisper ships. Order is the preference order.
    """
    names: list[str] = []
    try:
        import numpy  # noqa: F401
    except ImportError:
        return names
    from .silero import SileroDetector

    if SileroDetector.is_available():
        names.append("silero")
    names.append("heuristic")
    names.append("fake")
    return names


def create_detector(name: str, **opts: Any) -> SpeechDetector:
    """Build a detector by name: "silero", "heuristic" or "fake".

    Keyword options go to the detector's constructor (`path=` and `threads=`
    for Silero, `config=` for the heuristic, `script=` and the rest for the
    fake). Raises ValueError for an unknown name and
    `SpeechDetectorUnavailable` when the runtime is missing.
    """
    key = name.strip().lower()
    if key == "silero":
        from .silero import SileroDetector

        return SileroDetector(**opts)
    if key == "heuristic":
        from .heuristic import HeuristicDetector

        return HeuristicDetector(**opts)
    if key == "fake":
        from .fake import FakeDetector

        return FakeDetector(**opts)
    raise ValueError(f"unknown speech detector {name!r}; choose from {DETECTOR_NAMES}")
