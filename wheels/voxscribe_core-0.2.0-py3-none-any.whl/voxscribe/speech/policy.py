"""Layer 2 of the speech activity capability: policies and the tracker.

The same per-hop probability means different things to different consumers
because being wrong costs different things (ADR 0001):

  DISPLAY       an indicator that looks fake: hide when unsure, fast onset
  SEGMENTATION  lost words, which is data loss: include when unsure, with a
                generous pre-roll and hangover
  TURN          interrupting or lagging: combined with silence_policy and
                turn_taking, so it ends promptly and starts only on sustained
                speech
  BARGE_IN      talking over the user, or stopping on its own echo: demands
                strong, sustained evidence and lets go fast

A `SpeechPolicy` is data; `SpeechActivityTracker` is a pure state machine
from `SpeechFrame` to `SpeechEvent`. It absorbs `audio_frontend.VADGate`,
which remains as a thin compatibility layer, and its noise profiles.

Timing is measured in milliseconds from the frames' own `end_ms` values, so
the tracker works for any hop size and for frames produced by a browser
analyser at 60 frames a second, not only for 32 ms hops.
"""

from __future__ import annotations

import logging
import math
from collections.abc import Iterable
from dataclasses import dataclass, replace
from enum import Enum
from typing import Any

from ..logging_config import get_logger, log_event
from .detector import SpeechFrame
from .events import SpeechEvent

log = get_logger("voxscribe.speech.policy")


class NoiseProfile(Enum):
    """Environment presets absorbed from `audio_frontend`.

    A profile shifts a policy's thresholds and timing for the kinds of rooms
    the product runs in. It never changes which detector is used.
    """

    QUIET = "quiet"
    OFFICE = "office"
    MOBILE = "mobile"  # driving, walking outside, traffic
    PLANT_FLOOR = "plant_floor"  # heavy steady industrial noise


@dataclass(frozen=True)
class SpeechPolicy:
    """How a probability stream becomes started and ended decisions.

    name             identifier for logs and reports ("display", ...).
    start_threshold  a frame with probability at or above this counts toward
                     starting; a frame below it resets the run. 0..1.
    end_threshold    while speaking, a frame with probability below this
                     counts toward ending; at or above it resets the
                     hangover. Must not exceed `start_threshold` (that is the
                     hysteresis). 0..1.
    start_ms         milliseconds of consecutive qualifying frames before
                     "started" is emitted. 0 means the frame count alone
                     decides.
    start_frames     minimum consecutive qualifying frames before "started";
                     at least 1. With both limits a single long frame (a
                     reduced-motion client at 8 frames a second) cannot open
                     on one click, and a fast client cannot open on one
                     32 ms blip either.
    hangover_ms      milliseconds of consecutive frames below
                     `end_threshold` before "ended". Pauses between words
                     shorter than this do not end the utterance.
    pre_roll_ms      subtracted from the run start in the "started" event's
                     `at_ms` so a segmenter includes the soft onset the
                     detector reacted to late. Never below 0 on the timeline.
    steady_close_ms  while speaking, end as soon as the sound has been
                     steady (features.modulation_db below `steady_below_db`)
                     for this long, so a hum that starts while someone talks
                     cannot hold the gate open. 0 disables. Only acts when
                     frames carry features (the heuristic detector); model
                     frames without features are unaffected.
    steady_below_db  the modulation level that counts as steady, in dB.
    """

    name: str
    start_threshold: float
    end_threshold: float
    start_ms: int
    start_frames: int
    hangover_ms: int
    pre_roll_ms: int = 0
    steady_close_ms: int = 0
    steady_below_db: float = 2.0

    def __post_init__(self) -> None:
        if not 0.0 <= self.end_threshold <= self.start_threshold <= 1.0:
            raise ValueError(
                "SpeechPolicy needs 0 <= end_threshold <= start_threshold <= 1, got "
                f"end={self.end_threshold} start={self.start_threshold}"
            )
        if self.start_frames < 1:
            raise ValueError("SpeechPolicy.start_frames must be at least 1")
        for field_name in ("start_ms", "hangover_ms", "pre_roll_ms", "steady_close_ms"):
            if getattr(self, field_name) < 0:
                raise ValueError(f"SpeechPolicy.{field_name} must not be negative")

    def for_noise(self, profile: NoiseProfile) -> SpeechPolicy:
        """A copy of this policy shifted for an environment.

        The shifts are the ones `audio_frontend.config_for` used, expressed
        relative to the OFFICE baseline so they apply to every preset:

          QUIET        thresholds 0.05 lower
          OFFICE       unchanged
          MOBILE       thresholds 0.10 higher, hangover 300 ms longer so road
                       noise gaps do not cut utterances short
          PLANT_FLOOR  thresholds 0.20 higher, one more frame to start, hangover
                       500 ms longer: demand strong, sustained speech
        """
        start, end, frames, hang = _NOISE_SHIFTS[profile]
        return replace(
            self,
            name=f"{self.name}+{profile.value}",
            start_threshold=min(1.0, self.start_threshold + start),
            end_threshold=max(0.0, min(1.0, self.end_threshold + end)),
            start_frames=self.start_frames + frames,
            hangover_ms=self.hangover_ms + hang,
        )

    def to_dict(self) -> dict[str, Any]:
        """Plain dict for reports and logs."""
        return {
            "name": self.name,
            "start_threshold": self.start_threshold,
            "end_threshold": self.end_threshold,
            "start_ms": self.start_ms,
            "start_frames": self.start_frames,
            "hangover_ms": self.hangover_ms,
            "pre_roll_ms": self.pre_roll_ms,
            "steady_close_ms": self.steady_close_ms,
            "steady_below_db": self.steady_below_db,
        }


# (start shift, end shift, extra start frames, extra hangover ms)
_NOISE_SHIFTS: dict[NoiseProfile, tuple[float, float, int, int]] = {
    NoiseProfile.QUIET: (-0.05, -0.05, 0, 0),
    NoiseProfile.OFFICE: (0.0, 0.0, 0, 0),
    NoiseProfile.MOBILE: (0.10, 0.10, 0, 300),
    NoiseProfile.PLANT_FLOOR: (0.20, 0.20, 1, 500),
}


# ---- presets --------------------------------------------------------------
#
# The numbers are starting values checked by tests/speech against the golden
# vectors (docs/SPEECH-ACTIVITY.md states the required outcomes). Change them
# with `voxscribe speech-eval`, not by eye (ADR 0001, invariant 4).

DISPLAY = SpeechPolicy(
    name="display",
    start_threshold=0.5,
    end_threshold=0.35,
    start_ms=60,  # about 60 ms of speech-like frames, as the app's gate
    start_frames=2,  # over at least two frames, so a single click cannot open it
    hangover_ms=250,  # pauses between words do not make the strip flicker
    pre_roll_ms=0,
    steady_close_ms=500,  # a hum that starts mid-sentence lets go within half a second
    steady_below_db=2.0,
)

SEGMENTATION = SpeechPolicy(
    name="segmentation",
    start_threshold=0.4,  # include when unsure
    end_threshold=0.25,
    start_ms=60,
    start_frames=2,
    hangover_ms=700,  # a thinking pause inside a sentence stays in one segment
    pre_roll_ms=320,  # the soft onset the detector reacted to late is kept
)

TURN = SpeechPolicy(
    name="turn",
    start_threshold=0.5,
    end_threshold=0.35,
    start_ms=96,  # a cough does not open a turn
    start_frames=3,
    hangover_ms=300,  # ends promptly so silence_policy measures the real pause
    pre_roll_ms=0,
)

BARGE_IN = SpeechPolicy(
    name="barge_in",
    start_threshold=0.7,  # strong evidence before interrupting playback
    end_threshold=0.5,
    start_ms=128,
    start_frames=4,
    hangover_ms=200,  # lets go fast once the user stops
    pre_roll_ms=0,
)

PRESETS: dict[str, SpeechPolicy] = {
    "display": DISPLAY,
    "segmentation": SEGMENTATION,
    "turn": TURN,
    "barge_in": BARGE_IN,
}


def preset(name: str) -> SpeechPolicy:
    """Look up a preset by name, case-insensitive ("DISPLAY" or "display")."""
    key = name.strip().lower().replace("-", "_")
    try:
        return PRESETS[key]
    except KeyError:
        raise ValueError(f"unknown speech policy {name!r}; choose from {sorted(PRESETS)}") from None


# ---- tracker --------------------------------------------------------------


class SpeechActivityTracker:
    """Pure state machine: `SpeechFrame` in, `SpeechEvent` out.

    Feed every frame of a stream to `process()`; it returns the transition
    the frame caused, or None. Time comes from the frames' `end_ms` values
    (the duration of a frame is the difference to the previous frame's
    `end_ms`, or `end_ms` itself for the first frame), so the tracker does
    not need to know the hop size.

    `reset()` starts a new stream and logs a per-stream summary at INFO:
    seconds processed, seconds of speech, number of starts and the mean
    probability. Transitions are logged at DEBUG. Nothing is logged per
    frame at INFO or above.

    Limits: a frame whose `end_ms` does not advance (a detector reset without
    a tracker reset) is treated as one hop long; probabilities outside 0..1
    are clamped.
    """

    def __init__(self, policy: SpeechPolicy, *, detector: str = "unknown") -> None:
        self.policy = policy
        self.detector = detector
        self._init_state()

    def _init_state(self) -> None:
        self._speaking = False
        self._last_end_ms = 0
        self._last_hop_ms = 0
        self._run_start_ms = 0
        self._above_ms = 0
        self._above_frames = 0
        self._silence_ms = 0
        self._steady_ms = 0
        # Per-stream summary counters.
        self._frames = 0
        self._speech_ms = 0
        self._starts = 0
        self._prob_sum = 0.0

    @property
    def speaking(self) -> bool:
        """True between a "started" and the following "ended"."""
        return self._speaking

    def summary(self) -> dict[str, Any]:
        """The per-stream counters: seconds processed, seconds of speech,
        starts and mean probability, plus the policy and detector names."""
        return {
            "policy": self.policy.name,
            "detector": self.detector,
            "frames": self._frames,
            "seconds_processed": round(self._last_end_ms / 1000.0, 3),
            "seconds_speech": round(self._speech_ms / 1000.0, 3),
            "starts": self._starts,
            "mean_probability": round(self._prob_sum / self._frames, 4) if self._frames else 0.0,
        }

    def reset(self) -> None:
        """Forget the stream. Logs the summary of the stream that ends here
        when at least one frame was processed."""
        if self._frames:
            log_event(log, "speech_stream_summary", level=logging.INFO, **self.summary())
        self._init_state()

    def feed(self, frames: Iterable[SpeechFrame]) -> list[SpeechEvent]:
        """Process many frames and collect the transitions, in order."""
        out: list[SpeechEvent] = []
        for frame in frames:
            event = self.process(frame)
            if event is not None:
                out.append(event)
        return out

    def process(self, frame: SpeechFrame) -> SpeechEvent | None:
        """Advance the state machine by one frame.

        Returns the "started" or "ended" event the frame caused, else None.
        """
        p = min(1.0, max(0.0, float(frame.probability)))
        hop = frame.end_ms - self._last_end_ms
        if hop <= 0:
            hop = self._last_hop_ms or 1
        self._last_hop_ms = hop
        self._last_end_ms = frame.end_ms
        self._frames += 1
        self._prob_sum += p
        policy = self.policy

        if not self._speaking:
            if p >= policy.start_threshold:
                if self._above_frames == 0:
                    self._run_start_ms = frame.end_ms - hop
                self._above_ms += hop
                self._above_frames += 1
                if self._above_ms >= policy.start_ms and self._above_frames >= policy.start_frames:
                    self._speaking = True
                    self._above_ms = 0
                    self._above_frames = 0
                    self._silence_ms = 0
                    self._steady_ms = 0
                    self._starts += 1
                    self._speech_ms += hop
                    at_ms = max(0, self._run_start_ms - policy.pre_roll_ms)
                    return self._emit("started", at_ms, p, frame.end_ms)
            else:
                self._above_ms = 0
                self._above_frames = 0
            return None

        # Speaking: count silence toward the hangover, and steadiness toward
        # the steady-sound close when the frame carries features.
        self._speech_ms += hop
        if p < policy.end_threshold:
            self._silence_ms += hop
        else:
            self._silence_ms = 0
        if policy.steady_close_ms > 0 and frame.features is not None:
            if frame.features.modulation_db < policy.steady_below_db:
                self._steady_ms += hop
            else:
                self._steady_ms = 0
        ended_by_hangover = self._silence_ms >= policy.hangover_ms
        ended_by_steady = policy.steady_close_ms > 0 and self._steady_ms >= policy.steady_close_ms
        if ended_by_hangover or ended_by_steady:
            self._speaking = False
            self._silence_ms = 0
            self._steady_ms = 0
            return self._emit(
                "ended",
                frame.end_ms,
                p,
                frame.end_ms,
                reason="hangover" if ended_by_hangover else "steady",
            )
        return None

    def _emit(
        self, kind: str, at_ms: int, p: float, decided_ms: int, reason: str = ""
    ) -> SpeechEvent:
        event = SpeechEvent(kind=kind, at_ms=int(at_ms), probability=p, detector=self.detector)
        if log.isEnabledFor(logging.DEBUG):
            log_event(
                log,
                "speech_activity_transition",
                level=logging.DEBUG,
                kind=kind,
                at_ms=int(at_ms),
                decided_ms=int(decided_ms),
                probability=round(p, 3),
                policy=self.policy.name,
                detector=self.detector,
                reason=reason,
            )
        return event


def frames_for(ms: int, hop_ms: int) -> int:
    """Frames needed to cover `ms` at `hop_ms` per frame, rounded up, at least 1.

    A helper for clients that count frames instead of milliseconds (the app's
    gate counts both); kept here so the rounding rule has one home.
    """
    return max(1, math.ceil(ms / hop_ms)) if hop_ms > 0 else 1
