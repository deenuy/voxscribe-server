"""A model-free speech detector: the app's display gate ported to raw PCM.

Port of ideascribe-app/src/audio/speechGate.js (which reads a browser
AnalyserNode) to 16 kHz PCM with numpy. Used for diagnostics, display,
low-power devices and as an explainable second opinion next to Silero. Every
hop yields `SpeechFeatures`, so a product can show why the detector decided
what it did.

How it decides, per 512-sample hop (32 ms):
  1. Loudness against the room. Energy in the voice band (90 Hz to 4 kHz)
     from a 512-point Hann-windowed rFFT of the hop is compared with a floor
     learned from the room, and only while the detector itself does not hear
     speech. Steady noise becomes the floor and stops counting.
  2. Voicing. A pitch between 80 and 400 Hz, found by normalised
     autocorrelation of the last 64 ms (1024 samples) decimated by two to
     8 kHz, so the block holds at least two periods of 80 Hz. Vowels and
     voiced consonants are harmonic; clicks and broadband noise are not.
  3. Spectral shape. Flatness of the voice band: speech is peaky (formants),
     noise is flat. It stands in for voicing through unvoiced consonants.
  4. Modulation. Speech rises and falls with syllables, 2 to 8 times a
     second. The exponentially weighted standard deviation of band energy
     (time constant 250 ms) is large for speech and near zero for a hum.

Probability mapping (monotonic in every feature, documented in
docs/SPEECH-ACTIVITY.md):

    level      = ramp(snr_db,        3 dB -> 0,   9 dB -> 1)
    peaky      = ramp(0.5 - flatness, 0 -> 0,     0.3 -> 1)   (flatness 0.35 -> 0.5)
    voiced     = ramp(harmonicity,   0.35 -> 0,   0.65 -> 1)  (0.5 -> 0.5)
    voicing    = max(voiced, peaky)                         (peaky alone when
                                                             harmonicity is None)
    modulation = ramp(modulation_db, 1.5 dB -> 0, 4.5 dB -> 1)
    p          = min(level, voicing, modulation), and 0 during the warm-up

where ramp(x, a, b) is 0 below a, 1 above b and linear between. The weakest
piece of evidence bounds the probability: a hum is loud and voiced but not
modulated, white noise is modulated but not voiced, a click is loud but
neither. The app's gate opens at exactly the 0.5 point of each ramp, so the
DISPLAY policy's 0.5 start threshold reproduces its decision boundary.

One override, also from the app's gate: a second, fast steadiness estimate
(time constant 100 ms) of the same band energy. Once it has been below 2 dB
for 500 ms the sound is steady (a hum, a whine, a held note) and p is forced
to 0 until the energy moves again. The slow estimate alone remembers a
hum's onset for over a second; the fast one lets go within about half a
second after the onset settles.

Known limits, inherited from the app's gate by design:
  - Any human voice passes: a television or music with vocals is speech.
  - The onset of a steady sound (a hum that starts mid-stream, a held tone)
    looks modulated for up to about a second before the estimate settles.
    A hum present from the start never scores.
  - A whisper has no pitch and must be peaky to score.
  - A noise step is absorbed into the floor at 1.5 dB/s, so a sudden 30 dB
    rise in a non-flat noise (a fan switched on) can score for several
    seconds; flat noise (hiss) never does.
  - The first 600 ms teach the room: p is 0 there, and speech in that window
    raises the floor until the first pause.
  - Clipped or digitally silent input gives flatness 1 and harmonicity 0.

Cost: about 15 ms of CPU per second of audio (numpy, single thread).
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass

import numpy as np

from ..logging_config import get_logger, log_event
from .detector import SpeechFeatures, SpeechFrame

log = get_logger("voxscribe.speech.heuristic")

SAMPLE_RATE = 16000
HOP_SAMPLES = 512
EPS = 1e-12


@dataclass(frozen=True)
class HeuristicConfig:
    """Tuning of the heuristic detector. Defaults mirror the app's gate.

    Band and pitch ranges are in Hz; level thresholds in dB; time constants
    and rates in seconds and dB per second. `ramp_*` pairs are the (0, 1)
    points of the probability ramps described in the module docstring.
    """

    low_hz: float = 90.0
    high_hz: float = 4000.0
    min_pitch_hz: float = 80.0
    max_pitch_hz: float = 400.0
    decimate: int = 2
    pitch_block: int = 1024  # samples at 16 kHz, 64 ms: two periods of 80 Hz after decimation
    modulation_time_s: float = 0.25
    steady_time_s: float = 0.1
    steady_below_db: float = 2.0
    max_steady_s: float = 0.5
    floor_rise_db_per_s: float = 1.5
    floor_fall_per_s: float = 4.0
    warmup_s: float = 0.6
    hold_ms: int = 250  # how long after a speech-like hop the floor is not learned
    ramp_snr_db: tuple[float, float] = (3.0, 9.0)
    ramp_peaky: tuple[float, float] = (0.0, 0.3)  # applied to 0.5 - flatness
    ramp_harmonicity: tuple[float, float] = (0.35, 0.65)
    ramp_modulation_db: tuple[float, float] = (1.5, 4.5)


def ramp(x: float, lo: float, hi: float) -> float:
    """0 at or below `lo`, 1 at or above `hi`, linear between. Monotonic."""
    if x <= lo:
        return 0.0
    if x >= hi:
        return 1.0
    return (x - lo) / (hi - lo)


def band_features(power: np.ndarray, lo_bin: int, hi_bin: int) -> tuple[float, float]:
    """Mean power in dB and spectral flatness (0..1) of bins lo..hi inclusive.

    `power` is a one-sided power spectrum normalised so a full-scale sine at a
    bin centre reads 1.0 in its bin (0 dB).
    """
    band = power[lo_bin : hi_bin + 1]
    if band.shape[0] == 0:
        return -120.0, 1.0
    mean = float(band.mean())
    log_mean = float(np.log(band + EPS).mean())
    flatness = min(1.0, math.exp(log_mean) / (mean + EPS))
    return 10.0 * math.log10(mean + EPS), flatness


def pitch_strength(
    block: np.ndarray, rate: int, min_pitch_hz: float, max_pitch_hz: float, decimate: int
) -> tuple[float, float] | None:
    """Normalised autocorrelation pitch strength of a time-domain block.

    Returns (harmonicity 0..1, pitch_hz) or None when the block is too short
    to hold two periods of `min_pitch_hz` after decimation. Digital silence
    returns (0.0, 0.0) rather than dividing by zero.
    """
    n = block.shape[0] // decimate
    dec_rate = rate / decimate
    min_lag = max(2, int(math.floor(dec_rate / max_pitch_hz)))
    max_lag = int(math.ceil(dec_rate / min_pitch_hz))
    if n // 2 < max_lag or max_lag <= min_lag:
        return None
    x = block[: n * decimate].astype(np.float64).reshape(n, decimate).mean(axis=1)
    x -= x.mean()
    energy = float(np.dot(x, x))
    if energy < EPS:
        return 0.0, 0.0
    full = np.correlate(x, x, mode="full")[n - 1 :]  # full[lag] = sum x[i] x[i+lag]
    cs = np.concatenate([[0.0], np.cumsum(x * x)])
    lags = np.arange(min_lag, max_lag + 1)
    e1 = cs[n - lags]  # energy of x[0 : n-lag]
    e2 = energy - cs[lags]  # energy of x[lag : n]
    r = full[lags] / np.sqrt(e1 * e2 + EPS)
    best = int(np.argmax(r))
    harmonicity = float(min(1.0, max(0.0, r[best])))
    return harmonicity, float(dec_rate / lags[best])


class HeuristicDetector:
    """Explainable speech detector, 16 kHz, 512-sample (32 ms) hops, numpy only.

    `process()` accepts float32 mono samples of any length and returns one
    `SpeechFrame` per completed hop, with `features` filled. `reset()` forgets
    the room floor, the modulation estimate, the pitch history and the
    timeline, so a new recording starts with a fresh warm-up.
    """

    name = "heuristic"
    sample_rate = SAMPLE_RATE
    hop_samples = HOP_SAMPLES

    def __init__(self, config: HeuristicConfig | None = None) -> None:
        self.cfg = config or HeuristicConfig()
        self._window = np.hanning(HOP_SAMPLES).astype(np.float64)
        self._scale = 1.0 / ((self._window.sum() / 2.0) ** 2)
        bin_hz = SAMPLE_RATE / 2.0 / (HOP_SAMPLES // 2)
        self._lo_bin = max(1, int(math.ceil(self.cfg.low_hz / bin_hz)))
        self._hi_bin = min(HOP_SAMPLES // 2, int(math.floor(self.cfg.high_hz / bin_hz)))
        self._step = HOP_SAMPLES / SAMPLE_RATE
        self._alpha = 1.0 - math.exp(-self._step / self.cfg.modulation_time_s)
        self._beta = 1.0 - math.exp(-self._step / self.cfg.steady_time_s)
        self._hop_ms = HOP_SAMPLES * 1000 // SAMPLE_RATE
        self.reset()
        log_event(
            log,
            "speech_detector_created",
            level=logging.INFO,
            detector=self.name,
            model_path="",
            sample_rate=self.sample_rate,
            hop_samples=self.hop_samples,
            band_hz=f"{self.cfg.low_hz:g}-{self.cfg.high_hz:g}",
            pitch_hz=f"{self.cfg.min_pitch_hz:g}-{self.cfg.max_pitch_hz:g}",
        )

    def reset(self) -> None:
        """Forget the room and the timeline."""
        self._pending = np.zeros(0, dtype=np.float32)
        self._history = np.zeros(self.cfg.pitch_block, dtype=np.float32)
        self._samples_done = 0
        self._floor_db: float | None = None
        self._warm_left = self.cfg.warmup_s
        self._mod_mean: float | None = None
        self._mod_var = 0.0
        self._steady_mean: float | None = None
        self._steady_var = 0.0
        self._steady_for_s = 0.0
        self._hold_ms = 0

    def process(self, samples: np.ndarray) -> list[SpeechFrame]:
        """Consume samples (any length); one frame per completed hop."""
        x = np.asarray(samples, dtype=np.float32).reshape(-1)
        if self._pending.shape[0]:
            x = np.concatenate([self._pending, x])
        n_hops = x.shape[0] // HOP_SAMPLES
        if n_hops == 0:
            self._pending = x
            return []
        used = n_hops * HOP_SAMPLES
        hops = x[:used].reshape(n_hops, HOP_SAMPLES)
        self._pending = x[used:].copy()
        frames = [self._hop(hops[i]) for i in range(n_hops)]
        return frames

    def _hop(self, hop: np.ndarray) -> SpeechFrame:
        cfg = self.cfg
        step = self._step

        # 1 and 3. Loudness and shape of the voice band.
        spectrum = np.fft.rfft(hop.astype(np.float64) * self._window)
        power = (spectrum.real**2 + spectrum.imag**2) * self._scale
        band_db, flatness = band_features(power, self._lo_bin, self._hi_bin)

        # Room floor: follow both ways during warm-up; afterwards fall fast,
        # rise slowly, and never learn from hops the detector thinks are speech.
        if self._floor_db is None:
            self._floor_db = band_db
        elif self._warm_left > 0:
            self._floor_db += (band_db - self._floor_db) * min(1.0, step * 10.0)
        elif band_db < self._floor_db:
            self._floor_db += (band_db - self._floor_db) * min(1.0, step * cfg.floor_fall_per_s)
        elif self._hold_ms <= 0:
            self._floor_db = min(band_db, self._floor_db + cfg.floor_rise_db_per_s * step)
        warming = self._warm_left > 0
        self._warm_left -= step
        snr_db = band_db - self._floor_db

        # 4. Modulation: exponentially weighted standard deviation of band energy.
        if self._mod_mean is None:
            self._mod_mean = band_db
        delta = band_db - self._mod_mean
        self._mod_mean += self._alpha * delta
        self._mod_var = (1.0 - self._alpha) * (self._mod_var + self._alpha * delta * delta)
        modulation_db = math.sqrt(self._mod_var)

        # Steadiness: the same estimate with a short time constant, so it
        # settles soon after a step such as a hum's onset.
        if self._steady_mean is None:
            self._steady_mean = band_db
        d_steady = band_db - self._steady_mean
        self._steady_mean += self._beta * d_steady
        self._steady_var = (1.0 - self._beta) * (
            self._steady_var + self._beta * d_steady * d_steady
        )
        if math.sqrt(self._steady_var) < cfg.steady_below_db:
            self._steady_for_s += step
        else:
            self._steady_for_s = 0.0
        steady = self._steady_for_s >= cfg.max_steady_s

        # 2. Voicing over the last pitch_block samples.
        self._history = np.concatenate([self._history[HOP_SAMPLES:], hop])
        pitch = pitch_strength(
            self._history, SAMPLE_RATE, cfg.min_pitch_hz, cfg.max_pitch_hz, cfg.decimate
        )
        harmonicity: float | None
        if pitch is None:
            harmonicity, pitch_hz = None, 0.0
        else:
            harmonicity, pitch_hz = pitch

        # Probability: the weakest evidence bounds it.
        level = ramp(snr_db, *cfg.ramp_snr_db)
        peaky = ramp(0.5 - flatness, *cfg.ramp_peaky)
        voiced = ramp(harmonicity, *cfg.ramp_harmonicity) if harmonicity is not None else 0.0
        voicing = max(voiced, peaky)
        modulation = ramp(modulation_db, *cfg.ramp_modulation_db)
        p = 0.0 if (warming or steady) else min(level, voicing, modulation)

        if p >= 0.5:
            self._hold_ms = cfg.hold_ms
        else:
            self._hold_ms -= self._hop_ms

        self._samples_done += HOP_SAMPLES
        end_ms = self._samples_done * 1000 // SAMPLE_RATE
        features = SpeechFeatures(
            snr_db=float(snr_db),
            floor_db=float(self._floor_db),
            flatness=float(flatness),
            harmonicity=harmonicity,
            pitch_hz=float(pitch_hz),
            modulation_db=float(modulation_db),
        )
        return SpeechFrame(end_ms=end_ms, probability=float(p), features=features)
