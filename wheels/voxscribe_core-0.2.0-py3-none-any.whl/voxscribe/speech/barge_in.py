"""Barge-in detection with a playback reference (phase S4 of ADR 0001).

A device that speaks through its own loudspeaker while listening hears
three things on its microphone: the room, its own speech coming back as an
echo, and, sometimes, a person talking over it. `BargeInDetector` tells
them apart per microphone hop and answers one of:

    pass       no playback in progress; the hop is ordinary user audio
    suppress   playback in progress and the microphone is explained by the
               device's own echo (plus the room): drop it before ASR
    barge_in   playback in progress and a person is talking over it: the
               host stops playback and lets the audio through

Two inputs, both float32 mono, brought to 16 kHz with the S1 resampler when
they arrive at another rate:

    observe_playback(samples)   what the loudspeaker is playing, as it is
                                played (or a whole clip at once, right after
                                playback_started())
    observe_mic(samples)        what the microphone captured; returns one
                                `BargeInDecision` per completed 512-sample
                                (32 ms) hop

How a hop is judged
-------------------
1. Speech probability `p` from an S1 detector (Silero by default, any
   `SpeechDetector` accepted) on the raw microphone hop.
2. Echo correlation. The last 64 ms of microphone audio (two hops) is
   cross-correlated with the playback over lags 0 to 250 ms and normalised,
   so `rho` in 0..1 says how much of the microphone is a delayed copy of the
   playback. An echo correlates strongly (0.8 and above in a dry room, 0.4
   to 0.7 with reverberation); a different person's voice does not (the
   best of 4000 lags of two independent voices stays under about 0.3). The
   lag with the strongest correlation is locked while it is strong and
   reused when it is not.
3. Residual energy. The part of the microphone window that the playback at
   the best lag does not predict is `mic_energy * (1 - rho^2)`, the
   residual of a one-tap least-squares fit. It is compared with the room
   floor, learned as a slow-rising minimum of the residual: an echo-only hop
   leaves a residual at the floor; a person's voice leaves a residual well
   above it, however loud the echo is.
4. Echo energy estimate. During echo-only stretches (`rho` at or above
   `rho_adapt` and the residual explained) the gain of the echo path,
   `g_db = mic_db - playback_db` at the locked lag, is learned with a 0.5 s
   time constant. A hop whose energy is within `excess_max_db` of the
   expected echo energy `g_db + playback_db`, and still correlated
   (`rho >= rho_min`), is explained even when reverberation keeps the
   one-tap residual above the floor.
5. A hop is "explained by echo" when 3 or 4 says so. Explained hops feed
   probability 0 to a `SpeechActivityTracker` on the BARGE_IN preset;
   unexplained hops feed `p`. The preset therefore decides the timing:
   barge-in needs `p >= 0.7` on 4 consecutive unexplained hops (128 ms),
   and lets go after 200 ms below 0.5.

Playback silence (a pause inside the TTS clip) has no echo to explain the
microphone, so speech there is judged by the detector alone. The two
streams are assumed to run on one sample clock, playback aligned to the
microphone position at `playback_started()`; buffering between them is
what the 250 ms lag search absorbs.

Numbers (defaults in `BargeInConfig`): window 64 ms, lags 0 to 250 ms,
`rho_min` 0.35, `rho_adapt` 0.6, residual margin 10 dB above the floor,
floor rise 2 dB/s, `excess_max_db` 4 dB, playback below -70 dB (mean
square, full-scale sine is -3 dB) counts as silence. Cost: about 2 ms of
CPU per hop for the correlation (numpy, 1024 by 5024 samples) plus the
detector.

What this is not
----------------
This is detection, not acoustic echo cancellation. Nothing is subtracted
from the audio that reaches ASR; a barge-in segment still carries the echo.
A near-end voice much quieter than the echo at the microphone, or a room
whose reverberation tail outlasts 250 ms, is explained away and missed. A
full AEC (WebRTC AEC3, LocalVQE, or a multi-tap NLMS canceller on the same
reference) would remove the echo before detection and transcription, and
remains future work behind the same `EchoGuard` seam.

Logging via `voxscribe.logging_config`: verdict changes at DEBUG
(`barge_in_transition`), one `barge_in_stream_summary` at INFO per stream on
`reset()`, nothing per hop at INFO or above.
"""

from __future__ import annotations

import logging
import math
from collections.abc import Sequence
from dataclasses import dataclass
from typing import Any

import numpy as np

from ..logging_config import get_logger, log_event
from .detector import SpeechDetector, SpeechFrame
from .policy import BARGE_IN, SpeechActivityTracker, SpeechPolicy
from .resample import TARGET_RATE, Resampler

log = get_logger("voxscribe.speech.barge_in")

SAMPLE_RATE = TARGET_RATE
HOP_SAMPLES = 512
EPS = 1e-12
VERDICTS = ("pass", "suppress", "barge_in")


@dataclass(frozen=True)
class BargeInConfig:
    """Tuning of the echo explanation. Times in milliseconds or seconds as
    named, levels in dB of mean square (a full-scale sine reads -3 dB).

    max_lag_ms          lags searched between playback and microphone;
                        covers device buffering plus the acoustic path.
    window_ms           microphone analysis window; two hops by default.
    rho_min             correlation that still counts as echo-like for the
                        energy clause.
    rho_adapt           correlation strong enough to lock the lag and learn
                        the echo gain.
    residual_margin_db  residual this far above the room floor is not
                        explained by the echo.
    floor_rise_db_per_s how fast the learned floor may rise; it falls at once.
    floor_min_db        the floor never goes below this (digital silence).
    excess_max_db       microphone energy this far above the expected echo
                        energy is still explained by the energy clause.
    gain_time_s         time constant of the echo gain estimate.
    min_playback_db     playback energy below this is silence: no echo to
                        explain anything.
    max_playback_s      playback kept for alignment; older samples are
                        dropped (a clip fed at once must fit).
    """

    max_lag_ms: int = 250
    window_ms: int = 64
    rho_min: float = 0.35
    rho_adapt: float = 0.6
    residual_margin_db: float = 10.0
    floor_rise_db_per_s: float = 2.0
    floor_min_db: float = -90.0
    excess_max_db: float = 4.0
    gain_time_s: float = 0.5
    min_playback_db: float = -70.0
    max_playback_s: float = 120.0

    def __post_init__(self) -> None:
        if self.max_lag_ms <= 0 or self.window_ms <= 0:
            raise ValueError("BargeInConfig.max_lag_ms and window_ms must be positive")
        if not 0.0 <= self.rho_min <= self.rho_adapt <= 1.0:
            raise ValueError("BargeInConfig needs 0 <= rho_min <= rho_adapt <= 1")


@dataclass(frozen=True)
class BargeInDecision:
    """The verdict for one microphone hop.

    end_ms        end of the hop on the microphone timeline (ms since reset).
    verdict       "pass", "suppress" or "barge_in".
    probability   the detector's speech probability for the raw hop, 0..1.
    playback      True when playback was in progress for this hop.
    explained     True when the echo explained the microphone window.
    echo_rho      best normalised cross-correlation over the lags, 0..1.
    echo_lag_ms   lag of that correlation, milliseconds (the locked lag when
                  the hop was not correlated).
    residual_db   energy the echo did not explain, dB of mean square.
    floor_db      the learned room floor the residual was compared with.
    """

    end_ms: int
    verdict: str
    probability: float
    playback: bool
    explained: bool
    echo_rho: float
    echo_lag_ms: float
    residual_db: float
    floor_db: float


def db(mean_square: float) -> float:
    """10 log10 of a mean-square level, floored at -120 dB."""
    return max(-120.0, 10.0 * math.log10(float(mean_square) + EPS))


def summarize(decisions: Sequence[BargeInDecision]) -> dict[str, Any]:
    """Compact timeline of a decision list for tests, reports and logs.

    Returns hop and verdict counts, the first barge-in instant, and the runs
    of equal verdicts as (verdict, start_ms, end_ms) triples.
    """
    runs: list[tuple[str, int, int]] = []
    for d in decisions:
        if runs and runs[-1][0] == d.verdict:
            runs[-1] = (d.verdict, runs[-1][1], d.end_ms)
        else:
            runs.append((d.verdict, d.end_ms - HOP_SAMPLES * 1000 // SAMPLE_RATE, d.end_ms))
    counts = {v: sum(1 for d in decisions if d.verdict == v) for v in VERDICTS}
    first = next((d.end_ms for d in decisions if d.verdict == "barge_in"), None)
    playback = [d for d in decisions if d.playback]
    return {
        "hops": len(decisions),
        "seconds": round(decisions[-1].end_ms / 1000.0, 3) if decisions else 0.0,
        **counts,
        "barge_in_runs": sum(1 for r in runs if r[0] == "barge_in"),
        "first_barge_in_ms": first,
        "explained_fraction": (
            round(sum(1 for d in playback if d.explained) / len(playback), 3) if playback else None
        ),
        "mean_rho_during_playback": (
            round(float(np.mean([d.echo_rho for d in playback])), 3) if playback else None
        ),
        "runs": runs,
    }


class BargeInDetector:
    """Classifies microphone hops as pass, suppress or barge_in (see module).

    detector      an S1 `SpeechDetector` at 16 kHz, or None for the best
                  available one (`create_detector("silero")`, else the
                  heuristic).
    policy        the `SpeechPolicy` whose start and hangover timing decide
                  the barge-in; BARGE_IN by default.
    config        `BargeInConfig`.
    """

    def __init__(
        self,
        detector: SpeechDetector | None = None,
        *,
        policy: SpeechPolicy = BARGE_IN,
        config: BargeInConfig | None = None,
    ) -> None:
        if detector is None:
            detector = _default_detector()
        if detector.sample_rate != SAMPLE_RATE:
            raise ValueError(
                f"BargeInDetector needs a {SAMPLE_RATE} Hz detector, got {detector.sample_rate}"
            )
        self.detector = detector
        self.policy = policy
        self.cfg = config or BargeInConfig()
        self.tracker = SpeechActivityTracker(policy, detector=detector.name)
        self._max_lag = int(round(self.cfg.max_lag_ms * SAMPLE_RATE / 1000))
        self._window = max(HOP_SAMPLES, int(round(self.cfg.window_ms * SAMPLE_RATE / 1000)))
        self._hop_s = HOP_SAMPLES / SAMPLE_RATE
        self._gain_alpha = 1.0 - math.exp(-self._hop_s / self.cfg.gain_time_s)
        self._floor_rise = self.cfg.floor_rise_db_per_s * self._hop_s
        self._max_play = int(self.cfg.max_playback_s * SAMPLE_RATE)
        self._play_resampler: Resampler | None = None
        self._mic_resampler: Resampler | None = None
        self.reset()
        log_event(
            log,
            "barge_in_detector_created",
            level=logging.INFO,
            detector=detector.name,
            policy=policy.name,
            max_lag_ms=self.cfg.max_lag_ms,
            window_ms=self.cfg.window_ms,
            rho_min=self.cfg.rho_min,
            residual_margin_db=self.cfg.residual_margin_db,
        )

    # ---- state ----

    def reset(self) -> None:
        """Forget both streams and the learned echo path. Logs the stream
        summary at INFO when any hop was judged."""
        if getattr(self, "_hops", 0):
            log_event(log, "barge_in_stream_summary", level=logging.INFO, **self.summary())
        self.detector.reset()
        self.tracker.reset()
        if self._play_resampler is not None:
            self._play_resampler.reset()
        if self._mic_resampler is not None:
            self._mic_resampler.reset()
        self._mic_pending = np.zeros(0, dtype=np.float32)
        self._mic_window = np.zeros(self._window, dtype=np.float32)
        self._mic_pos = 0  # microphone samples consumed (hop-aligned)
        self._play = np.zeros(0, dtype=np.float32)
        self._play_offset = 0  # absolute index of self._play[0] on the shared timeline
        self._energies: np.ndarray | None = None
        self._explicit: bool | None = None
        self._lag = 0
        self._gain_db: float | None = None
        self._floor_db: float | None = None
        self._last_verdict = "pass"
        # Per-stream summary counters.
        self._hops = 0
        self._playback_hops = 0
        self._explained_hops = 0
        self._counts = dict.fromkeys(VERDICTS, 0)
        self._barge_ins = 0
        self._rho_sum = 0.0

    @property
    def playback_active(self) -> bool:
        """True while the host has said playback is in progress, or, when it
        never said, while playback audio covers the current microphone
        position."""
        if self._explicit is not None:
            return self._explicit
        return self._play_end > max(0, self._mic_pos - self._max_lag)

    @property
    def _play_end(self) -> int:
        return self._play_offset + self._play.shape[0]

    @property
    def echo_lag_ms(self) -> float:
        """The locked echo lag, milliseconds."""
        return self._lag * 1000.0 / SAMPLE_RATE

    @property
    def echo_gain_db(self) -> float | None:
        """Learned echo path gain (mic minus playback, dB), or None."""
        return self._gain_db

    @property
    def speaking(self) -> bool:
        """True while the barge-in tracker holds a person's speech open."""
        return self.tracker.speaking

    def summary(self) -> dict[str, Any]:
        """Per-stream counters for the INFO summary."""
        return {
            "detector": self.detector.name,
            "policy": self.policy.name,
            "hops": self._hops,
            "seconds_processed": round(self._mic_pos / SAMPLE_RATE, 3),
            "playback_hops": self._playback_hops,
            "explained_fraction": (
                round(self._explained_hops / self._playback_hops, 3) if self._playback_hops else 0.0
            ),
            "mean_rho_during_playback": (
                round(self._rho_sum / self._playback_hops, 3) if self._playback_hops else 0.0
            ),
            "barge_ins": self._barge_ins,
            "echo_lag_ms": round(self.echo_lag_ms, 1),
            "echo_gain_db": round(self._gain_db, 1) if self._gain_db is not None else None,
            "floor_db": round(self._floor_db, 1) if self._floor_db is not None else None,
            **{f"verdict_{k}": v for k, v in self._counts.items()},
        }

    # ---- playback side ----

    def playback_started(self) -> None:
        """The host starts an utterance: playback audio fed from now on is
        aligned to the current microphone position."""
        self._explicit = True
        self._play = np.zeros(0, dtype=np.float32)
        self._play_offset = self._mic_pos
        if self._play_resampler is not None:
            self._play_resampler.reset()

    def playback_stopped(self) -> None:
        """The host stopped or finished playback. The reference is kept so
        the echo tail of the last 250 ms is still explained."""
        self._explicit = False

    def observe_playback(self, samples: Any, sample_rate: int = SAMPLE_RATE) -> None:
        """Append playback audio (float32 mono at `sample_rate`)."""
        x = np.asarray(samples, dtype=np.float32).reshape(-1)
        if sample_rate != SAMPLE_RATE:
            if self._play_resampler is None or self._play_resampler.in_rate != sample_rate:
                self._play_resampler = Resampler(sample_rate, SAMPLE_RATE)
            x = self._play_resampler.process(x)
        if x.shape[0] == 0:
            return
        if self._explicit is None and self._play_end <= self._mic_pos - self._max_lag:
            # Playback resumes after a gap and the host never said when: align
            # it to the microphone position, as playback_started() would.
            self._play = np.zeros(0, dtype=np.float32)
            self._play_offset = self._mic_pos
        self._play = np.concatenate([self._play, x])
        if self._play.shape[0] > self._max_play:
            drop = self._play.shape[0] - self._max_play
            self._play = self._play[drop:]
            self._play_offset += drop

    # ---- microphone side ----

    def observe_mic(self, samples: Any, sample_rate: int = SAMPLE_RATE) -> list[BargeInDecision]:
        """Consume microphone audio (float32 mono at `sample_rate`); one
        decision per completed 32 ms hop, in order. A partial hop waits."""
        x = np.asarray(samples, dtype=np.float32).reshape(-1)
        if sample_rate != SAMPLE_RATE:
            if self._mic_resampler is None or self._mic_resampler.in_rate != sample_rate:
                self._mic_resampler = Resampler(sample_rate, SAMPLE_RATE)
            x = self._mic_resampler.process(x)
        if self._mic_pending.shape[0]:
            x = np.concatenate([self._mic_pending, x])
        n_hops = x.shape[0] // HOP_SAMPLES
        if n_hops == 0:
            self._mic_pending = x
            return []
        used = n_hops * HOP_SAMPLES
        hops = x[:used].reshape(n_hops, HOP_SAMPLES)
        self._mic_pending = x[used:].copy()
        return [self._hop(hops[i]) for i in range(n_hops)]

    def _hop(self, hop: np.ndarray) -> BargeInDecision:
        cfg = self.cfg
        self._mic_window = np.concatenate([self._mic_window[HOP_SAMPLES:], hop])
        self._mic_pos += HOP_SAMPLES
        end_ms = self._mic_pos * 1000 // SAMPLE_RATE
        playback = self.playback_active

        mic = self._mic_window.astype(np.float64)
        mic_e = float(np.dot(mic, mic)) / self._window
        rho, lag, play_e_lag = 0.0, self._lag, 0.0
        residual_hop = hop
        if playback:
            rho, lag, play_e_lag, echo = self._correlate(mic, mic_e)
            if echo is not None:
                # The detector hears what the one-tap echo estimate leaves
                # over, so "speech likely" is about the near end, not about
                # the device's own speech. The audio that reaches ASR is
                # never touched.
                residual_hop = (hop.astype(np.float64) - echo[-HOP_SAMPLES:]).astype(np.float32)
        frames = self.detector.process(residual_hop)
        p = float(frames[-1].probability) if frames else 0.0
        residual_e = mic_e * max(0.0, 1.0 - rho * rho)
        residual_db = db(residual_e)
        self._learn_floor(residual_db)
        floor_db = self._floor_db if self._floor_db is not None else cfg.floor_min_db

        explained = False
        if playback:
            by_residual = residual_db <= floor_db + cfg.residual_margin_db
            if rho >= cfg.rho_adapt and by_residual:
                # An echo-only stretch: lock the lag and learn the path gain.
                self._lag = lag
                play_e_lag = self._play_energy_at(lag)
                if db(play_e_lag) > cfg.min_playback_db:
                    sample = db(mic_e) - db(play_e_lag)
                    if self._gain_db is None:
                        self._gain_db = sample
                    else:
                        self._gain_db += self._gain_alpha * (sample - self._gain_db)
            by_energy = (
                self._gain_db is not None
                and rho >= cfg.rho_min
                and db(play_e_lag) > cfg.min_playback_db
                and db(mic_e) - (self._gain_db + db(play_e_lag)) <= cfg.excess_max_db
            )
            explained = by_residual or by_energy

        # The preset decides the timing: unexplained speech-like hops must
        # sustain for start_ms before a barge-in, and let go after hangover_ms.
        p_eff = 0.0 if (explained or not playback) else p
        self.tracker.process(SpeechFrame(end_ms=end_ms, probability=p_eff))
        if not playback:
            verdict = "pass"
        elif self.tracker.speaking:
            verdict = "barge_in"
        else:
            verdict = "suppress"

        self._hops += 1
        self._counts[verdict] += 1
        if playback:
            self._playback_hops += 1
            self._rho_sum += rho
            if explained:
                self._explained_hops += 1
        if verdict != self._last_verdict:
            if verdict == "barge_in":
                self._barge_ins += 1
            if log.isEnabledFor(logging.DEBUG):
                log_event(
                    log,
                    "barge_in_transition",
                    level=logging.DEBUG,
                    verdict=verdict,
                    previous=self._last_verdict,
                    end_ms=end_ms,
                    probability=round(p, 3),
                    echo_rho=round(rho, 3),
                    echo_lag_ms=round(lag * 1000.0 / SAMPLE_RATE, 1),
                    residual_db=round(residual_db, 1),
                    floor_db=round(floor_db, 1),
                )
            self._last_verdict = verdict
        return BargeInDecision(
            end_ms=end_ms,
            verdict=verdict,
            probability=p,
            playback=playback,
            explained=explained,
            echo_rho=rho,
            echo_lag_ms=lag * 1000.0 / SAMPLE_RATE,
            residual_db=residual_db,
            floor_db=floor_db,
        )

    def _correlate(
        self, mic: np.ndarray, mic_e: float
    ) -> tuple[float, int, float, np.ndarray | None]:
        """Best normalised cross-correlation of the microphone window against
        the playback over lags 0..max_lag.

        Returns (rho, lag_samples, playback mean square at the locked lag,
        echo estimate): the estimate is the playback window at the best lag
        scaled by its least-squares gain, the same length as the microphone
        window, or None when the playback is silent.
        """
        W, L = self._window, self._max_lag
        start = self._mic_pos - W - L  # absolute index of the first reference sample
        ref = np.zeros(W + L, dtype=np.float64)
        lo = max(start, self._play_offset)
        hi = min(self._mic_pos, self._play_end)
        if hi > lo:
            ref[lo - start : hi - start] = self._play[
                lo - self._play_offset : hi - self._play_offset
            ]
        cs = np.concatenate([[0.0], np.cumsum(ref * ref)])
        energies = (cs[W:] - cs[:-W]) / W  # mean square of ref[k:k+W], k = 0..L
        self._energies = energies
        locked_e = self._play_energy_at(self._lag)
        silent = 10 ** (self.cfg.min_playback_db / 10.0)
        if mic_e <= EPS or float(energies.max()) <= silent:
            return 0.0, self._lag, locked_e, None
        c = np.correlate(ref, mic, mode="valid")  # c[k] = sum ref[k+n] mic[n], lag = L - k
        r = np.abs(c) / (np.sqrt(energies * mic_e) * W + EPS)
        r = np.where(energies > silent, r, 0.0)
        k = int(np.argmax(r))
        rho = float(min(1.0, r[k]))
        echo: np.ndarray | None = None
        if energies[k] > silent:
            gain = float(c[k]) / (float(energies[k]) * W)  # least-squares one-tap gain
            echo = gain * ref[k : k + W]
        return rho, L - k, locked_e, echo

    def _play_energy_at(self, lag: int) -> float:
        """Mean square of the playback window at `lag` samples from the last
        correlation, 0.0 outside the searched range."""
        energies = getattr(self, "_energies", None)
        if energies is None or not 0 <= lag <= self._max_lag:
            return 0.0
        return float(energies[self._max_lag - lag])

    def _learn_floor(self, residual_db: float) -> None:
        cfg = self.cfg
        value = max(cfg.floor_min_db, residual_db)
        if self._floor_db is None or value < self._floor_db:
            self._floor_db = value
        else:
            self._floor_db = min(value, self._floor_db + self._floor_rise)


def _default_detector() -> SpeechDetector:
    from . import create_detector
    from .silero import SileroDetector

    if SileroDetector.is_available():
        return create_detector("silero")
    return create_detector("heuristic")
