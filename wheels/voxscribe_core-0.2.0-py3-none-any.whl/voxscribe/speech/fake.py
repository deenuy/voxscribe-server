"""A scripted detector for tests: fakes are first-class (ADR 0001).

`FakeDetector` consumes audio like a real detector (it buffers partial hops
and advances the timeline) but takes its probabilities from a script, so a
test can drive the policy layer through any sequence of evidence without
synthesising audio that happens to produce it.
"""

from __future__ import annotations

from collections.abc import Callable, Sequence

import numpy as np

from .detector import SpeechFeatures, SpeechFrame


class FakeDetector:
    """Emits scripted probabilities, one per hop of consumed audio.

      script       either a sequence of probabilities, used in order (the
                   last value repeats once the sequence is exhausted, or
                   `after` is used when given), or a function of time in
                   seconds (the hop's end time) returning a probability.
      features     optional sequence or function, same shapes as `script`,
                   providing `SpeechFeatures` per hop (for steady-close tests).
                   None leaves `SpeechFrame.features` empty.
      sample_rate  Hz, default 16000. hop_samples default 512.
      after        probability once a sequence script runs out; None repeats
                   the last value (0.0 for an empty script).

    The audio content is ignored; only its length matters.
    """

    name = "fake"

    def __init__(
        self,
        script: Sequence[float] | Callable[[float], float] = (),
        *,
        features: Sequence[SpeechFeatures | None]
        | Callable[[float], SpeechFeatures | None]
        | None = None,
        sample_rate: int = 16000,
        hop_samples: int = 512,
        after: float | None = None,
    ) -> None:
        self.sample_rate = int(sample_rate)
        self.hop_samples = int(hop_samples)
        self._script = script
        self._features = features
        self._after = after
        self.reset()

    def reset(self) -> None:
        """Forget the partial hop and restart the timeline and the script."""
        self._pending = 0
        self._samples_done = 0
        self._index = 0

    def _probability(self, index: int, end_s: float) -> float:
        if callable(self._script):
            return float(self._script(end_s))
        seq = self._script
        if index < len(seq):
            return float(seq[index])
        if self._after is not None:
            return float(self._after)
        return float(seq[-1]) if seq else 0.0

    def _feature(self, index: int, end_s: float) -> SpeechFeatures | None:
        if self._features is None:
            return None
        if callable(self._features):
            return self._features(end_s)
        seq = self._features
        if index < len(seq):
            return seq[index]
        return seq[-1] if seq else None

    def process(self, samples: np.ndarray) -> list[SpeechFrame]:
        """Consume samples (any length) and return one frame per completed hop."""
        n = int(np.asarray(samples).shape[0]) if samples is not None else 0
        self._pending += n
        frames: list[SpeechFrame] = []
        while self._pending >= self.hop_samples:
            self._pending -= self.hop_samples
            self._samples_done += self.hop_samples
            end_ms = self._samples_done * 1000 // self.sample_rate
            end_s = self._samples_done / self.sample_rate
            frames.append(
                SpeechFrame(
                    end_ms=end_ms,
                    probability=self._probability(self._index, end_s),
                    features=self._feature(self._index, end_s),
                )
            )
            self._index += 1
        return frames
