"""Turn-taking driven by speech activity events (phase S4 of ADR 0001).

The turn-taking policy (`voxscribe.turn_taking`, with the pause bands of
`voxscribe.silence_policy`) was written for ASR chunks: the gap before a
chunk told it how long the speaker had paused. This adapter feeds the same
policy, unchanged, from the `SpeechEvent` timeline of a
`SpeechActivityTracker` instead:

    speech "ended"   the pause starts at `ended.at_ms`
    speech "started" the pause is over; its length is `started.at_ms` minus
                     the pause start, classified into a pause band and
                     handed to `turn_taking.on_chunk`
    tick(now_ms)     the host asks what to do about a pause still in
                     progress; the length so far goes to
                     `turn_taking.on_silence`

The policy's public API is untouched: `on_chunk` and `on_silence` keep their
signatures and their tests, and a product that still measures pauses from
ASR chunks keeps working. What changes is where the milliseconds come from:
the detector sees the pause as it happens, so a hold or a close no longer
waits for the next ASR result.

Units: every time is integer milliseconds on the stream timeline that the
detector and tracker use (`SpeechFrame.end_ms`, `SpeechEvent.at_ms`). The
adapter never reads audio, never reads a clock and never decides what the
text means: completeness comes from `silence_policy.assess_completeness`
on the text the host supplies with `update_text()`, or from a callable the
host injects (a product may route it through the audio lane).

Logging goes through `voxscribe.logging_config`: every decision at DEBUG
(`turn_adapter_decision`), one `turn_adapter_summary` at INFO per stream on
`reset()`, nothing per frame at INFO or above.

Limits: the adapter trusts the event timeline. An `ended` whose `at_ms`
precedes the last `started` (a tracker reset without an adapter reset) is
clamped to a zero-length pause; a `started` that arrives while the adapter
still believes speech is in progress (a missed `ended`) is treated as a
zero-length pause too and never raises. The pause the tracker reports is
measured from the end of its hangover, so `silence_offset_ms` (the driver
sets it to the policy's `hangover_ms`) adds the hangover back and the pause
bands see the real pause.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from ..logging_config import get_logger, log_event
from ..silence_policy import Completeness, PauseBand, PauseBandConfig, assess_completeness, classify
from ..turn_taking import ChunkAction, SilenceAction, TurnTakingConfig, on_chunk, on_silence
from .detector import SpeechDetector, SpeechFrame
from .events import SpeechEvent
from .policy import TURN, SpeechActivityTracker, SpeechPolicy

log = get_logger("voxscribe.speech.turns")

CompletenessProvider = Callable[[str], Completeness]


@dataclass(frozen=True)
class TurnDecision:
    """One turn-taking decision produced by the adapter.

    source        "speech" when a `started` event ended a pause (the action
                  is a `ChunkAction`), "silence" when a `tick()` judged a
                  pause still in progress (a `SilenceAction`), "final" when
                  the host finalized the stream.
    action        the policy's verdict, exactly as `turn_taking` returns it.
    at_ms         the stream instant the decision applies to: the
                  `started.at_ms`, the tick's `now_ms`, or the finalize time.
    silence_ms    the pause the decision was based on, milliseconds, never
                  negative.
    band          the pause band `silence_policy.classify` assigned to it.
    turn_open     whether a turn is open after the decision was applied.
    completeness  the completeness verdict the policy saw.
    """

    source: str
    action: ChunkAction | SilenceAction
    at_ms: int
    silence_ms: int
    band: PauseBand
    turn_open: bool
    completeness: Completeness

    @property
    def closes_turn(self) -> bool:
        """True when this decision closed a turn (a new one may have opened)."""
        return self.action in (
            ChunkAction.CLOSE_THEN_OPEN,
            SilenceAction.CLOSE,
            SilenceAction.CLOSE_INCOMPLETE,
        )

    def to_dict(self) -> dict[str, Any]:
        """Plain dict for logs and reports (no text, only the verdict)."""
        return {
            "source": self.source,
            "action": self.action.value,
            "at_ms": self.at_ms,
            "silence_ms": self.silence_ms,
            "band": self.band.value,
            "turn_open": self.turn_open,
            "complete": self.completeness.complete,
            "confidence": round(self.completeness.confidence, 3),
            "reason": self.completeness.reason,
        }


class SpeechTurnAdapter:
    """Drives `turn_taking` from `SpeechEvent`s and host ticks.

    Construction:
      pause_config       pause band edges (`PauseBandConfig`); defaults are
                         the conversational dictation bands (400 / 1500 /
                         6000 ms).
      turn_config        `TurnTakingConfig`; the default hold cap is 30 s.
      completeness       callable from the current turn text to a
                         `Completeness`; defaults to
                         `silence_policy.assess_completeness`.
      silence_offset_ms  added to every measured pause, so a pause reported
                         from the end of a tracker hangover is measured from
                         the last speech frame instead. 0 by default.

    Feed every event of one stream to `observe()`, in order, and call
    `tick(now_ms)` as often as the host wants silence judged (every frame is
    fine: a verdict is returned only when it changes within one pause).
    `update_text()` keeps the adapter's view of the open turn's text current;
    a close clears it because the next speech starts a new turn.
    """

    def __init__(
        self,
        *,
        pause_config: PauseBandConfig | None = None,
        turn_config: TurnTakingConfig | None = None,
        completeness: CompletenessProvider | None = None,
        silence_offset_ms: int = 0,
    ) -> None:
        if silence_offset_ms < 0:
            raise ValueError("SpeechTurnAdapter.silence_offset_ms must not be negative")
        self.pause_config = pause_config or PauseBandConfig()
        self.turn_config = turn_config or TurnTakingConfig()
        self._completeness = completeness or assess_completeness
        self.silence_offset_ms = int(silence_offset_ms)
        self._init_state()

    def _init_state(self) -> None:
        self._turn_open = False
        self._speaking = False
        self._pause_start_ms: int | None = None
        self._last_silence_action: SilenceAction = SilenceAction.NONE
        self._text = ""
        self._last_at_ms = 0
        # Per-stream summary counters.
        self._events = 0
        self._decisions = 0
        self._turns_opened = 0
        self._turns_closed = 0
        self._holds = 0
        self._longest_pause_ms = 0

    # ---- state ----

    @property
    def turn_open(self) -> bool:
        """True while a turn is open (speech or a pause that has not closed it)."""
        return self._turn_open

    @property
    def speaking(self) -> bool:
        """True between a `started` and the following `ended`."""
        return self._speaking

    @property
    def text(self) -> str:
        """The open turn's text as last supplied by `update_text()`."""
        return self._text

    def update_text(self, text: str) -> None:
        """Replace the adapter's view of the open turn's text (the host's
        provisional plus stable text of the current turn)."""
        self._text = text or ""

    def silence_ms(self, now_ms: int) -> int:
        """Pause length at `now_ms`, milliseconds; 0 while speaking or before
        the first `ended`."""
        if self._speaking or self._pause_start_ms is None:
            return 0
        return max(0, int(now_ms) - self._pause_start_ms) + self.silence_offset_ms

    def summary(self) -> dict[str, Any]:
        """Per-stream counters for the INFO summary."""
        return {
            "events": self._events,
            "decisions": self._decisions,
            "turns_opened": self._turns_opened,
            "turns_closed": self._turns_closed,
            "holds": self._holds,
            "longest_pause_ms": self._longest_pause_ms,
            "seconds_processed": round(self._last_at_ms / 1000.0, 3),
            "turn_open": self._turn_open,
        }

    def reset(self) -> None:
        """Forget the stream. Logs the summary at INFO when anything was seen."""
        if self._events or self._decisions:
            log_event(log, "turn_adapter_summary", level=logging.INFO, **self.summary())
        self._init_state()

    # ---- inputs ----

    def observe(self, event: SpeechEvent) -> TurnDecision | None:
        """Consume one speech event.

        "ended" starts a pause and returns None. "started" ends the pause,
        runs `turn_taking.on_chunk` on its length and returns the decision.
        """
        self._events += 1
        at_ms = int(event.at_ms)
        self._last_at_ms = max(self._last_at_ms, at_ms)
        if event.kind == "ended":
            if self._speaking or self._pause_start_ms is None:
                self._pause_start_ms = at_ms
            self._speaking = False
            self._last_silence_action = SilenceAction.NONE
            return None

        # "started": the pause is over.
        if self._speaking:
            gap_ms = 0  # a missed "ended": nothing to measure
        else:
            gap_ms = self.silence_ms(at_ms) if self._pause_start_ms is not None else 0
        self._speaking = True
        self._pause_start_ms = None
        self._last_silence_action = SilenceAction.NONE
        self._longest_pause_ms = max(self._longest_pause_ms, gap_ms)

        band = classify(gap_ms, self.pause_config)
        completeness = self._completeness(self._text)
        action = on_chunk(self._turn_open, band, completeness, self.turn_config)
        if action is ChunkAction.OPEN_NEW:
            self._turn_open = True
            self._turns_opened += 1
        elif action is ChunkAction.CLOSE_THEN_OPEN:
            self._turns_closed += 1
            self._turns_opened += 1
            self._text = ""
            self._turn_open = True
        elif action in (ChunkAction.HOLD_THEN_EXTEND, ChunkAction.RESUME_THEN_EXTEND):
            self._holds += 1
        return self._decide("speech", action, at_ms, gap_ms, band, completeness)

    def tick(self, now_ms: int) -> TurnDecision | None:
        """Judge the pause in progress at `now_ms`.

        Returns a decision only when the policy's verdict changes within the
        current pause (NONE, then HOLD or SOFT_COMMIT, then a close), so the
        host may call it on every frame. Returns None while speaking, with no
        open turn, or when nothing changed.
        """
        now_ms = int(now_ms)
        self._last_at_ms = max(self._last_at_ms, now_ms)
        if self._speaking or not self._turn_open or self._pause_start_ms is None:
            return None
        silence = self.silence_ms(now_ms)
        self._longest_pause_ms = max(self._longest_pause_ms, silence)
        band = classify(silence, self.pause_config)
        completeness = self._completeness(self._text)
        action = on_silence(band, completeness, float(silence), self.turn_config)
        if action is SilenceAction.NONE or action is self._last_silence_action:
            return None
        self._last_silence_action = action
        if action in (SilenceAction.CLOSE, SilenceAction.CLOSE_INCOMPLETE):
            self._turn_open = False
            self._turns_closed += 1
            self._text = ""
        elif action is SilenceAction.HOLD:
            self._holds += 1
        return self._decide("silence", action, now_ms, silence, band, completeness)

    def finalize(self, now_ms: int) -> TurnDecision | None:
        """The host ends the stream: an open turn closes regardless of the
        pause, as `SilenceAction.CLOSE` (complete text) or
        `CLOSE_INCOMPLETE` (incomplete text). None when no turn is open."""
        now_ms = int(now_ms)
        self._last_at_ms = max(self._last_at_ms, now_ms)
        if not self._turn_open:
            return None
        silence = self.silence_ms(now_ms)
        band = classify(silence, self.pause_config)
        completeness = self._completeness(self._text)
        action = SilenceAction.CLOSE if completeness.complete else SilenceAction.CLOSE_INCOMPLETE
        self._turn_open = False
        self._speaking = False
        self._pause_start_ms = None
        self._turns_closed += 1
        self._text = ""
        return self._decide("final", action, now_ms, silence, band, completeness)

    def _decide(
        self,
        source: str,
        action: ChunkAction | SilenceAction,
        at_ms: int,
        silence_ms: int,
        band: PauseBand,
        completeness: Completeness,
    ) -> TurnDecision:
        self._decisions += 1
        decision = TurnDecision(
            source=source,
            action=action,
            at_ms=at_ms,
            silence_ms=silence_ms,
            band=band,
            turn_open=self._turn_open,
            completeness=completeness,
        )
        if log.isEnabledFor(logging.DEBUG):
            log_event(log, "turn_adapter_decision", level=logging.DEBUG, **decision.to_dict())
        return decision


class SpeechTurnDriver:
    """Frames in, turn decisions out: a `SpeechActivityTracker` on the TURN
    preset feeding a `SpeechTurnAdapter`, with a tick on every silent frame.

    `process(frame)` returns the decisions the frame caused (at most one
    from the event, at most one from the tick), `feed(frames)` collects
    them, and `process_audio(samples)` runs a detector first. The pause is
    measured from the last speech frame: the driver sets the adapter's
    `silence_offset_ms` to the policy's `hangover_ms`.
    """

    def __init__(
        self,
        *,
        policy: SpeechPolicy = TURN,
        detector: SpeechDetector | None = None,
        detector_name: str = "unknown",
        **adapter_options: Any,
    ) -> None:
        self.policy = policy
        self.detector = detector
        name = detector.name if detector is not None else detector_name
        self.tracker = SpeechActivityTracker(policy, detector=name)
        adapter_options.setdefault("silence_offset_ms", policy.hangover_ms)
        self.adapter = SpeechTurnAdapter(**adapter_options)

    def process(self, frame: SpeechFrame) -> list[TurnDecision]:
        """Advance by one frame; return the decisions it caused, in order."""
        out: list[TurnDecision] = []
        event = self.tracker.process(frame)
        if event is not None:
            decision = self.adapter.observe(event)
            if decision is not None:
                out.append(decision)
        if not self.tracker.speaking:
            decision = self.adapter.tick(frame.end_ms)
            if decision is not None:
                out.append(decision)
        return out

    def feed(self, frames) -> list[TurnDecision]:
        """Process many frames and collect the decisions."""
        out: list[TurnDecision] = []
        for frame in frames:
            out.extend(self.process(frame))
        return out

    def process_audio(self, samples) -> list[TurnDecision]:
        """Run the detector on `samples` (float32 mono at its rate), then the
        frames. Raises ValueError when no detector was given."""
        if self.detector is None:
            raise ValueError("SpeechTurnDriver.process_audio needs a detector")
        return self.feed(self.detector.process(samples))

    def reset(self) -> None:
        """Reset detector, tracker and adapter (each logs its own summary)."""
        if self.detector is not None:
            self.detector.reset()
        self.tracker.reset()
        self.adapter.reset()
