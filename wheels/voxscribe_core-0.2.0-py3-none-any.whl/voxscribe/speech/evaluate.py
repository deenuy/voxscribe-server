"""Evaluate a detector and a policy against labelled audio.

Runs over the packaged golden vectors (voxscribe/speech/vectors) or over one
WAV with a labels file, and prints JSON with, per item and overall:

  frame precision and recall    tracker "speaking" state per frame against
                                the labels (speech is the positive class;
                                frames outside any labelled region are
                                ignored)
  onset delay                   per speech region, ms from the region start
                                to the first frame the tracker is speaking;
                                null when it never speaks inside the region
  open ms per minute of         "speaking" frames whose centre falls in a
  nonspeech                     nonspeech region, normalised
  starts in nonspeech           "started" events decided inside nonspeech
  missed speech ms              labelled speech not covered by any segment
                                (started.at_ms to ended.at_ms, pre-roll and
                                hangover included)
  coverage per speech region    covered ms / region ms, by segments
  cpu seconds per audio second  process_time of detector plus tracker

and a conformance verdict against the `required_outcomes` in vectors.json
(docs/SPEECH-ACTIVITY.md). ADR 0001, invariant 4: run this before a default
changes.

    voxscribe speech-eval --detector silero --policy all
    voxscribe speech-eval --detector heuristic --policy display --json out.json
    voxscribe speech-eval --wav take.wav --labels take.json --policy segmentation
    python -m voxscribe.speech.evaluate --help

A labels file for `--wav` is a JSON object with "regions" (list of
{start_ms, end_ms, label}) and optionally "required_outcomes" and
"overrides", in the same shape as one item of vectors.json.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from importlib import resources
from pathlib import Path
from typing import Any

from . import SPEC_VERSION, available_detectors, create_detector
from .detector import SpeechDetector, SpeechFrame
from .events import SpeechEvent
from .policy import PRESETS, SpeechActivityTracker, SpeechPolicy, preset

VECTORS_PACKAGE = "voxscribe.speech.vectors"


# ---- vectors ----------------------------------------------------------------


def vectors_dir() -> Path:
    """Directory of the packaged golden vectors."""
    return Path(str(resources.files(VECTORS_PACKAGE.rsplit(".", 1)[0]) / "vectors"))


def load_manifest(directory: Path | None = None) -> dict[str, Any]:
    """Read vectors.json (packaged by default) and check its spec version."""
    base = directory or vectors_dir()
    manifest = json.loads((base / "vectors.json").read_text())
    if manifest.get("spec_version") != SPEC_VERSION:
        raise ValueError(
            f"vectors.json spec_version {manifest.get('spec_version')} does not match "
            f"the package SPEC_VERSION {SPEC_VERSION}"
        )
    manifest["_dir"] = str(base)
    return manifest


# ---- running ------------------------------------------------------------------


def run_item(
    samples: Any,
    sample_rate: int,
    detector: SpeechDetector,
    policy: SpeechPolicy,
    *,
    chunk: int = 4096,
) -> dict[str, Any]:
    """Feed one signal through detector and tracker in `chunk`-sample pieces.

    Returns frames, the open state after each frame, events with their
    decision times, and the CPU seconds spent.
    """
    import numpy as np

    from .resample import resample

    x = np.asarray(samples, dtype=np.float32).reshape(-1)
    if sample_rate != detector.sample_rate:
        x = resample(x, sample_rate, detector.sample_rate)
    detector.reset()
    tracker = SpeechActivityTracker(policy, detector=detector.name)
    frames: list[SpeechFrame] = []
    open_after: list[bool] = []
    events: list[tuple[SpeechEvent, int]] = []
    cpu0 = time.process_time()
    for start in range(0, x.shape[0], chunk):
        for frame in detector.process(x[start : start + chunk]):
            event = tracker.process(frame)
            frames.append(frame)
            open_after.append(tracker.speaking)
            if event is not None:
                events.append((event, frame.end_ms))
    cpu = time.process_time() - cpu0
    summary = tracker.summary()
    tracker.reset()
    return {
        "frames": frames,
        "open": open_after,
        "events": events,
        "cpu_seconds": cpu,
        "audio_seconds": x.shape[0] / detector.sample_rate,
        "summary": summary,
    }


def segments_from_events(
    events: list[tuple[SpeechEvent, int]], end_of_stream_ms: int
) -> list[tuple[int, int]]:
    """[started.at_ms, ended.at_ms) pairs; an open segment ends at the stream end."""
    out: list[tuple[int, int]] = []
    start: int | None = None
    for event, _decided in events:
        if event.kind == "started":
            start = event.at_ms
        elif start is not None:
            out.append((start, max(start, event.at_ms)))
            start = None
    if start is not None:
        out.append((start, end_of_stream_ms))
    return out


def _overlap_ms(a0: int, a1: int, b0: int, b1: int) -> int:
    return max(0, min(a1, b1) - max(a0, b0))


# ---- scoring ------------------------------------------------------------------


def score_item(run: dict[str, Any], regions: list[dict[str, Any]], hop_ms: int) -> dict[str, Any]:
    """Compare one run with its labelled regions. See the module docstring."""
    frames: list[SpeechFrame] = run["frames"]
    open_after: list[bool] = run["open"]
    events: list[tuple[SpeechEvent, int]] = run["events"]
    end_ms = frames[-1].end_ms if frames else 0
    segments = segments_from_events(events, end_ms)

    def label_at(t_ms: float) -> str | None:
        for r in regions:
            if r["start_ms"] <= t_ms < r["end_ms"]:
                return r["label"]
        return None

    tp = fp = fn = tn = 0
    open_in_nonspeech_ms = 0
    nonspeech_ms = sum(r["end_ms"] - r["start_ms"] for r in regions if r["label"] == "nonspeech")
    speech_ms = sum(r["end_ms"] - r["start_ms"] for r in regions if r["label"] == "speech")
    for frame, is_open in zip(frames, open_after, strict=True):
        centre = frame.end_ms - hop_ms / 2.0
        label = label_at(centre)
        if label is None:
            continue
        if label == "speech":
            if is_open:
                tp += 1
            else:
                fn += 1
        else:
            if is_open:
                fp += 1
                open_in_nonspeech_ms += hop_ms
            else:
                tn += 1

    starts_in_nonspeech = 0
    for event, decided_ms in events:
        if event.kind == "started" and label_at(decided_ms - hop_ms / 2.0) == "nonspeech":
            starts_in_nonspeech += 1

    region_reports: list[dict[str, Any]] = []
    missed_ms = 0
    missed_regions = 0
    for r in regions:
        if r["label"] != "speech":
            continue
        length = r["end_ms"] - r["start_ms"]
        covered = sum(_overlap_ms(s0, s1, r["start_ms"], r["end_ms"]) for s0, s1 in segments)
        covered = min(length, covered)
        onset: int | None = None
        inside = 0
        total = 0
        for frame, is_open in zip(frames, open_after, strict=True):
            centre = frame.end_ms - hop_ms / 2.0
            if r["start_ms"] <= centre < r["end_ms"]:
                total += 1
                if is_open:
                    inside += 1
                    if onset is None:
                        onset = frame.end_ms - r["start_ms"]
        if covered == 0:
            missed_regions += 1
        missed_ms += length - covered
        region_reports.append(
            {
                "start_ms": r["start_ms"],
                "end_ms": r["end_ms"],
                "onset_delay_ms": onset,
                "open_fraction": round(inside / total, 4) if total else 0.0,
                "coverage": round(covered / length, 4) if length else 0.0,
            }
        )

    precision = tp / (tp + fp) if (tp + fp) else None
    recall = tp / (tp + fn) if (tp + fn) else None
    return {
        "frames": len(frames),
        "precision": round(precision, 4) if precision is not None else None,
        "recall": round(recall, 4) if recall is not None else None,
        "tp": tp,
        "fp": fp,
        "fn": fn,
        "tn": tn,
        "open_ms_in_nonspeech": open_in_nonspeech_ms,
        "nonspeech_ms": nonspeech_ms,
        "open_ms_per_minute_nonspeech": (
            round(open_in_nonspeech_ms * 60000.0 / nonspeech_ms, 1) if nonspeech_ms else None
        ),
        "starts_in_nonspeech": starts_in_nonspeech,
        "speech_ms": speech_ms,
        "missed_speech_ms": missed_ms,
        "missed_speech_regions": missed_regions,
        "speech_regions": region_reports,
        "segments": [{"start_ms": s0, "end_ms": s1} for s0, s1 in segments],
        "events": [dict(e.to_contract_dict(), decided_ms=d) for e, d in events],
        "cpu_seconds": round(run["cpu_seconds"], 4),
        "audio_seconds": round(run["audio_seconds"], 3),
        "cpu_per_audio_second": (
            round(run["cpu_seconds"] / run["audio_seconds"], 5) if run["audio_seconds"] else None
        ),
        "mean_probability": run["summary"]["mean_probability"],
    }


def check_outcomes(score: dict[str, Any], required: dict[str, Any]) -> list[str]:
    """Names of the required outcomes the score violates (empty means pass)."""
    failures: list[str] = []
    limit = required.get("max_open_ms_in_nonspeech")
    if limit is not None and score["open_ms_in_nonspeech"] > limit:
        failures.append(f"open_ms_in_nonspeech {score['open_ms_in_nonspeech']} > {limit}")
    limit = required.get("max_starts_in_nonspeech")
    if limit is not None and score["starts_in_nonspeech"] > limit:
        failures.append(f"starts_in_nonspeech {score['starts_in_nonspeech']} > {limit}")
    limit = required.get("min_open_fraction_in_speech")
    if limit is not None:
        for r in score["speech_regions"]:
            if r["open_fraction"] < limit:
                failures.append(
                    f"open_fraction {r['open_fraction']} < {limit} in region {r['start_ms']}"
                )
    limit = required.get("max_onset_delay_ms")
    if limit is not None:
        for r in score["speech_regions"]:
            if r["onset_delay_ms"] is None or r["onset_delay_ms"] > limit:
                failures.append(
                    f"onset_delay_ms {r['onset_delay_ms']} > {limit} in region {r['start_ms']}"
                )
    limit = required.get("min_coverage_per_speech_region")
    if limit is not None:
        for r in score["speech_regions"]:
            if r["coverage"] < limit:
                failures.append(f"coverage {r['coverage']} < {limit} in region {r['start_ms']}")
    limit = required.get("max_missed_speech_regions")
    if limit is not None and score["missed_speech_regions"] > limit:
        failures.append(f"missed_speech_regions {score['missed_speech_regions']} > {limit}")
    return failures


def required_for(
    manifest: dict[str, Any], item: dict[str, Any], policy_name: str
) -> dict[str, Any]:
    """Required outcomes for one item and policy: the class defaults with the
    item's overrides applied. An override of null removes that requirement."""
    base = dict(manifest.get("required_outcomes", {}).get(policy_name, {}))
    for key, value in item.get("overrides", {}).get(policy_name, {}).items():
        if value is None:
            base.pop(key, None)
        else:
            base[key] = value
    return base


# ---- drivers -----------------------------------------------------------------


def evaluate_vectors(
    detector: SpeechDetector,
    policy: SpeechPolicy,
    manifest: dict[str, Any] | None = None,
    *,
    chunk: int = 4096,
    item_ids: list[str] | None = None,
) -> dict[str, Any]:
    """Run every item of the manifest (packaged vectors by default).

    Returns {"detector", "policy", "items": [...], "overall": {...}, "pass"}.
    """
    from .wav import read_wav

    manifest = manifest or load_manifest()
    base = Path(manifest["_dir"])
    hop_ms = detector.hop_samples * 1000 // detector.sample_rate
    items_out: list[dict[str, Any]] = []
    for item in manifest["items"]:
        if item_ids and item["id"] not in item_ids:
            continue
        samples, rate = read_wav(base / item["file"])
        run = run_item(samples, rate, detector, policy, chunk=chunk)
        score = score_item(run, item["regions"], hop_ms)
        required = required_for(manifest, item, policy.name.split("+")[0])
        failures = check_outcomes(score, required)
        items_out.append(
            {
                "id": item["id"],
                "category": item["category"],
                "required": required,
                "failures": failures,
                "pass": not failures,
                **score,
            }
        )
    return {
        "spec_version": manifest["spec_version"],
        "detector": detector.name,
        "policy": policy.to_dict(),
        "chunk_samples": chunk,
        "items": items_out,
        "overall": overall(items_out),
        "pass": all(i["pass"] for i in items_out),
    }


def evaluate_wav(
    path: str | Path,
    labels: dict[str, Any],
    detector: SpeechDetector,
    policy: SpeechPolicy,
    *,
    chunk: int = 4096,
) -> dict[str, Any]:
    """Run one WAV with a labels object ({"regions": [...], ...})."""
    from .wav import read_wav

    samples, rate = read_wav(path)
    hop_ms = detector.hop_samples * 1000 // detector.sample_rate
    run = run_item(samples, rate, detector, policy, chunk=chunk)
    score = score_item(run, labels["regions"], hop_ms)
    required = dict(labels.get("required_outcomes", {}).get(policy.name.split("+")[0], {}))
    required.update(labels.get("overrides", {}).get(policy.name.split("+")[0], {}))
    failures = check_outcomes(score, required) if required else []
    item = {
        "id": labels.get("id", Path(path).stem),
        "category": labels.get("category", "custom"),
        "required": required,
        "failures": failures,
        "pass": not failures,
        **score,
    }
    return {
        "spec_version": SPEC_VERSION,
        "detector": detector.name,
        "policy": policy.to_dict(),
        "chunk_samples": chunk,
        "items": [item],
        "overall": overall([item]),
        "pass": item["pass"],
    }


def overall(items: list[dict[str, Any]]) -> dict[str, Any]:
    """Pooled frame metrics and totals across items."""
    tp = sum(i["tp"] for i in items)
    fp = sum(i["fp"] for i in items)
    fn = sum(i["fn"] for i in items)
    nonspeech_ms = sum(i["nonspeech_ms"] for i in items)
    open_ns = sum(i["open_ms_in_nonspeech"] for i in items)
    onsets = [
        r["onset_delay_ms"]
        for i in items
        for r in i["speech_regions"]
        if r["onset_delay_ms"] is not None
    ]
    cpu = sum(i["cpu_seconds"] for i in items)
    audio = sum(i["audio_seconds"] for i in items)
    return {
        "items": len(items),
        "items_passed": sum(1 for i in items if i["pass"]),
        "precision": round(tp / (tp + fp), 4) if (tp + fp) else None,
        "recall": round(tp / (tp + fn), 4) if (tp + fn) else None,
        "open_ms_in_nonspeech": open_ns,
        "open_ms_per_minute_nonspeech": round(open_ns * 60000.0 / nonspeech_ms, 1)
        if nonspeech_ms
        else None,
        "starts_in_nonspeech": sum(i["starts_in_nonspeech"] for i in items),
        "missed_speech_ms": sum(i["missed_speech_ms"] for i in items),
        "missed_speech_regions": sum(i["missed_speech_regions"] for i in items),
        "median_onset_delay_ms": _median(onsets),
        "max_onset_delay_ms": max(onsets) if onsets else None,
        "cpu_seconds": round(cpu, 4),
        "audio_seconds": round(audio, 3),
        "cpu_per_audio_second": round(cpu / audio, 5) if audio else None,
    }


def _median(values: list[float]) -> float | None:
    if not values:
        return None
    s = sorted(values)
    mid = len(s) // 2
    return float(s[mid]) if len(s) % 2 else (s[mid - 1] + s[mid]) / 2.0


# ---- CLI ----------------------------------------------------------------------


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="voxscribe speech-eval",
        description="Evaluate a speech detector and policy against labelled audio.",
    )
    parser.add_argument("--detector", default="silero", help="silero, heuristic or fake")
    parser.add_argument(
        "--policy", default="all", help="display, segmentation, turn, barge_in or all"
    )
    parser.add_argument("--wav", default=None, help="evaluate this WAV instead of the vectors")
    parser.add_argument("--labels", default=None, help="labels JSON for --wav")
    parser.add_argument("--vectors", default=None, help="directory holding vectors.json")
    parser.add_argument(
        "--item", action="append", default=[], help="only this vector item (repeatable)"
    )
    parser.add_argument("--chunk", type=int, default=4096, help="samples per process() call")
    parser.add_argument("--json", default=None, help="write the full report here")
    parser.add_argument("--quiet", action="store_true", help="print only the summary lines")
    args = parser.parse_args(argv)

    try:
        detector = create_detector(args.detector)
    except Exception as exc:  # noqa: BLE001 - report the reason and exit cleanly
        print(f"cannot create detector {args.detector!r}: {exc}", file=sys.stderr)
        print(f"available detectors: {available_detectors()}", file=sys.stderr)
        return 2

    policies = list(PRESETS.values()) if args.policy == "all" else [preset(args.policy)]
    reports: list[dict[str, Any]] = []
    for policy in policies:
        if args.wav:
            if not args.labels:
                print("--wav needs --labels", file=sys.stderr)
                return 2
            labels = json.loads(Path(args.labels).read_text())
            reports.append(evaluate_wav(args.wav, labels, detector, policy, chunk=args.chunk))
        else:
            manifest = load_manifest(Path(args.vectors) if args.vectors else None)
            reports.append(
                evaluate_vectors(
                    detector, policy, manifest, chunk=args.chunk, item_ids=args.item or None
                )
            )

    out = {
        "spec_version": SPEC_VERSION,
        "detector": detector.name,
        "load_average": _load_average(),
        "reports": reports,
    }
    if args.json:
        Path(args.json).parent.mkdir(parents=True, exist_ok=True)
        Path(args.json).write_text(json.dumps(out, indent=2) + "\n")
    if args.quiet:
        for r in reports:
            o = r["overall"]
            print(
                f"{detector.name:10s} {r['policy']['name']:13s} pass={r['pass']} "
                f"items={o['items_passed']}/{o['items']} precision={o['precision']} "
                f"recall={o['recall']} open_ns_ms={o['open_ms_in_nonspeech']} "
                f"missed_ms={o['missed_speech_ms']} cpu/s={o['cpu_per_audio_second']}"
            )
    else:
        print(json.dumps(out, indent=2))
    return 0 if all(r["pass"] for r in reports) else 1


def _load_average() -> list[float] | None:
    try:
        return [round(v, 2) for v in os.getloadavg()]
    except (AttributeError, OSError):
        return None


if __name__ == "__main__":
    sys.exit(main())
