"""Layer 3 of the speech activity capability: the events a tracker emits.

Only transitions are events. Per-frame probabilities are never persisted and
never cross the event contract; a product that wants a level meter reads
`SpeechFrame` directly inside the session (ADR 0001, invariant 3).

The wire shape is frozen in docs/EVENT-CONTRACT.md under
`event_type: speech_activity`; `to_contract_dict()` is the single place that
produces it.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

EVENT_TYPE = "speech_activity"
KINDS = ("started", "ended")


@dataclass(frozen=True)
class SpeechEvent:
    """A speech activity transition decided by a `SpeechActivityTracker`.

    kind         "started" or "ended".
    at_ms        where on the stream timeline the transition applies, in
                 integer milliseconds since the tracker's reset. For
                 "started" this is the beginning of the first frame of the
                 qualifying run minus the policy's pre-roll (never below 0),
                 so the audio from `at_ms` onward belongs to the utterance.
                 For "ended" it is the end of the frame at which the
                 hangover expired (or the steady-sound close fired), so the
                 audio up to `at_ms` belongs to the utterance. The event is
                 always emitted later than its "started" `at_ms` by at least
                 the policy's start time plus pre-roll; consumers that need
                 the decision instant read the frame they fed.
    probability  the detector probability of the frame that triggered the
                 transition, 0..1.
    detector     the detector name ("silero", "heuristic", "fake") so a log
                 or a client can tell which definition of speech produced
                 the event.
    """

    kind: str
    at_ms: int
    probability: float
    detector: str

    def __post_init__(self) -> None:
        if self.kind not in KINDS:
            raise ValueError(f"SpeechEvent.kind must be one of {KINDS}, got {self.kind!r}")

    @property
    def speaking(self) -> bool:
        """True for "started", False for "ended"."""
        return self.kind == "started"

    def to_contract_dict(self) -> dict[str, Any]:
        """The flat JSON object defined in docs/EVENT-CONTRACT.md.

        `probability` is rounded to three decimals so two runs of the same
        audio produce byte-identical lines.
        """
        return {
            "event_type": EVENT_TYPE,
            "kind": self.kind,
            "at_ms": int(self.at_ms),
            "probability": round(float(self.probability), 3),
            "detector": self.detector,
        }

    def to_socket_dict(self) -> dict[str, Any]:
        """The engine's live socket message, extended additively per ADR 0001.

        Old clients read only `type` and `speech`; `at_ms`, `p` and `detector`
        are the new fields. Phase S2 wires this into the server.
        """
        return {
            "type": "vad",
            "speech": self.speaking,
            "at_ms": int(self.at_ms),
            "p": round(float(self.probability), 3),
            "detector": self.detector,
        }
