"""Bring 48 kHz and 44.1 kHz capture to the 16 kHz the detectors require.

Method: a windowed-sinc low-pass FIR (Blackman window) at the input rate,
then the output instants are read by linear interpolation of the filtered
signal. Integer ratios (48000 to 16000) therefore decimate exactly; rational
ones (44100 to 16000) interpolate between filtered neighbours, which adds a
small extra roll-off near the cutoff that does not matter for speech
detection. numpy only, no scipy.

Numbers (for a 48 kHz input):
  - cutoff 6900 Hz, transition about 1.6 kHz wide, so content above the
    16 kHz Nyquist (8 kHz) is below -58 dB before it can fold back; speech
    energy between 6.9 and 8 kHz is attenuated, which the detectors never use
  - 165 taps, group delay (taps - 1) / 2 input samples = 1.7 ms. Output is
    aligned to the filter centre, so the delay is in the sample count, not a
    time shift of the content relative to its own timeline
  - cost about 0.2 ms of CPU per second of 48 kHz audio on a laptop

`Resampler` is stateful: chunked streaming produces the same samples as one
call on the whole signal (tests/speech/test_resample.py checks it). Rates
below 16 kHz are refused; equal rates pass through unchanged.
"""

from __future__ import annotations

import math

import numpy as np

TARGET_RATE = 16000


def design_lowpass(in_rate: int, cutoff_hz: float, transition_hz: float) -> np.ndarray:
    """Blackman-windowed sinc low-pass. Returns float64 taps summing to 1.

    The tap count is odd and chosen from the Blackman main-lobe width (about
    5.5 cycles of the input rate per transition band). Minimum 15 taps.
    """
    taps = int(math.ceil(5.5 * in_rate / transition_hz))
    taps = max(15, taps | 1)
    half = (taps - 1) // 2
    n = np.arange(-half, half + 1, dtype=np.float64)
    fc = cutoff_hz / in_rate
    h = 2.0 * fc * np.sinc(2.0 * fc * n)
    h *= np.blackman(taps)
    h /= h.sum()
    return h


class Resampler:
    """Stateful rate converter to `out_rate` (default 16000).

    Feed float32 mono samples at `in_rate` in chunks of any size; get float32
    samples at `out_rate`. The first output sample sits at input time 0; the
    k-th at k * in_rate / out_rate input samples. Call `reset()` for a new
    stream. `flush()` pushes the filter's tail through and returns the final
    samples (only needed when the whole signal matters, as in file
    conversion; a live stream never needs it).
    """

    def __init__(self, in_rate: int, out_rate: int = TARGET_RATE) -> None:
        if in_rate < out_rate:
            raise ValueError(
                f"Resampler only reduces the rate: in_rate={in_rate} is below out_rate={out_rate}"
            )
        self.in_rate = int(in_rate)
        self.out_rate = int(out_rate)
        self.ratio = self.in_rate / self.out_rate
        self.passthrough = self.in_rate == self.out_rate
        if self.passthrough:
            self.taps = np.ones(1)
        else:
            cutoff = 0.43125 * out_rate  # 6900 Hz for 16 kHz output
            transition = 0.1 * out_rate  # 1600 Hz for 16 kHz output
            self.taps = design_lowpass(self.in_rate, cutoff, transition)
        self.half = (len(self.taps) - 1) // 2
        self.reset()

    def reset(self) -> None:
        """Forget history: the next sample starts a new stream at time 0."""
        self._hist = np.zeros(len(self.taps) - 1, dtype=np.float32)
        self._in_pos = 0  # absolute index of the next input sample
        self._out_index = 0  # index of the next output sample
        self._tail_y = 0.0  # y at (start of the next valid range - 1)
        self._tail_valid = False

    @property
    def delay_seconds(self) -> float:
        """Group delay of the anti-aliasing filter, seconds."""
        return self.half / self.in_rate

    def process(self, samples: np.ndarray) -> np.ndarray:
        """Convert one chunk. Returns float32 at `out_rate` (possibly empty)."""
        x = np.asarray(samples, dtype=np.float32).reshape(-1)
        if self.passthrough:
            return x.copy()
        if x.shape[0] == 0:
            return np.zeros(0, dtype=np.float32)
        buf = np.concatenate([self._hist, x])
        self._in_pos += x.shape[0]
        self._hist = buf[-(len(self.taps) - 1) :].copy()
        if buf.shape[0] < len(self.taps):
            return np.zeros(0, dtype=np.float32)
        valid = np.convolve(buf.astype(np.float64), self.taps, mode="valid")
        # valid[i] is the filtered signal at absolute input index start + i.
        start = self._in_pos - x.shape[0] - (len(self.taps) - 1) + self.half
        if self._tail_valid:
            y = np.concatenate([[self._tail_y], valid])
            y_start = start - 1
        else:
            y = valid
            y_start = start
        y_end = y_start + y.shape[0]  # exclusive
        self._tail_y = float(valid[-1])
        self._tail_valid = True

        # Output k needs y at floor(t_k) and floor(t_k) + 1, both inside
        # [y_start, y_end): the largest eligible k has t_k < y_end - 1.
        first_k = self._out_index
        last_k = int(math.floor((y_end - 1) / self.ratio))
        if last_k * self.ratio >= y_end - 1:
            last_k -= 1
        if last_k < first_k:
            return np.zeros(0, dtype=np.float32)
        k = np.arange(first_k, last_k + 1, dtype=np.float64)
        t = k * self.ratio
        n0 = np.floor(t).astype(np.int64)
        frac = t - n0
        i0 = n0 - y_start
        keep = i0 >= 0
        i0 = i0[keep]
        frac = frac[keep]
        out = y[i0] * (1.0 - frac) + y[i0 + 1] * frac
        self._out_index = last_k + 1
        return out.astype(np.float32)

    def flush(self) -> np.ndarray:
        """Push the filter tail through. Returns the remaining output samples."""
        if self.passthrough:
            return np.zeros(0, dtype=np.float32)
        return self.process(np.zeros(len(self.taps), dtype=np.float32))


def resample(samples: np.ndarray, in_rate: int, out_rate: int = TARGET_RATE) -> np.ndarray:
    """One-shot conversion of a whole signal.

    Returns floor(len(samples) * out_rate / in_rate) float32 samples.
    """
    x = np.asarray(samples, dtype=np.float32).reshape(-1)
    r = Resampler(in_rate, out_rate)
    if r.passthrough:
        return x.copy()
    out = np.concatenate([r.process(x), r.flush()])
    n_out = int(math.floor(x.shape[0] * out_rate / in_rate))
    if out.shape[0] < n_out:
        out = np.concatenate([out, np.zeros(n_out - out.shape[0], dtype=np.float32)])
    return out[:n_out]


def to_mono_float32(samples: np.ndarray) -> np.ndarray:
    """Any PCM layout to float32 mono in -1..1.

    Accepts int16 (scaled by 1/32768), int32 (by 1/2^31), float32 or float64
    arrays, 1-D or (frames, channels); channels are averaged.
    """
    x = np.asarray(samples)
    if x.dtype == np.int16:
        x = x.astype(np.float32) / 32768.0
    elif x.dtype == np.int32:
        x = x.astype(np.float64) / 2147483648.0
    if x.ndim == 2:
        x = x.mean(axis=1) if x.shape[1] > 1 else x[:, 0]
    return x.astype(np.float32)
