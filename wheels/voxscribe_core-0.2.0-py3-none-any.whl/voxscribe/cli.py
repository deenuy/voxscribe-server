"""VoxScribe CLI: drive the post-processor from the terminal.

Usage:
  python -m voxscribe.cli "let's meet at 2 actually 3"
  python -m voxscribe.cli --mode classroom "let's meet at 2 actually 3"
  python -m voxscribe.cli --mode ideascribe --listen        # PM brainstorm session
  python -m voxscribe.cli --mode seniorcare --listen        # caregiver session
  python -m voxscribe.cli --eval                            # PRD edge cases
  python -m voxscribe.cli --provider claude "draft the email"
  python -m voxscribe.cli --listen-once # speak -> transcribe -> clean -> print
  python -m voxscribe.cli --listen      # long-horizon session; writes output/
  python -m voxscribe.cli --listen-stop # SIGTERM the running session

Text mode requires a reachable provider (Ollama by default). --listen and
--listen-once need the listen extra (pip install 'voxscribe-core[listen]')
for the microphone and Whisper; if the LLM is unreachable it degrades to
deterministic-only cleanup instead of failing.
"""

from __future__ import annotations

import argparse
import logging
import os
import signal
import sys
import time
from pathlib import Path

from .audio_providers import FakeASRProvider, WhisperASRProvider
from .cli_ui import (
    RuntimeSummary,
    is_interactive_terminal,
    render_completion_summary,
    render_startup_layout,
    should_show_startup_panel,
    supports_color,
)
from .context import DictationMode
from .dictionary import Dictionary
from .lexicon import Lexicon, load_lexicon
from .listen import FakeAudioSource, MicrophoneSource, listen_once
from .logging_config import (
    LogConfig,
    clear_log_context,
    configure_logging,
    enable_session_log,
    get_logger,
    log_event,
    set_log_context,
)
from .output_delivery import (
    InsertConfig,
    choose_payload,
    cli_focus_warning,
    deliver_cursor_insert_text,
    format_user_message,
    render_diagnostics,
    select_inserter,
)
from .policy import (
    PolicyGate,
    PolicyPackError,
    emit_policy_applied,
    fail_closed_gate,
    load_policy_pack,
)
from .postprocessor import PostProcessor
from .providers import ClaudeProvider, DeterministicFallback, OllamaProvider
from .safety_signals import scan as _safety_scan
from .session_metadata import (
    delete_session_metadata,
    load_session_metadata,
    make_session_metadata,
    update_session_metadata,
    write_session_metadata,
)
from .session_report import ReportConfig, render_markdown
from .stream_state import StreamProcessor
from .streaming_listen import (
    StreamingMicConfig,
    StreamingMicrophone,
    run_listen_session,
)
from .utils.config_loader import VoxScribeConfig, load_config

log = get_logger("voxscribe.cli")
_log_ollama = get_logger("voxscribe.ollama")


# Last-resort defaults, used *only* when config could not be loaded at all.
# Everything the panel shows is otherwise resolved from config.yaml so the
# startup card is a faithful mirror of the running configuration.
_FALLBACK_LLM_MODEL = "gemma3:4b"
_FALLBACK_VERSION = "0.0.0"


EDGE_CASES = [
    (DictationMode.IDEASCRIBE, "i think we should ship it but actually no the data is wrong"),
    (
        DictationMode.IDEASCRIBE,
        "the feature should be optional um actually it must be on by default",
    ),
    (DictationMode.CLASSROOM, "let's meet at 2 um actually 3"),
    (DictationMode.CLASSROOM, "going to the store for 1. apples 2. bananas 3. oranges"),
    (
        DictationMode.SENIORCARE,
        "she took lisinopril 10 milligrams at 8 AM and walked for 20 minutes",
    ),
    (DictationMode.SENIORCARE, "mood was good this morning um she ate half her breakfast"),
]


def _version_from_pyproject() -> str | None:
    """Read [project].version (or [tool.poetry].version) from the nearest
    pyproject.toml, walking up from this file.

    This reflects edits *live* — no reinstall needed — in a source checkout,
    which is why it ranks above installed metadata. In an installed wheel
    pyproject.toml usually isn't present, so this returns None and the caller
    falls back to importlib.metadata."""
    try:
        import tomllib  # Python 3.11+
    except ModuleNotFoundError:
        try:
            import tomli as tomllib  # type: ignore[no-redef]
        except ModuleNotFoundError:
            return None
    here = Path(__file__).resolve()
    for parent in list(here.parents)[:6]:
        candidate = parent / "pyproject.toml"
        if not candidate.is_file():
            continue
        try:
            with candidate.open("rb") as fh:
                data = tomllib.load(fh)
        except Exception:
            return None
        ver = (data.get("project") or {}).get("version")
        if isinstance(ver, str) and ver.strip():
            return ver.strip()
        ver = ((data.get("tool") or {}).get("poetry") or {}).get("version")
        if isinstance(ver, str) and ver.strip():
            return ver.strip()
        return None  # found the file but no static version (likely dynamic)
    return None


def _resolve_version(cfg: VoxScribeConfig | None) -> str:
    """Resolve the product version without hardcoding it in the CLI.

    Resolution order (single source of truth first):
    1. voxscribe.__version__ — from installed package metadata or fallback
    2. pyproject.toml [project].version — read live in source checkouts
    3. config.yaml override — cfg.app.version (warning if mismatched with __version__)
    4. LogConfig.service_version
    5. _FALLBACK_VERSION
    """
    try:
        from . import __version__
        if __version__ and __version__ != "0.0.0":
            return __version__
    except Exception:
        pass
    pyproject_ver = _version_from_pyproject()
    if pyproject_ver:
        return pyproject_ver
    if cfg is not None:
        for owner_attr, ver_attr in (("service", "version"), ("app", "version")):
            owner = getattr(cfg, owner_attr, None)
            ver = getattr(owner, ver_attr, None) if owner is not None else None
            if isinstance(ver, str) and ver.strip():
                return ver.strip()
        direct = getattr(cfg, "version", None)
        if isinstance(direct, str) and direct.strip():
            return direct.strip()
    return getattr(LogConfig, "service_version", "") or _FALLBACK_VERSION


def _resolve_llm_model(cfg: VoxScribeConfig | None) -> str:
    """The configured LLM model, falling back only when config is absent."""
    llm = getattr(cfg, "llm", None) if cfg is not None else None
    model = getattr(llm, "model", None) if llm is not None else None
    return model or _FALLBACK_LLM_MODEL


def _resolve_environment(cfg: VoxScribeConfig | None) -> str:
    """Resolve the environment label (config first, then LogConfig, then 'local')."""
    if cfg is not None:
        for owner_attr, env_attr in (("service", "environment"), ("app", "environment")):
            owner = getattr(cfg, owner_attr, None)
            val = getattr(owner, env_attr, None) if owner is not None else None
            if isinstance(val, str) and val.strip():
                return val.strip()
        for attr in ("environment", "env"):
            val = getattr(cfg, attr, None)
            if isinstance(val, str) and val.strip():
                return val.strip()
    return getattr(LogConfig, "environment", "") or "local"


def _resolve_language(args: argparse.Namespace, cfg: VoxScribeConfig | None) -> str:
    """Resolve the ASR language: explicit CLI flag wins (including '' =
    auto-detect); otherwise cfg.asr.language; otherwise 'en'."""
    if getattr(args, "language", None) is not None:
        return args.language  # may be "" to mean auto-detect
    asr = getattr(cfg, "asr", None) if cfg is not None else None
    lang = getattr(asr, "language", None) if asr is not None else None
    return lang if isinstance(lang, str) else "en"


def _resolve_account_id(cfg: VoxScribeConfig | None, ledger_path: str) -> str:
    """Resolve the billing account id.

    Order of precedence: (1) `billing.account_id` from config; (2) a stable
    random id persisted to `<ledger_dir>/account.id` for anonymous local
    use; (3) the literal `"anon-local"` if neither of those is reachable
    (read-only filesystem, etc).  Identity resolution must never block a
    session — we always return *something*.
    """
    billing = getattr(cfg, "billing", None) if cfg is not None else None
    explicit = (getattr(billing, "account_id", "") or "").strip()
    if explicit:
        return explicit
    try:
        import uuid

        id_file = Path(ledger_path).parent / "account.id"
        if id_file.exists():
            val = id_file.read_text(encoding="utf-8").strip()
            if val:
                return val
        new_id = f"anon-{uuid.uuid4().hex[:12]}"
        id_file.parent.mkdir(parents=True, exist_ok=True)
        id_file.write_text(new_id + "\n", encoding="utf-8")
        return new_id
    except OSError:
        return "anon-local"


def _resolve_device_id() -> str:
    """Stable per-machine id derived from the hostname.

    A hash (not the raw hostname) so the ledger never carries a name that
    might identify the user's machine to anyone reading the file.  Never
    raises — returns `"anon-device"` if even hostname lookup fails."""
    try:
        import hashlib
        import socket

        host = socket.gethostname() or ""
        if not host:
            return "anon-device"
        return "dev-" + hashlib.sha256(host.encode("utf-8")).hexdigest()[:16]
    except Exception:  # noqa: BLE001
        return "anon-device"


def _resolve_db_path(cfg: VoxScribeConfig | None) -> str:
    """SQLite path for the local store. CLI flag is not exposed; env var
    `VOXSCRIBE_DB_PATH` already overrides via the config loader."""
    storage = getattr(cfg, "storage", None) if cfg is not None else None
    return (getattr(storage, "db_path", "") or "logs/voxscribe.db").strip() or "logs/voxscribe.db"


def _recover_command(cfg: VoxScribeConfig | None) -> int:
    """Scan the local store and rebuild incomplete transcripts from the WAL.

    Returns 0 even when no sessions needed recovery so a wrapping shell
    script (e.g. `make recover && make listen`) can chain commands."""
    from .recovery import recover_incomplete
    from .store import open_store

    db_path = _resolve_db_path(cfg)
    version = _resolve_version(cfg)
    store = open_store(db_path)
    try:
        rebuilt = recover_incomplete(store, app_version=version)
    finally:
        store.close()
    if rebuilt:
        print(
            f"recovery: rebuilt {len(rebuilt)} session(s): {', '.join(rebuilt)}",
            file=sys.stderr,
        )
    else:
        print("recovery: no incomplete sessions.", file=sys.stderr)
    return 0


def _check_ollama_connectivity(
    model: str,
    host: str = "http://localhost:11434",
    level: int = logging.INFO,
) -> tuple[bool, str]:
    """Ping Ollama and return (available, version_or_empty_string).

    Logs a one-line health result at ``level`` (callers pass DEBUG when the
    startup panel is shown so the user doesn't see a duplicate line). Returns
    True and the version string on success; False and '' on failure so the
    caller can populate the startup panel Ollama line."""
    import json as _json
    import urllib.error
    import urllib.request

    try:
        with urllib.request.urlopen(f"{host}/api/version", timeout=2) as resp:
            data = _json.loads(resp.read().decode())
        version = str(data.get("version", "unknown"))
        log_event(
            _log_ollama,
            "ollama_connected",
            level=level,
            version=version,
            model=model,
            model_status="available",
        )
        return (True, version)
    except Exception:
        log_event(
            _log_ollama,
            "ollama_unavailable",
            level=logging.WARNING,
            model=model,
            fallback="deterministic",
        )
        return (False, "")


def _policy_pack_root(cfg: VoxScribeConfig | None) -> Path:
    """Resolve the on-disk root that holds per-mode policy YAML packs.
    Config wins; a resource resolver checks legacy override, then packaged."""
    if cfg is not None:
        safety_cfg = getattr(cfg, "safety", None)
        if safety_cfg is not None:
            configured = getattr(safety_cfg, "policy_pack_root", "") or ""
            if configured:
                return Path(configured)
    # Check for legacy override first, then use packaged resources
    legacy = Path("config") / "policies"
    if legacy.is_dir():
        return legacy
    try:
        from .resources import resolve
        return resolve("resources_config/policies/ideascribe.yaml").parent
    except FileNotFoundError:
        # Fallback for missing package: return legacy path anyway
        return legacy


def _load_gate(mode_name: str, cfg: VoxScribeConfig | None) -> PolicyGate:
    """Load the pack for `mode_name` and return a gate. On any load error
    return a synthetic fail-closed gate so every downstream delivery
    withholds the candidate and every audit row carries the sentinel
    policy_version 'gate-unavailable'. Startup never blocks on a missing
    pack — the audit ledger surfaces the outage."""
    try:
        pack = load_policy_pack(mode_name, _policy_pack_root(cfg))
    except PolicyPackError as exc:
        log_event(
            log,
            "policy_pack_load_failed",
            level=logging.WARNING,
            mode=mode_name,
            reason=str(exc)[:200],
        )
        return fail_closed_gate(mode_name)
    return PolicyGate(pack=pack)


def _safety_scanner(text: str, chunk_id: str):
    """Adapter matching StreamProcessor's safety_scanner Callable[[str, str], ...]
    signature — the safety_signals module keeps its own keyword args and
    the CLI translates to positional here."""
    return _safety_scan(text, chunk_id)


def build_provider(name: str):
    """Construct an LLM provider using the current config for model/temperature/timeout."""
    from .utils.config_loader import get_config as _get_config

    try:
        llm = _get_config().llm
    except Exception:
        llm = None
    if name == "claude":
        return ClaudeProvider(
            model=llm.model if llm else "claude-sonnet-4-6",
            temperature=llm.temperature if llm else 0.1,
            timeout=float(llm.timeout_seconds) if llm else 30.0,
        )
    return OllamaProvider(
        model=llm.model if llm else None,
        temperature=llm.temperature if llm else 0.1,
        timeout=float(llm.timeout_seconds) if llm else 30.0,
    )


def _listen_once_command(args: argparse.Namespace, cfg: VoxScribeConfig | None = None) -> int:
    provider_name = args.provider or (cfg.llm.provider if cfg else "ollama")
    log_event(
        log,
        "listen_once_requested",
        command="listen_once",
        provider=provider_name,
        asr=args.asr,
        audio_source=args.audio_source,
        mode=args.mode,
        max_seconds=args.max_seconds,
    )
    provider = DeterministicFallback(build_provider(provider_name))
    processor = StreamProcessor(
        PostProcessor(provider, Dictionary()),
        safety_scanner=_safety_scanner,
    )
    asr_model = args.whisper_model or (cfg.asr.model if cfg else "base.en")

    if args.asr == "fake":
        script = [" ".join(args.text)] if args.text else ["testing one two three"]
        asr = FakeASRProvider(script)
        source: object = FakeAudioSource()
    else:
        asr = WhisperASRProvider(
            model_size=asr_model,
            language=_resolve_language(args, cfg) or None,
            word_timestamps=args.word_timestamps,
        )
        if args.audio_source == "fake":
            source = FakeAudioSource()
        else:
            source = MicrophoneSource()
            print(
                f"listening (up to {args.max_seconds:.0f}s)... speak now",
                file=sys.stderr,
            )

    listen_once_mode = args.mode or (cfg.listen.default_mode if cfg else "ideascribe")
    try:
        report = listen_once(
            source,  # type: ignore[arg-type]
            asr,
            processor,
            DictationMode(listen_once_mode),
            max_seconds=args.max_seconds,
        )
    except (RuntimeError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    if not report.raw_text:
        print("(no speech detected)")
        return 0

    print(f"raw   : {report.raw_text}")
    print(f"clean : {report.clean_text}")
    t = report.timings_ms
    print(
        f"stages: capture {t['capture']:.0f}ms | asr {t['asr']:.0f}ms | "
        f"intelligence {t['intelligence']:.0f}ms | total {t['total']:.0f}ms"
    )
    if provider.fell_back:
        print("note  : model unavailable, deterministic-only cleanup applied")
    return 0


PID_FILE_NAME = "voxscribe.pid"


def _listen_command(args: argparse.Namespace, cfg: VoxScribeConfig | None = None) -> int:
    """Run a long-horizon listening session. Stops on SIGTERM/SIGINT, then
    finalizes the kernel and flushes the transcript to output/."""
    # ---- resolve everything the panel shows, from config (not hardcoded) ----
    provider_name = args.provider or (cfg.llm.provider if cfg else "ollama")
    mode_name = args.mode or (cfg.listen.default_mode if cfg else "ideascribe")
    asr_model = args.whisper_model or (cfg.asr.model if cfg else "base.en")
    output_dir_str = args.output_dir or (cfg.paths.output_dir if cfg else "output")
    llm_model = _resolve_llm_model(cfg)
    version = _resolve_version(cfg)
    environment = _resolve_environment(cfg)
    language = _resolve_language(args, cfg)
    mode_source = "cli" if args.mode else "default"

    # ---- decide panel/color up front so the brand greets the user first ----
    cli_cfg = cfg.cli if cfg else None
    is_tty = is_interactive_terminal()
    show_panel = should_show_startup_panel(cli_cfg, LogConfig.fmt, is_tty) if cli_cfg else is_tty
    use_unicode = cli_cfg.use_unicode if cli_cfg else True
    compact_mode = cli_cfg.compact_startup_panel if cli_cfg else False
    use_color = supports_color(getattr(cli_cfg, "use_color", True), is_tty)

    # Note: the brand banner is no longer printed here on its own. It is now
    # rendered together with the runtime panel (side by side on wide terminals)
    # once the panel's data is ready — see render_startup_layout below.

    # When the panel is shown, demote startup INFO chatter to DEBUG so the
    # banner/panel are the only things the user sees on startup. The session
    # log (always JSON) still captures every event regardless of level.
    _startup_level = logging.DEBUG if show_panel else logging.INFO

    log_event(
        log,
        "voxscribe_starting",
        level=_startup_level,
        version=version,
        env=environment,
    )
    log_event(
        log,
        "listen_start_requested",
        level=_startup_level,
        provider=provider_name,
        mode=mode_name,
        output_dir=output_dir_str,
        whisper_model=asr_model,
        language=language,
        report=bool(args.report),
        report_format=args.report_format,
    )
    output_dir = Path(output_dir_str)
    output_dir.mkdir(parents=True, exist_ok=True)
    pid_file = output_dir / PID_FILE_NAME

    if pid_file.exists():
        try:
            old_pid = int(pid_file.read_text().strip())
            os.kill(old_pid, 0)
        except (ValueError, ProcessLookupError, PermissionError):
            pid_file.unlink(missing_ok=True)
        else:
            print(
                f"error: a session is already running (pid {old_pid}). "
                f"Run 'make listen-stop' first.",
                file=sys.stderr,
            )
            return 1

    session_id = args.session_id or time.strftime("session-%Y%m%d-%H%M%S")
    pid = os.getpid()
    # Captured here so the billing ledger row carries the actual session
    # start time, not the time at which `record_session` runs after stop.
    session_started_at_epoch = time.time()
    set_log_context(session_id=session_id, command="listen", pid=pid)
    log_event(log, "session_created", level=_startup_level, output=output_dir_str)

    session_log_path = enable_session_log(session_id) or ""
    pid_file.write_text(str(pid))
    if session_log_path:
        log_event(log, "session_log_ready", level=_startup_level, file=session_log_path)

    metadata = make_session_metadata(
        session_id=session_id,
        pid=pid,
        output_dir=str(output_dir),
        service=LogConfig.service,
        service_version=version,
        environment=environment,
        session_log_path=session_log_path,
    )
    write_session_metadata(metadata, output_dir)

    # ---- local store + crash recovery -----------------------------------
    # Open the SQLite store FIRST so a crash from a prior session can be
    # rebuilt before we start capturing fresh audio.  Recovery is fast
    # (no audio, no LLM) and idempotent — safe to run on every start.
    from .recovery import recover_incomplete as _recover_incomplete
    from .store import open_store as _open_store

    db_path = _resolve_db_path(cfg)
    store_handle: object | None = None
    try:
        store_handle = _open_store(db_path)
        try:
            rebuilt = _recover_incomplete(store_handle, app_version=version)
            if rebuilt:
                log_event(
                    log,
                    "recovery_complete",
                    level=_startup_level,
                    sessions=len(rebuilt),
                )
        except Exception as exc:  # noqa: BLE001 — never block startup
            log_event(
                log,
                "recovery_failed",
                level=logging.WARNING,
                reason=type(exc).__name__,
            )
    except Exception as exc:  # noqa: BLE001
        log_event(
            log,
            "store_open_failed",
            level=logging.WARNING,
            db_path=db_path,
            reason=type(exc).__name__,
        )
        store_handle = None

    # ---- billing identity (resolved once per session) ----------------------
    # account_id and device_id tag every ledger row so a future server can
    # reconcile claims; never blocks startup if the filesystem is read-only.
    billing_cfg_early = getattr(cfg, "billing", None)
    ledger_path_early = getattr(billing_cfg_early, "ledger_path", "logs/voxscribe.db")
    account_id = _resolve_account_id(cfg, ledger_path_early)
    device_id = _resolve_device_id()
    week_reset_tz_early = getattr(billing_cfg_early, "week_reset_tz", "America/Los_Angeles")
    weekly_cap_early = int(getattr(billing_cfg_early, "weekly_word_cap", 2000) or 2000)
    enforce_cap = bool(getattr(billing_cfg_early, "enforce_cap", False))

    # Dormant cap guard. enforce_cap defaults to False in v1 so this is
    # inert; flip the config flag (or env override) to turn it on without
    # touching code. The guard checks the recomputed weekly cache for
    # this account, not a running counter, so a crashed retry can't slip
    # past the cap.
    # TODO(server-sync): replace the local check with a server-authoritative
    # one before turning enforcement on for paying customers.
    if enforce_cap:
        try:
            from .usage import weekly_summary as _weekly_summary_pre

            pre = _weekly_summary_pre(
                account_id,
                ledger_path=Path(ledger_path_early) if ledger_path_early else None,
                week_reset_tz=week_reset_tz_early,
                word_cap=weekly_cap_early,
            )
            if pre.words >= weekly_cap_early:
                print(
                    f"weekly word cap reached ({pre.words} / {weekly_cap_early} "
                    f"this week). Resets at {pre.resets_at}.",
                    file=sys.stderr,
                )
                pid_file.unlink(missing_ok=True)
                delete_session_metadata(output_dir)
                clear_log_context()
                return 0
        except Exception:  # noqa: BLE001
            pass  # never let the guard block a session

    # ---- durable session start (SQLite) ----------------------------------
    # The sessions row carries enough context that recovery can rebuild
    # this session even after a kill -9 — including paths for transcript
    # / events so the rebuilt `.txt` lands in the same place the user
    # would have looked for.
    if store_handle is not None:
        try:
            store_handle.start_session(  # type: ignore[attr-defined]
                session_id,
                account_id=account_id,
                device_id=device_id,
                product="",  # filled in after product resolution below
                mode=mode_name,
                language=language,
                pid=pid,
                asr_model=asr_model,
                llm_model=llm_model,
                app_version=version,
                transcript_path=str(output_dir / f"{session_id}.txt"),
                events_path=str(output_dir / f"{session_id}.jsonl"),
                at=session_started_at_epoch,
            )
        except Exception as exc:  # noqa: BLE001
            log_event(
                log,
                "store_start_session_failed",
                level=logging.WARNING,
                session_id=session_id,
                reason=type(exc).__name__,
            )

    # ---- policy pack + response gate (invariants 5, 5a, 5b) -----------------
    # Load once per session and stamp policy_version_applied on the audit
    # ledger before any chunk is fed. A missing / malformed pack does NOT
    # block startup; the gate is None and every downstream delivery hits the
    # fail-closed sentinel path (policy_version=gate-unavailable).
    gate = _load_gate(mode_name, cfg)
    emit_policy_applied(
        gate,
        mode=mode_name,
        store=store_handle,
        session_id=session_id,
        at=session_started_at_epoch,
    )

    # ---- panel prerequisites only (these emit NO operational INFO logs) ----
    # Report-on-stop defaults to ON (config/env-driven). The CLI flag, if set
    # explicitly, overrides config so existing callers stay deterministic.
    report_cfg = ReportConfig.from_config(cfg) if cfg is not None else ReportConfig.from_env()
    build_report = args.report or report_cfg.on_stop
    report_format = args.report_format if args.report else report_cfg.fmt
    insert_cfg = InsertConfig.from_config(cfg) if cfg is not None else InsertConfig.from_env()

    # ---- Ollama health check (before panel so its status appears in it) ----
    ollama_ok: bool | None = None
    ollama_ver: str = ""
    if provider_name == "ollama":
        ollama_ok, ollama_ver = _check_ollama_connectivity(llm_model, level=_startup_level)

    # ---- startup layout: banner + runtime panel, side by side when wide ----
    # Painted BEFORE any provider/ASR/mic construction so that those objects'
    # own INFO logs (e.g. "LLM Provider Selected") appear *after* the startup
    # card, never wedged into it.
    if show_panel:
        runtime_summary = RuntimeSummary(
            version=version,
            environment=environment,
            session_id=session_id,
            pid=pid,
            mode=f"{mode_name}({mode_source})",
            language=language or "en",
            asr_provider=f"Whisper / {asr_model}",
            llm_provider=f"{provider_name} / {llm_model}",
            ollama_available=ollama_ok,
            ollama_version=ollama_ver,
            report_enabled=bool(build_report),
            report_format=report_format or "off",
            insert_enabled=bool(insert_cfg.enabled),
            output_dir=output_dir_str,
            session_log_path=session_log_path,
            use_unicode=use_unicode,
            use_color=use_color,
            compact_mode=compact_mode,
        )
        print(render_startup_layout(runtime_summary), file=sys.stderr, flush=True)

    # ---- now construct the pipeline (these may emit INFO logs) -------------
    provider = DeterministicFallback(build_provider(provider_name))
    dictionary = Dictionary()
    for term in args.bias_term:
        dictionary.learn(term.lower(), term, source="cli")
    lexicon: Lexicon | None = None
    if args.lexicon:
        try:
            lexicon = load_lexicon(args.lexicon)
        except (OSError, ValueError) as exc:
            print(f"error: could not load lexicon {args.lexicon}: {exc}", file=sys.stderr)
            return 1
    processor = StreamProcessor(
        PostProcessor(provider, dictionary),
        safety_scanner=_safety_scanner,
    )
    asr = WhisperASRProvider(
        model_size=asr_model,
        language=language or None,
        word_timestamps=args.word_timestamps,
    )
    mic = StreamingMicrophone(StreamingMicConfig())
    summarizer = provider if (build_report and report_cfg.use_llm) else None

    def _shutdown(_signum, _frame):
        print("\nstopping session, finalizing…", file=sys.stderr)
        mic.stop()

    signal.signal(signal.SIGINT, _shutdown)
    signal.signal(signal.SIGTERM, _shutdown)

    # Resolve product label from modes config (front-matter + log tagging).
    product_name = ""
    if cfg is not None:
        mode_entry = getattr(cfg.modes, mode_name, None)
        product_name = getattr(mode_entry, "product", "") if mode_entry else ""
    if not product_name:
        from .context import product_label as _product_label

        try:
            product_name = _product_label(DictationMode(mode_name))
        except ValueError:
            product_name = mode_name

    log_event(
        log,
        "runtime_ready",
        level=_startup_level,
        mode=f"{mode_name}({mode_source})",
        product=product_name,
        asr=f"Whisper/{asr_model}",
        llm=f"{provider_name}/{llm_model}",
        report=report_format if build_report else "off",
        insert="on" if insert_cfg.enabled else "off",
        output=output_dir_str,
    )

    if not build_report:
        print(
            "  warning     : report generation disabled "
            "(VOXSCRIBE_REPORT_ON_STOP=false). Only .txt/.jsonl will be "
            "written; cursor insertion will fall back to plain stable text.",
            file=sys.stderr,
        )

    log_event(log, "listening_started", level=_startup_level, stop="make listen-stop")

    # ---- shutdown phase tracker (structured, no raw prints) ----------------
    def _phase(msg: str) -> None:
        """Silently persist the last completed phase for listen-stop timeout
        recovery.  No raw stdout/stderr print — structured log events are
        emitted at the CLI-level call sites instead."""
        try:
            tokens = msg.replace("phase:", "").strip().split()
            if len(tokens) >= 2 and tokens[1] in {"ok", "completed", "done"}:
                update_session_metadata(
                    output_dir,
                    extras={"last_completed_phase": tokens[0]},
                )
        except Exception:  # noqa: BLE001
            pass

    report = None
    try:
        listen_cfg = getattr(cfg, "listen", None) if cfg is not None else None
        gap_threshold_s = float(getattr(listen_cfg, "gap_log_threshold_s", 30.0) or 30.0)
        report = run_listen_session(
            mic,
            asr,
            processor,
            session_id,
            output_dir,
            DictationMode(mode_name),
            lexicon=lexicon,
            build_report=build_report,
            report_format=report_format,
            summarizer=summarizer,
            phase_logger=_phase,
            product=product_name,
            gap_log_threshold_s=gap_threshold_s,
            store=store_handle,
            gate=gate,
        )

        # Artifact paths land in session_metadata so listen-stop and any
        # downstream tooling can resolve them without re-deriving names.
        update_session_metadata(
            output_dir,
            transcript_path=report.txt_path,
            events_path=report.jsonl_path,
            report_path=report.report_path or "",
        )
        log_event(
            log,
            "transcript_written",
            path=report.txt_path,
            spans=report.stable_spans,
            bytes_written=_safe_bytes(report.txt_path),
        )
        log_event(
            log,
            "events_written",
            path=report.jsonl_path,
            segments=report.segments_seen,
            ticks=report.ticks_seen,
            bytes_written=_safe_bytes(report.jsonl_path),
        )
        if report.report_path:
            log_event(
                log,
                "markdown_report_written"
                if report.report_path.endswith(".md")
                else "report_written",
                path=report.report_path,
                bytes_written=_safe_bytes(report.report_path),
            )

        t = report.timings_ms

        # ---- account-attributable usage ledger (Wispr-style meter) ----
        # Per-session row is the source of truth; the weekly cache is
        # recomputed from it on every write. Idempotent on `session_id`,
        # so a crash mid-finalize + retry cannot double-count.
        billing_cfg = getattr(cfg, "billing", None)
        weekly_cap = int(getattr(billing_cfg, "weekly_word_cap", 0) or 0)
        ledger_path = getattr(billing_cfg, "ledger_path", "logs/usage.json")
        week_reset_tz = getattr(billing_cfg, "week_reset_tz", "America/Los_Angeles")

        # AI actions are LLM generations that produce a deliverable
        # (report / PRD / care summary). Raw dictation is cheap (words
        # only); AI actions are metered separately so the premium meter
        # can gate the heavier Gemma calls without affecting cap math.
        ai_actions = 1 if (build_report and summarizer is not None) else 0
        llm_requests = ai_actions  # surfaced separately on the panel

        # Empty/failed sessions must not consume the cap.
        counted = report.words_finalized > 0
        uncounted_reason = None if counted else "no_speech"

        from .usage import (
            WeeklyUsage as _WeeklyUsage,
        )
        from .usage import (
            record_session as _record_usage,
        )

        ended_at_iso = time.strftime(
            "%Y-%m-%dT%H:%M:%SZ",
            time.gmtime(time.time()),
        )
        started_at_iso = time.strftime(
            "%Y-%m-%dT%H:%M:%SZ",
            time.gmtime(session_started_at_epoch),
        )
        try:
            weekly = _record_usage(
                session_id=session_id,
                account_id=account_id,
                device_id=device_id,
                mode=mode_name,
                words=report.words_finalized,
                audio_seconds=report.audio_speech_s + report.audio_silence_s,
                ai_actions=ai_actions,
                started_at=started_at_iso,
                ended_at=ended_at_iso,
                counted=counted,
                uncounted_reason=uncounted_reason,
                ledger_path=Path(ledger_path) if ledger_path else None,
                week_reset_tz=week_reset_tz,
                word_cap=weekly_cap or 2000,
            )
        except Exception as exc:  # noqa: BLE001 — ledger must not break a session
            log_event(
                log,
                "usage_ledger_write_failed",
                level=logging.WARNING,
                reason=type(exc).__name__,
            )
            weekly = _WeeklyUsage(
                account_id=account_id,
                iso_week="",
                words=report.words_finalized,
                word_cap=weekly_cap or 2000,
                ai_actions=ai_actions,
                sessions=1,
                audio_seconds=report.audio_speech_s + report.audio_silence_s,
                resets_at="",
            )
        weekly_words_used = weekly.words

        # ---- finalize the session row + outbox handoff -------------------
        if store_handle is not None:
            try:
                store_handle.finalize_session(  # type: ignore[attr-defined]
                    session_id,
                    state="completed",
                    words=report.words_finalized,
                    chars=report.chars_finalized,
                    ai_actions=ai_actions,
                    audio_seconds=report.audio_speech_s + report.audio_silence_s,
                    rtf=report.rtf,
                    avg_confidence=report.avg_confidence,
                    repetitions=report.repetitions_seen,
                    llm_requests=llm_requests,
                    counted=counted,
                    uncounted_reason=uncounted_reason or "",
                    transcript_path=report.txt_path,
                    report_path=report.report_path or "",
                    events_path=report.jsonl_path,
                    ended_at=ended_at_iso,
                )
                store_handle.enqueue_outbox(  # type: ignore[attr-defined]
                    "session",
                    session_id,
                    "upsert",
                    {
                        "session_id": session_id,
                        "account_id": account_id,
                        "device_id": device_id,
                        "state": "completed",
                        "words": report.words_finalized,
                        "audio_seconds": (report.audio_speech_s + report.audio_silence_s),
                        "ai_actions": ai_actions,
                        "counted": counted,
                        "app_version": version,
                    },
                )
            except Exception as exc:  # noqa: BLE001
                log_event(
                    log,
                    "store_finalize_failed",
                    level=logging.WARNING,
                    session_id=session_id,
                    reason=type(exc).__name__,
                )

        # ---- completion summary (human-facing) ----
        completion = render_completion_summary(
            session_id=session_id,
            txt_path=report.txt_path,
            jsonl_path=report.jsonl_path,
            report_path=report.report_path or "",
            session_log_path=session_log_path,
            stable_spans=report.stable_spans,
            segments_seen=report.segments_seen,
            ticks_seen=report.ticks_seen,
            bias_prompts_sent=report.bias_prompts_sent,
            timings_ms=t,
            provider_fell_back=bool(provider.fell_back),
            use_unicode=use_unicode,
            use_color=use_color,
            compact_mode=compact_mode,
            words_finalized=report.words_finalized,
            chars_finalized=report.chars_finalized,
            audio_speech_s=report.audio_speech_s,
            audio_silence_s=report.audio_silence_s,
            avg_confidence=report.avg_confidence,
            rtf=report.rtf,
            repetitions_seen=report.repetitions_seen,
            mode=mode_name,
            asr_model=asr_model,
            llm_provider=provider_name,
            llm_model=llm_model,
            llm_requests=llm_requests,
            weekly_words_used=weekly_words_used,
            weekly_word_cap=weekly_cap,
            weekly_resets_at=weekly.resets_at,
            started_at=started_at_iso,
            ended_at=ended_at_iso,
            display_tz=getattr(getattr(cfg, "display", None), "timezone", "") or "",
        )
        print(f"\n{completion}", file=sys.stderr, flush=True)

        # Persist the customer-facing metrics on session_completed so a log
        # aggregator can power dashboards (words/week, RTF distribution,
        # confidence p50/p99) without re-parsing the human panel.
        log_event(
            log,
            "session_completed",
            session_id=session_id,
            duration_s=round(t.get("total", 0) / 1000, 1),
            words=report.words_finalized,
            chars=report.chars_finalized,
            audio_s=round(report.audio_speech_s + report.audio_silence_s, 1),
            speech_ratio=round(report.speech_ratio, 2),
            rtf=round(report.rtf, 3),
            avg_confidence=round(report.avg_confidence, 3),
            repetitions=report.repetitions_seen,
            llm_requests=llm_requests,
            ai_actions=ai_actions,
            counted=counted,
            account_id=account_id,
            device_id=device_id,
            weekly_words=weekly_words_used,
            weekly_cap=weekly_cap,
            weekly_resets_at=weekly.resets_at,
            spans=report.stable_spans,
            segments=report.segments_seen,
            report=report.report_path or "",
        )

        # ---- cursor insertion (after file export) ----
        log_event(log, "shutdown_phase_started", phase="output_delivery")
        _phase("phase: output_delivery start")
        _maybe_insert_at_cursor(
            report,
            cfg=cfg,
            gate=gate,
            store=store_handle,
            session_id=session_id,
        )
        _phase("phase: output_delivery ok")
        log_event(log, "shutdown_phase_completed", phase="output_delivery")
    finally:
        log_event(log, "shutdown_phase_started", phase="cleanup_pid_file")
        _phase("phase: cleanup_pid_file start")
        pid_file.unlink(missing_ok=True)
        delete_session_metadata(output_dir)
        _phase("phase: cleanup_pid_file ok")
        log_event(log, "shutdown_phase_completed", phase="cleanup_pid_file")
        if store_handle is not None:
            try:
                store_handle.close()  # type: ignore[attr-defined]
            except Exception:  # noqa: BLE001
                pass
        clear_log_context()
    return 0


def _safe_bytes(path: str) -> int:
    """Best-effort file size in bytes for log enrichment. Returns 0 on
    error rather than failing the calling event."""
    try:
        return Path(path).stat().st_size
    except OSError:
        return 0


def _maybe_insert_at_cursor(
    report,
    cfg: VoxScribeConfig | None = None,
    *,
    gate: PolicyGate | None = None,
    store: object | None = None,
    session_id: str = "",
) -> None:
    """Deliver the final text to the user's focused text field, if enabled.

    Three target modes:
      - active         paste into whatever has focus right now
      - refocus_delay  print a countdown, sleep, then paste
      - last_focused_app   scaffold only; prints unsupported message

    Config/env-driven, off by default. Any failure here is reported as a
    warning — never raised — because file export has already succeeded.

    The candidate is passed through the response gate before insertion; on
    deny/fail-closed outcomes the pack's scripted fallback is inserted
    instead. Every evaluation writes to the safety ledger, records
    retention, and emits response_gated to the events table."""
    insert_cfg = InsertConfig.from_config(cfg) if cfg is not None else InsertConfig.from_env()
    if not insert_cfg.enabled:
        return

    markdown_text: str | None = None
    if report.session_report is not None:
        try:
            markdown_text = render_markdown(report.session_report)
        except Exception as exc:  # noqa: BLE001
            print(
                f"  insert      : warning: could not render markdown ({exc}); "
                f"falling back to plain text",
                file=sys.stderr,
            )

    candidate = choose_payload(
        insert_cfg.fmt,
        markdown_text=markdown_text,
        plain_text=report.stable_text or "",
    )

    if not candidate.strip():
        print("  insert      : nothing to insert (empty transcript)", file=sys.stderr)
        return

    payload = deliver_cursor_insert_text(
        gate,
        candidate,
        store=store,
        session_id=session_id or getattr(report, "session_id", ""),
    )

    # Pre-paste warning: 'active' mode under a CLI stop almost certainly
    # pastes into Terminal instead of the user's intended target.
    warning = cli_focus_warning(insert_cfg)
    if warning:
        for line in warning.splitlines():
            print(f"  insert      : {line}", file=sys.stderr)

    inserter = select_inserter(insert_cfg)
    for line in render_diagnostics(insert_cfg, inserter, payload):
        print(f"  {line}")

    try:
        result = inserter.insert_text(payload)
    except Exception as exc:  # noqa: BLE001 — never raise out of CLI
        print(f"  insert      : warning: inserter raised: {exc}", file=sys.stderr)
        return

    # One uniform user-facing line, plus a structured result line for
    # diagnostics (so the user can see exactly what came back).
    print(f"  insert      : {format_user_message(insert_cfg, result)}")
    detail = result.error or result.message or ""
    print(
        f"  insert      : result={'success' if result.success else 'failure'}"
        f" platform={result.platform} method={result.method}"
        + (f" reason={detail}" if detail else "")
    )


def _listen_stop_command(args: argparse.Namespace) -> int:
    log_event(log, "listen_stop_requested", command="listen_stop", output_dir=args.output_dir)
    pid_file = Path(args.output_dir) / PID_FILE_NAME

    # Rebind context to the session_id of the running listen process so
    # the stop-side and the listen-side logs cluster on the same
    # `session_id` in Datadog/Loki/CloudWatch. The metadata file is the
    # only authoritative source — pid alone cannot be reversed into one.
    meta = load_session_metadata(args.output_dir)
    if meta is not None:
        set_log_context(
            session_id=meta.session_id,
            command="listen_stop",
            pid=meta.pid,
        )
        log_event(
            log,
            "session_metadata_loaded",
            path=str(Path(args.output_dir) / "voxscribe.session.json"),
        )

    if not pid_file.exists():
        log_event(log, "listen_stop_no_session", level=logging.WARNING)
        print("no running session.", file=sys.stderr)
        return 1
    try:
        pid = int(pid_file.read_text().strip())
    except ValueError:
        log_event(log, "pid_file_malformed", level=logging.WARNING)
        print("malformed pid file; removing.", file=sys.stderr)
        pid_file.unlink(missing_ok=True)
        return 1
    try:
        os.kill(pid, signal.SIGTERM)
        log_event(log, "signal_sent", pid=pid, signal="SIGTERM")
        log_event(log, "waiting_for_process_exit", pid=pid)
    except ProcessLookupError:
        log_event(log, "listen_stop_stale_pid", level=logging.WARNING, pid=pid)
        print(f"pid {pid} not running; clearing stale pid file.", file=sys.stderr)
        pid_file.unlink(missing_ok=True)
        return 1

    # Wait for the session to flush, finalize, write the report, and
    # (optionally) perform cursor insertion. The summarizer LLM call can
    # take 10-30s on CPU for long transcripts, so the budget is 60s. The
    # transcript itself is already on disk before this loop matters — we
    # are waiting for the *report* and any *insertion* to finish.
    stop_budget_s = 60.0
    poll_interval_s = 0.2
    deadline_ticks = int(stop_budget_s / poll_interval_s)
    for tick in range(deadline_ticks):
        if not pid_file.exists():
            log_event(log, "session_exit_clean", pid=pid)
            print(f"session stopped (pid {pid}).")
            return 0
        # Around the halfway mark, hint that finalization may be running
        # the summarizer LLM call. The listen process's stderr stream
        # carries phase logs in the original terminal.
        if tick == deadline_ticks // 2:
            print(
                "  still finalizing (summarizer LLM call can take 10-30s on "
                "CPU). Watch the listen terminal for phase logs.",
                file=sys.stderr,
            )
        time.sleep(poll_interval_s)
    # Resolve the listen-side's last completed shutdown phase so the
    # operator (and any log aggregator alert) sees exactly where finalize
    # stalled, not just "timed out somewhere".
    latest = load_session_metadata(args.output_dir)
    last_phase = ""
    if latest is not None:
        last_phase = str(latest.extras.get("last_completed_phase", ""))
    log_event(
        log,
        "session_exit_timeout",
        level=logging.WARNING,
        pid=pid,
        budget_s=stop_budget_s,
        last_completed_phase=last_phase or "unknown",
        hint="watch listen terminal for shutdown_phase events",
    )
    print(
        f"warning: session (pid {pid}) is still finalizing after "
        f"{stop_budget_s:.0f}s. The transcript file is already on disk; "
        f"the report and/or cursor insertion may still be in progress. "
        f"Check the listen terminal for phase logs.",
        file=sys.stderr,
    )
    return 0


def main(argv: list[str] | None = None) -> int:
    # Subcommands live ahead of the flag parser because the first positional
    # is otherwise transcript text. `voxscribe speech-eval ...` runs the speech
    # activity evaluation (docs/SPEECH-ACTIVITY.md) and touches nothing else.
    raw_argv = list(sys.argv[1:] if argv is None else argv)
    if raw_argv and raw_argv[0] == "speech-eval":
        from .speech.evaluate import main as speech_eval_main

        return speech_eval_main(raw_argv[1:])

    parser = argparse.ArgumentParser(prog="voxscribe")
    parser.add_argument("text", nargs="*", help="raw transcript to clean")
    parser.add_argument("--mode", default=None, choices=[m.value for m in DictationMode])
    parser.add_argument("--provider", default=None, choices=["ollama", "claude"])
    parser.add_argument("--eval", action="store_true", help="run PRD edge cases")
    parser.add_argument(
        "--listen-once",
        action="store_true",
        help="record one utterance, transcribe, clean, print with latencies",
    )
    parser.add_argument(
        "--listen",
        action="store_true",
        help="long-horizon session: mic -> kernel -> output/ until stop",
    )
    parser.add_argument(
        "--listen-stop",
        action="store_true",
        help="SIGTERM the running --listen session and wait for clean shutdown",
    )
    parser.add_argument(
        "--recover",
        action="store_true",
        help=(
            "scan the local store for sessions left in recording/finalizing"
            " state, rebuild their transcripts from the WAL, and exit"
        ),
    )
    parser.add_argument("--output-dir", default="output")
    parser.add_argument("--session-id", default="")
    parser.add_argument("--asr", default="whisper", choices=["whisper", "fake"])
    parser.add_argument("--audio-source", default="mic", choices=["mic", "fake"])
    parser.add_argument("--max-seconds", type=float, default=15.0)
    parser.add_argument(
        "--whisper-model",
        default=None,
        help=(
            "faster-whisper model size (default: from config, base.en). "
            "Try 'small.en' for better accuracy or 'distil-large-v3' for ~5x speed."
        ),
    )
    parser.add_argument(
        "--language",
        default=None,
        help=(
            "ISO language code for ASR (e.g. en, es). Omitted = from config "
            "(asr.language, default 'en'). Empty string = auto-detect."
        ),
    )
    parser.add_argument(
        "--word-timestamps",
        action="store_true",
        help="emit per-word timing in TranscriptChunk.words (costs ~25%% decode)",
    )
    parser.add_argument(
        "--bias-term",
        action="append",
        default=[],
        help=(
            "domain term to bias ASR toward (repeatable). Joined into Whisper's "
            "initial_prompt alongside the user dictionary."
        ),
    )
    parser.add_argument(
        "--lexicon",
        default="",
        help=(
            "path to a project lexicon JSON (bias_terms + phrase rules). Bias "
            "entries feed Whisper's initial_prompt; phrase rules apply as a "
            "deterministic post-pass after Flow Intelligence cleanup."
        ),
    )
    parser.add_argument(
        "--report",
        action="store_true",
        help=(
            "emit a finalize-time SessionReport (topic, themes, takeaways, "
            "original transcript). Writes output/<session_id>.report.<fmt>."
        ),
    )
    parser.add_argument(
        "--report-format",
        default="md",
        choices=["md", "json"],
        help="SessionReport output format (default: md).",
    )
    args = parser.parse_args(argv)

    cfg = load_config()
    configure_logging(config=cfg)

    if args.recover:
        cmd = "recover"
    elif args.listen_stop:
        cmd = "listen_stop"
    elif args.listen:
        cmd = "listen"
    elif args.listen_once:
        cmd = "listen_once"
    elif args.eval:
        cmd = "eval"
    else:
        cmd = "text"
    provider_name = args.provider or cfg.llm.provider
    mode_name = args.mode or cfg.listen.default_mode
    # When a listen session is about to paint the brand banner + panel, this
    # line is just pre-amble noise above it — demote to DEBUG so the banner is
    # the first thing on screen. It stays at INFO for every other command and
    # in non-TTY/JSON (Docker) contexts where the panel is suppressed.
    _cli_cfg = getattr(cfg, "cli", None)
    _panel_coming = (
        should_show_startup_panel(_cli_cfg, LogConfig.fmt, is_interactive_terminal())
        if _cli_cfg
        else is_interactive_terminal()
    )
    _cmd_level = logging.DEBUG if (cmd == "listen" and _panel_coming) else logging.INFO
    log_event(
        log,
        "cli_command_received",
        level=_cmd_level,
        command=cmd,
        provider=provider_name,
        mode=mode_name,
    )

    if args.recover:
        return _recover_command(cfg)
    if args.listen_stop:
        return _listen_stop_command(args)
    if args.listen:
        return _listen_command(args, cfg=cfg)
    if args.listen_once:
        return _listen_once_command(args, cfg=cfg)

    pp = PostProcessor(build_provider(provider_name), Dictionary())

    if args.eval:
        for mode, raw in EDGE_CASES:
            out = pp.process(raw, mode)
            print(f"[{mode.value:6}] raw: {raw}")
            print(f"         out: {out.text}\n")
        return 0

    if not args.text:
        parser.print_help()
        return 1

    out = pp.process(" ".join(args.text), DictationMode(mode_name))
    print(out.text)
    return 0


if __name__ == "__main__":
    sys.exit(main())
