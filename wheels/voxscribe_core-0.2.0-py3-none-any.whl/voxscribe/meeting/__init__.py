"""Meeting subpackage: transcription, enrichment, summarization, assistance.

Product-agnostic meeting intelligence: live transcription, question detection,
enrichment, summarization, and real-time assistance.
"""

from .assist import LiveAssist, Suggestion
from .enrich import EnhancedSourceChunk, EnrichedBlock, Enricher, TranscriptSegment
from .live import AutoStop, LiveTranscriber, Segment, SpeechTransition
from .qdetect import LLMConfirmHook, QuestionDetector, QuestionResult
from .summary import MeetingSummary, SummaryDetail, summarize_meeting
from .usage_meter import TokenMeter, UsageSnapshot

__all__ = [
    "AutoStop",
    "Enricher",
    "EnhancedSourceChunk",
    "EnrichedBlock",
    "LLMConfirmHook",
    "LiveAssist",
    "LiveTranscriber",
    "MeetingSummary",
    "QuestionDetector",
    "QuestionResult",
    "Segment",
    "Suggestion",
    "SummaryDetail",
    "TokenMeter",
    "TranscriptSegment",
    "UsageSnapshot",
    "summarize_meeting",
]
