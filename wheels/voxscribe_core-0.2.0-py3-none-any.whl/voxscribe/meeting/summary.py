"""Meeting summarization with LLM and extractive fallback."""

from __future__ import annotations

import logging
from dataclasses import dataclass

from ..knowledge.llm_stream import StreamingLLMProvider
from ..logging_config import get_logger, log_event
from .llm_json import complete_json

log = get_logger("voxscribe.meeting.summary")

PROMPT_VERSION = "v1"


@dataclass
class SummaryDetail:
    """One detail section in the summary."""

    title: str
    body: str


@dataclass
class MeetingSummary:
    """Complete meeting summary."""

    overview: str
    details: list[SummaryDetail]


def summarize_meeting(
    llm: StreamingLLMProvider,
    segments: list[dict],
    notes: list[dict],
    enhanced: list[dict] | None = None,
    allow_extractive: bool = False,
) -> MeetingSummary:
    """Summarize a meeting.

    Args:
        llm: streaming LLM provider
        segments: transcript segments [{id, text, ...}]
        notes: shorthand notes [{blockId, text, ...}]
        enhanced: enhanced notes (optional)
        allow_extractive: if True, fall back to extractive summary on LLM error

    Returns:
        MeetingSummary with overview and details
    """
    transcript = " ".join(seg.get("text", "") for seg in segments)
    shorthand = " ".join(note.get("text", "") for note in notes)
    enhanced_text = ""
    if enhanced:
        for block in enhanced:
            enhanced_text += f"{block.get('text', '')} "

    context = f"Transcript:\n{transcript}\n\nShorthand:\n{shorthand}"
    if enhanced_text:
        context += f"\n\nEnhanced Notes:\n{enhanced_text}"

    system_prompt = (
        "You are a meeting summarizer. Generate a concise overview and 3-5 detail items. "
        "Output ONLY valid JSON with fields 'overview' (string) and 'details' "
        "(array of {title, body}). Be factual and extractive."
    )

    try:
        parsed, raw = complete_json(llm, system_prompt, context, max_tokens=2048)
        summary = _summary_from_json(parsed)
        if summary is None:
            raise ValueError(f"the model did not return a usable summary: {raw[:120]!r}")
        return summary
    except Exception as e:
        log_event(
            log,
            "summarization_error",
            level=logging.WARNING,
            error=str(e),
        )
        if allow_extractive:
            return _extractive_summary(segments, notes, enhanced)
        else:
            raise


def _summary_from_json(data: dict | None) -> MeetingSummary | None:
    """Build a summary from parsed JSON; None when it has no overview."""
    if not data:
        return None
    overview = data.get("overview")
    if not isinstance(overview, str) or not overview.strip():
        return None
    details = []
    for item in data.get("details") or []:
        if isinstance(item, dict):
            title, body = item.get("title"), item.get("body")
            if isinstance(body, str) and body.strip():
                details.append(SummaryDetail(title=str(title or "").strip(), body=body.strip()))
    return MeetingSummary(overview=overview.strip(), details=details)


def generate_meeting_title(
    llm: StreamingLLMProvider,
    segments: list[dict],
    notes: list[dict],
) -> str | None:
    """Generate a concise 3-8 word title from a meeting transcript.

    Returns None on failure; callers should treat that as "keep existing title".
    """
    transcript = " ".join(seg.get("text", "") for seg in segments).strip()
    if not transcript:
        # Fall back to notes text
        transcript = " ".join(note.get("text", "") for note in notes).strip()
    if not transcript:
        return None

    # Truncate to first 1000 chars so the title call is cheap
    excerpt = transcript[:1000]

    system_prompt = (
        "You are a meeting titler. Given a transcript excerpt, produce a concise title "
        "of 3 to 8 words that captures what the recording is about. "
        "Output ONLY valid JSON with a single field: {\"title\": \"...\"}. "
        "No markdown, no commentary."
    )

    try:
        parsed, raw = complete_json(llm, system_prompt, excerpt, max_tokens=64)
        if parsed and isinstance(parsed.get("title"), str):
            title = parsed["title"].strip()
            if title:
                return title
        log_event(log, "title_generation_unusable", level=logging.WARNING, raw=raw[:80])
    except Exception as exc:
        log_event(log, "title_generation_error", level=logging.WARNING, error=str(exc))
    return None


def _extractive_summary(
    segments: list[dict],
    notes: list[dict],
    enhanced: list[dict] | None = None,
) -> MeetingSummary:
    """Extractive fallback: pull key sentences."""
    overview = "Meeting summary:"
    if notes:
        overview = notes[0].get("text", "Meeting notes taken.")

    details = []
    for note in notes[:5]:
        text = note.get("text", "")
        if text:
            details.append(
                SummaryDetail(
                    title="Note",
                    body=text[:100],
                )
            )

    return MeetingSummary(overview=overview, details=details)
