"""Live transcriber with energy-based VAD and segment management."""

from __future__ import annotations

import logging
from collections import deque
from dataclasses import dataclass

from ..audio_providers import ASRProvider
from ..logging_config import get_logger, log_event

log = get_logger("voxscribe.meeting.live")


@dataclass(frozen=True)
class SpeechTransition:
    """A speech activity transition emitted to the live socket.

    speaking    True when speech started, False when it ended.
    at_ms       session-timeline millisecond where the transition applies.
    probability detector's probability at the frame that triggered it, or
                None when the energy gate (no detector) produced the event.
    detector    source name: "silero", "heuristic", "fake", or "energy".
    """

    speaking: bool
    at_ms: int
    probability: float | None
    detector: str


@dataclass
class Segment:
    """One transcribed segment (provisional or stable)."""

    id: str
    start_ms: int
    end_ms: int
    source: str  # "mic" or "system"
    speaker: str | None
    text: str
    state: str  # "provisional" or "stable"


class AutoStop:
    """Helper for auto-stopping after N minutes of silence."""

    def __init__(self, silence_minutes: int):
        self.silence_minutes = silence_minutes
        self.silence_start_ms = None

    def tick(self, is_speech: bool, elapsed_ms: int) -> bool:
        """Update silence tracker. Return True if should auto-stop."""
        if is_speech:
            self.silence_start_ms = None
            return False
        else:
            if self.silence_start_ms is None:
                self.silence_start_ms = elapsed_ms
            elapsed_silence_ms = elapsed_ms - self.silence_start_ms
            silence_threshold_ms = self.silence_minutes * 60 * 1000
            return elapsed_silence_ms >= silence_threshold_ms


class LiveTranscriber:
    """Live transcriber accepting PCM16 frames and emitting segments.

    Turn detection is energy based. Two gates are available:
      - "fixed": a frame is speech when its RMS is above `vad_threshold` (the original behaviour).
      - "adaptive": a frame is speech when its RMS is well above a running noise floor, so a quiet
        microphone or far-field speaker audio is still heard. Hysteresis keeps an utterance open
        through the dips between words.

    An utterance keeps every frame from its first speech frame (plus `pre_roll_ms` of audio from
    just before it) until `silence_duration_ms` of non-speech, so the recognizer hears continuous
    audio.
    An utterance longer than `max_segment_ms` is cut into a stable segment, which bounds both the
    partial re-decodes and the latency of stable text. Segment times are on the session timeline.
    """

    def __init__(
        self,
        asr_provider: ASRProvider,
        session_id: str,
        sample_rate: int = 16000,
        vad_threshold: float = 0.03,
        silence_duration_ms: int = 500,
        partial_update_interval_ms: int = 1000,
        vad_mode: str = "fixed",
        pre_roll_ms: int = 250,
        max_segment_ms: int | None = 15000,
        noise_floor_init: float = 0.005,
        speech_ratio: float = 2.0,
        release_ratio: float = 1.6,
        min_speech_rms: float = 0.002,
        energy_smoothing: float = 0.2,
        skip_partials_when_behind: bool = True,
        detector=None,
        policy=None,
    ):
        if vad_mode not in ("fixed", "adaptive", "detector"):
            raise ValueError(f"vad_mode must be 'fixed', 'adaptive', or 'detector', got {vad_mode!r}")
        self.asr = asr_provider
        self.session_id = session_id
        self.sample_rate = sample_rate
        self.vad_threshold = vad_threshold
        self.silence_duration_ms = silence_duration_ms
        self.partial_update_interval_ms = partial_update_interval_ms
        self.vad_mode = vad_mode
        self.pre_roll_ms = pre_roll_ms
        self.max_segment_ms = max_segment_ms
        self.speech_ratio = speech_ratio
        self.release_ratio = release_ratio
        self.min_speech_rms = min_speech_rms
        self.energy_smoothing = energy_smoothing
        self.skip_partials_when_behind = skip_partials_when_behind
        self._last_push_done: float | None = None  # monotonic time the previous push_audio returned
        self.noise_floor = noise_floor_init
        self.smoothed_rms: float | None = None

        self._detector = detector
        self._policy = policy
        if vad_mode == "detector" and detector is not None and policy is not None:
            from ..speech.policy import SpeechActivityTracker
            self._tracker = SpeechActivityTracker(policy, detector=detector.name)
            # pre_roll and silence window come from the policy
            self.pre_roll_ms = policy.pre_roll_ms
            self.silence_duration_ms = policy.hangover_ms
        else:
            self._tracker = None
        self._pending_transitions: list[SpeechTransition] = []
        self._last_speech_probability: float | None = None
        self._last_speech_probability_at_ms: int = 0

        self.segments: dict[str, Segment] = {}
        self.segment_counter = 0
        self.audio_buffer = deque()
        self.buffer_ms = 0  # length of audio_buffer in ms
        self.buffer_start_ms = 0  # session time of the first sample in audio_buffer
        self.pre_roll = deque()  # recent non-speech frames, for the start of the next utterance
        self.pre_roll_buffer_ms = 0
        self.in_speech = False
        self.silence_start_ms = None
        self.elapsed_ms = 0
        self.session_start_ms = 0
        self.echo_suppression_window_ms = 2000
        self.last_partial_update_ms = 0
        self.current_segment_id = None
        self.partial_segments: dict[str, Segment] = {}  # Track partials by id
        self._new_partials: dict[str, Segment] = {}  # changed since the last pop_partials()
        self.last_rms = 0.0

    def _is_speech(self, energy: float, frame_ms: int = 10) -> bool:
        """Decide one frame, and track the noise floor in adaptive mode.

        The adaptive rates are stated per 10 ms and scaled to the frame's length, so a client
        that sends 100 ms frames gets the same behaviour in time as one that sends 10 ms frames.
        """
        if self.vad_mode == "fixed":
            return energy > self.vad_threshold
        # Decide on a short running average (about 50 ms at 10 ms frames), not single frames, so the
        # floor is not dragged down by one quiet frame and the hangover sees real pauses.
        steps = max(1.0, frame_ms / 10)
        if self.smoothed_rms is None:
            self.smoothed_rms = energy
        self.smoothed_rms += (energy - self.smoothed_rms) * (
            1 - (1 - self.energy_smoothing) ** steps
        )
        energy = self.smoothed_rms
        # The floor follows quiet stretches down quickly and rises slowly (about 0.4 dB a second at
        # 10 ms frames, 0.2 dB while speech goes on), so a steady background becomes the floor but
        # a long utterance does not lift the floor into the speech.
        if energy < self.noise_floor:
            self.noise_floor += (energy - self.noise_floor) * (1 - 0.95**steps)
        else:
            self.noise_floor *= (1.0002 if self.in_speech else 1.0005) ** steps
        self.noise_floor = max(self.noise_floor, 1e-5)
        ratio = self.release_ratio if self.in_speech else self.speech_ratio
        return energy > self.min_speech_rms and energy > self.noise_floor * ratio

    @property
    def detector_name(self) -> str:
        """Short name of the active detector: the detector name or 'energy'."""
        if self._detector is not None:
            return self._detector.name
        return "energy"

    @property
    def policy(self):
        """The SpeechPolicy used in detector mode, else None."""
        return self._policy

    @property
    def speech_probability(self) -> float | None:
        """Latest per-frame speech probability from the detector, or None."""
        return self._last_speech_probability

    @property
    def speech_probability_at_ms(self) -> int:
        """Session-timeline ms of the frame that produced speech_probability."""
        return self._last_speech_probability_at_ms

    def push_audio(self, source_tag: int, frame: bytes) -> list[Segment]:
        """Push PCM16 audio frame (source_tag: 0=mic, 1=system).

        Returns: list of newly stable segments from this push.
        For partial segments, use pop_partials() (or get_pending_partials()) after calling this.
        """
        import array
        import time

        arrived = time.monotonic()
        source = "mic" if source_tag == 0 else "system"
        samples = array.array("h", frame)
        if not samples:
            return []
        try:
            return self._push(source, samples, arrived)
        finally:
            self._last_push_done = time.monotonic()

    def _push(self, source: str, samples, arrived: float) -> list[Segment]:
        import math
        import sys

        # Only swap on big-endian hosts; input is little-endian PCM16
        if sys.byteorder == "big":
            samples.byteswap()
        float_samples = [s / 32768.0 for s in samples]

        energy = math.sqrt(sum(s * s for s in float_samples) / len(float_samples))
        self.last_rms = energy
        frame_ms = len(samples) * 1000 // self.sample_rate
        frame_start_ms = self.elapsed_ms

        if self._tracker is not None and self._detector is not None:
            behind = (
                self.skip_partials_when_behind
                and self._last_push_done is not None
                and (arrived - self._last_push_done) * 1000 < frame_ms / 2
            )
            self.elapsed_ms += frame_ms
            return self._push_with_detector(source, float_samples, frame_ms, behind, frame_start_ms)

        is_speech = self._is_speech(energy, frame_ms)
        frame_start_ms = self.elapsed_ms
        # Frames that follow the previous one much faster than real time are a backlog (they queued
        # while a decode ran). Partial decodes wait until it is drained, or they would keep the
        # transcriber behind the speaker for the rest of the session.
        behind = (
            self.skip_partials_when_behind
            and self._last_push_done is not None
            and (arrived - self._last_push_done) * 1000 < frame_ms / 2
        )
        self.elapsed_ms += frame_ms

        new_stable: list[Segment] = []
        if is_speech:
            self.silence_start_ms = None
            if not self.in_speech:
                # A new utterance starts with the audio just before it (soft onsets survive).
                self.in_speech = True
                self.audio_buffer = self.pre_roll
                self.buffer_ms = self.pre_roll_buffer_ms
                self.buffer_start_ms = frame_start_ms - self.pre_roll_buffer_ms
                self.pre_roll = deque()
                self.pre_roll_buffer_ms = 0
        elif self.in_speech and self.silence_start_ms is None:
            self.silence_start_ms = frame_start_ms

        if self.in_speech:
            # Every frame of an utterance is kept, quiet ones too: the recognizer needs
            # continuous audio.
            self.audio_buffer.append(float_samples)
            self.buffer_ms += frame_ms
            if (
                self.silence_start_ms is not None
                and self.elapsed_ms - self.silence_start_ms > self.silence_duration_ms
            ):
                new_stable = self._finalize_segment(source)
                self._end_utterance()
            elif self.max_segment_ms and self.buffer_ms >= self.max_segment_ms:
                # Long continuous speech: publish what we have and carry on in a new segment.
                new_stable = self._finalize_segment(source)
                self.current_segment_id = None
                self.partial_segments.clear()
                self.buffer_start_ms = self.elapsed_ms
                self.last_partial_update_ms = self.elapsed_ms
            elif (
                is_speech
                and not behind
                and self.elapsed_ms - self.last_partial_update_ms
                >= self.partial_update_interval_ms
            ):
                self._update_partials(source)
        else:
            self.pre_roll.append(float_samples)
            self.pre_roll_buffer_ms += frame_ms
            while self.pre_roll and (
                self.pre_roll_buffer_ms - self._frame_ms(self.pre_roll[0]) >= self.pre_roll_ms
            ):
                self.pre_roll_buffer_ms -= self._frame_ms(self.pre_roll.popleft())
            if self.pre_roll_ms <= 0:
                self.pre_roll.clear()
                self.pre_roll_buffer_ms = 0

        return new_stable

    def _push_with_detector(
        self, source: str, float_samples: list, frame_ms: int, behind: bool, frame_start_ms: int
    ) -> list[Segment]:
        import numpy as np

        float32 = np.array(float_samples, dtype=np.float32)
        det_frames = self._detector.process(float32)

        if det_frames:
            last = det_frames[-1]
            self._last_speech_probability = last.probability
            self._last_speech_probability_at_ms = last.end_ms

        events = self._tracker.feed(det_frames) if det_frames else []
        for ev in events:
            self._pending_transitions.append(
                SpeechTransition(
                    speaking=(ev.kind == "started"),
                    at_ms=ev.at_ms,
                    probability=ev.probability,
                    detector=ev.detector,
                )
            )

        is_speech = self._tracker.speaking
        had_ended = any(ev.kind == "ended" for ev in events)

        new_stable: list[Segment] = []

        if is_speech:
            self.silence_start_ms = None
            if not self.in_speech:
                self.in_speech = True
                self.audio_buffer = self.pre_roll
                self.buffer_ms = self.pre_roll_buffer_ms
                self.buffer_start_ms = frame_start_ms - self.pre_roll_buffer_ms
                self.pre_roll = deque()
                self.pre_roll_buffer_ms = 0

        if self.in_speech:
            self.audio_buffer.append(float_samples)
            self.buffer_ms += frame_ms
            if had_ended:
                # Tracker already applied hangover; finalize immediately
                new_stable = self._finalize_segment(source)
                self._end_utterance()
            elif self.max_segment_ms and self.buffer_ms >= self.max_segment_ms:
                new_stable = self._finalize_segment(source)
                self.current_segment_id = None
                self.partial_segments.clear()
                self.buffer_start_ms = self.elapsed_ms
                self.last_partial_update_ms = self.elapsed_ms
            elif (
                is_speech
                and not behind
                and self.elapsed_ms - self.last_partial_update_ms >= self.partial_update_interval_ms
            ):
                self._update_partials(source)
        else:
            self.pre_roll.append(float_samples)
            self.pre_roll_buffer_ms += frame_ms
            while self.pre_roll and (
                self.pre_roll_buffer_ms - self._frame_ms(self.pre_roll[0]) >= self.pre_roll_ms
            ):
                self.pre_roll_buffer_ms -= self._frame_ms(self.pre_roll.popleft())
            if self.pre_roll_ms <= 0:
                self.pre_roll.clear()
                self.pre_roll_buffer_ms = 0

        return new_stable

    def pop_speech_transitions(self) -> list[SpeechTransition]:
        """Speech activity transitions since the last call, each returned once."""
        result = self._pending_transitions[:]
        self._pending_transitions.clear()
        return result

    def close(self) -> list[Segment]:
        """Finalize buffered audio and log a session summary."""
        tail = self.flush()
        if self._tracker is not None:
            summary = self._tracker.summary()
            log_event(
                log,
                "session_summary",
                level=logging.INFO,
                session_id=self.session_id,
                audio_seconds=round(self.elapsed_ms / 1000, 1),
                mode=self.vad_mode,
                detector=self.detector_name,
                seconds_speech=summary.get("seconds_speech"),
                starts=summary.get("starts"),
            )
        else:
            log_event(
                log,
                "session_summary",
                level=logging.INFO,
                session_id=self.session_id,
                audio_seconds=round(self.elapsed_ms / 1000, 1),
                segments=self.segment_counter,
                mode=self.vad_mode,
                detector=self.detector_name,
            )
        return tail

    def _frame_ms(self, frame) -> int:
        return len(frame) * 1000 // self.sample_rate

    def _end_utterance(self) -> None:
        self.in_speech = False
        self.silence_start_ms = None
        self.current_segment_id = None
        self.partial_segments.clear()
        self.audio_buffer = deque()
        self.buffer_ms = 0

    def _buffer_samples(self) -> list[float]:
        samples: list[float] = []
        for frame in self.audio_buffer:
            samples.extend(frame)
        return samples

    def _update_partials(self, source: str) -> None:
        """Re-decode the current utterance and emit a partial segment update."""
        import time

        samples = self._buffer_samples()
        if not samples:
            return
        base_ms = self.buffer_start_ms
        started_at_ms = self.elapsed_ms
        started = time.monotonic()
        try:
            chunks = self.asr.transcribe(samples, self.sample_rate, self.session_id)
            text = " ".join(c.text.strip() for c in chunks if c.text and c.text.strip())
            if text:
                # The same id for every partial of this utterance; the stable segment reuses it.
                if self.current_segment_id is None:
                    self.current_segment_id = f"{self.session_id}#{self.segment_counter}"
                    self.segment_counter += 1
                previous = self.partial_segments.get(self.current_segment_id)
                start_ms = base_ms + int(chunks[0].t_start_ms or 0)
                partial = Segment(
                    id=self.current_segment_id,
                    start_ms=start_ms,
                    end_ms=max(start_ms, self.elapsed_ms),
                    source=source,
                    speaker=None,
                    text=text,
                    state="provisional",
                )
                self.partial_segments[self.current_segment_id] = partial
                if previous is None or previous.text != partial.text:
                    self._new_partials[partial.id] = partial
        except Exception as e:
            log_event(
                log,
                "partial_transcription_error",
                level=logging.WARNING,
                error=str(e),
            )
        # The next partial starts one interval after this one started, or once this decode's own
        # length has passed if it was slower, so slow decodes run back to back but never pile up.
        spent_ms = int((time.monotonic() - started) * 1000)
        overrun_ms = max(0, spent_ms - self.partial_update_interval_ms)
        self.last_partial_update_ms = started_at_ms + overrun_ms

    def flush(self) -> list[Segment]:
        """Finalize any buffered audio at session end. Returns newly stable segments."""
        if not self.audio_buffer:
            return []
        stable = self._finalize_segment("mic")
        self._end_utterance()
        return stable

    def get_pending_partials(self) -> list[Segment]:
        """The current partial segments (kept until their utterance is finalized)."""
        return list(self.partial_segments.values())

    def pop_partials(self) -> list[Segment]:
        """Partial segments whose text changed since the last call, each returned once."""
        result = list(self._new_partials.values())
        self._new_partials.clear()
        return result

    def _finalize_segment(self, source: str) -> list[Segment]:
        """Finalize the current audio buffer into segments on the session timeline."""
        if not self.audio_buffer:
            return []

        samples = self._buffer_samples()
        base_ms = self.buffer_start_ms
        end_of_buffer_ms = base_ms + len(samples) * 1000 // self.sample_rate
        self.audio_buffer = deque()
        self.buffer_ms = 0
        self._new_partials.clear()

        if not samples:
            return []

        try:
            chunks = self.asr.transcribe(samples, self.sample_rate, self.session_id)
            new_segments = []
            reuse_id = self.current_segment_id  # the first stable segment replaces the partial line
            for chunk in chunks:
                if not chunk.text or not chunk.text.strip():
                    continue
                if reuse_id:
                    seg_id, reuse_id = reuse_id, None
                else:
                    seg_id = f"{self.session_id}#{self.segment_counter}"
                    self.segment_counter += 1
                start_ms = base_ms + int(chunk.t_start_ms or 0)
                end_ms = end_of_buffer_ms
                if chunk.t_end_ms:
                    end_ms = min(base_ms + int(chunk.t_end_ms), end_of_buffer_ms)
                seg = Segment(
                    id=seg_id,
                    start_ms=start_ms,
                    end_ms=max(start_ms, end_ms),
                    source=source,
                    speaker=None,
                    text=chunk.text.strip(),
                    state="stable",
                )
                self.segments[seg_id] = seg
                new_segments.append(seg)

            self._suppress_echoes(new_segments, source)
            return new_segments
        except Exception as e:
            log_event(
                log,
                "transcription_error",
                level=logging.WARNING,
                error=str(e),
            )
            return []

    def flush(self, source_tag: int = 0) -> list[Segment]:
        """Finalize whatever utterance is open (for example when the recording stops)."""
        if not self.in_speech:
            return []
        out = self._finalize_segment("mic" if source_tag == 0 else "system")
        self._end_utterance()
        return out

    def _suppress_echoes(self, new_segs: list[Segment], source: str) -> None:
        """Suppress near-duplicate speech between mic and system sources."""
        if source != "system":
            return

        other_source = "mic"
        for seg in new_segs:
            for other_id, other_seg in list(self.segments.items()):
                if (
                    other_seg.source == other_source
                    and abs(other_seg.start_ms - seg.start_ms) < self.echo_suppression_window_ms
                    and self._similar_text(seg.text, other_seg.text)
                ):
                    del self.segments[other_id]
                    log_event(
                        log,
                        "echo_suppressed",
                        other_id=other_id,
                        new_id=seg.id,
                    )

    def _similar_text(self, text1: str, text2: str, ratio: float = 0.8) -> bool:
        """Check if two texts are similar (Jaccard > ratio)."""
        words1 = set(text1.lower().split())
        words2 = set(text2.lower().split())
        if not words1 or not words2:
            return False
        intersection = len(words1 & words2)
        union = len(words1 | words2)
        return intersection / union >= ratio

    def get_segment(self, segment_id: str) -> Segment | None:
        """Get a segment by ID."""
        return self.segments.get(segment_id)

    def list_segments(self) -> list[Segment]:
        """List all segments."""
        return list(self.segments.values())
