"""Audio front-end: noise robustness lives here, not in the text layer.

The honest engineering answer to "handle traffic, plant floor, driving, poor
mic" is a three-stage front-end before any text exists:

  1. Denoise   suppress steady and transient background noise on the raw PCM
  2. VAD gate  decide what is speech vs noise, drop the rest, find utterance ends
  3. Robust ASR Parakeet v3 is trained on noisy far-field speech and degrades
                gracefully; the cloud tier (ElevenLabs Scribe) is the fallback
                when local accuracy is not enough in extreme noise

This module owns stages 1 and 2 as testable logic plus a clean interface. The
real DSP for the denoiser runs in the native audio thread (or a sidecar). The
text post-processor adds a final, smaller safety net via the noise rule in its
prompt: it drops obvious mis-hears without inventing words.

Recommended denoiser implementations (swap behind the Denoiser protocol):
  - DeepFilterNet: real-time, CPU-friendly, strong on non-stationary noise
    (good for traffic and plant floor). Apache 2.0.
  - RNNoise: tiny and fast, good for steady noise and mic hiss.
  - Silero denoiser: pairs naturally with Silero VAD.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Protocol

from .speech.detector import SpeechFrame
from .speech.policy import NoiseProfile, SpeechActivityTracker, SpeechPolicy

__all__ = [
    "Denoiser",
    "NoiseProfile",
    "PassthroughDenoiser",
    "VADConfig",
    "VADGate",
    "config_for",
]


class Denoiser(Protocol):
    """Processes one PCM chunk and returns a denoised chunk of the same size."""

    def process(self, samples: list[float], sample_rate: int) -> list[float]: ...


class PassthroughDenoiser:
    """No-op default. Replace with DeepFilterNet or RNNoise in the host app."""

    def process(self, samples: list[float], sample_rate: int) -> list[float]:
        return samples


@dataclass
class VADConfig:
    """VAD gate tuning. Raise thresholds in noisy environments so background
    energy does not falsely trigger speech."""

    chunk_ms: int = 32  # one audio chunk, matches a 512-sample frame at 16k
    start_threshold: float = 0.5  # prob to begin counting toward speech
    end_threshold: float = 0.35  # prob below which we count toward silence
    start_chunks: int = 2  # consecutive chunks above start_threshold
    end_silence_ms: int = 1500  # trailing silence that ends an utterance


def config_for(profile: NoiseProfile) -> VADConfig:
    """VAD settings for an environment. `NoiseProfile` now lives in
    `voxscribe.speech.policy` and is re-exported here; the numbers below are
    the originals, and `SpeechPolicy.for_noise` carries the same shifts."""
    if profile is NoiseProfile.QUIET:
        return VADConfig(start_threshold=0.45, end_threshold=0.30)
    if profile is NoiseProfile.OFFICE:
        return VADConfig(start_threshold=0.50, end_threshold=0.35)
    if profile is NoiseProfile.MOBILE:
        # More trailing silence so road noise gaps do not cut utterances short.
        return VADConfig(start_threshold=0.60, end_threshold=0.45, end_silence_ms=1800)
    # PLANT_FLOOR: hardest case. Demand strong, sustained speech to trigger.
    return VADConfig(start_threshold=0.70, end_threshold=0.55, start_chunks=3, end_silence_ms=2000)


def policy_for(config: VADConfig) -> SpeechPolicy:
    """Express a `VADConfig` as a `SpeechPolicy` with identical decisions.

    `start_chunks` becomes `start_frames` (with `start_ms` 0 so the count
    alone decides, as before) and `end_silence_ms` becomes `hangover_ms`,
    which the tracker rounds up to whole chunks exactly as the old gate did.
    """
    return SpeechPolicy(
        name="vad_gate",
        start_threshold=config.start_threshold,
        end_threshold=min(config.end_threshold, config.start_threshold),
        start_ms=0,
        start_frames=max(1, config.start_chunks),
        hangover_ms=max(1, config.end_silence_ms),
    )


class VADGate:
    """Hysteresis gate over per-chunk speech probabilities.

    Feed it the Silero VAD probability for each chunk. It emits "speech_start"
    when speech begins and "speech_end" when an utterance completes, so the
    host knows exactly when to flush accumulated audio to the ASR. Pure logic,
    no audio, fully testable.

    Compatibility layer: since 0.2.0 the decisions come from
    `voxscribe.speech.SpeechActivityTracker` with the policy `policy_for(cfg)`;
    the public API and behaviour of this class are unchanged. New code should
    use the tracker and `SpeechEvent` directly.
    """

    def __init__(self, config: VADConfig | None = None):
        self.cfg = config or VADConfig()
        self._end_silence_chunks = max(1, math.ceil(self.cfg.end_silence_ms / self.cfg.chunk_ms))
        self._tracker = SpeechActivityTracker(policy_for(self.cfg), detector="external")
        self._chunks = 0

    def process(self, prob: float) -> str | None:
        self._chunks += 1
        frame = SpeechFrame(end_ms=self._chunks * self.cfg.chunk_ms, probability=prob)
        event = self._tracker.process(frame)
        if event is None:
            return None
        return "speech_start" if event.kind == "started" else "speech_end"

    @property
    def speaking(self) -> bool:
        return self._tracker.speaking

    @property
    def tracker(self) -> SpeechActivityTracker:
        """The underlying tracker, for a per-stream summary or a reset."""
        return self._tracker
