"""Two-stage wake gate: detector patience, then a voice check, then a recognizer confirm.

The old trigger started a session when one 80 ms frame scored 0.5 (ROOT-CAUSE Defect A item 1).
This gate asks three questions in order of cost, and stops at the first "no":

  stage 1  patience    did the detector score at or above threshold on enough consecutive frames?
  stage 2a voice       is at least MIN_SPEECH_RATIO of the last second human voice (Silero)?
  stage 2b confirm     does a short recognizer pass over the last 2 s contain the phrase?

Every candidate that reaches a verdict is returned as a `WakeDecision`, accepted or with a
reject reason, so the host can record it. An accepted decision carries the audio heard after the
phrase ended (`pre_roll`) so "hey vox, what time is it" in one breath keeps its question.

The gate is synchronous and pure: the detector, the voice check and the recognizer are injected,
and time is the stream sample count, never a wall clock. Hosts call `process()` once per 80 ms
frame off the event loop; a candidate frame takes as long as the recognizer pass.
"""
from __future__ import annotations

import logging
from collections.abc import Callable, Collection, Mapping, Sequence
from dataclasses import dataclass, field
from enum import Enum

import numpy as np

from ..models import WordTiming
from ..session.ports import WakeDetector
from .phrase import DEFAULT_ALIASES, match_phrase

log = logging.getLogger("voxscribe.wake.gate")

SAMPLE_RATE = 16_000
FRAME_SAMPLES = 1_280            # 80 ms, the openWakeWord frame and the gate's unit of time

DETECT_THRESHOLD = 0.5           # stage 1 score at or above this counts toward patience
PATIENCE_FRAMES = 2              # consecutive frames for a frame-classifier detector
MIN_SPEECH_RATIO = 0.3           # fraction of the voice window that must be speech
ASR_CONFIRM_PHRASE = "hey vox"   # what the recognizer confirm listens for
RING_S = 3.0                     # audio kept for the voice check, the confirm and the pre-roll
VOICE_WINDOW_S = 1.0             # window for the voice check, ending at the candidate frame
CONFIRM_WINDOW_S = 2.0           # window for the recognizer confirm, ending at the candidate frame
REFRACTORY_S = 2.0               # no new candidate this soon after a verdict
TELEMETRY_PERIOD_S = 60.0        # one peak-score summary per this much audio

VoiceRatio = Callable[[np.ndarray], float]
Transcribe = Callable[[np.ndarray], Sequence[WordTiming]]


class RejectReason(str, Enum):
    PATIENCE = "patience"            # crossed threshold, fell back before PATIENCE frames
    NO_VOICE = "no_voice"            # voice check below MIN_SPEECH_RATIO
    NO_TEXT = "no_text"              # recognizer heard no words
    NO_MATCH = "no_match"            # recognizer heard words, not the phrase
    CONFIRM_ERROR = "confirm_error"  # recognizer raised; fail closed


@dataclass(frozen=True)
class GateConfig:
    threshold: float = DETECT_THRESHOLD
    min_speech_ratio: float = MIN_SPEECH_RATIO
    phrase: str = ASR_CONFIRM_PHRASE
    aliases: Mapping[str, Collection[str]] = field(default_factory=lambda: DEFAULT_ALIASES)
    ring_s: float = RING_S
    voice_window_s: float = VOICE_WINDOW_S
    confirm_window_s: float = CONFIRM_WINDOW_S
    refractory_s: float = REFRACTORY_S
    telemetry_period_s: float = TELEMETRY_PERIOD_S
    sample_rate: int = SAMPLE_RATE
    frame_samples: int = FRAME_SAMPLES


@dataclass(frozen=True)
class WakeDecision:
    """One candidate's verdict. Positions are absolute samples on the gate's stream timeline."""

    accepted: bool
    score: float
    detector: str
    at_sample: int
    reason: RejectReason | None = None
    speech_ratio: float | None = None
    phrase_end_sample: int | None = None
    pre_roll: np.ndarray = field(default_factory=lambda: np.zeros(0, dtype=np.float32))

    @property
    def reject_reason(self) -> str | None:
        return self.reason.value if self.reason is not None else None


@dataclass(frozen=True)
class TelemetryWindow:
    peak_score: float
    peak_rms: float
    frames: int


class AudioRing:
    """The last `seconds` of mono float32 audio on an absolute sample timeline."""

    def __init__(self, seconds: float, sample_rate: int = SAMPLE_RATE) -> None:
        self._cap = max(1, int(round(seconds * sample_rate)))
        self._sr = sample_rate
        self._buf = np.zeros(self._cap, dtype=np.float32)
        self._end = 0      # absolute samples ever appended
        self._held = 0     # samples currently held, at most _cap

    @property
    def end_sample(self) -> int:
        return self._end

    @property
    def start_sample(self) -> int:
        return self._end - self._held

    def append(self, x: np.ndarray) -> None:
        x = np.asarray(x, dtype=np.float32).reshape(-1)
        n = x.shape[0]
        if n >= self._cap:
            self._buf[:] = x[-self._cap:]
            # Rotate so the write position stays consistent with _end.
            self._buf = np.roll(self._buf, (self._end + n) % self._cap)
        else:
            pos = self._end % self._cap
            first = min(n, self._cap - pos)
            self._buf[pos: pos + first] = x[:first]
            if first < n:
                self._buf[: n - first] = x[first:]
        self._end += n
        self._held = min(self._cap, self._held + n)

    def since(self, start_sample: int) -> np.ndarray:
        """Audio from absolute `start_sample` to now, clamped to what is held."""
        start = max(start_sample, self.start_sample)
        n = self._end - start
        if n <= 0:
            return np.zeros(0, dtype=np.float32)
        idx = (np.arange(start, self._end) % self._cap)
        return self._buf[idx].copy()

    def last_seconds(self, seconds: float) -> np.ndarray:
        return self.since(self._end - int(round(seconds * self._sr)))

    def clear(self) -> None:
        """Drop the held audio; the timeline keeps counting."""
        self._held = 0


class WakeGate:
    """Feed 80 ms frames; get a `WakeDecision` whenever a candidate reaches a verdict."""

    def __init__(
        self,
        detector: WakeDetector,
        *,
        voice_ratio: VoiceRatio | None,
        transcribe: Transcribe | None,
        config: GateConfig | None = None,
    ) -> None:
        self.detector = detector
        self.config = config or GateConfig()
        self._voice_ratio = voice_ratio
        self._transcribe = transcribe
        self._patience = max(1, int(detector.patience_frames))
        self._refractory_frames = int(round(
            self.config.refractory_s * self.config.sample_rate / self.config.frame_samples))
        self._telemetry_frames = int(round(
            self.config.telemetry_period_s * self.config.sample_rate / self.config.frame_samples))
        self.ring = AudioRing(self.config.ring_s, self.config.sample_rate)
        self._run = 0
        self._run_peak = 0.0
        self._fired = False
        self._cooldown = 0
        self._tele_peak = 0.0
        self._tele_rms = 0.0
        self._tele_frames = 0
        self._tele_ready: TelemetryWindow | None = None

    # ------------------------------------------------------------------ public

    def process(self, frame: np.ndarray) -> WakeDecision | None:
        frame = np.asarray(frame, dtype=np.float32).reshape(-1)
        if frame.shape[0] != self.config.frame_samples:
            raise ValueError(f"wake gate expects {self.config.frame_samples} samples per frame, "
                             f"got {frame.shape[0]}")
        self.ring.append(frame)
        score = float(self.detector.score(frame))
        self._observe(score, float(np.sqrt(np.mean(frame ** 2))))
        in_cooldown = self._cooldown > 0
        if in_cooldown:
            self._cooldown -= 1

        if score >= self.config.threshold:
            self._run += 1
            self._run_peak = max(self._run_peak, score)
            if self._run >= self._patience and not self._fired:
                # One verdict per run; a run inside the refractory window is the same utterance.
                self._fired = True
                if in_cooldown:
                    return None
                decision = self._evaluate(self._run_peak)
                self._cooldown = self._refractory_frames
                return decision
            return None

        run, peak, fired = self._run, self._run_peak, self._fired
        self._run, self._run_peak, self._fired = 0, 0.0, False
        if run > 0 and not fired:
            return WakeDecision(accepted=False, score=peak, detector=self.detector.model_name,
                                at_sample=self.ring.end_sample, reason=RejectReason.PATIENCE)
        return None

    def reset(self) -> None:
        """Start fresh after a session: detector state, held audio and patience run are dropped."""
        self.detector.reset()
        self.ring.clear()
        self._run, self._run_peak, self._fired = 0, 0.0, False
        self._cooldown = 0

    def pop_telemetry(self) -> TelemetryWindow | None:
        """The summary of the last completed period, once."""
        out, self._tele_ready = self._tele_ready, None
        return out

    # ------------------------------------------------------------------ internal

    def _observe(self, score: float, rms: float) -> None:
        self._tele_peak = max(self._tele_peak, score)
        self._tele_rms = max(self._tele_rms, rms)
        self._tele_frames += 1
        if self._tele_frames >= self._telemetry_frames:
            self._tele_ready = TelemetryWindow(self._tele_peak, self._tele_rms, self._tele_frames)
            self._tele_peak, self._tele_rms, self._tele_frames = 0.0, 0.0, 0

    def _evaluate(self, score: float) -> WakeDecision:
        cfg = self.config
        at = self.ring.end_sample
        name = self.detector.model_name

        ratio: float | None = None
        if self._voice_ratio is not None:
            ratio = float(self._voice_ratio(self.ring.last_seconds(cfg.voice_window_s)))
            if ratio < cfg.min_speech_ratio:
                return WakeDecision(False, score, name, at, RejectReason.NO_VOICE, ratio)

        if self._transcribe is None:
            return WakeDecision(True, score, name, at, None, ratio, phrase_end_sample=at)

        window = self.ring.last_seconds(cfg.confirm_window_s)
        window_start = self.ring.end_sample - window.shape[0]
        try:
            words = list(self._transcribe(window))
        except Exception as exc:  # noqa: BLE001 - any recognizer failure must fail closed
            log.warning("wake confirm failed: %s", type(exc).__name__)
            return WakeDecision(False, score, name, at, RejectReason.CONFIRM_ERROR, ratio)
        if not words:
            return WakeDecision(False, score, name, at, RejectReason.NO_TEXT, ratio)
        match = match_phrase(words, cfg.phrase, cfg.aliases)
        if match is None:
            return WakeDecision(False, score, name, at, RejectReason.NO_MATCH, ratio)

        phrase_end = window_start + int(round(match.end_ms * cfg.sample_rate / 1000))
        phrase_end = min(max(phrase_end, window_start), at)
        return WakeDecision(True, score, name, at, None, ratio, phrase_end_sample=phrase_end,
                            pre_roll=self.ring.since(phrase_end))
