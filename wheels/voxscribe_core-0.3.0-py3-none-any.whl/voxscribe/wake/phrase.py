"""Phonetic phrase match for the recognizer confirm step of the wake gate.

A short recognizer pass over the 2 s before a candidate rarely spells an unusual name the way the
profile does: "hey vox" comes back as "Hey Vox", "Hey, Max!", "pay box", "K-Vox" or "Hey voice".
Exact string comparison would reject most real wakes, and a loose edit distance would accept
"hey what's up". The rule here sits between the two:

* the name (last word of the phrase) must rhyme with a transcript word: the same phonetic key from
  the first vowel on, so the onset consonant may differ (v, f, b, m are the confusions observed),
  or be listed in `aliases` for that phrase;
* each lead word ("hey") must loosely match the word before it: the same rime, or a single
  letter, or be missing because the window started after it;
* or one transcript word carries the whole phrase run together ("Heyvox").

The key is a deliberately small consonant-class code, not a full phonetic algorithm: vowels
collapse to one symbol, voiced and unvoiced pairs share a class, and the silent letters that show
up in the observed mishearings (final e, the l in "walks") are dropped.
"""
from __future__ import annotations

import re
from collections.abc import Collection, Mapping, Sequence
from dataclasses import dataclass

from ..models import WordTiming

_VOWEL = "A"
_VOWELS = frozenset("aeiouy")
_CLASSES = {
    "b": "P", "p": "P",
    "f": "F", "v": "F", "w": "F",
    "c": "K", "g": "K", "k": "K", "q": "K",
    "s": "S", "z": "S",
    "d": "T", "t": "T",
    "m": "N", "n": "N",
    "l": "L", "r": "R", "j": "J",
}
_MIN_RIME = 2          # a name rime shorter than this ("A") would match almost any word

# Recognizer confusions that do not rhyme, observed on synthetic voices with Whisper base.en
# (T02 bake-off: Flo and Reed voices). Keyed by phrase so a renamed assistant starts empty.
DEFAULT_ALIASES: Mapping[str, Collection[str]] = {"hey vox": ("voice",)}


@dataclass(frozen=True)
class PhraseMatch:
    """Where the phrase was heard, on the timeline of the words passed in."""

    start_ms: float
    end_ms: float


def _letters(word: str) -> str:
    return re.sub(r"[^a-z]", "", word.lower())


def phonetic_key(word: str) -> str:
    """Consonant-class key: "vox" -> "FAKS", "Max" -> "NAKS", "voice" -> "FAS"."""
    w = _letters(word)
    if not w:
        return ""
    w = w.replace("ph", "f").replace("ck", "k").replace("x", "ks").replace("qu", "kw")
    w = re.sub(r"c(?=[eiy])", "s", w)
    w = re.sub(r"lk", "k", w)                  # walk, folk, talk
    if len(w) > 2 and w.endswith("e"):         # silent final e
        w = w[:-1]
    out: list[str] = []
    for ch in w:
        code = _VOWEL if ch in _VOWELS else _CLASSES.get(ch, "")
        if code and (not out or out[-1] != code):
            out.append(code)
    return "".join(out)


def _rime(key: str) -> str:
    i = key.find(_VOWEL)
    return key[i:] if i >= 0 else key


def _tokens(words: Sequence[WordTiming]) -> list[tuple[str, WordTiming]]:
    out: list[tuple[str, WordTiming]] = []
    for w in words:
        for part in re.split(r"[^A-Za-z]+", w.word):
            if part:
                out.append((part.lower(), w))
    return out


def match_phrase(
    words: Sequence[WordTiming],
    phrase: str,
    aliases: Mapping[str, Collection[str]] | None = None,
) -> PhraseMatch | None:
    """Return where `phrase` was heard in `words`, or None."""
    phrase_tokens = [t for t in (_letters(p) for p in phrase.split()) if t]
    if not phrase_tokens:
        return None
    alias_set = {_letters(a) for a in (aliases if aliases is not None else DEFAULT_ALIASES)
                 .get(" ".join(phrase_tokens), ())}
    name, lead = phrase_tokens[-1], phrase_tokens[:-1]
    name_rime = _rime(phonetic_key(name))
    joined_rime = _rime(phonetic_key("".join(phrase_tokens)))

    def name_ok(tok: str) -> bool:
        r = _rime(phonetic_key(tok))
        return tok in alias_set or (len(name_rime) >= _MIN_RIME and r == name_rime)

    def lead_ok(tok: str, want: str) -> bool:
        return len(tok) == 1 or _rime(phonetic_key(tok)) == _rime(phonetic_key(want))

    toks = _tokens(words)
    for i, (tok, timing) in enumerate(toks):
        if lead and len(tok) > len(name) and _rime(phonetic_key(tok)) == joined_rime:
            return PhraseMatch(start_ms=timing.t_start_ms, end_ms=timing.t_end_ms)
        if not name_ok(tok):
            continue
        start = timing.t_start_ms
        ok = True
        for j, want in enumerate(reversed(lead), start=1):
            if i - j < 0:
                break                       # the window began after the lead words
            prev_tok, prev_timing = toks[i - j]
            if not lead_ok(prev_tok, want):
                ok = False
                break
            start = prev_timing.t_start_ms
        if ok:
            return PhraseMatch(start_ms=start, end_ms=timing.t_end_ms)
    return None
