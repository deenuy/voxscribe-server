# wake: gate with patience, voice check and recognizer confirm. Implemented in T02.
