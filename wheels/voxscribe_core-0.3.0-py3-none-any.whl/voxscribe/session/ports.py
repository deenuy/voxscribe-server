"""Ports: the Protocols the engine calls and a host implements with adapters.

Section 3 of the delivery plan names ten ports. T02 defines `WakeDetector`; the others land with
the session runtime in T08. This module imports nothing from a server, a database driver, a sound
library or a platform call, and nothing at runtime beyond the standard library.
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Protocol, runtime_checkable

if TYPE_CHECKING:  # numpy is only needed by callers that pass arrays
    import numpy as np


@runtime_checkable
class WakeDetector(Protocol):
    """Stage 1 of the wake gate: a cheap, always-on scorer for one wake phrase.

    `patience_frames` is how many consecutive frames at or above the gate threshold this detector
    needs before the gate spends a voice check and a recognizer pass on it. A frame classifier
    that emits a fresh probability every 80 ms (openWakeWord) uses the gate default; a keyword
    spotter that emits one event per decoded phrase, after its own search over many frames,
    uses 1.
    """

    model_name: str
    patience_frames: int

    def reset(self) -> None:
        """Forget all buffered audio and internal state."""
        ...

    def score(self, pcm_float32_mono: np.ndarray) -> float:
        """Score one 80 ms frame. Returns 0.0..1.0."""
        ...
