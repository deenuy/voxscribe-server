"""Profile loader: reads a YAML file and returns a validated Profile.

Unknown top-level keys and unknown sub-config keys are silently ignored so that
a profile written for a later schema version can still load on an older build.
"""

from __future__ import annotations

import dataclasses
from pathlib import Path
from typing import Any

import yaml

from voxscribe.profile.schema import (
    EnrollmentConfig,
    GateConfig,
    NetworkConfig,
    Profile,
    ProfileValidationError,
    ReplyConfig,
    WakeConfig,
)

_BUILTIN_PROFILES_DIR = Path(__file__).parent / "profiles"

_SUB_CONFIG_MAP: dict[str, type] = {
    "wake": WakeConfig,
    "reply": ReplyConfig,
    "gate": GateConfig,
    "network": NetworkConfig,
    "enrollment": EnrollmentConfig,
}

_TOP_SCALAR_FIELDS = frozenset(
    {f.name for f in dataclasses.fields(Profile)}
    - _SUB_CONFIG_MAP.keys()
)


def _merge_dataclass(cls: type, data: dict[str, Any]) -> Any:
    """Return an instance of cls populated from data; unknown keys are ignored."""
    known = {f.name for f in dataclasses.fields(cls)}
    return cls(**{k: v for k, v in data.items() if k in known})


def load_profile(path: str | Path | None = None) -> Profile:
    """Load and validate a profile from a YAML file.

    If path is None, return the default Profile() (personal mode).
    Raises ProfileValidationError on invalid combinations of settings.
    """
    if path is None:
        profile = Profile()
        _validate(profile)
        return profile

    path = Path(path)
    raw: dict[str, Any] = yaml.safe_load(path.read_text(encoding="utf-8")) or {}

    sub_configs: dict[str, Any] = {
        key: _merge_dataclass(cls, raw.get(key) or {})
        for key, cls in _SUB_CONFIG_MAP.items()
    }

    top_scalars = {k: v for k, v in raw.items() if k in _TOP_SCALAR_FIELDS}

    profile = Profile(**sub_configs, **top_scalars)
    _validate(profile)
    return profile


def _validate(profile: Profile) -> None:
    """Raise ProfileValidationError for any invalid combination of settings."""
    if profile.enrollment.required and profile.mode == "classroom":
        raise ProfileValidationError(
            "classroom mode does not support enrollment.required=True; "
            "use mode=senior_care for enrolled sessions"
        )

    if not profile.network.allowed and profile.reply.delegate == "gemini":
        raise ProfileValidationError(
            "network.allowed=False is incompatible with reply.delegate=gemini; "
            "set reply.delegate=ollama for zero-network mode"
        )
