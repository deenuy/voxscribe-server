"""Configuration and policy resources."""
