"""Profile schema: dataclasses that define the per-product configuration contract.

Each field has a default so a minimal YAML only needs to override what differs
from the personal-assistant baseline.  The loader validates the merged result.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

ProductMode = Literal["personal", "ideascribe", "senior_care", "classroom"]


@dataclass
class WakeConfig:
    """Wake-word gate settings."""

    phrase: str = "hey vox"
    model: str = "hey_vox_v1"
    threshold: float = 0.50
    patience_frames: int = 2
    min_speech_ratio: float = 0.30


@dataclass
class ReplyConfig:
    """LLM reply settings."""

    delegate: Literal["ollama", "gemini"] = "ollama"
    model: str = "llama3.2"
    system_prompt_path: str = ""
    max_turns: int = 20
    idle_timeout_s: float = 20.0
    follow_up_window_s: float = 60.0


@dataclass
class GateConfig:
    """Content safety gate settings."""

    policy_pack: str = "default"
    action_claim_blocked: bool = True


@dataclass
class NetworkConfig:
    """Network access settings."""

    allowed: bool = True


@dataclass
class EnrollmentConfig:
    """Voice enrollment settings."""

    required: bool = False


@dataclass
class Profile:
    """Complete product profile.  One YAML per product; engine has no hardcoded product defaults."""

    mode: ProductMode = "personal"
    wake: WakeConfig = field(default_factory=WakeConfig)
    reply: ReplyConfig = field(default_factory=ReplyConfig)
    gate: GateConfig = field(default_factory=GateConfig)
    network: NetworkConfig = field(default_factory=NetworkConfig)
    enrollment: EnrollmentConfig = field(default_factory=EnrollmentConfig)
    quiet_hours_enabled: bool = False
    quiet_hours_start: str = "22:00"
    quiet_hours_end: str = "07:00"
    # When True, a wake inside the quiet-hours window is blocked (the default for all modes).
    # Set False for senior care: the person must still be able to call for help at night.
    quiet_hours_block_wake: bool = True
    # End-of-turn silence in seconds: how long the host waits without speech before it
    # considers the turn over when the turn detector is unavailable.
    # Bounds: 0.5 to 60.0 seconds (validated by the loader).
    end_of_turn_pause_s: float = 6.0


class ProfileValidationError(Exception):
    """Raised when a profile contains an invalid combination of settings."""
