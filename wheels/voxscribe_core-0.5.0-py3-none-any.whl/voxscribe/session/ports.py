"""Ports: the ten Protocols the engine calls and a host implements with adapters (ADR 0002).

    AudioIn  AudioOut  WakeDetector  Recognizer  Talker  Delegate  Speech  Gate  SessionStore  Clock

A host (voxscribe-server `app/local/voice/host.py`) is the only place that knows which adapter
backs each port. Engine code types against these Protocols and never imports an adapter.

The data types the ports exchange are plain dataclasses defined here, so an adapter translates
its own types into them and the engine never sees a provider type.

Time: every port that takes a time takes stream time (milliseconds of audio since the stream
was reset), never engine uptime. `Clock` hands out both; only `stream_ms()` may be passed to
`Speech.tick()`. A `Speech` adapter raises `ClockDomainError` when it is handed another clock.

Sync and async: a method that does blocking CPU work (`Recognizer.transcribe`,
`WakeDetector.score`, `Speech.process`) is synchronous and the host runs it off the event loop.
A method that does I/O the real adapter already performs asynchronously (playback, the
database, the reply model, synthesis behind a lock) is a coroutine.

This module imports nothing from a server, a database driver, a sound library or a platform
call, and nothing at runtime beyond the standard library (ADR 0004).
"""
from __future__ import annotations

from collections.abc import AsyncIterator, Sequence
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Protocol, runtime_checkable

if TYPE_CHECKING:  # numpy is only needed by callers that pass arrays
    import numpy as np

    from ..models import WordTiming


class ClockDomainError(RuntimeError):
    """A stream-time API was handed a time from another clock (usually engine uptime)."""


# ---------------------------------------------------------------------------------------------
# Data exchanged through the ports


@dataclass(frozen=True)
class TranscriptSegment:
    """One recognizer segment on the stream timeline of the recognizer stream that produced it."""

    id: str
    text: str
    start_ms: int
    end_ms: int
    state: str = "stable"          # "stable" or "provisional"
    source: str = "mic"
    speaker: str | None = None


@dataclass(frozen=True)
class TranscriptionResult:
    """A one-shot recognizer pass over a short window (the wake confirm)."""

    text: str = ""
    words: tuple[WordTiming, ...] = ()


@dataclass(frozen=True)
class TurnDecision:
    """What the turn policy decided about the audio fed so far."""

    closes_turn: bool
    action: str = ""
    silence_ms: int = 0


GATE_PASS = "pass"         # speak the sentence
GATE_REFUSE = "refuse"     # speak `replacement` instead of the whole reply, nothing else
GATE_REPLACE = "replace"   # speak `replacement` in place of this sentence, then stop the reply


@dataclass(frozen=True)
class GateDecision:
    """The gate's verdict on one sentence, given before anything is synthesised."""

    decision: str = GATE_PASS
    category: str = "ok"
    replacement: str | None = None

    @property
    def passed(self) -> bool:
        return self.decision == GATE_PASS


@dataclass
class ReplyStream:
    """A reply from the delegate: sentences in speaking order, produced lazily.

    `cue` is a fixed phrase spoken at once so the speaker is not silent while the reply model
    starts; `lead_in` is a fixed phrase spoken before a slow source (a search) is consumed. Both
    are scripted text and are spoken without a gate pass. `fallback` is the text recorded when
    the source yields nothing; it is not spoken.
    """

    sentences: AsyncIterator[str]
    source: str = "llm"
    cue: str | None = None
    lead_in: str | None = None
    fallback: str = ""


@dataclass(frozen=True)
class TurnRecord:
    """A turn the store has opened; `handle` is the store's bookkeeping, opaque to the engine."""

    session_id: str
    turn_n: int
    turn_id: str
    handle: Any = None


@dataclass
class ReplyOutcome:
    """What the reply stage spoke, and when (Clock.mono_ms), for the store's latency ledger."""

    decision: str = GATE_PASS
    category: str = "ok"
    text: str = ""
    sentences: list[str] = field(default_factory=list)
    started_ms: int | None = None
    first_sentence_ms: int | None = None
    first_audio_ms: int | None = None
    playback_end_ms: int | None = None


# ---------------------------------------------------------------------------------------------
# Ports


class FrameQueue(Protocol):
    """The subset of asyncio.Queue a capture subscriber reads: float32 mono chunks."""

    async def get(self) -> np.ndarray: ...

    def get_nowait(self) -> np.ndarray: ...

    def empty(self) -> bool: ...


@runtime_checkable
class AudioIn(Protocol):
    """Microphone or other PCM source. Subscribers each get their own drop-oldest queue."""

    sample_rate: int

    async def start(self) -> None: ...

    async def stop(self) -> None: ...

    def subscribe(self) -> FrameQueue: ...

    def unsubscribe(self, queue: FrameQueue) -> None: ...

    def capture_muted(self) -> bool:
        """True while capture may contain our own playback (the echo guard window)."""
        ...


@runtime_checkable
class AudioOut(Protocol):
    """Speaker or other PCM sink. `available` is False when no output device is open."""

    available: bool

    async def play(self, pcm_float32_mono: np.ndarray, sample_rate: int) -> None:
        """Queue audio for playback; returns once queued, not once heard."""
        ...

    async def play_file(self, path: str) -> None:
        """Play a short cue file to completion."""
        ...

    def stop_playback(self) -> None: ...

    @property
    def is_playing(self) -> bool: ...

    def playback_ref(self) -> np.ndarray:
        """The most recently played samples, the reference for barge-in and echo checks."""
        ...


@runtime_checkable
class WakeDetector(Protocol):
    """Stage 1 of the wake gate: a cheap, always-on scorer for one wake phrase.

    `patience_frames` is how many consecutive frames at or above the gate threshold this detector
    needs before the gate spends a voice check and a recognizer pass on it. A frame classifier
    that emits a fresh probability every 80 ms (openWakeWord) uses the gate default; a keyword
    spotter that emits one event per decoded phrase, after its own search over many frames,
    uses 1.
    """

    model_name: str
    patience_frames: int

    def reset(self) -> None:
        """Forget all buffered audio and internal state."""
        ...

    def score(self, pcm_float32_mono: np.ndarray) -> float:
        """Score one 80 ms frame. Returns 0.0..1.0."""
        ...


class RecognizerStream(Protocol):
    """One turn of streaming recognition. Every method blocks; call off the event loop."""

    def push(self, pcm_float32_mono: np.ndarray) -> list[TranscriptSegment]:
        """Feed audio; returns segments that became stable."""
        ...

    def pop_partials(self) -> list[TranscriptSegment]: ...

    def flush(self) -> list[TranscriptSegment]:
        """End of turn: everything still pending, as stable segments."""
        ...


@runtime_checkable
class Recognizer(Protocol):
    """Speech to text: a one-shot pass (the wake confirm) and a streaming pass (a turn)."""

    def transcribe(self, pcm_float32_mono: np.ndarray) -> TranscriptionResult: ...

    def open_stream(self, session_id: str) -> RecognizerStream | None:
        """A fresh stream for one turn, or None when no recognizer is configured."""
        ...


@runtime_checkable
class Talker(Protocol):
    """Text to speech. Returns float32 mono at `sample_rate`; an empty array on failure."""

    sample_rate: int

    async def synthesize(self, text: str) -> np.ndarray: ...

    async def fixed(self, phrase: str) -> np.ndarray:
        """A scripted phrase (cue, refusal), pre-rendered where the adapter can."""
        ...

    async def warm(self) -> None: ...


class Speculation(Protocol):
    """A reply generation started before the turn's final text is known."""

    def cancel(self) -> None: ...

    def __aiter__(self) -> AsyncIterator[str]: ...


@runtime_checkable
class Delegate(Protocol):
    """Produces the reply for a turn. It never speaks: the reply stage gates and speaks."""

    async def warm(self) -> None: ...

    def speculate(self, partial_text: str, history: Sequence[dict] | None) -> Speculation: ...

    async def reply(self, turn_text: str, session_id: str, *, turn_id: str | None = None,
                    history: Sequence[dict] | None = None,
                    speculation: Speculation | None = None) -> ReplyStream: ...


@runtime_checkable
class Speech(Protocol):
    """Speech activity: the turn policy's view of the audio, and the wake gate's voice check."""

    def reset(self) -> None:
        """Start a new turn; the adapter's stream clock returns to zero."""
        ...

    def process(self, pcm_float32_mono: np.ndarray) -> list[TurnDecision]: ...

    def tick(self, stream_ms: int) -> list[TurnDecision]:
        """Poll for a pause decision. Raises ClockDomainError for a time not on the stream."""
        ...

    def update_text(self, text: str) -> None:
        """The running transcript, for completeness-aware turn decisions."""
        ...

    def voice_ratio(self, pcm_float32_mono: np.ndarray) -> float:
        """Share of the window that is human voice, 0.0..1.0."""
        ...


@runtime_checkable
class Gate(Protocol):
    """Approves or refuses one sentence before it is synthesised. Fails closed."""

    fail_closed_phrase: str

    def needs_session_tools(self, sentence: str) -> bool:
        """True when `check` must see the session's tool rows, so ordinary sentences cost no I/O."""
        ...

    def check(self, sentence: str, session_tools: Sequence[str] = (), *,
              user_text: str = "") -> GateDecision: ...


@runtime_checkable
class SessionStore(Protocol):
    """Persists wake candidates, sessions, transcript segments and turns."""

    async def record_wake(self, *, score: float, accepted: bool, reject_reason: str | None,
                          detector: str | None, speech_ratio: float | None,
                          session_id: str | None = None) -> None: ...

    async def create_session(self, wake_score: float, *, detector: str | None = None,
                             speech_ratio: float | None = None) -> str: ...

    async def add_segment(self, session_id: str, segment: TranscriptSegment) -> None: ...

    async def begin_turn(self, session_id: str, turn_n: int, text: str) -> TurnRecord: ...

    async def session_tools(self, session_id: str) -> list[str]: ...

    async def add_turn(self, turn: TurnRecord, outcome: ReplyOutcome, *, turn_end_ms: int,
                       asr_final_ms: int | None = None) -> None: ...

    async def close_session(self, session_id: str) -> None: ...


@runtime_checkable
class Clock(Protocol):
    """`stream_ms` is audio time since the turn's stream reset; `mono_ms` is wall latency time."""

    def stream_ms(self) -> int: ...

    def mono_ms(self) -> int: ...


PORTS: tuple[type, ...] = (AudioIn, AudioOut, WakeDetector, Recognizer, Talker, Delegate,
                           Speech, Gate, SessionStore, Clock)
