"""Reply stage: every sentence passes the gate before the talker sees it (ADR 0001).

    delegate sentences -> Gate.check -> Talker.synthesize -> AudioOut.play

The gate is fail-closed. A refusal stops the reply and speaks only the refusal phrase; a
replacement speaks the fixed phrase in place of the sentence and stops; a gate that raises is
treated as a refusal with `Gate.fail_closed_phrase`. The candidate sentence is never handed to
the talker unless the gate passed it.

Tool rows are fetched only for a sentence the gate says needs them, so an ordinary reply costs
no store round trip. Times in the outcome come from `Clock.mono_ms()`, the latency clock.
"""
from __future__ import annotations

import logging
from collections.abc import Awaitable, Callable, Sequence

from ..ports import (
    GATE_PASS,
    GATE_REFUSE,
    GATE_REPLACE,
    AudioOut,
    Clock,
    Gate,
    GateDecision,
    ReplyOutcome,
    ReplyStream,
    Talker,
)

log = logging.getLogger("voxscribe.session.reply")

GATE_ERROR = "gate_error"

SessionTools = Callable[[], Awaitable[Sequence[str]]]


async def speak_reply(
    stream: ReplyStream,
    *,
    gate: Gate,
    talker: Talker,
    audio_out: AudioOut | None,
    clock: Clock,
    user_text: str,
    session_tools: SessionTools,
) -> ReplyOutcome:
    """Gate, synthesise and play one reply. Never raises for a source, gate or talker failure."""
    speaker = audio_out if audio_out is not None and audio_out.available else None
    out = ReplyOutcome(started_ms=clock.mono_ms())

    async def say(text: str, *, fixed: bool) -> None:
        if speaker is None:
            return
        try:
            pcm = await (talker.fixed(text) if fixed else talker.synthesize(text))
            if getattr(pcm, "size", len(pcm)):
                await speaker.play(pcm, talker.sample_rate)
                if out.first_audio_ms is None:
                    out.first_audio_ms = clock.mono_ms()
        except Exception:  # noqa: BLE001 - a failed sentence must not end the session
            log.exception("reply: speech output failed fixed=%s", fixed)

    if stream.cue:
        await say(stream.cue, fixed=True)
        out.first_audio_ms = None        # the cue is not the reply's first audio
    if stream.lead_in:
        await say(stream.lead_in, fixed=True)

    replacement: str | None = None
    try:
        async for sentence in stream.sentences:
            if out.first_sentence_ms is None:
                out.first_sentence_ms = clock.mono_ms()
            verdict = await _check(gate, sentence, user_text, session_tools)
            if verdict.decision == GATE_REPLACE and verdict.replacement:
                out.decision, out.category = GATE_REPLACE, verdict.category
                out.sentences.append(verdict.replacement)
                await say(verdict.replacement, fixed=True)
                break
            if verdict.decision != GATE_PASS:
                out.decision, out.category = GATE_REFUSE, verdict.category
                replacement = verdict.replacement or gate.fail_closed_phrase
                log.info("reply: gate refused category=%s", verdict.category)
                if speaker is not None and out.sentences:
                    speaker.stop_playback()
                break
            out.sentences.append(sentence)
            await say(sentence, fixed=False)
    except Exception:  # noqa: BLE001 - a broken source keeps what was already spoken
        log.exception("reply: sentence source failed")

    if out.decision == GATE_REFUSE:
        out.text = replacement or gate.fail_closed_phrase
        await say(out.text, fixed=True)
    elif out.sentences:
        out.text = " ".join(out.sentences)
    else:
        out.text = stream.fallback
    out.playback_end_ms = clock.mono_ms() if speaker is not None else None
    return out


async def _check(gate: Gate, sentence: str, user_text: str,
                 session_tools: SessionTools) -> GateDecision:
    try:
        tools: Sequence[str] = ()
        if gate.needs_session_tools(sentence):
            tools = await session_tools()
        return gate.check(sentence, tools, user_text=user_text)
    except Exception as exc:  # noqa: BLE001 - fail closed
        log.warning("reply: gate failed, refusing: %s", type(exc).__name__)
        return GateDecision(GATE_REFUSE, GATE_ERROR, gate.fail_closed_phrase)
