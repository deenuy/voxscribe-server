# stages: capture, recognize, turn, reply, playback. reply.py lands in T08; the others follow
# as the host's cascade moves into the engine.
