"""Sprint 6: diarization as overlap marking.

Phase 0 design: label overlapping speech with session-scoped role IDs
(speaker-1, speaker-2, ...) without persistent voiceprints.

Invariants:
  - Role IDs are session-scoped: "speaker-2" in session A has no identity
    relationship to "speaker-2" in session B. Nothing about a speaker
    persists to the database across sessions.
  - No biometric identifier is extracted or stored. The marker works on
    time-overlap metadata (chunk timestamps and speaker_tag from the ASR
    provider's optional diarization hint), not on audio signal fingerprints.
  - Classroom data minimization applies: when classroom mode is active the
    caller must pass classroom=True, which disables even session-scoped
    role assignment (all chunks remain primary/untagged) so no diarization
    label can act as a biometric proxy for a minor.

Public API:
  DiarizationSession   -- session-scoped state; call mark(chunk) on each chunk.
  OverlapMarker        -- stateless helper: given two chunks, is this overlap?
  OverlapRecord        -- result of a mark() call for one chunk.
"""

from __future__ import annotations

from dataclasses import dataclass, field

# ---- overlap record ----------------------------------------------------------


@dataclass
class OverlapRecord:
    """Result of marking one TranscriptChunk for overlap.

    speaker_role is "primary" when no overlap was detected or when
    diarization is disabled (classroom mode). When a second speaker is
    detected the role is "speaker-N" where N is the session-scoped ordinal
    (starting at 2; primary = speaker-1 conceptually but labeled "primary"
    to avoid numeric identity associations).

    is_overlap is True when this chunk's time window collides with the
    previous primary speaker window AND the chunk's speaker_tag (if any)
    differs from the primary tag recorded at session start.

    contamination_risk is True when an overlapping chunk's text would
    otherwise appear verbatim in the primary narrative. The caller should
    exclude such chunks from primary-narrative summarization."""

    chunk_id: str
    speaker_role: str  # "primary" | "speaker-2" | "speaker-3" | ...
    is_overlap: bool
    contamination_risk: bool


# ---- overlap marker (stateless) ---------------------------------------------


class OverlapMarker:
    """Stateless helper: given two chunks' time windows and speaker tags,
    decide if there is a speaker-change overlap.

    Time overlap: the newer chunk starts before the previous chunk ends.
    Speaker change: the two chunks carry different speaker_tag values (when
    the ASR provider emits them) or the energy split exceeds a threshold
    (not implemented in Phase 0; reserved for Phase 1 enhancement).

    When speaker_tag information is absent from both chunks the marker
    returns no_overlap=True so it never falsely promotes a chunk to overlap
    status and never splits a single speaker into two roles."""

    @staticmethod
    def is_overlap(
        *,
        prev_end_ms: float,
        curr_start_ms: float,
        prev_tag: str | None,
        curr_tag: str | None,
    ) -> bool:
        """Return True when curr overlaps temporally with prev AND the
        speaker tags differ (or at least one tag is present indicating the
        ASR provider emits per-chunk speaker attribution)."""
        if curr_start_ms >= prev_end_ms:
            return False
        # Both tags absent: cannot distinguish speaker change from single-
        # speaker rapid speech; default to no overlap.
        if prev_tag is None and curr_tag is None:
            return False
        return prev_tag != curr_tag


# ---- session-scoped diarization state ----------------------------------------


@dataclass
class DiarizationSession:
    """Session-scoped diarization state.

    Lifecycle: create once per session, call mark() for each incoming
    TranscriptChunk in order, discard when the session ends. Nothing is
    persisted to the database — the role assignments are ephemeral metadata
    used by the product layer to exclude caregiver speech from the primary
    narrative and to label overlap events in the event stream.

    classroom: when True, all chunks receive role="primary" regardless of
    speaker tags. This enforces data minimization for minors: no diarization
    label exists that could act as a session-scoped biometric proxy."""

    classroom: bool = False
    _primary_tag: str | None = field(default=None, repr=False)
    _role_map: dict[str, str] = field(default_factory=dict, repr=False)
    _next_role_ordinal: int = field(default=2, repr=False)
    _prev_end_ms: float = field(default=0.0, repr=False)
    _prev_tag: str | None = field(default=None, repr=False)

    def mark(self, chunk) -> OverlapRecord:
        """Mark a TranscriptChunk and return an OverlapRecord.

        chunk is duck-typed: expects chunk_id (str), text (str), and
        optionally start_ms, end_ms, speaker_tag attributes. Missing
        attributes default to sentinel values that produce no-overlap."""
        chunk_id = str(getattr(chunk, "chunk_id", "") or "")
        text = str(getattr(chunk, "text", "") or "")
        start_ms = float(getattr(chunk, "start_ms", 0.0) or 0.0)
        end_ms = float(getattr(chunk, "end_ms", start_ms + 500.0) or start_ms + 500.0)
        tag = getattr(chunk, "speaker_tag", None)

        # Classroom mode: no diarization labels, ever.
        if self.classroom:
            self._prev_end_ms = end_ms
            self._prev_tag = tag
            return OverlapRecord(
                chunk_id=chunk_id,
                speaker_role="primary",
                is_overlap=False,
                contamination_risk=False,
            )

        # Bootstrap primary tag from the first chunk.
        if self._primary_tag is None and tag is not None:
            self._primary_tag = tag

        overlap = OverlapMarker.is_overlap(
            prev_end_ms=self._prev_end_ms,
            curr_start_ms=start_ms,
            prev_tag=self._prev_tag,
            curr_tag=tag,
        )

        if not overlap or tag is None or tag == self._primary_tag:
            role = "primary"
        else:
            # Assign or recall a session-scoped role ordinal for this tag.
            if tag not in self._role_map:
                self._role_map[tag] = f"speaker-{self._next_role_ordinal}"
                self._next_role_ordinal += 1
            role = self._role_map[tag]

        contamination = overlap and role != "primary" and bool(text.strip())
        self._prev_end_ms = end_ms
        self._prev_tag = tag
        return OverlapRecord(
            chunk_id=chunk_id,
            speaker_role=role,
            is_overlap=overlap,
            contamination_risk=contamination,
        )

    def non_primary_roles(self) -> set[str]:
        """Return the set of non-primary roles assigned this session."""
        return set(self._role_map.values())
