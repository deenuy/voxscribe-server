"""Session metadata file: the bridge between `make listen` and `make
listen-stop`.

Why this exists: the stop command needs to recover the active session's
identity (id, pid, artifact paths) so it can log the shutdown under the
same `session_id`, surface the right report path, and align with
container log aggregators that key on `session_id`. The pid file alone
carries only the OS pid; everything else has to live somewhere readable.

Storage: a single JSON object at `output/voxscribe.session.json`. One
session at a time — the listen-start command refuses to create a second
when this file (and its pid) is live.

This module is pure I/O — no logging here, because logging context is
exactly what callers use this file to *establish*."""

from __future__ import annotations

import json
import os
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path

SESSION_METADATA_FILE = "voxscribe.session.json"


@dataclass
class SessionMetadata:
    """The minimal handshake between listen-start and listen-stop.

    Paths are recorded as strings (not Path) so JSON serialization is
    trivial across platforms. `started_at` is ISO-8601 UTC for
    interoperability with container log timestamps."""

    session_id: str
    pid: int
    started_at: str
    output_dir: str
    transcript_path: str
    events_path: str
    report_path: str = ""
    session_log_path: str = ""
    # Service identity captured at session start so a long-running
    # session keeps its provenance even if the host process is later
    # upgraded.
    service: str = ""
    service_version: str = ""
    environment: str = ""
    # Free-form extras (last completed phase, fallback flags, …) kept
    # under one key so the schema stays stable for log aggregators.
    extras: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)


def session_metadata_path(output_dir: str | os.PathLike) -> Path:
    """Where the session metadata file lives for the given output dir."""
    return Path(output_dir) / SESSION_METADATA_FILE


def make_session_metadata(
    *,
    session_id: str,
    pid: int,
    output_dir: str | os.PathLike,
    service: str = "",
    service_version: str = "",
    environment: str = "",
    session_log_path: str = "",
) -> SessionMetadata:
    """Build a SessionMetadata from the canonical artifact-naming rule.

    Every artifact lives under output_dir and is named after session_id.
    Centralizing the construction here keeps listen-start and any future
    session admin tooling (HTTP server, supervisor) consistent."""
    out = Path(output_dir)
    return SessionMetadata(
        session_id=session_id,
        pid=pid,
        started_at=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        output_dir=str(out),
        transcript_path=str(out / f"{session_id}.txt"),
        events_path=str(out / f"{session_id}.jsonl"),
        report_path=str(out / f"{session_id}.report.md"),
        session_log_path=session_log_path,
        service=service,
        service_version=service_version,
        environment=environment,
    )


def write_session_metadata(meta: SessionMetadata, output_dir: str | os.PathLike) -> Path:
    """Persist the metadata atomically (write to a temp file then rename)
    so a concurrent reader never sees a half-written file."""
    path = session_metadata_path(output_dir)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(meta.to_dict(), indent=2), encoding="utf-8")
    tmp.replace(path)
    return path


def load_session_metadata(output_dir: str | os.PathLike) -> SessionMetadata | None:
    """Read the metadata file, or return None if it is missing or
    unparseable. Stale/malformed files are NOT auto-deleted here — the
    caller decides whether to recover or fail loudly."""
    path = session_metadata_path(output_dir)
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    if not isinstance(data, dict) or "session_id" not in data:
        return None
    extras = data.get("extras") or {}
    if not isinstance(extras, dict):
        extras = {}
    return SessionMetadata(
        session_id=str(data["session_id"]),
        pid=int(data.get("pid", 0)),
        started_at=str(data.get("started_at", "")),
        output_dir=str(data.get("output_dir", "")),
        transcript_path=str(data.get("transcript_path", "")),
        events_path=str(data.get("events_path", "")),
        report_path=str(data.get("report_path", "")),
        session_log_path=str(data.get("session_log_path", "")),
        service=str(data.get("service", "")),
        service_version=str(data.get("service_version", "")),
        environment=str(data.get("environment", "")),
        extras=extras,
    )


def update_session_metadata(
    output_dir: str | os.PathLike,
    **fields,
) -> SessionMetadata | None:
    """Read-modify-write a subset of fields. Returns the updated metadata,
    or None when no file exists. Use for late-binding paths (report_path
    is empty until finalize runs) and for stamping the last completed
    shutdown phase into `extras['last_completed_phase']`."""
    meta = load_session_metadata(output_dir)
    if meta is None:
        return None
    for k, v in fields.items():
        if k == "extras" and isinstance(v, dict):
            meta.extras.update(v)
        elif hasattr(meta, k):
            setattr(meta, k, v)
    write_session_metadata(meta, output_dir)
    return meta


def delete_session_metadata(output_dir: str | os.PathLike) -> None:
    """Remove the metadata file. Idempotent — used in the listen
    finally-block alongside pid file cleanup."""
    path = session_metadata_path(output_dir)
    try:
        path.unlink()
    except FileNotFoundError:
        pass
