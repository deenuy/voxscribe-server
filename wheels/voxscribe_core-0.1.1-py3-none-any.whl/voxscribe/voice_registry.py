"""Voice registry: named open-source voices selected per mode via config.

Zero-code voice switching (the same pattern as personas and lexicons): the
TTS config carries a catalog of named voices and a mode -> voice-name map;
this module resolves the effective VoiceSpec for a session and enforces the
Phase 0 voice policy boundaries:

  - Cloud TTS voices are explicit opt-in only (per catalog entry) and are
    rejected outright in seniorcare and classroom, extending the ASR cloud
    rule to TTS.
  - Voice cloning, custom-recorded persona voices, and any voice resembling
    a real person are out of Phase 0 scope. A config that requests one is
    rejected with an error referencing their deferred-for-legal-review
    status (consent, likeness, and biometric surface). They are not built.

The registry only selects and validates. Construction of the actual
TTSProvider from a VoiceSpec happens at the composition root.
"""

from __future__ import annotations

from dataclasses import dataclass

_CLOUD_PROHIBITED_MODES = ("seniorcare", "classroom")
_DEFERRED_KINDS = ("cloned", "real_person")


class VoiceRegistryError(RuntimeError):
    """A configured voice violates the Phase 0 voice policy or is missing."""


@dataclass(frozen=True)
class VoiceSpec:
    """The resolved voice for one session: uniform across TTS backends so a
    different backend presents its voices the same way (protocol rule)."""

    name: str
    voice_id: str
    language: str = "en"
    speed: float = 1.0
    pitch: float = 0.0
    kind: str = "open_source"  # open_source | cloud | cloned | real_person


def select_voice(mode: str, tts_cfg: object) -> VoiceSpec:
    """Resolve and validate the voice for `mode` from a TTSConfig.

    Raises VoiceRegistryError when the mode has no mapping, the named voice
    is not in the catalog, or the voice violates a policy boundary. Callers
    treat a registry error as fail-closed: no voice means no speaking."""
    mode_norm = (mode or "").strip().lower()
    mode_voices = dict(getattr(tts_cfg, "mode_voices", None) or {})
    catalog = dict(getattr(tts_cfg, "voices", None) or {})

    name = str(mode_voices.get(mode_norm, "") or "")
    if not name:
        raise VoiceRegistryError(f"no voice configured for mode {mode_norm!r}")
    entry = catalog.get(name)
    if not isinstance(entry, dict):
        raise VoiceRegistryError(f"voice {name!r} is not in the voice catalog")

    kind = str(entry.get("kind", "open_source") or "open_source").strip().lower()
    if kind in _DEFERRED_KINDS:
        raise VoiceRegistryError(
            f"voice {name!r} (kind: {kind}) is deferred for legal review: "
            "voice cloning, custom-recorded persona voices, and voices "
            "resembling real people are out of Phase 0 scope pending "
            "consent, likeness, and biometric review."
        )
    if kind == "cloud":
        if mode_norm in _CLOUD_PROHIBITED_MODES:
            raise VoiceRegistryError(
                f"cloud TTS voices are prohibited in {mode_norm} mode; "
                "select an open-source on-device voice."
            )
        if not bool(entry.get("cloud_opt_in", False)):
            raise VoiceRegistryError(
                f"cloud voice {name!r} requires explicit opt-in "
                "(cloud_opt_in: true on the catalog entry)."
            )
    elif kind != "open_source":
        raise VoiceRegistryError(f"voice {name!r} has unknown kind {kind!r}")

    return VoiceSpec(
        name=name,
        voice_id=str(entry.get("voice_id", "") or name),
        language=str(entry.get("language", "en") or "en"),
        speed=float(entry.get("speed", 1.0) or 1.0),
        pitch=float(entry.get("pitch", 0.0) or 0.0),
        kind=kind,
    )


def build_tts_provider(tts_cfg: object, voice: VoiceSpec):
    """Composition-root factory: a TTSProvider for the resolved voice.

    `fake` builds the deterministic double (tests and dry runs); `piper`
    builds the local reference adapter, which fails closed at synth time
    when the runtime or model file is absent; `none` refuses."""
    provider_name = str(getattr(tts_cfg, "provider", "") or "").strip().lower()
    if provider_name == "fake":
        from .audio_providers import FakeTTSProvider

        return FakeTTSProvider(
            voice_id=voice.voice_id,
            language=voice.language,
            speed=voice.speed,
            pitch=voice.pitch,
        )
    if provider_name == "piper":
        from .audio_providers import PiperTTSProvider

        return PiperTTSProvider(
            model_path=str(getattr(tts_cfg, "model_path", "") or ""),
            voice_id=voice.voice_id,
            language=voice.language,
            speed=voice.speed,
            pitch=voice.pitch,
        )
    raise VoiceRegistryError(f"unknown or disabled tts provider {provider_name!r}")
