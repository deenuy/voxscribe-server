"""Deterministic backtrack-correction heuristics.

Precision over recall, deliberately: a wrong correction changes meaning,
while a missed one just leaves slightly rougher text for the model pass to
polish. So this module only acts on patterns that are near-unambiguous:

  strong markers   "scratch that", "let me rephrase", "correction" —
                   always a correction; drop the current clause before it
  number swap      "<number> {no wait|actually|i mean} <number>" — two
                   comparable alternatives around a marker
  explicit not-X   "no / sorry / not X, Y" where X was just said — replace
                   the earlier X with Y

Everything else — including "actually" and "I mean" in ordinary
conversational use ("I actually like it", "no problem") — is left untouched.
`residual_markers` reports whether ambiguous markers remain, which is the
uncertainty signal the audio-judgment lane (CP5) can act on.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

_STRONG = re.compile(r"\b(?:scratch that|let me rephrase|correction)\b[,.]?\s*", re.I)

# "<number> no wait <number>", "<number> actually <number>", with optional
# trailing unit kept from the second alternative onward.
_NUMBER_SWAP = re.compile(
    r"\b(\d+\w*)\s+(?:no[,]?\s+wait|wait[,]?\s+no|actually|i mean|no[,])\s+(\d+\w*)",
    re.I,
)

# "no, sorry, not Mary" / "sorry not Mary" / "no not Mary" — requires the
# no/sorry prefix so ordinary "not" ("it should not prescribe") never fires.
_NOT_X = re.compile(
    r"\b(?:no[,.]?\s+sorry[,.]?|sorry[,.]?\s+no[,.]?|no[,.]?|sorry[,.]?)\s+not\s+(\w+)[,.]?\s*",
    re.I,
)

_WEAK_MARKERS = re.compile(r"\b(?:actually|i mean|wait)\b", re.I)


@dataclass
class CorrectionResult:
    text: str
    applied: bool
    residual_markers: bool  # ambiguous markers remain: judgment may help


def _tidy(text: str) -> str:
    out = re.sub(r"\s+", " ", text).strip()
    return re.sub(r"\s+([,.!?])", r"\1", out)


def apply_backtracks(text: str, strong_only: bool = False) -> CorrectionResult:
    out = text
    applied = False

    # Strong markers: drop the clause being corrected (back to the last
    # sentence boundary), keep what follows the marker.
    while True:
        m = _STRONG.search(out)
        if m is None:
            break
        clause_start = max(out.rfind(p, 0, m.start()) for p in ".!?\n") + 1
        out = _tidy(out[:clause_start] + " " + out[m.end() :])
        applied = True

    if not strong_only:
        # Number swap: keep the second alternative.
        swapped = _NUMBER_SWAP.sub(lambda m: m.group(2), out)
        if swapped != out:
            out, applied = swapped, True

        # Explicit not-X: replace the earlier mention of X with what follows.
        m = _NOT_X.search(out)
        if m is not None:
            target = m.group(1)
            before = out[: m.start()]
            mentions = list(re.finditer(rf"\b{re.escape(target)}\b[,.]?", before, re.I))
            if mentions:
                last = mentions[-1]
                before = before[: last.start()] + before[last.end() :]
                out = _tidy(before + " " + out[m.end() :])
                applied = True

    return CorrectionResult(
        text=_tidy(out),
        applied=applied,
        residual_markers=_WEAK_MARKERS.search(out) is not None,
    )
