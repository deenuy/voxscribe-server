"""Gemma 4 Audio adapter: audio-native judgment hints (scaffold).

This provider answers narrow AudioJudgmentRequests — thought completion,
correction ambiguity, repetition intent, transcript repair, punctuation,
emphasis — with strict-JSON structured hints, served by a local Ollama
multimodal Gemma model. It sits *under* the kernel:

  - it never mutates output text, closes a turn, or emits revision events;
  - the UncertaintyRouter decides whether a hint is accepted;
  - any failure (network, timeout, malformed reply) fails closed to the
    heuristic answer carried in the request.

Scaffold boundaries: the transport is an injectable callable so tests never
touch the network, and requests currently carry the text window plus chunk
ids; attaching the raw audio window (which the host holds, keyed by chunk
id) is the host-integration step that makes the judgment truly
audio-grounded. The prompt and parsing contracts here do not change when
that lands.
"""

from __future__ import annotations

import json
import logging
import os
import re
import time
import urllib.request
from collections.abc import Callable

from .logging_config import get_logger, log_event
from .models import AudioJudgment, AudioJudgmentRequest, JudgmentKind

log = get_logger("voxscribe.gemma_audio")


DEFAULT_AUDIO_MODEL = os.environ.get("VOXSCRIBE_GEMMA_AUDIO_MODEL", "gemma3n:e4b")

_QUESTIONS = {
    JudgmentKind.THOUGHT_COMPLETION: (
        "Does the speaker sound finished with this thought, or mid-thought? "
        "Answer 'complete' or 'incomplete'."
    ),
    JudgmentKind.CORRECTION_AMBIGUITY: (
        "If the marker words here signal a self-correction, return the "
        "corrected text. If they are ordinary conversational use, return the "
        "text unchanged."
    ),
    JudgmentKind.REPETITION_INTENT: (
        "Was the repetition deliberate emphasis, or a restart/thinking loop? "
        "Answer 'emphasis' or 'stutter'."
    ),
    JudgmentKind.TRANSCRIPT_REPAIR: (
        "The transcript below may contain recognition errors. Return the "
        "most plausible corrected transcript, changing as little as possible."
    ),
    JudgmentKind.PUNCTUATION: ("Return the text with punctuation implied by the delivery."),
    JudgmentKind.EMPHASIS: ("Which words were stressed? Answer with the stressed words."),
}


class GemmaAudioProvider:
    """AudioUnderstandingProvider backed by an Ollama-served Gemma model."""

    def __init__(
        self,
        model: str = DEFAULT_AUDIO_MODEL,
        host: str = "http://localhost:11434",
        timeout: float = 10.0,
        transport: Callable[[str], str] | None = None,
        name: str = "gemma-audio",
        log: Callable[[str], None] | None = None,
    ):
        self.model = model
        self.url = f"{host.rstrip('/')}/api/generate"
        self.timeout = timeout
        self.transport = transport or self._http_transport
        self.name = name
        self._log = log or (lambda _: None)

    def judge(self, request: AudioJudgmentRequest) -> AudioJudgment:
        prompt = self.build_prompt(request)
        log_event(
            log,
            "audio_judgment_requested",
            level=logging.DEBUG,
            provider=self.name,
            model=self.model,
            kind=str(request.kind),
        )
        t0 = time.perf_counter()
        try:
            raw = self.transport(prompt)
            data = self._parse(raw)
            answer = str(data["answer"]).strip()
            confidence = max(0.0, min(1.0, float(data["confidence"])))
            if not answer:
                raise ValueError("empty answer")
            log_event(
                log,
                "audio_judgment_completed",
                level=logging.DEBUG,
                provider=self.name,
                kind=str(request.kind),
                duration_ms=round((time.perf_counter() - t0) * 1000.0, 1),
                confidence=round(confidence, 3),
            )
            return AudioJudgment(
                request_id=request.request_id,
                kind=request.kind,
                answer=answer,
                confidence=confidence,
                evidence=str(data.get("evidence", "")),
                source=self.name,
            )
        except Exception as exc:
            log_event(
                log,
                "audio_judgment_failed",
                level=logging.WARNING,
                provider=self.name,
                kind=str(request.kind),
                reason=type(exc).__name__,
            )
            self._log(f"[{self.name}] falling back to deterministic: {type(exc).__name__}: {exc}")
            return self._fallback(request)

    def _fallback(self, request: AudioJudgmentRequest) -> AudioJudgment:
        """Fail closed: the deterministic answer always wins on any fault."""
        return AudioJudgment(
            request_id=request.request_id,
            kind=request.kind,
            answer=request.heuristic_answer,
            confidence=request.heuristic_confidence,
            evidence="provider unavailable or malformed reply",
            source="deterministic",
        )

    def build_prompt(self, request: AudioJudgmentRequest) -> str:
        question = _QUESTIONS[request.kind]
        return (
            "You analyze a fragment of a speech transcript and answer one "
            "narrow question about it. Respond with strict JSON only: "
            '{"answer": "...", "confidence": 0.0-1.0, "evidence": "..."}\n'
            f"Question: {question}\n"
            f"Transcript window: {request.text_window}\n"
            f"A first-pass heuristic said: {request.heuristic_answer} "
            f"(confidence {request.heuristic_confidence:.2f}). "
            "Disagree only when you have grounds."
        )

    def health_info(self) -> dict:
        """Read-only metadata about this provider for host dashboards.
        Does not contact the model — returns configuration only."""
        return {
            "provider": self.name,
            "model": self.model,
            "endpoint": self.url,
            "timeout_s": self.timeout,
            "transport": "injected" if self.transport is not self._http_transport else "http",
        }

    @staticmethod
    def _parse(raw: str) -> dict:
        match = re.search(r"\{.*\}", raw, re.S)
        if match is None:
            raise ValueError("no JSON object in reply")
        data = json.loads(match.group(0))
        if not isinstance(data, dict):
            raise ValueError(f"JSON object is not a dict: {type(data).__name__}")
        missing = [k for k in ("answer", "confidence") if k not in data]
        if missing:
            raise ValueError(f"missing required keys in reply: {missing}")
        return data

    def _http_transport(self, prompt: str) -> str:
        body = {
            "model": self.model,
            "prompt": prompt,
            "stream": False,
            "format": "json",
            "options": {"temperature": 0.0},
        }
        data = json.dumps(body).encode("utf-8")
        req = urllib.request.Request(
            self.url, data=data, headers={"Content-Type": "application/json"}
        )
        with urllib.request.urlopen(req, timeout=self.timeout) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
        return payload.get("response", "")
