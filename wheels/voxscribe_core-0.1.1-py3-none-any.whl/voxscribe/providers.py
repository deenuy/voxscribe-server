"""Swappable LLM backends.

Two providers ship: a local one (Ollama, the Phase 1 default, runs Gemma on
Apple Silicon for $0) and a cloud one (Claude, the premium tier). Both
implement the same tiny interface so the post-processor never knows or cares
which is active. This mirrors the provider-switching pattern from the
ai-voice-agents repo: pick the backend, keep the call site identical.

No third-party runtime dependencies. Uses stdlib urllib so the core stays
light and easy to vendor into a sidecar or port to Swift.
"""

from __future__ import annotations

import json
import logging
import os
import time
import urllib.error
import urllib.request
from typing import Protocol

from .logging_config import get_logger, log_event

log = get_logger("voxscribe.providers")


# The Ollama tag must match a model you have pulled (run `ollama list`).
# The PRD targets Gemma 4 E4B. Set VOXSCRIBE_OLLAMA_MODEL to your exact tag,
# e.g. "gemma4:4b" once pulled, or fall back to a Gemma 3 tag that is local.
DEFAULT_LOCAL_MODEL = os.environ.get("VOXSCRIBE_OLLAMA_MODEL", "gemma3:4b")
DEFAULT_CLOUD_MODEL = "claude-sonnet-4-6"


class LLMProvider(Protocol):
    """Minimal contract every backend honors."""

    def complete(self, system: str, prompt: str, max_tokens: int = 2048) -> str: ...


class DeterministicFallback:
    """Wraps any LLMProvider so the pipeline degrades instead of failing when
    the model is unreachable: the prompt is returned unchanged, which means
    snippets (before) and dictionary normalization (after) still produce
    useful output. The listen-once loop uses this so "speak and see text"
    works with no model running. `fell_back` records whether any call failed.
    """

    def __init__(self, inner: LLMProvider):
        self.inner = inner
        self.fell_back = False

    def complete(self, system: str, prompt: str, max_tokens: int = 2048) -> str:
        try:
            return self.inner.complete(system, prompt, max_tokens)
        except (RuntimeError, OSError) as exc:  # URLError subclasses OSError
            self.fell_back = True
            log_event(
                log,
                "llm_fallback_used",
                level=logging.WARNING,
                provider=type(self.inner).__name__,
                reason=type(exc).__name__,
            )
            return prompt


class OllamaProvider:
    """Local inference via Ollama. Default backend for the free local tier."""

    def __init__(
        self,
        model: str = DEFAULT_LOCAL_MODEL,
        host: str = "http://localhost:11434",
        temperature: float = 0.1,
        timeout: float = 30.0,
    ):
        self.model = model
        self.url = f"{host.rstrip('/')}/api/generate"
        self.temperature = temperature
        self.timeout = timeout
        log_event(
            log,
            "llm_provider_selected",
            provider="ollama",
            model=model,
            local=True,
        )

    def complete(self, system: str, prompt: str, max_tokens: int = 2048) -> str:
        body = {
            "model": self.model,
            "system": system,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": self.temperature,
                "top_p": 0.9,
                "num_predict": max_tokens,
            },
        }
        data = json.dumps(body).encode("utf-8")
        req = urllib.request.Request(
            self.url, data=data, headers={"Content-Type": "application/json"}
        )
        log_event(
            log,
            "llm_call_started",
            level=logging.DEBUG,
            provider="ollama",
            model=self.model,
            prompt_chars=len(prompt),
            max_tokens=max_tokens,
        )
        t0 = time.perf_counter()
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                payload = json.loads(resp.read().decode("utf-8"))
        except urllib.error.URLError as exc:
            log_event(
                log,
                "llm_call_failed",
                level=logging.WARNING,
                provider="ollama",
                model=self.model,
                reason=type(exc).__name__,
                duration_ms=round((time.perf_counter() - t0) * 1000.0, 1),
            )
            raise RuntimeError(
                f"Ollama unreachable at {self.url}. Is `ollama serve` running "
                f"and is model '{self.model}' pulled? Original error: {exc}"
            ) from exc
        response = payload.get("response", "").strip()
        log_event(
            log,
            "llm_call_completed",
            level=logging.DEBUG,
            provider="ollama",
            model=self.model,
            duration_ms=round((time.perf_counter() - t0) * 1000.0, 1),
            response_chars=len(response),
        )
        return response


class ClaudeProvider:
    """Cloud inference via the Anthropic Messages API. Premium accuracy tier."""

    def __init__(
        self,
        model: str = DEFAULT_CLOUD_MODEL,
        api_key: str | None = None,
        temperature: float = 0.1,
        timeout: float = 30.0,
    ):
        self.model = model
        self.api_key = api_key or os.environ.get("ANTHROPIC_API_KEY", "")
        self.url = "https://api.anthropic.com/v1/messages"
        self.temperature = temperature
        self.timeout = timeout
        # api_key is intentionally NOT logged — only the boolean "is it set".
        log_event(
            log,
            "llm_provider_selected",
            provider="claude",
            model=model,
            local=False,
            api_key_present=bool(self.api_key),
        )

    def complete(self, system: str, prompt: str, max_tokens: int = 2048) -> str:
        if not self.api_key:
            raise RuntimeError("ANTHROPIC_API_KEY is not set for ClaudeProvider.")
        log_event(
            log,
            "llm_call_started",
            level=logging.DEBUG,
            provider="claude",
            model=self.model,
            prompt_chars=len(prompt),
            max_tokens=max_tokens,
        )
        t0 = time.perf_counter()
        body = {
            "model": self.model,
            "max_tokens": max_tokens,
            "temperature": self.temperature,
            "system": system,
            "messages": [{"role": "user", "content": prompt}],
        }
        data = json.dumps(body).encode("utf-8")
        req = urllib.request.Request(
            self.url,
            data=data,
            headers={
                "Content-Type": "application/json",
                "x-api-key": self.api_key,
                "anthropic-version": "2023-06-01",
            },
        )
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                payload = json.loads(resp.read().decode("utf-8"))
        except (urllib.error.URLError, OSError) as exc:
            log_event(
                log,
                "llm_call_failed",
                level=logging.WARNING,
                provider="claude",
                model=self.model,
                reason=type(exc).__name__,
                duration_ms=round((time.perf_counter() - t0) * 1000.0, 1),
            )
            raise
        parts = [b.get("text", "") for b in payload.get("content", []) if b.get("type") == "text"]
        response = "".join(parts).strip()
        log_event(
            log,
            "llm_call_completed",
            level=logging.DEBUG,
            provider="claude",
            model=self.model,
            duration_ms=round((time.perf_counter() - t0) * 1000.0, 1),
            response_chars=len(response),
        )
        return response
