"""Versioned per-mode policy engine and the fail-closed response gate.

Voice-design invariants 5, 5a, 5b:

  - Output side: every candidate the system speaks or displays passes the
    mandatory, deny-capable response gate before delivery. The gate is
    deterministic-first, fail-closed (unavailable or uncertain means the
    safe scripted fallback, never the candidate), and cannot be bypassed
    by any product layer, provider, or config.
  - Every gate decision is auditable (kernel emits response_gated and
    records candidate_hash, policy_version, rule, and outcome).
  - Policy is configuration, not code. Packs are versioned YAML,
    per-mode, loaded at session start.

This module owns loading, evaluation, and the small helpers the CLI uses
to gate the two ungated surfaces (session_report.py, output_delivery.py).
It never touches the store directly; the caller writes the audit rows so
transactions remain in one place.
"""

from __future__ import annotations

import hashlib
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

from .models import PolicyEvent, PolicyEventKind, event_to_dict

try:
    import yaml as _yaml

    _YAML_AVAILABLE = True
except ImportError:
    _YAML_AVAILABLE = False


Posture = Literal["allowlist", "denylist"]
Outcome = Literal["allow", "deny", "fallback"]


DEFAULT_FALLBACK_LINE = "[content withheld by policy]"


class PolicyPackError(RuntimeError):
    """Raised when a pack file is missing, malformed, or names an unknown mode.
    Callers translate this to a fail-closed gate at session start."""


@dataclass(frozen=True)
class RetentionPolicy:
    audio_seconds: int = 0
    transcript_seconds: int = 0


@dataclass(frozen=True)
class PolicyPack:
    """One mode's frozen policy at a specific version. Immutable so the
    session-scoped audit stays keyed to a single policy_version even if the
    on-disk file is edited mid-session."""

    mode: str
    policy_version: str
    posture: Posture
    fallback_line: str
    allowed_surfaces: tuple[str, ...] = ()
    denied_surfaces: tuple[str, ...] = ()
    deny_patterns: tuple[str, ...] = ()
    retention: RetentionPolicy = field(default_factory=RetentionPolicy)
    # Scripted backchannel lines for seniorcare mode (product-layer config).
    # Empty means no backchannels. Lines are round-robined; no LLM involved.
    backchannel_lines: tuple[str, ...] = ()


@dataclass(frozen=True)
class GateDecision:
    """One evaluation. `delivered_text` is what the caller MUST use as the
    outgoing text; on allow it is the candidate, on deny/fallback it is
    the pack's scripted line. `candidate_hash` lets audit-replay match a
    ledger row to a specific candidate without persisting the raw text."""

    outcome: Outcome
    delivered_text: str
    candidate_hash: str
    policy_version: str
    surface: str
    rule: str


# ---- pack loading ----------------------------------------------------------


_KNOWN_MODES = ("seniorcare", "classroom", "dictation", "ideascribe")


def load_policy_pack(mode: str, root: Path | str) -> PolicyPack:
    """Load and freeze a policy pack for `mode` from `root/<mode>.yaml`.

    Fail-closed: any load error raises PolicyPackError. The composition
    root translates this to a fallback-only gate rather than proceeding
    with an unversioned policy."""
    if not _YAML_AVAILABLE:
        raise PolicyPackError("PyYAML is required to load policy packs")
    mode_norm = (mode or "").strip().lower()
    if mode_norm not in _KNOWN_MODES:
        raise PolicyPackError(f"unknown mode {mode!r}; expected one of {list(_KNOWN_MODES)}")
    path = Path(root) / f"{mode_norm}.yaml"
    if not path.exists():
        raise PolicyPackError(f"policy pack not found: {path}")
    try:
        raw = _yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except (_yaml.YAMLError, OSError) as exc:
        raise PolicyPackError(f"could not read {path}: {exc}") from exc
    if not isinstance(raw, dict):
        raise PolicyPackError(f"policy pack {path} must be a YAML mapping")

    posture = str(raw.get("posture", "")).strip().lower()
    if posture not in ("allowlist", "denylist"):
        raise PolicyPackError(f"policy pack {path}: posture must be allowlist or denylist")
    file_mode = str(raw.get("mode", "")).strip().lower()
    if file_mode and file_mode != mode_norm:
        raise PolicyPackError(
            f"policy pack {path}: file mode {file_mode!r} does not match {mode_norm!r}"
        )
    policy_version = str(raw.get("policy_version", "")).strip()
    if not policy_version:
        raise PolicyPackError(f"policy pack {path}: policy_version is required")

    fallback_line = str(raw.get("fallback_line", "")).strip() or DEFAULT_FALLBACK_LINE
    allowed = tuple(str(s).strip() for s in (raw.get("allowed_surfaces") or []))
    denied = tuple(str(s).strip() for s in (raw.get("denied_surfaces") or []))
    deny_patterns = tuple(str(p) for p in (raw.get("deny_patterns") or []))

    retention_raw = raw.get("retention") or {}
    retention = RetentionPolicy(
        audio_seconds=int(retention_raw.get("audio_seconds", 0) or 0),
        transcript_seconds=int(retention_raw.get("transcript_seconds", 0) or 0),
    )
    backchannel_lines = tuple(
        str(s) for s in (raw.get("backchannel_lines") or []) if str(s).strip()
    )

    return PolicyPack(
        mode=mode_norm,
        policy_version=policy_version,
        posture=posture,  # type: ignore[arg-type]
        fallback_line=fallback_line,
        allowed_surfaces=allowed,
        denied_surfaces=denied,
        deny_patterns=deny_patterns,
        retention=retention,
        backchannel_lines=backchannel_lines,
    )


# ---- response gate ---------------------------------------------------------


def _candidate_hash(text: str) -> str:
    """Short stable hash keying audit records to candidates without
    persisting raw text. Truncated to 16 hex chars: collision-safe at
    session-scale, small in the ledger."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


@dataclass(frozen=True)
class PolicyGate:
    """Deterministic-first, fail-closed response gate.

    evaluate() never raises. Any internal error is caught and reported as
    a fallback decision; a bypass path does not exist. Callers write the
    decision to the audit ledger and use `delivered_text` as the outgoing
    text without inspecting `outcome`."""

    pack: PolicyPack

    def evaluate(self, candidate: str, *, surface: str) -> GateDecision:
        cand = candidate or ""
        chash = _candidate_hash(cand)
        try:
            if self.pack.posture == "allowlist":
                if surface not in self.pack.allowed_surfaces:
                    return self._fallback(
                        chash,
                        surface,
                        rule=f"allowlist_surface_not_permitted:{surface}",
                    )
            else:
                if surface in self.pack.denied_surfaces:
                    return self._deny(
                        chash,
                        surface,
                        rule=f"denylist_surface:{surface}",
                    )

            for pattern in self.pack.deny_patterns:
                try:
                    match = re.search(pattern, cand)
                except re.error as exc:
                    return self._fallback(
                        chash,
                        surface,
                        rule=f"malformed_deny_pattern:{type(exc).__name__}",
                    )
                if match is not None:
                    return self._deny(
                        chash,
                        surface,
                        rule=f"deny_pattern:{pattern}",
                    )

            return GateDecision(
                outcome="allow",
                delivered_text=cand,
                candidate_hash=chash,
                policy_version=self.pack.policy_version,
                surface=surface,
                rule="passed",
            )
        except Exception as exc:  # noqa: BLE001, fail-closed
            return self._fallback(
                chash,
                surface,
                rule=f"gate_error:{type(exc).__name__}",
            )

    def _deny(self, chash: str, surface: str, *, rule: str) -> GateDecision:
        return GateDecision(
            outcome="deny",
            delivered_text=self.pack.fallback_line,
            candidate_hash=chash,
            policy_version=self.pack.policy_version,
            surface=surface,
            rule=rule,
        )

    def _fallback(self, chash: str, surface: str, *, rule: str) -> GateDecision:
        return GateDecision(
            outcome="fallback",
            delivered_text=self.pack.fallback_line,
            candidate_hash=chash,
            policy_version=self.pack.policy_version,
            surface=surface,
            rule=rule,
        )


def evaluate_or_fallback(gate: PolicyGate | None, candidate: str, *, surface: str) -> GateDecision:
    """One helper the CLI uses at every ungated surface. When gate is None
    (pack load failed at session start) the caller gets a hard fallback
    decision keyed to the sentinel policy_version 'gate-unavailable', so
    the audit still records that the gate was down at that moment."""
    if gate is not None:
        return gate.evaluate(candidate, surface=surface)
    return GateDecision(
        outcome="fallback",
        delivered_text=DEFAULT_FALLBACK_LINE,
        candidate_hash=_candidate_hash(candidate or ""),
        policy_version="gate-unavailable",
        surface=surface,
        rule="gate_unavailable",
    )


def fail_closed_gate(mode: str) -> PolicyGate:
    """Synthetic fail-closed gate used when a real pack cannot be loaded.

    Posture=allowlist with an empty allowed_surfaces list, so every
    delivery falls through to the pack fallback_line and every audit row
    is stamped with the sentinel policy_version 'gate-unavailable'. The
    composition root uses this to keep production paths fail-closed
    without requiring every downstream helper to special-case gate=None."""
    pack = PolicyPack(
        mode=(mode or "").strip().lower() or "unknown",
        policy_version="gate-unavailable",
        posture="allowlist",
        fallback_line=DEFAULT_FALLBACK_LINE,
        allowed_surfaces=(),
        denied_surfaces=(),
        deny_patterns=(),
        retention=RetentionPolicy(),
    )
    return PolicyGate(pack=pack)


# ---- audit + retention on delivery -----------------------------------------


def _shortest_retention_seconds(pack: PolicyPack | None) -> int:
    """Retention window used at delivery time: the shortest positive window
    the pack declares. Zero from the pack means 'no retention' — the
    absence of an expires_at rather than an instant purge."""
    if pack is None:
        return 0
    windows = [
        w for w in (pack.retention.audio_seconds, pack.retention.transcript_seconds) if w > 0
    ]
    return min(windows) if windows else 0


def _expires_at_iso(seconds: int, *, at: float | None = None) -> str:
    if seconds <= 0:
        return ""
    base = at if at is not None else time.time()
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(base + seconds))


def deliver_gated(
    gate: PolicyGate | None,
    candidate: str,
    *,
    surface: str,
    store: Any | None,
    session_id: str,
    at: float | None = None,
) -> str:
    """String form of deliver_gated_decision: returns only the text the
    caller MUST deliver. See deliver_gated_decision for the contract."""
    return deliver_gated_decision(
        gate,
        candidate,
        surface=surface,
        store=store,
        session_id=session_id,
        at=at,
    ).delivered_text


def deliver_gated_decision(
    gate: PolicyGate | None,
    candidate: str,
    *,
    surface: str,
    store: Any | None,
    session_id: str,
    at: float | None = None,
) -> GateDecision:
    """Evaluate the response gate, record the full audit trail, and return
    the decision. `delivered_text` is the text the caller MUST deliver;
    callers that need the outcome and candidate_hash for their own events
    (the TTS response loop) use this form.

    This is the single seam every ungated surface uses (session_report,
    cursor_insert, future TTS). It writes three rows on every call:

      1. safety_ledger row (kind=response_gated) so audit-replay can key
         a decision to a candidate_hash + policy_version + rule.
      2. events row (event_type=response_gated) so the JSONL projection
         and the EVENT-CONTRACT stay canonical.
      3. retention_records row keyed to the surface, marked kept only when
         the gate allowed the candidate. Denied / fallback rows record the
         withhold so the compliance trail is complete.

    Composition rule: gate=None means "no gate wired at this call site" —
    the candidate passes through unchanged and nothing is written to the
    store. The fail-closed invariant is enforced at the composition root
    (the CLI): production paths always wire a gate, synthesizing a
    fail-closed pack when the on-disk YAML cannot be loaded. Tests and
    non-CLI entry points that legitimately never wire a gate get
    pass-through behavior instead of a surprise fallback.

    Never raises. Any store error is swallowed so a broken ledger cannot
    turn a fail-closed gate into a fail-open surface."""
    if gate is None:
        return GateDecision(
            outcome="allow",
            delivered_text=candidate,
            candidate_hash=_candidate_hash(candidate or ""),
            policy_version="",
            surface=surface,
            rule="no_gate_wired",
        )
    try:
        decision = gate.evaluate(candidate, surface=surface)
    except Exception as exc:  # noqa: BLE001 — outermost fail-closed seam
        decision = GateDecision(
            outcome="fallback",
            delivered_text=gate.pack.fallback_line,
            candidate_hash=_candidate_hash(candidate or ""),
            policy_version=gate.pack.policy_version,
            surface=surface,
            rule=f"deliver_gated_error:{type(exc).__name__}",
        )
    if store is None:
        return decision
    pack = gate.pack if gate is not None else None
    retention_s = _shortest_retention_seconds(pack)
    expires_at = _expires_at_iso(retention_s, at=at)
    payload = {
        "session_id": session_id,
        "surface": decision.surface,
        "outcome": decision.outcome,
        "candidate_hash": decision.candidate_hash,
        "policy_version": decision.policy_version,
        "rule": decision.rule,
    }
    try:
        store.append_safety_ledger(
            session_id,
            kind=PolicyEventKind.RESPONSE_GATED.value,
            payload=payload,
            outcome=decision.outcome,
            candidate_hash=decision.candidate_hash,
            policy_version=decision.policy_version,
            rule=decision.rule,
            at=at,
        )
    except Exception:  # noqa: BLE001 — gate must remain fail-closed regardless
        pass
    try:
        event = PolicyEvent(
            kind=PolicyEventKind.RESPONSE_GATED,
            session_id=session_id,
            policy_version=decision.policy_version,
            outcome=decision.outcome,
            candidate_hash=decision.candidate_hash,
            surface=decision.surface,
            rule=decision.rule,
        )
        seq = store.next_event_seq(session_id)
        store.append_event(session_id, seq, event_to_dict(event), at=at)
    except Exception:  # noqa: BLE001
        pass
    try:
        store.record_retention(
            session_id,
            surface=decision.surface,
            kept=(decision.outcome == "allow"),
            expires_at=expires_at,
            policy_version=decision.policy_version,
            at=at,
        )
    except Exception:  # noqa: BLE001
        pass
    return decision


def emit_policy_applied(
    gate: PolicyGate | None,
    *,
    mode: str,
    store: Any | None,
    session_id: str,
    at: float | None = None,
) -> None:
    """Stamp policy_version_applied on the session before the first chunk.
    One event per session. When gate is None (no gate wired at the call
    site), this is a no-op — the composition root, not this helper, is
    responsible for constructing a fail-closed gate when a pack is
    missing so a real policy_version is always stamped in production."""
    if store is None or gate is None:
        return
    policy_version = gate.pack.policy_version
    posture = gate.pack.posture
    mode_value = gate.pack.mode
    event = PolicyEvent(
        kind=PolicyEventKind.APPLIED,
        session_id=session_id,
        policy_version=policy_version,
        posture=posture,
        mode=mode_value,
    )
    try:
        seq = store.next_event_seq(session_id)
        store.append_event(session_id, seq, event_to_dict(event), at=at)
    except Exception:  # noqa: BLE001
        pass
    try:
        store.append_safety_ledger(
            session_id,
            kind=PolicyEventKind.APPLIED.value,
            payload={
                "session_id": session_id,
                "mode": mode_value,
                "policy_version": policy_version,
                "posture": posture,
            },
            policy_version=policy_version,
            at=at,
        )
    except Exception:  # noqa: BLE001
        pass
