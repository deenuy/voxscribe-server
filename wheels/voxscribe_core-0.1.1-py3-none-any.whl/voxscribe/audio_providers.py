"""Audio-side provider contracts and deterministic fakes.

Three contracts sit under the kernel:

  ASRProvider                 turns captured audio into TranscriptChunks
  AudioUnderstandingProvider  answers narrow judgment questions grounded in
                              the audio itself (Gemma 4 Audio is the intended
                              first real implementation, arriving in CP5)
  TTSProvider                 synthesizes gate-approved text to audio frames
                              (Lane 7); the response loop owns playback and
                              barge-in, the provider only synthesizes

All provide signal, structured hints, or frames. None writes output text,
closes a turn, or emits a revision event — the deterministic controller in
voxscribe-core owns every written character, and only gate-approved text
ever reaches a TTSProvider. Provider-specific runtime choices (model tags,
endpoints, torch, sounddevice) stay behind these contracts and out of this
package's hot path.

The fakes make every kernel test runnable with no model, no microphone, and
no network, mirroring FakeProvider in the pipeline tests.
"""

from __future__ import annotations

import hashlib
import math
from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Protocol

from .models import (
    AudioJudgment,
    AudioJudgmentRequest,
    JudgmentKind,
    TranscriptChunk,
    WordTiming,
)


class ASRProvider(Protocol):
    """Minimal contract every speech recognizer honors.

    `initial_prompt` is an optional soft biasing hint accepted by all
    modern ASRs (Whisper, gpt-4o-transcribe). Adapters that cannot honor it
    should accept and ignore the argument so callers stay decoupled.
    """

    def transcribe(
        self,
        samples: Sequence[float],
        sample_rate: int,
        session_id: str,
        initial_prompt: str | None = None,
    ) -> list[TranscriptChunk]: ...


class AudioUnderstandingProvider(Protocol):
    """Answers one AudioJudgmentRequest with one structured AudioJudgment.
    Hints only; acceptance is the UncertaintyRouter's decision."""

    def judge(self, request: AudioJudgmentRequest) -> AudioJudgment: ...


class WhisperASRProvider:
    """Local ASR via faster-whisper (CTranslate2, no torch). Optional
    dependency: install the `listen` extra. The import and model load are
    lazy, so constructing this adapter costs nothing and the package imports
    cleanly with no audio dependencies installed.

    Whisper segments map one-to-one to TranscriptChunks: segment timing
    becomes chunk timing, exp(avg_logprob) becomes confidence, and the gap
    to the previous segment becomes gap_ms_before — exactly the pause signal
    the kernel's silence policy consumes.

    Quality knobs match ChatGPT Realtime conventions:
      - `language` follows OpenAI's two-letter codes ("en", "es", ...). None
        triggers Whisper's language detection.
      - `initial_prompt` is the documented soft-biasing surface, capped near
        Whisper's 224-token budget by the caller (see contextual_biasing).
      - `beam_size=5` matches faster-whisper's accuracy-tuned default; the
        prior `beam_size=1` was a CP1 speed shortcut that hurts WER badly.
      - `word_timestamps` emits per-word timing into TranscriptChunk.words
        when the host needs SRT/VTT or per-word UI; default off because it
        costs ~25% extra decode time.
    """

    def __init__(
        self,
        model_size: str = "small.en",
        device: str = "cpu",
        compute_type: str = "int8",
        language: str | None = "en",
        beam_size: int = 5,
        word_timestamps: bool = False,
        default_initial_prompt: str | None = None,
        vad_filter: bool = True,
        vad_min_silence_ms: int = 500,
    ):
        self.model_size = model_size
        self.device = device
        self.compute_type = compute_type
        self.language = language
        self.beam_size = beam_size
        self.word_timestamps = word_timestamps
        self.default_initial_prompt = default_initial_prompt
        self.vad_filter = vad_filter
        self.vad_min_silence_ms = vad_min_silence_ms
        self._model = None

    def _load(self):
        if self._model is None:
            try:
                from faster_whisper import WhisperModel
            except ImportError as exc:
                raise RuntimeError(
                    "WhisperASRProvider needs faster-whisper. Install the "
                    "listen extra: pip install 'voxscribe-core[listen]'"
                ) from exc
            self._model = WhisperModel(
                self.model_size, device=self.device, compute_type=self.compute_type
            )
        return self._model

    def transcribe(
        self,
        samples: Sequence[float],
        sample_rate: int,
        session_id: str = "session",
        initial_prompt: str | None = None,
    ) -> list[TranscriptChunk]:
        if sample_rate != 16000:
            raise ValueError(f"WhisperASRProvider expects 16kHz audio, got {sample_rate}")
        import numpy as np  # ships with faster-whisper

        model = self._load()
        audio = np.asarray(samples, dtype="float32")
        prompt = initial_prompt if initial_prompt is not None else self.default_initial_prompt

        segments, _info = model.transcribe(
            audio,
            beam_size=self.beam_size,
            language=self.language,
            initial_prompt=prompt or None,
            word_timestamps=self.word_timestamps,
            vad_filter=self.vad_filter,
            vad_parameters={"min_silence_duration_ms": self.vad_min_silence_ms}
            if self.vad_filter
            else None,
        )

        chunks: list[TranscriptChunk] = []
        prev_end_ms = 0.0
        for i, seg in enumerate(segments):
            text = seg.text.strip()
            if not text:
                continue
            start_ms, end_ms = seg.start * 1000.0, seg.end * 1000.0
            words: list[WordTiming] = []
            if self.word_timestamps and getattr(seg, "words", None):
                for w in seg.words:
                    if w.word is None:
                        continue
                    words.append(
                        WordTiming(
                            word=w.word.strip(),
                            t_start_ms=float(w.start) * 1000.0,
                            t_end_ms=float(w.end) * 1000.0,
                            confidence=float(getattr(w, "probability", 1.0) or 1.0),
                        )
                    )
            chunks.append(
                TranscriptChunk(
                    chunk_id=f"{session_id}-c{i}",
                    session_id=session_id,
                    text=text,
                    t_start_ms=start_ms,
                    t_end_ms=end_ms,
                    confidence=min(1.0, max(0.0, math.exp(seg.avg_logprob))),
                    gap_ms_before=max(0.0, start_ms - prev_end_ms),
                    words=words,
                )
            )
            prev_end_ms = end_ms
        return chunks


ScriptEntry = str | tuple[str, float]


class FakeASRProvider:
    """Scripted ASR. Ignores the audio entirely and emits the scripted texts
    as TranscriptChunks with synthetic, monotonically increasing timings.

    Script entries are either "text" or ("text", gap_ms_before), so tests can
    stage pauses between chunks without any real audio.
    """

    def __init__(
        self,
        script: Sequence[ScriptEntry],
        confidence: float = 0.95,
        ms_per_word: float = 300.0,
    ):
        self._script: list[tuple[str, float]] = [
            (entry, 0.0) if isinstance(entry, str) else (entry[0], float(entry[1]))
            for entry in script
        ]
        self.confidence = confidence
        self.ms_per_word = ms_per_word
        # Last initial_prompt seen — tests assert biasing wiring without
        # depending on a real model.
        self.last_initial_prompt: str | None = None
        self.initial_prompts_seen: list[str | None] = []

    def transcribe(
        self,
        samples: Sequence[float] | None = None,
        sample_rate: int = 16000,
        session_id: str = "session",
        initial_prompt: str | None = None,
    ) -> list[TranscriptChunk]:
        self.last_initial_prompt = initial_prompt
        self.initial_prompts_seen.append(initial_prompt)
        chunks: list[TranscriptChunk] = []
        clock = 0.0
        for i, (text, gap_ms) in enumerate(self._script):
            clock += gap_ms
            duration = max(1, len(text.split())) * self.ms_per_word
            chunks.append(
                TranscriptChunk(
                    chunk_id=f"{session_id}-c{i}",
                    session_id=session_id,
                    text=text,
                    t_start_ms=clock,
                    t_end_ms=clock + duration,
                    confidence=self.confidence,
                    gap_ms_before=gap_ms,
                )
            )
            clock += duration
        return chunks


class FakeAudioUnderstandingProvider:
    """Scripted judgments keyed by JudgmentKind; defaults to echoing the
    heuristic answer at its own confidence. Records every request so tests
    can assert exactly when the router consulted the audio lane."""

    def __init__(
        self,
        answers: dict[JudgmentKind, tuple] | None = None,
        name: str = "fake-audio",
    ):
        # answers: kind -> (answer, confidence) or (answer, confidence, evidence)
        self.answers = answers or {}
        self.requests: list[AudioJudgmentRequest] = []
        self.name = name

    def judge(self, request: AudioJudgmentRequest) -> AudioJudgment:
        self.requests.append(request)
        if request.kind in self.answers:
            scripted = self.answers[request.kind]
            answer, confidence = scripted[0], scripted[1]
            evidence = scripted[2] if len(scripted) > 2 else ""
        else:
            answer = request.heuristic_answer
            confidence = request.heuristic_confidence
            evidence = "echo"
        return AudioJudgment(
            request_id=request.request_id,
            kind=request.kind,
            answer=answer,
            confidence=confidence,
            evidence=evidence,
            source=self.name,
        )


# ---- TTS (Lane 7: response) --------------------------------------------------


@dataclass
class TTSAudio:
    """One synthesized utterance: mono PCM float frames plus timing. The
    response loop hands these to an AudioSink for playback; the provider
    never plays audio itself."""

    frames: list[float]
    sample_rate: int
    duration_s: float = 0.0


class TTSProvider(Protocol):
    """Minimal contract every speech synthesizer honors (Lane 7).

    Voice attributes are uniform across backends so the voice registry can
    present any backend's voices the same way: `voice_id` names the loaded
    voice, `language` is the two-letter code, and `speed` / `pitch` are the
    only prosody knobs the product layer may set. synthesize() receives
    gate-approved text only; callers are responsible for gating. A failing
    provider raises; it must never corrupt caller state or return partial
    frames as success."""

    voice_id: str
    language: str
    speed: float
    pitch: float

    def synthesize(self, text: str) -> TTSAudio: ...


@dataclass
class FakeTTSProvider:
    """Deterministic synth double: no model, no audio device.

    Frames are a constant-amplitude signal whose amplitude derives from the
    voice_id and whose length scales with the text, so tests can assert
    that a different configured voice produces different spoken output
    without any real synthesis. `fail` makes synthesize raise, for
    provider-failure tests."""

    voice_id: str = "fake-voice"
    language: str = "en"
    speed: float = 1.0
    pitch: float = 0.0
    sample_rate: int = 16000
    fail: bool = False
    synthesized: list[str] = field(default_factory=list)

    def synthesize(self, text: str) -> TTSAudio:
        if self.fail:
            raise RuntimeError("fake TTS failure")
        self.synthesized.append(text)
        # Amplitude in (0, 1], stable per voice_id: same voice, same sound.
        digest = hashlib.sha256(self.voice_id.encode("utf-8")).digest()
        amplitude = (digest[0] + 1) / 256.0
        # 10 ms of frames per character, scaled by speed (faster = shorter).
        n = max(1, int(len(text) * self.sample_rate * 0.01 / max(0.1, self.speed)))
        frames = [amplitude] * n
        return TTSAudio(
            frames=frames,
            sample_rate=self.sample_rate,
            duration_s=n / self.sample_rate,
        )


class PiperTTSProvider:
    """Local on-device TTS via Piper (rhasspy/piper, MIT-licensed ONNX
    voices). The reference open-source adapter for the edge tier; the model
    file is named by config so swapping voices or backends is configuration,
    never code.

    Fail-closed: if the piper runtime or the configured model file is not
    installed, construction succeeds (cheap, import-free) but synthesize()
    raises a clear RuntimeError. Nothing is spoken on a failed load; the
    response loop reports the failure and the session continues. Tests use
    FakeTTSProvider, never this adapter."""

    def __init__(
        self,
        model_path: str,
        voice_id: str = "",
        language: str = "en",
        speed: float = 1.0,
        pitch: float = 0.0,
    ):
        self.model_path = model_path
        self.voice_id = voice_id or model_path
        self.language = language
        self.speed = speed
        self.pitch = pitch
        self._voice = None

    def _load(self):
        if self._voice is None:
            try:
                from piper.voice import PiperVoice
            except ImportError as exc:
                raise RuntimeError(
                    "PiperTTSProvider needs the piper-tts runtime. Install it "
                    "(pip install piper-tts) or configure tts.provider: fake."
                ) from exc
            from pathlib import Path as _Path

            if not self.model_path or not _Path(self.model_path).exists():
                raise RuntimeError(
                    f"Piper voice model not found: {self.model_path!r}. Set "
                    "tts.model_path to a downloaded .onnx voice file."
                )
            self._voice = PiperVoice.load(self.model_path)
        return self._voice

    def synthesize(self, text: str) -> TTSAudio:
        voice = self._load()
        frames: list[float] = []
        sample_rate = int(getattr(voice.config, "sample_rate", 22050))
        # Piper streams int16 PCM bytes; normalize to mono float in [-1, 1].
        # length_scale is Piper's inverse-speed knob.
        for chunk in voice.synthesize_stream_raw(text, length_scale=1.0 / max(0.1, self.speed)):
            for i in range(0, len(chunk) - 1, 2):
                sample = int.from_bytes(chunk[i : i + 2], "little", signed=True)
                frames.append(sample / 32768.0)
        return TTSAudio(
            frames=frames,
            sample_rate=sample_rate,
            duration_s=len(frames) / sample_rate if sample_rate else 0.0,
        )
