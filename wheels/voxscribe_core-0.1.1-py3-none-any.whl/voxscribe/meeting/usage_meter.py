"""Token usage meter for meeting features."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class UsageSnapshot:
    """Token usage snapshot."""

    transcription_words: int = 0
    enrich_tokens: int = 0
    chat_tokens: int = 0
    assist_tokens: int = 0
    embed_tokens: int = 0

    @property
    def total(self) -> int:
        """Total tokens (approximate)."""
        return (
            self.transcription_words  # words -> tokens at fixed ratio
            + self.enrich_tokens
            + self.chat_tokens
            + self.assist_tokens
            + self.embed_tokens
        )


class TokenMeter:
    """Track token usage by feature."""

    WORDS_TO_TOKENS_RATIO = 4 / 3  # rough estimate

    def __init__(self):
        self.transcription_words = 0
        self.enrich_tokens = 0
        self.chat_tokens = 0
        self.assist_tokens = 0
        self.embed_tokens = 0

    def add_transcription(self, word_count: int) -> None:
        """Record transcription words."""
        self.transcription_words += word_count

    def add_enrich(self, token_count: int) -> None:
        """Record enrichment tokens."""
        self.enrich_tokens += token_count

    def add_chat(self, token_count: int) -> None:
        """Record chat/Q&A tokens."""
        self.chat_tokens += token_count

    def add_assist(self, token_count: int) -> None:
        """Record live assist tokens."""
        self.assist_tokens += token_count

    def add_embed(self, token_count: int) -> None:
        """Record embedding tokens."""
        self.embed_tokens += token_count

    def snapshot(self) -> UsageSnapshot:
        """Get current usage snapshot."""
        return UsageSnapshot(
            transcription_words=self.transcription_words,
            enrich_tokens=self.enrich_tokens,
            chat_tokens=self.chat_tokens,
            assist_tokens=self.assist_tokens,
            embed_tokens=self.embed_tokens,
        )

    def reset(self) -> None:
        """Reset all counters."""
        self.transcription_words = 0
        self.enrich_tokens = 0
        self.chat_tokens = 0
        self.assist_tokens = 0
        self.embed_tokens = 0
