"""Live assistance: real-time question answering during meetings."""

from __future__ import annotations

import logging
from dataclasses import dataclass

from ..knowledge.answer import AnswerComposer
from ..logging_config import get_logger, log_event
from .live import Segment
from .qdetect import QuestionDetector

log = get_logger("voxscribe.meeting.assist")


@dataclass
class Suggestion:
    """Live assistance suggestion."""

    id: str
    offset_ms: int
    question: str
    answer: str
    citations: list[dict]


class LiveAssist:
    """Live assistance during transcription."""

    def __init__(
        self,
        question_detector: QuestionDetector,
        answer_composer: AnswerComposer,
        rate_limit_sec: int = 5,
        dedupe_window_sec: int = 60,
    ):
        self.qdetect = question_detector
        self.answer_composer = answer_composer
        self.rate_limit_sec = rate_limit_sec
        self.dedupe_window_sec = dedupe_window_sec

        self.last_assist_ms = 0
        self.recent_questions: dict[str, int] = {}
        self.suggestion_counter = 0

    def process_segment(
        self,
        segment: Segment,
        meeting_segments: list[Segment],
    ) -> Suggestion | None:
        """Process a segment, return assistance suggestion if applicable.

        Returns None if: not a question, rate limited, or answer is not grounded.
        """
        qresult = self.qdetect.detect(segment.text)
        if not qresult.is_question or qresult.confidence < 0.7:
            return None

        now_ms = segment.end_ms
        if now_ms - self.last_assist_ms < self.rate_limit_sec * 1000:
            return None

        question_normalized = qresult.question_text.lower().strip()
        if question_normalized in self.recent_questions:
            if now_ms - self.recent_questions[question_normalized] < self.dedupe_window_sec * 1000:
                return None

        self.recent_questions[question_normalized] = now_ms

        try:
            token_stream, citations = self.answer_composer.stream(
                qresult.question_text
            )

            answer_tokens = []
            for token in token_stream:
                answer_tokens.append(token)

            answer = "".join(answer_tokens).strip()

            if "no source found" in answer.lower() and not citations:
                log_event(
                    log,
                    "assist_no_source",
                    question=qresult.question_text[:100],
                )
                return None

            self.last_assist_ms = now_ms
            self.suggestion_counter += 1

            suggestion = Suggestion(
                id=f"assist_{self.suggestion_counter}",
                offset_ms=segment.end_ms,
                question=qresult.question_text,
                answer=answer,
                citations=[c.to_dict() for c in citations],
            )

            log_event(
                log,
                "assist_suggestion",
                question=qresult.question_text[:50],
                answer_len=len(answer),
                citations=len(citations),
            )

            return suggestion
        except Exception as e:
            log_event(
                log,
                "assist_error",
                level=logging.WARNING,
                question=qresult.question_text[:50],
                error=str(e),
            )
            return None
