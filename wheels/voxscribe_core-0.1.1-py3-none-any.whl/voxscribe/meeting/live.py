"""Live transcriber with energy-based VAD and segment management."""

from __future__ import annotations

import logging
from collections import deque
from dataclasses import dataclass

from ..audio_providers import ASRProvider
from ..logging_config import get_logger, log_event

log = get_logger("voxscribe.meeting.live")


@dataclass
class Segment:
    """One transcribed segment (provisional or stable)."""

    id: str
    start_ms: int
    end_ms: int
    source: str  # "mic" or "system"
    speaker: str | None
    text: str
    state: str  # "provisional" or "stable"


class AutoStop:
    """Helper for auto-stopping after N minutes of silence."""

    def __init__(self, silence_minutes: int):
        self.silence_minutes = silence_minutes
        self.silence_start_ms = None

    def tick(self, is_speech: bool, elapsed_ms: int) -> bool:
        """Update silence tracker. Return True if should auto-stop."""
        if is_speech:
            self.silence_start_ms = None
            return False
        else:
            if self.silence_start_ms is None:
                self.silence_start_ms = elapsed_ms
            elapsed_silence_ms = elapsed_ms - self.silence_start_ms
            silence_threshold_ms = self.silence_minutes * 60 * 1000
            return elapsed_silence_ms >= silence_threshold_ms


class LiveTranscriber:
    """Live transcriber accepting PCM16 frames and emitting segments."""

    def __init__(
        self,
        asr_provider: ASRProvider,
        session_id: str,
        sample_rate: int = 16000,
        vad_threshold: float = 0.03,
        silence_duration_ms: int = 500,
        partial_update_interval_ms: int = 1000,
    ):
        self.asr = asr_provider
        self.session_id = session_id
        self.sample_rate = sample_rate
        self.vad_threshold = vad_threshold
        self.silence_duration_ms = silence_duration_ms
        self.partial_update_interval_ms = partial_update_interval_ms

        self.segments: dict[str, Segment] = {}
        self.segment_counter = 0
        self.audio_buffer = deque()
        self.silence_start_ms = None
        self.elapsed_ms = 0
        self.session_start_ms = 0
        self.echo_suppression_window_ms = 2000
        self.last_partial_update_ms = 0
        self.current_segment_id = None
        self.partial_segments: dict[str, Segment] = {}  # Track partials by id

    def push_audio(self, source_tag: int, frame: bytes) -> list[Segment]:
        """Push PCM16 audio frame (source_tag: 0=mic, 1=system).

        Returns: list of newly stable segments from this push.
        For partial segments, use get_pending_partials() after calling this.
        """
        import array
        import math
        import sys

        source = "mic" if source_tag == 0 else "system"
        samples = array.array("h", frame)
        # Only swap on big-endian hosts; input is little-endian PCM16
        if sys.byteorder == "big":
            samples.byteswap()
        float_samples = [s / 32768.0 for s in samples]

        energy = math.sqrt(sum(s * s for s in float_samples) / len(float_samples))
        is_speech = energy > self.vad_threshold

        self.elapsed_ms += len(samples) * 1000 // self.sample_rate

        if is_speech:
            self.audio_buffer.append(float_samples)
            self.silence_start_ms = None
            # Emit partial segments while speech is ongoing
            if self.elapsed_ms - self.last_partial_update_ms >= self.partial_update_interval_ms:
                self._update_partials(source)
                self.last_partial_update_ms = self.elapsed_ms
        else:
            if self.silence_start_ms is None:
                self.silence_start_ms = self.elapsed_ms

        new_stable = []
        if is_speech or (
            self.silence_start_ms is not None
            and self.elapsed_ms - self.silence_start_ms > self.silence_duration_ms
        ):
            if self.audio_buffer and not is_speech:
                new_stable = self._finalize_segment(source)
                self.current_segment_id = None
                self.partial_segments.clear()

        return new_stable

    def _update_partials(self, source: str) -> None:
        """Re-decode the growing audio buffer and emit partial segment updates."""
        if not self.audio_buffer:
            return

        samples = []
        for frame in self.audio_buffer:
            samples.extend(frame)

        if not samples:
            return

        start_ms = max(0, self.elapsed_ms - len(samples) * 1000 // self.sample_rate)
        end_ms = self.elapsed_ms

        try:
            chunks = self.asr.transcribe(samples, self.sample_rate, self.session_id)
            if chunks:
                # Use the same segment id for all partials of this speech burst
                if self.current_segment_id is None:
                    self.current_segment_id = f"{self.session_id}#{self.segment_counter}"
                    self.segment_counter += 1

                # Create partial segment from the first chunk (usually just one in partial)
                chunk = chunks[0]
                partial = Segment(
                    id=self.current_segment_id,
                    start_ms=int(chunk.t_start_ms or start_ms),
                    end_ms=int(chunk.t_end_ms or end_ms),
                    source=source,
                    speaker=None,
                    text=chunk.text,
                    state="provisional",
                )
                self.partial_segments[self.current_segment_id] = partial
        except Exception as e:
            log_event(
                log,
                "partial_transcription_error",
                level=logging.WARNING,
                error=str(e),
            )

    def get_pending_partials(self) -> list[Segment]:
        """Get and clear pending partial segments."""
        result = list(self.partial_segments.values())
        # Don't clear yet - they will be cleared when segment finalizes
        return result

    def _finalize_segment(self, source: str) -> list[Segment]:
        """Finalize the current audio buffer into segments."""
        if not self.audio_buffer:
            return []

        samples = []
        for frame in self.audio_buffer:
            samples.extend(frame)

        self.audio_buffer.clear()

        if not samples:
            return []

        start_ms = max(0, self.elapsed_ms - len(samples) * 1000 // self.sample_rate)
        end_ms = self.elapsed_ms

        try:
            chunks = self.asr.transcribe(samples, self.sample_rate, self.session_id)
            new_segments = []
            for chunk in chunks:
                seg_id = f"{self.session_id}#{self.segment_counter}"
                self.segment_counter += 1
                seg = Segment(
                    id=seg_id,
                    start_ms=int(chunk.t_start_ms or start_ms),
                    end_ms=int(chunk.t_end_ms or end_ms),
                    source=source,
                    speaker=None,
                    text=chunk.text,
                    state="stable",
                )
                self.segments[seg_id] = seg
                new_segments.append(seg)

            self._suppress_echoes(new_segments, source)
            return new_segments
        except Exception as e:
            log_event(
                log,
                "transcription_error",
                level=logging.WARNING,
                error=str(e),
            )
            return []

    def _suppress_echoes(self, new_segs: list[Segment], source: str) -> None:
        """Suppress near-duplicate speech between mic and system sources."""
        if source != "system":
            return

        other_source = "mic"
        for seg in new_segs:
            for other_id, other_seg in list(self.segments.items()):
                if (
                    other_seg.source == other_source
                    and abs(other_seg.start_ms - seg.start_ms) < self.echo_suppression_window_ms
                    and self._similar_text(seg.text, other_seg.text)
                ):
                    del self.segments[other_id]
                    log_event(
                        log,
                        "echo_suppressed",
                        other_id=other_id,
                        new_id=seg.id,
                    )

    def _similar_text(self, text1: str, text2: str, ratio: float = 0.8) -> bool:
        """Check if two texts are similar (Jaccard > ratio)."""
        words1 = set(text1.lower().split())
        words2 = set(text2.lower().split())
        if not words1 or not words2:
            return False
        intersection = len(words1 & words2)
        union = len(words1 | words2)
        return intersection / union >= ratio

    def get_segment(self, segment_id: str) -> Segment | None:
        """Get a segment by ID."""
        return self.segments.get(segment_id)

    def list_segments(self) -> list[Segment]:
        """List all segments."""
        return list(self.segments.values())
