"""Deterministic question detection from text."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol


@dataclass
class QuestionResult:
    """Result of question detection."""

    is_question: bool
    question_text: str
    confidence: float  # 0.0-1.0
    reason: str


class LLMConfirmHook(Protocol):
    """Optional LLM hook for confirming borderline questions."""

    def confirm(self, text: str) -> bool:
        """Return True if text is a question."""
        ...


class QuestionDetector:
    """Deterministic question detection."""

    def __init__(self, llm_confirm: LLMConfirmHook | None = None):
        self.llm_confirm = llm_confirm
        self.wh_words = {
            "what",
            "when",
            "where",
            "who",
            "why",
            "how",
            "which",
        }
        self.modals = {"can", "could", "will", "would", "should", "may", "might", "do", "does"}
        self.interrogative_tags = {"right?", "isn't it?", "doesn't it?", "won't you?"}

    def detect(self, text: str, context: str = "") -> QuestionResult:
        """Detect if text is a question.

        Returns QuestionResult with confidence and reason.
        """
        text = text.strip()
        if not text:
            return QuestionResult(
                is_question=False,
                question_text="",
                confidence=0.0,
                reason="empty",
            )

        lower_text = text.lower()

        rhetorical_phrases = {
            "you know?",
            "right?",
            "okay?",
            "yeah?",
            "no?",
            "yes?",
        }
        if lower_text.endswith(tuple(rhetorical_phrases)):
            confidence = 0.3
            reason = "rhetorical_filler"
            return QuestionResult(
                is_question=False,
                question_text="",
                confidence=confidence,
                reason=reason,
            )

        if text.endswith("?"):
            confidence = 0.95
            reason = "ends_with_question_mark"
            return QuestionResult(
                is_question=True,
                question_text=text,
                confidence=confidence,
                reason=reason,
            )

        if lower_text.endswith(tuple(self.interrogative_tags)):
            confidence = 0.85
            reason = "tag_question"
            return QuestionResult(
                is_question=True,
                question_text=text,
                confidence=confidence,
                reason=reason,
            )

        words = lower_text.split()
        if words and words[0] in self.wh_words:
            confidence = 0.9
            reason = "starts_with_wh_word"
            return QuestionResult(
                is_question=True,
                question_text=text,
                confidence=confidence,
                reason=reason,
            )

        if len(words) > 1 and words[0] in self.modals and not lower_text.endswith((".", "!")):
            confidence = 0.8
            reason = "modal_inversion"
            return QuestionResult(
                is_question=True,
                question_text=text,
                confidence=confidence,
                reason=reason,
            )

        if self.llm_confirm:
            try:
                is_q = self.llm_confirm.confirm(text)
                confidence = 0.7
                reason = "llm_confirm"
                return QuestionResult(
                    is_question=is_q,
                    question_text=text if is_q else "",
                    confidence=confidence,
                    reason=reason,
                )
            except Exception:
                pass

        return QuestionResult(
            is_question=False,
            question_text="",
            confidence=0.0,
            reason="no_question_markers",
        )
