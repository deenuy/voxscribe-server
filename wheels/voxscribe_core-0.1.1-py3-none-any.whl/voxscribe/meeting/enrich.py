"""Enrich shorthand blocks with LLM-generated content and citations."""

from __future__ import annotations

import logging
from dataclasses import dataclass

from ..knowledge.llm_stream import StreamingLLMProvider
from ..knowledge.retriever import Retriever
from ..logging_config import get_logger, log_event
from .llm_json import complete_json

log = get_logger("voxscribe.meeting.enrich")


@dataclass
class TranscriptSegment:
    """One segment of transcript for context."""

    id: str
    start_ms: int
    end_ms: int
    text: str


@dataclass
class EnrichedBlock:
    """Enhanced shorthand block with citations."""

    block_id: str
    text: str
    citations: list[dict]  # Citation dicts per contract
    status: str  # "pending", "stable", "edited"


@dataclass
class EnhancedSourceChunk:
    """Source chunk for enrichment."""

    source_id: str
    chunk_id: str
    title: str
    locator: str | None
    text: str = ""


class Enricher:
    """Enrich shorthand blocks with LLM and retrieval."""

    def __init__(
        self,
        llm: StreamingLLMProvider,
        retriever: Retriever | None = None,
        context_window_sec: int = 30,
    ):
        self.llm = llm
        self.retriever = retriever
        self.context_window_sec = context_window_sec

    def enrich(
        self,
        block_id: str,
        text: str,
        offset_ms: int,
        transcript_segments: list[TranscriptSegment],
        retrieved_chunks: list[EnhancedSourceChunk] | None = None,
        style: str = "standard",
    ) -> EnrichedBlock:
        """Enrich one block.

        Returns EnrichedBlock with citations and status.
        """
        window_ms = self.context_window_sec * 1000
        window_start = max(0, offset_ms - window_ms)
        window_end = offset_ms + window_ms

        context_segs = [
            seg
            for seg in transcript_segments
            if seg.end_ms >= window_start and seg.start_ms <= window_end
        ]

        if not context_segs:
            return EnrichedBlock(
                block_id=block_id,
                text="",
                citations=[],
                status="pending",
            )

        chunks = [self._as_chunk(c) for c in (retrieved_chunks or [])]

        system_prompt = self._make_system_prompt(style)
        user_prompt = self._make_user_prompt(text, offset_ms, context_segs, chunks)

        try:
            parsed, raw = complete_json(self.llm, system_prompt, user_prompt, max_tokens=1024)
            note_text = parsed.get("text") if parsed else None
            if not isinstance(note_text, str) or not note_text.strip():
                log_event(
                    log,
                    "enrichment_unparseable",
                    level=logging.WARNING,
                    block_id=block_id,
                    reply=raw[:200],
                )
                return EnrichedBlock(block_id=block_id, text="", citations=[], status="pending")

            citations = self._citations(parsed.get("cites", []), context_segs, chunks)
            return EnrichedBlock(
                block_id=block_id, text=note_text.strip(), citations=citations, status="stable"
            )
        except Exception as e:
            log_event(
                log, "enrichment_error", level=logging.WARNING, block_id=block_id, error=str(e)
            )
            return EnrichedBlock(block_id=block_id, text="", citations=[], status="pending")

    @staticmethod
    def _as_chunk(chunk) -> EnhancedSourceChunk:
        """Accept a chunk object or a plain dict (the server passes dicts)."""
        if isinstance(chunk, EnhancedSourceChunk):
            return chunk
        get = chunk.get if isinstance(chunk, dict) else lambda k, d=None: getattr(chunk, k, d)
        return EnhancedSourceChunk(
            source_id=str(get("source_id", "") or ""),
            chunk_id=str(get("chunk_id", "") or ""),
            title=str(get("title", "") or "Source"),
            locator=get("locator", None),
            text=str(get("text", "") or ""),
        )

    @staticmethod
    def _citations(cites, context_segs, chunks) -> list[dict]:
        """Map the ids the model returned to real segments and chunks; drop anything unknown."""
        out: list[dict] = []
        seen: set[tuple[str, str]] = set()
        for raw in cites if isinstance(cites, list) else []:
            cite = str(raw).strip().strip("[]").strip()
            if cite.startswith("seg_"):
                key, wanted = "seg", cite[4:]
            elif cite.startswith("chunk_"):
                key, wanted = "chunk", cite[6:]
            else:
                key, wanted = "any", cite
            if key in ("seg", "any"):
                seg = next((x for x in context_segs if x.id == wanted), None)
                if seg and ("seg", seg.id) not in seen:
                    seen.add(("seg", seg.id))
                    out.append(
                        {
                            "kind": "transcript",
                            "segmentId": seg.id,
                            "startMs": seg.start_ms,
                            "endMs": seg.end_ms,
                        }
                    )
                    continue
            if key in ("chunk", "any"):
                chunk = next((x for x in chunks if x.chunk_id == wanted), None)
                if chunk and ("chunk", chunk.chunk_id) not in seen:
                    seen.add(("chunk", chunk.chunk_id))
                    out.append(
                        {
                            "kind": "source",
                            "sourceId": chunk.source_id,
                            "chunkId": chunk.chunk_id,
                            "title": chunk.title,
                            "locator": chunk.locator,
                        }
                    )
        return out

    def _make_system_prompt(self, style: str) -> str:
        """System prompt for enrichment."""
        voice = (
            "Rewrite the shorthand into one or two clear, concise sentences."
            if style == "concise"
            else "Expand the shorthand into complete sentences with the relevant detail "
            "from the transcript."
        )
        return (
            "You are a careful meeting note-taker. "
            + voice
            + " Use only facts that appear in the transcript or source passages you are given; "
            "never add anything else. "
            'Reply with ONLY one JSON object: {"text": "<the note>", "cites": ["<id>", ...]}. '
            "Each id must be copied exactly from the square brackets shown before a "
            "transcript line or source passage (for example seg_ab12 or chunk_9). "
            "Cite every id the note relies on. "
            "No markdown fences, no commentary."
        )

    def _make_user_prompt(
        self,
        shorthand: str,
        offset_ms: int,
        segments: list[TranscriptSegment],
        chunks: list[EnhancedSourceChunk],
    ) -> str:
        """User prompt for enrichment: ids are shown so the model can cite them."""

        def clock(ms: int) -> str:
            total = max(0, int(ms // 1000))
            return f"{total // 60}:{total % 60:02d}"

        lines = [f"Shorthand note (written at {clock(offset_ms)}):", shorthand, "", "Transcript:"]
        for seg in segments:
            lines.append(f"[seg_{seg.id}] ({clock(seg.start_ms)}) {seg.text}")
        if chunks:
            lines += ["", "Source passages:"]
            for chunk in chunks:
                where = f" ({chunk.locator})" if chunk.locator else ""
                lines.append(f"[chunk_{chunk.chunk_id}] {chunk.title}{where}: {chunk.text}")
        lines += ["", 'Reply with JSON only: {"text": "...", "cites": ["seg_...", "chunk_..."]}']
        return "\n".join(lines)
