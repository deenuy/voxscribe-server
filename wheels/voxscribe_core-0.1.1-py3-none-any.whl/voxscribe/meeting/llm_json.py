"""Get a JSON object out of a model that was asked for one.

Models often wrap JSON in a markdown code fence, add a sentence before it, or
trail off. `extract_json` copes with those; `complete_json` asks again once with
a firmer instruction when the first reply cannot be parsed. A reply that still
cannot be parsed returns None, never the raw text, so callers cannot show a
model's formatting noise to a user as if it were content.
"""

from __future__ import annotations

import json
import re

_FENCE = re.compile(r"```(?:json|JSON)?\s*(.*?)```", re.DOTALL)

RETRY_REMINDER = (
    "\n\nYour previous reply was not valid JSON. Reply again with ONLY one JSON object, "
    "no markdown fences, no commentary."
)


def extract_json(response: str) -> dict | None:
    """Return the first JSON object found in `response`, or None."""
    if not response:
        return None
    text = response.strip()
    candidates = [text]
    fenced = _FENCE.search(text)
    if fenced:
        candidates.insert(0, fenced.group(1).strip())
    start, end = text.find("{"), text.rfind("}")
    if start != -1 and end > start:
        candidates.append(text[start : end + 1])
    for candidate in candidates:
        try:
            value = json.loads(candidate)
        except (json.JSONDecodeError, ValueError):
            continue
        if isinstance(value, dict):
            return value
    return None


def complete_json(
    llm, system: str, user: str, max_tokens: int, retries: int = 1
) -> tuple[dict | None, str]:
    """Stream a reply, parse it as JSON, retry up to `retries` times with a reminder.

    Returns (parsed_or_None, last_raw_reply). Provider errors propagate.
    """
    prompt = user
    raw = ""
    for attempt in range(retries + 1):
        raw = "".join(llm.stream(system, prompt, max_tokens=max_tokens))
        parsed = extract_json(raw)
        if parsed is not None:
            return parsed, raw
        if attempt < retries:
            prompt = user + RETRY_REMINDER
    return None, raw
