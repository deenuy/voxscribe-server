"""Repetition detection and classification — string math, no model.

Adjacent repeated n-grams (n = 1..4) are detected case-insensitively.
Classification decides what happens:

  stutter    "send it send it today" — restart noise, collapse to one copy
  emphasis   "very very important"   — deliberate, always preserved

Detection and action are separate on purpose: in PM mode (and for
idea-level repetition in CP6) the kernel detects and reports without
collapsing, because repetition is evidence there, not noise. Why the
repetition happened (thinking loop vs emphasis) is prosody — a judgment the
audio lane can refine later; the deterministic floor only collapses the
adjacency cases where meaning is safe.
"""

from __future__ import annotations

import re

from .models import RepetitionEvent, RepetitionKind

# Single words whose immediate repetition is usually deliberate.
_EMPHASIS_WORDS = {"very", "really", "so", "no", "never", "truly", "many", "much"}


def _norm(token: str) -> str:
    return re.sub(r"[^\w']", "", token).lower()


def collapse_repetitions(text: str, collapse: bool = True) -> tuple[str, list[RepetitionEvent]]:
    """Find adjacent repeated n-grams. With collapse=False (PM mode) the text
    is returned unchanged and repetitions are only reported."""
    tokens = text.split()
    out: list[str] = []
    events: list[RepetitionEvent] = []
    i = 0
    while i < len(tokens):
        matched = False
        for n in (4, 3, 2, 1):
            if i + 2 * n > len(tokens):
                continue
            first = [_norm(t) for t in tokens[i : i + n]]
            if not any(first) or first != [_norm(t) for t in tokens[i + n : i + 2 * n]]:
                continue
            # count how many consecutive copies there are
            k = 2
            while (
                i + (k + 1) * n <= len(tokens)
                and [_norm(t) for t in tokens[i + k * n : i + (k + 1) * n]] == first
            ):
                k += 1
            phrase = " ".join(tokens[i : i + n])
            is_emphasis = n == 1 and first[0] in _EMPHASIS_WORDS
            if is_emphasis or not collapse:
                out.extend(tokens[i : i + k * n])  # preserve
                events.append(
                    RepetitionEvent(
                        kind=RepetitionKind.EMPHASIS if is_emphasis else RepetitionKind.STUTTER,
                        phrase=phrase,
                        count=k,
                        collapsed=False,
                    )
                )
            else:
                # keep the last copy: it carries any trailing punctuation
                out.extend(tokens[i + (k - 1) * n : i + k * n])
                events.append(
                    RepetitionEvent(
                        kind=RepetitionKind.STUTTER, phrase=phrase, count=k, collapsed=True
                    )
                )
            i += k * n
            matched = True
            break
        if not matched:
            out.append(tokens[i])
            i += 1
    return " ".join(out), events
