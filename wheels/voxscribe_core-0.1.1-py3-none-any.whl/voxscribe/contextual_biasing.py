"""Contextual vocabulary biasing: what the ASR / prompt layer should favor
right now. Dictionary terms are always in (they are the words the user cares
most about); the active topic's keywords join while that topic is live, so a
resumed topic restores its vocabulary — "back to the deploy thing" brings
the deploy vocabulary back with it.

The total list is capped because Whisper's initial_prompt is bounded
(~224 tokens) and longer biasing prompts dilute signal. We reserve a quota
for topic terms so a large dictionary cannot crowd live conversational
context out — the topic vocabulary is what makes biasing track the current
thread.
"""

from __future__ import annotations

from .dictionary import Dictionary
from .lexicon import Lexicon
from .models import VocabularyBiasTerm


def build_bias_terms(
    dictionary: Dictionary,
    topic_keywords: list[str],
    limit: int = 24,
    topic_quota: int = 8,
    lexicon: Lexicon | None = None,
) -> list[VocabularyBiasTerm]:
    """Build a bounded bias list with reserved slots for topic terms.

    `topic_quota` slots are held for active-topic keywords; the remainder
    is filled with dictionary terms. If a lexicon is provided, its
    bias_terms ride the dictionary-tier budget — at the front, so the
    project's high-signal surfaces (Kimi, Turnstile, BridgeMind) are never
    crowded out by generic builtin entries. The topic_quota is unchanged so
    live topic vocabulary still gets its reserved share.
    """
    topic_quota = max(0, min(topic_quota, limit))
    dict_budget = limit - topic_quota

    dict_terms: list[VocabularyBiasTerm] = []
    seen: set[str] = set()

    if lexicon is not None:
        for surface, weight in lexicon.bias_surfaces():
            key = surface.lower()
            if key in seen:
                continue
            seen.add(key)
            dict_terms.append(VocabularyBiasTerm(surface, weight, "lexicon"))

    for _input_form, output_form in dictionary._terms():
        key = output_form.lower()
        if key in seen:
            continue
        seen.add(key)
        dict_terms.append(VocabularyBiasTerm(output_form, 1.0, "dictionary"))

    topic_terms: list[VocabularyBiasTerm] = []
    for word in topic_keywords:
        key = word.lower()
        if key in seen:
            continue
        seen.add(key)
        topic_terms.append(VocabularyBiasTerm(word, 0.6, "topic", ttl_turns=8))
        if len(topic_terms) >= topic_quota:
            break

    # If topic underfills its quota, dictionary may use the leftover slots.
    dict_budget += max(0, topic_quota - len(topic_terms))
    return dict_terms[:dict_budget] + topic_terms


def bias_terms_to_prompt(terms: list[VocabularyBiasTerm]) -> str:
    """Render bias terms as a Whisper initial_prompt string.

    Whisper's initial_prompt is a 224-token soft hint: it nudges the
    decoder's vocabulary distribution without forcing any output. A
    comma-separated list framed as a "domain vocabulary" hint is the
    documented pattern.
    """
    if not terms:
        return ""
    # Preserve weight ordering by source: lexicon/dictionary high-weight
    # before topic (0.6). `source` tiebreak keeps lexicon ahead of topic
    # when weights tie.
    ordered = sorted(terms, key=lambda t: (-t.weight, t.source))
    vocab = ", ".join(t.term for t in ordered)
    return f"Vocabulary in use: {vocab}."
