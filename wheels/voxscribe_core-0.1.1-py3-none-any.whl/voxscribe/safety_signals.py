"""Read-only safety signal scanner: deterministic keyword/pattern matching.

Emits SafetySignal metadata events for the host's safety dashboard or session
review. The scanner is pure and runs on every chunk's raw text; it never
mutates, redacts, or withholds output — the controller's output text is
untouched by anything in this module.

Design:
  - Precision over recall: a false positive is worse than a missed signal.
  - Keywords are whole-word matched (word-boundary regex), case-insensitive.
  - Patterns for structured data (SSN, credit card) use exact format regex.
  - Severity is heuristically assigned per match; the host can override.
  - The scanner is deterministic — no model, no randomness.
"""

from __future__ import annotations

import re

from .models import SafetyCategory, SafetySignal

# ---- per-category keyword lists ----
# Each list is deliberately conservative: only words whose primary meaning
# in isolation signals the category. Conversational use ("I'd kill for a
# coffee") is not matched because "kill" alone is too ambiguous.

_SELF_HARM_KEYWORDS = [
    "suicide",
    "suicidal",
    "self-harm",
    "self harm",
    "cut myself",
    "end my life",
    "take my own life",
    "want to die",
    "kill myself",
    "hurt myself",
    "harm myself",
]

_VIOLENCE_KEYWORDS = [
    "kill them",
    "murder",
    "massacre",
    "slaughter",
    "torture",
    "beat to death",
    "strangle",
    "shoot up",
    "bomb the",
]

_HATE_KEYWORDS = [
    # Multi-word phrases only — single slurs are too context-dependent
    # for a deterministic scanner and belong in the host's moderation layer.
    "exterminate the",
    "ethnic cleansing",
    "white supremacy",
    "racial purity",
    "master race",
]

_HARASSMENT_KEYWORDS = [
    "stalk you",
    "dox you",
    "doxx you",
    "swat you",
]

_SEXUAL_CONTENT_KEYWORDS = [
    "sexual assault",
    "rape",
    "molest",
    "child pornography",
    "sexually abuse",
    "sexually explicit",
]

_CHILD_SAFETY_KEYWORDS = [
    "child abuse",
    "abuse a child",
    "hurt a child",
    "exploit a child",
    "groom a child",
    "child exploitation",
]

_WEAPONS_KEYWORDS = [
    "build a bomb",
    "make a bomb",
    "pipe bomb",
    "homemade explosive",
    "improvised explosive",
    "make explosives",
]

_ILLICIT_SUBSTANCES_KEYWORDS = [
    "buy drugs",
    "sell drugs",
    "trafficking drugs",
    "make meth",
    "cook meth",
    "synthesize fentanyl",
]

_MEDICAL_CLAIMS_KEYWORDS = [
    "cure for cancer",
    "guaranteed to cure",
    "medical advice is",
    "instead of chemotherapy",
    "vaccines cause",
    "essential oils cure",
]

# ---- structured data patterns ----
# These match exact formats: SSN, credit card numbers, etc.
# High precision by design — only exact format matches.

_SSN_PATTERN = re.compile(r"\b\d{3}-\d{2}-\d{4}\b")
_CREDIT_CARD_PATTERN = re.compile(r"\b(?:\d[ -]?){12,19}\b")

# ---- category config ----
# Maps category -> (keywords, severity, label for evidence)

_CATEGORY_CONFIG: dict[SafetyCategory, tuple[list[str], float]] = {
    SafetyCategory.SELF_HARM: (_SELF_HARM_KEYWORDS, 0.95),
    SafetyCategory.VIOLENCE: (_VIOLENCE_KEYWORDS, 0.90),
    SafetyCategory.HATE: (_HATE_KEYWORDS, 0.90),
    SafetyCategory.HARASSMENT: (_HARASSMENT_KEYWORDS, 0.85),
    SafetyCategory.SEXUAL_CONTENT: (_SEXUAL_CONTENT_KEYWORDS, 0.95),
    SafetyCategory.CHILD_SAFETY: (_CHILD_SAFETY_KEYWORDS, 0.95),
    SafetyCategory.WEAPONS: (_WEAPONS_KEYWORDS, 0.85),
    SafetyCategory.ILLICIT_SUBSTANCES: (_ILLICIT_SUBSTANCES_KEYWORDS, 0.85),
    SafetyCategory.MEDICAL_CLAIMS: (_MEDICAL_CLAIMS_KEYWORDS, 0.70),
}


def _match_keywords(
    text: str,
    chunk_id: str,
    category: SafetyCategory,
    keywords: list[str],
    base_severity: float,
) -> list[SafetySignal]:
    """Scan for keyword phrases, returning one SafetySignal per match."""
    signals: list[SafetySignal] = []
    lowered = text.lower()
    for kw in keywords:
        kw_lower = kw.lower()
        start = 0
        while True:
            idx = lowered.find(kw_lower, start)
            if idx == -1:
                break
            # Whole-word check: the match must be bounded by word boundaries
            # or string edges. We verify by checking the surrounding chars.
            before_ok = idx == 0 or not lowered[idx - 1].isalnum()
            after_ok = (
                idx + len(kw_lower) == len(lowered) or not lowered[idx + len(kw_lower)].isalnum()
            )
            if before_ok and after_ok:
                signals.append(
                    SafetySignal(
                        category=category,
                        severity=base_severity,
                        chunk_id=chunk_id,
                        text=text[idx : idx + len(kw)],
                        start_char=idx,
                        end_char=idx + len(kw),
                        evidence=f"keyword match: {kw}",
                    )
                )
            start = idx + len(kw_lower)
    return signals


def _match_patterns(
    text: str,
    chunk_id: str,
    category: SafetyCategory,
    pattern: re.Pattern,
    severity: float,
    evidence_label: str,
) -> list[SafetySignal]:
    """Scan for a regex pattern, returning one SafetySignal per match."""
    signals: list[SafetySignal] = []
    for m in pattern.finditer(text):
        signals.append(
            SafetySignal(
                category=category,
                severity=severity,
                chunk_id=chunk_id,
                text=m.group(0),
                start_char=m.start(),
                end_char=m.end(),
                evidence=evidence_label,
            )
        )
    return signals


def scan(
    text: str,
    chunk_id: str,
    *,
    enabled_categories: set[SafetyCategory] | None = None,
) -> list[SafetySignal]:
    """Scan raw chunk text for safety-relevant patterns.

    Args:
        text: The raw transcript chunk text to scan.
        chunk_id: The chunk this text belongs to (for provenance).
        enabled_categories: If provided, only these categories are scanned.
            If None (the default), all categories are scanned.

    Returns:
        A list of SafetySignal metadata events. Never mutates the text.
        The caller decides what to do with the signals (log, dashboard, etc.).
    """
    if not text.strip():
        return []

    signals: list[SafetySignal] = []

    # Keyword scans
    for category, (keywords, severity) in _CATEGORY_CONFIG.items():
        if enabled_categories is not None and category not in enabled_categories:
            continue
        signals.extend(_match_keywords(text, chunk_id, category, keywords, severity))

    # Structured data scans (always PERSONAL_DATA)
    if enabled_categories is None or SafetyCategory.PERSONAL_DATA in enabled_categories:
        signals.extend(
            _match_patterns(
                text,
                chunk_id,
                SafetyCategory.PERSONAL_DATA,
                _SSN_PATTERN,
                0.95,
                "SSN format match",
            )
        )
        signals.extend(
            _match_patterns(
                text,
                chunk_id,
                SafetyCategory.PERSONAL_DATA,
                _CREDIT_CARD_PATTERN,
                0.80,
                "credit card number format match",
            )
        )

    return signals
