"""Layered long-horizon memory: bounded by construction.

hot    the open turn buffer plus a small window of recent chunks, held in
       ConversationSessionState (bounded by max_provisional_chars and
       hot_chunks). The only verbatim transcript text in working state.
warm   one compact record per closed turn: clean text, chunk ids, topic,
       keywords. Capped; the oldest demote to cold.
cold   one digest per topic: merged keyword counts and a turn tally.
       Grows with the number of topics, never with session length.
ledger every raw chunk in SQLite (the same storage pattern Dictionary
       uses), so any stable span's source_chunk_ids resolve back to raw
       transcript text for the life of the session — full traceability
       without holding the transcript in RAM.
"""

from __future__ import annotations

import sqlite3
from collections import Counter
from collections.abc import Callable
from dataclasses import dataclass, field

from .models import TranscriptChunk

_SCHEMA = """
CREATE TABLE IF NOT EXISTS chunk_ledger (
  chunk_id TEXT PRIMARY KEY,
  session_id TEXT NOT NULL,
  text TEXT NOT NULL,
  t_start_ms REAL DEFAULT 0,
  t_end_ms REAL DEFAULT 0,
  gap_ms_before REAL DEFAULT 0,
  confidence REAL DEFAULT 1.0
);
CREATE INDEX IF NOT EXISTS idx_ledger_session ON chunk_ledger(session_id);
"""


@dataclass
class TurnRecord:
    session_id: str
    turn_id: str
    text: str
    chunk_ids: list[str]
    topic_id: str
    keywords: list[str] = field(default_factory=list)


@dataclass
class TopicDigest:
    keyword_counts: Counter = field(default_factory=Counter)
    turns: int = 0


@dataclass
class ProseSummary:
    """A human-readable summary of a topic, either keyword-based (deterministic)
    or LLM-generated prose (optional, flag-gated)."""

    topic_id: str
    text: str
    source: str = "keyword"  # "keyword" | "llm"
    top_keywords: list[str] = field(default_factory=list)
    turn_count: int = 0


class MemoryManager:
    def __init__(
        self,
        db_path: str = ":memory:",
        hot_chunks: int = 64,
        warm_turns: int = 50,
    ):
        self.hot_chunks = hot_chunks
        self.warm_turns = warm_turns
        self._conn = sqlite3.connect(db_path)
        self._conn.executescript(_SCHEMA)
        self.warm: list[TurnRecord] = []
        self.cold: dict[str, TopicDigest] = {}

    # ---- writes ----

    def record_chunk(self, chunk: TranscriptChunk) -> None:
        self._conn.execute(
            "INSERT OR REPLACE INTO chunk_ledger "
            "(chunk_id, session_id, text, t_start_ms, t_end_ms, gap_ms_before, confidence) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (
                chunk.chunk_id,
                chunk.session_id,
                chunk.text,
                chunk.t_start_ms,
                chunk.t_end_ms,
                chunk.gap_ms_before,
                chunk.confidence,
            ),
        )
        self._conn.commit()

    def record_turn(self, record: TurnRecord) -> None:
        self.warm.append(record)
        while len(self.warm) > self.warm_turns:
            self._demote(self.warm.pop(0))

    def _demote(self, record: TurnRecord) -> None:
        digest = self.cold.setdefault(record.topic_id, TopicDigest())
        digest.keyword_counts.update(record.keywords)
        digest.turns += 1
        # the turn's verbatim text leaves RAM; its chunks stay in the ledger

    # ---- reads ----

    def resolve_chunks(self, chunk_ids: list[str]) -> list[str]:
        """Raw transcript texts for the given chunk ids, in request order."""
        texts: list[str] = []
        for chunk_id in chunk_ids:
            row = self._conn.execute(
                "SELECT text FROM chunk_ledger WHERE chunk_id = ?", (chunk_id,)
            ).fetchone()
            texts.append(row[0] if row else "")
        return texts

    def warm_for(self, session_id: str) -> list[TurnRecord]:
        return [r for r in self.warm if r.session_id == session_id]

    def summarize_topic(
        self,
        topic_id: str,
        *,
        llm: Callable[[list[str], int], str] | None = None,
    ) -> ProseSummary | None:
        """Produce a human-readable summary of a cold-digest topic.

        Without an LLM (the default), the summary is keyword-based:
        "Topic mainly about: gardens, tomatoes, summer — across 5 turns."

        With an LLM callable, it generates prose. If the LLM fails (returns
        empty or raises), the keyword fallback is used instead — fail closed.

        This method is never called on the per-chunk hot path. It is for
        session review, host dashboard, or offline summarization.
        """
        digest = self.cold.get(topic_id)
        if digest is None:
            return None
        top_kw = [w for w, _ in digest.keyword_counts.most_common(8)]
        if not top_kw:
            return None
        if llm is not None:
            try:
                prose = llm(top_kw, digest.turns)
                if prose and prose.strip():
                    return ProseSummary(
                        topic_id=topic_id,
                        text=prose.strip(),
                        source="llm",
                        top_keywords=top_kw,
                        turn_count=digest.turns,
                    )
            except Exception:
                pass  # fail closed to keyword fallback
        # Deterministic keyword summary
        kw_list = ", ".join(top_kw[:5])
        text = f"Topic mainly about: {kw_list} — across {digest.turns} turns"
        return ProseSummary(
            topic_id=topic_id,
            text=text,
            source="keyword",
            top_keywords=top_kw,
            turn_count=digest.turns,
        )

    def summarize_all(
        self,
        *,
        llm: Callable[[list[str], int], str] | None = None,
    ) -> list[ProseSummary]:
        """Summarize every cold-digest topic."""
        return [
            summary
            for tid in self.cold
            if (summary := self.summarize_topic(tid, llm=llm)) is not None
        ]

    def stats(self, session_id: str | None = None) -> dict:
        if session_id is None:
            ledger = self._conn.execute("SELECT COUNT(*) FROM chunk_ledger").fetchone()[0]
            warm = len(self.warm)
        else:
            ledger = self._conn.execute(
                "SELECT COUNT(*) FROM chunk_ledger WHERE session_id = ?",
                (session_id,),
            ).fetchone()[0]
            warm = len(self.warm_for(session_id))
        return {
            "ledger_chunks": ledger,
            "warm_turns": warm,
            "cold_topics": len(self.cold),
        }

    def close(self) -> None:
        self._conn.close()
