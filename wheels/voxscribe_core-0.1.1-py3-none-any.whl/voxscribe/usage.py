"""Per-session, account-attributable usage ledger.

History:
  v1  weekly aggregates only       (logs/usage.json, since-removed)
  v2  per-session entries + cache  (logs/usage.json, since-removed)
  v3  SQLite-backed store          (logs/voxscribe.db, current)

This module preserves the v2 public API — `record_session(...)`,
`weekly_summary(...)`, `current_iso_week(...)`, `WeeklyUsage`,
`LEGACY_ACCOUNT_ID` — but every call now delegates to `voxscribe.store`.
The JSON file is no longer written; it is imported on first store open
and renamed to `usage.json.imported`.  Callers that pass a `ledger_path`
get it interpreted as the SQLite DB path — SQLite happily opens a file
with any extension, so an existing test that passes `tmp_path / "usage.json"`
keeps working without code changes.

Timezone-aware ISO week computation lives here (kept identical to the v2
implementation) because it is presentation-level: the store records
whatever `iso_week` string the caller computed and never re-derives it.
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path

from . import store as _store

try:
    from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
except ImportError:  # pragma: no cover — zoneinfo ships in Python 3.9+
    ZoneInfo = None  # type: ignore[assignment]
    ZoneInfoNotFoundError = Exception  # type: ignore[assignment,misc]


# ---- public constants ------------------------------------------------------


DEFAULT_LEDGER_PATH = Path("logs") / "voxscribe.db"
DEFAULT_WEEK_RESET_TZ = "America/Los_Angeles"
LEGACY_ACCOUNT_ID = _store._LEGACY_ACCOUNT_ID


# Carry the v2 schema version for any caller that still reads the
# attribute via `usage.SCHEMA_VERSION`.  The actual on-disk schema is
# `store.SCHEMA_VERSION`.
SCHEMA_VERSION = 2


# ---- timezone + ISO-week helpers ------------------------------------------


def _zone(tz_name: str) -> timezone:
    if ZoneInfo is None:
        return timezone.utc
    try:
        return ZoneInfo(tz_name)  # type: ignore[return-value]
    except ZoneInfoNotFoundError:
        return timezone.utc


def _iso_week(dt: datetime, tz_name: str = DEFAULT_WEEK_RESET_TZ) -> str:
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    local = dt.astimezone(_zone(tz_name))
    return local.strftime("%G-W%V")


def current_iso_week(
    at: float | None = None,
    tz_name: str = DEFAULT_WEEK_RESET_TZ,
) -> str:
    epoch = at if at is not None else time.time()
    return _iso_week(datetime.fromtimestamp(epoch, tz=timezone.utc), tz_name)


_WEEK_RE = re.compile(r"^(\d{4})-W(\d{2})$")


def _week_start(iso_week: str, tz_name: str) -> datetime:
    m = _WEEK_RE.match(iso_week)
    if not m:
        raise ValueError(f"invalid ISO week label: {iso_week!r}")
    year, week = int(m.group(1)), int(m.group(2))
    naive = datetime.strptime(f"{year}-W{week:02d}-1", "%G-W%V-%u")
    return naive.replace(tzinfo=_zone(tz_name))


def week_resets_at(
    iso_week: str,
    tz_name: str = DEFAULT_WEEK_RESET_TZ,
) -> str:
    start = _week_start(iso_week, tz_name)
    next_start = start + timedelta(days=7)
    return next_start.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _iso_utc(at: float | None = None) -> str:
    epoch = at if at is not None else time.time()
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(epoch))


# ---- public data model ----------------------------------------------------


@dataclass
class WeeklyUsage:
    account_id: str
    iso_week: str
    words: int
    word_cap: int
    ai_actions: int
    sessions: int
    audio_seconds: float
    resets_at: str
    first_at: str = ""
    last_at: str = ""

    @property
    def audio_minutes(self) -> float:
        return self.audio_seconds / 60.0


# ---- public API ------------------------------------------------------------


def _open(ledger_path: str | Path | None) -> _store.Store:
    """Open the SQLite store. `ledger_path` is the DB filename; we keep
    the v2 parameter name so existing callers don't have to change."""
    path = Path(ledger_path) if ledger_path is not None else DEFAULT_LEDGER_PATH
    return _store.open_store(path)


def record_session(
    *,
    session_id: str,
    account_id: str,
    device_id: str,
    mode: str,
    words: int,
    audio_seconds: float,
    ai_actions: int = 0,
    started_at: str | None = None,
    ended_at: str | None = None,
    counted: bool = True,
    uncounted_reason: str | None = None,
    ledger_path: str | Path | None = None,
    week_reset_tz: str = DEFAULT_WEEK_RESET_TZ,
    word_cap: int = 2000,
    at: float | None = None,
) -> WeeklyUsage:
    """Write through to the SQLite store.

    The behavior contract is the v2 contract:
      * idempotent on `session_id`
      * `counted=False` rows are stored but excluded from weekly totals
      * negative `words` / `audio_seconds` / `ai_actions` clamp to 0
    Now backed by `sessions` + `usage_records` tables instead of a JSON
    file.  Existing callers (the CLI, the test suite) do not have to
    change.
    """
    words = max(0, int(words or 0))
    audio_seconds = max(0.0, float(audio_seconds or 0.0))
    ai_actions = max(0, int(ai_actions or 0))

    now_epoch = at if at is not None else time.time()
    ended_iso = ended_at or _iso_utc(now_epoch)
    started_iso = started_at or ended_iso

    # iso_week computed from ended_at in the configured tz.
    try:
        end_dt = (
            datetime.strptime(ended_iso, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
            if ended_at
            else datetime.fromtimestamp(now_epoch, tz=timezone.utc)
        )
    except ValueError:
        end_dt = datetime.fromtimestamp(now_epoch, tz=timezone.utc)
    iso_week_label = _iso_week(end_dt, week_reset_tz)

    store = _open(ledger_path)
    try:
        # Ensure the sessions row exists; for callers that did not run
        # the CLI's `start_session` path this both seeds the row and
        # marks it complete.  INSERT OR REPLACE lets the v2 test suite
        # write directly into the store without prior session bootstrap.
        with store.transaction() as c:
            c.execute(
                "INSERT INTO sessions("
                " id, account_id, device_id, mode, state,"
                " started_at, ended_at, words, audio_seconds, ai_actions,"
                " counted, uncounted_reason, created_at, updated_at"
                ") VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?) "
                "ON CONFLICT(id) DO UPDATE SET "
                " account_id=excluded.account_id,"
                " device_id=excluded.device_id,"
                " mode=excluded.mode,"
                " state=excluded.state,"
                " started_at=excluded.started_at,"
                " ended_at=excluded.ended_at,"
                " words=excluded.words,"
                " audio_seconds=excluded.audio_seconds,"
                " ai_actions=excluded.ai_actions,"
                " counted=excluded.counted,"
                " uncounted_reason=excluded.uncounted_reason,"
                " updated_at=excluded.updated_at",
                (
                    session_id,
                    account_id,
                    device_id,
                    mode or "",
                    "completed",
                    started_iso,
                    ended_iso,
                    words,
                    audio_seconds,
                    ai_actions,
                    1 if counted else 0,
                    (uncounted_reason or "") if not counted else "",
                    started_iso,
                    ended_iso,
                ),
            )
        store.record_usage(
            session_id,
            account_id=account_id,
            iso_week=iso_week_label,
            words=words,
            ai_actions=ai_actions,
            audio_seconds=audio_seconds,
            counted=counted,
        )

        totals = store.weekly_summary(account_id, iso_week_label)
    finally:
        store.close()

    return WeeklyUsage(
        account_id=account_id,
        iso_week=iso_week_label,
        words=totals.words,
        word_cap=int(word_cap),
        ai_actions=totals.ai_actions,
        sessions=totals.sessions,
        audio_seconds=totals.audio_seconds,
        resets_at=week_resets_at(iso_week_label, week_reset_tz),
        first_at=totals.first_at,
        last_at=totals.last_at,
    )


def weekly_summary(
    account_id: str,
    iso_week: str | None = None,
    *,
    ledger_path: str | Path | None = None,
    week_reset_tz: str = DEFAULT_WEEK_RESET_TZ,
    word_cap: int = 2000,
    at: float | None = None,
) -> WeeklyUsage:
    """Read-only snapshot for one account's current ISO week."""
    week_key = iso_week or current_iso_week(at, week_reset_tz)
    store = _open(ledger_path)
    try:
        totals = store.weekly_summary(account_id, week_key)
    finally:
        store.close()
    return WeeklyUsage(
        account_id=account_id or "",
        iso_week=week_key,
        words=totals.words,
        word_cap=int(word_cap),
        ai_actions=totals.ai_actions,
        sessions=totals.sessions,
        audio_seconds=totals.audio_seconds,
        resets_at=week_resets_at(week_key, week_reset_tz),
        first_at=totals.first_at,
        last_at=totals.last_at,
    )
