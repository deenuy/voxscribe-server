"""Deterministic fake implementations for ideas extraction and scoring."""

from .extraction import Citation, EvidenceItem, ExtractedIdea


def fake_extract_ideas(
    segments: list[dict], notes: str = "", **kwargs
) -> list[ExtractedIdea] | None:
    """Deterministic fake idea extraction.

    Extracts exactly one idea per unique speaker in the meeting, using
    their speech as evidence.
    """
    if not segments:
        return None

    speaker_segments = {}
    for seg in segments:
        speaker = seg.get("speaker", "Unknown")
        if speaker not in speaker_segments:
            speaker_segments[speaker] = []
        speaker_segments[speaker].append(seg)

    ideas = []
    idea_types = [
        "new_product",
        "new_feature",
        "feature_enhancement",
        "ai_capability",
        "workflow_automation",
        "data_product",
        "platform_capability",
        "governance_control",
        "experiment",
        "technical_enabler",
        "risk_compliance",
    ]

    for i, (speaker, speaker_segs) in enumerate(sorted(speaker_segments.items())):
        type_idx = i % len(idea_types)
        idea_type = idea_types[type_idx]

        # Use first segment as evidence
        first_seg = speaker_segs[0]
        quote = first_seg.get("text", "")[:100]
        segment_id = first_seg.get("id", "seg_0")

        evidence = [
            EvidenceItem(
                quote=quote,
                speaker=speaker,
                citation=Citation(
                    kind="transcript",
                    segment_id=segment_id,
                    start_ms=first_seg.get("startMs", 0),
                    end_ms=first_seg.get("endMs", 1000),
                ),
            )
        ]

        rubric = {}
        for key in [
            "problem",
            "persona",
            "value",
            "strategy",
            "differentiation",
            "feasibility",
            "data_ai",
            "scope",
            "risk",
            "execution",
        ]:
            # Deterministic score based on speaker and key
            base = sum(ord(c) for c in speaker) + sum(ord(c) for c in key)
            score = (base % 11)
            rubric[key] = {"score": score, "note": f"fake score for {key}"}

        idea = ExtractedIdea(
            title=f"{speaker}'s {idea_type} idea",
            summary=f"An {idea_type} suggested by {speaker}",
            type=idea_type,
            evidence=evidence,
            challenges=[],
            gaps=[],
            assumptions=[],
            contradictions=[],
            originator=speaker,
            contributors=[],
            rubric=rubric,
        )
        ideas.append(idea)

    return ideas if ideas else None


def fake_score_idea(
    title: str, summary: str, evidence_quotes: list[str], **kwargs
) -> dict | None:
    """Deterministic fake scoring.

    Score is based on the hash of title and evidence count.
    """
    rubric_keys = [
        "problem",
        "persona",
        "value",
        "strategy",
        "differentiation",
        "feasibility",
        "data_ai",
        "scope",
        "risk",
        "execution",
    ]

    result = {}
    base = sum(ord(c) for c in title) + len(evidence_quotes) * 10
    for i, key in enumerate(rubric_keys):
        score = ((base + i * 7) % 11)
        result[key] = {"score": score, "note": f"fake {key} score"}

    return result


def fake_generate_prd(
    title: str,
    summary: str,
    type_: str,
    evidence: list[dict],
    challenges: list[dict],
    score: int,
    **kwargs,
) -> str:
    """Deterministic fake PRD generation."""
    lines = [
        f"# {title}",
        "",
        f"**Type:** {type_}",
        f"**Score:** {score}/100",
        "",
        "## Problem",
        summary,
        "",
        "## Personas",
        "To be determined based on evidence.",
        "",
        "## Goals and Non-Goals",
        "- Achieve the stated objective",
        "",
        "## Requirements",
        f"Support the {type_} with the provided evidence.",
        "",
        "## User Stories",
        "As a user, I want to benefit from this idea.",
        "",
        "**Acceptance Criteria:**",
        "- Idea is implemented",
        "",
        "## Risks",
    ]

    for ch in challenges:
        lines.append(f"- {ch.get('category')}: {ch.get('question')}")

    if not challenges:
        lines.append("- No major risks identified")

    lines.extend(
        [
            "",
            "## Open Questions",
            "- How will success be measured?",
            "",
            "## Success Metrics",
            "- Adoption rate",
            "- User satisfaction",
            "",
        ]
    )

    return "\n".join(lines)
