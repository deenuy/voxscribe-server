"""Extract candidate ideas from transcript segments with citation validation."""

from __future__ import annotations

from dataclasses import dataclass

from ..knowledge.llm_stream import StreamingLLMProvider
from ..meeting.llm_json import complete_json


@dataclass
class Citation:
    """A citation to a transcript segment."""

    kind: str
    segment_id: str | None = None
    start_ms: int | None = None
    end_ms: int | None = None


@dataclass
class EvidenceItem:
    """Evidence quote with citation."""

    quote: str
    speaker: str | None
    citation: Citation


@dataclass
class ChallengeItem:
    """A challenge or risk."""

    category: str
    type: str
    question: str
    citation: Citation | None = None


@dataclass
class Contradiction:
    """Two contradictory statements."""

    a_quote: str
    a_citation: Citation
    b_quote: str
    b_citation: Citation


@dataclass
class ExtractedIdea:
    """An idea extracted from a transcript."""

    title: str
    summary: str
    type: str
    evidence: list[EvidenceItem]
    challenges: list[ChallengeItem]
    gaps: list[str]
    assumptions: list[str]
    contradictions: list[Contradiction]
    originator: str | None
    contributors: list[str]
    rubric: dict[str, dict]


def extract_ideas(
    llm: StreamingLLMProvider,
    segments: list[dict],
    notes: str = "",
    transcript_context: str = "",
) -> list[ExtractedIdea] | None:
    """Extract candidate ideas from transcript segments.

    Args:
        llm: streaming LLM provider
        segments: [{id, text, speaker, startMs, endMs, ...}]
        notes: user notes (optional)
        transcript_context: overall context about the meeting

    Returns:
        List of ExtractedIdea or None if parsing failed
    """
    # Build segment map for citation validation
    segment_map = {seg.get("id"): seg for seg in segments}

    # Build transcript text
    transcript = "\n".join(
        f"{seg.get('speaker', 'Unknown')}: {seg.get('text', '')}"
        for seg in segments
    )

    context = f"Transcript:\n{transcript}"
    if notes:
        context += f"\n\nUser Notes:\n{notes}"
    if transcript_context:
        context += f"\n\nContext:\n{transcript_context}"

    system_prompt = (
        "Extract all distinct ideas discussed. For each idea, provide: "
        "title, summary, type (one of: new_product, new_feature, feature_enhancement, "
        "ai_capability, workflow_automation, data_product, platform_capability, "
        "governance_control, experiment, technical_enabler, risk_compliance), "
        "evidence quotes with segment IDs (only valid IDs from the transcript), "
        "challenges, gaps, assumptions, contradictions between evidence items, "
        "originator speaker name, contributor speaker names, "
        "and per-dimension rubric scores 0-10 with reasons. "
        "Output ONLY valid JSON array of {title, summary, type, evidence: [], "
        "challenges: [], gaps: [], assumptions: [], contradictions: [], originator, "
        "contributors: [], rubric: {}}. "
        "Drop any evidence or challenge without a valid citation."
    )

    import json

    parsed, raw = complete_json(llm, system_prompt, context, max_tokens=4096, retries=1)

    # Handle case where response is a JSON array
    # extract_json may extract first dict from array, so try to parse raw if needed
    if not parsed and raw:
        try:
            parsed = json.loads(raw.strip())
        except (json.JSONDecodeError, ValueError):
            parsed = None

    if not parsed:
        return None

    ideas = []
    # Handle both single dict and list of dicts
    items_to_process = [parsed] if isinstance(parsed, dict) else (
        parsed if isinstance(parsed, list) else []
    )

    for item in items_to_process:
        idea = _idea_from_json(item, segment_map)
        if idea:
            ideas.append(idea)

    return ideas if ideas else None


def _idea_from_json(data: dict, segment_map: dict) -> ExtractedIdea | None:
    """Build an idea from parsed JSON, validating citations."""
    if not isinstance(data, dict):
        return None

    title = data.get("title", "").strip()
    summary = data.get("summary", "").strip()
    if_type = data.get("type", "new_feature").strip()

    if not title or not summary:
        return None

    # Validate and clean evidence
    evidence = []
    for ev in data.get("evidence") or []:
        if not isinstance(ev, dict):
            continue
        quote = ev.get("quote", "").strip()
        speaker = ev.get("speaker")
        citation_data = ev.get("citation", {})

        if not quote or not isinstance(citation_data, dict):
            continue

        segment_id = citation_data.get("segmentId")
        if segment_id not in segment_map:
            continue  # Drop invalid citations

        seg = segment_map[segment_id]
        citation = Citation(
            kind="transcript",
            segment_id=segment_id,
            start_ms=citation_data.get("startMs") or seg.get("startMs"),
            end_ms=citation_data.get("endMs") or seg.get("endMs"),
        )
        evidence.append(EvidenceItem(quote=quote, speaker=speaker, citation=citation))

    # Validate and clean challenges
    challenges = []
    for ch in data.get("challenges") or []:
        if not isinstance(ch, dict):
            continue
        category = ch.get("category", "").strip()
        ch_type = ch.get("type", "").strip()
        question = ch.get("question", "").strip()
        if not category or not question:
            continue

        citation = None
        citation_data = ch.get("citation", {})
        if citation_data and isinstance(citation_data, dict):
            segment_id = citation_data.get("segmentId")
            if segment_id in segment_map:
                seg = segment_map[segment_id]
                citation = Citation(
                    kind="transcript",
                    segment_id=segment_id,
                    start_ms=citation_data.get("startMs") or seg.get("startMs"),
                    end_ms=citation_data.get("endMs") or seg.get("endMs"),
                )

        challenges.append(
            ChallengeItem(
                category=category, type=ch_type, question=question, citation=citation
            )
        )

    # Extract gaps
    gaps = [g.strip() for g in (data.get("gaps") or []) if isinstance(g, str) and g.strip()]

    # Extract assumptions
    assumptions = [a.strip() for a in (data.get("assumptions") or []) if isinstance(a, str) and a.strip()]  # noqa: E501

    # Validate and clean contradictions
    contradictions = []
    for cont in data.get("contradictions") or []:
        if not isinstance(cont, dict):
            continue
        a_data = cont.get("a", {})
        b_data = cont.get("b", {})
        if not isinstance(a_data, dict) or not isinstance(b_data, dict):
            continue

        a_quote = a_data.get("quote", "").strip()
        b_quote = b_data.get("quote", "").strip()
        if not a_quote or not b_quote:
            continue

        a_citation_data = a_data.get("citation", {})
        b_citation_data = b_data.get("citation", {})

        a_seg_id = a_citation_data.get("segmentId") if isinstance(a_citation_data, dict) else None
        b_seg_id = b_citation_data.get("segmentId") if isinstance(b_citation_data, dict) else None

        if a_seg_id not in segment_map or b_seg_id not in segment_map:
            continue

        a_seg = segment_map[a_seg_id]
        b_seg = segment_map[b_seg_id]

        a_citation = Citation(
            kind="transcript",
            segment_id=a_seg_id,
            start_ms=a_citation_data.get("startMs", a_seg.get("startMs")),
            end_ms=a_citation_data.get("endMs", a_seg.get("endMs")),
        )
        b_citation = Citation(
            kind="transcript",
            segment_id=b_seg_id,
            start_ms=b_citation_data.get("startMs", b_seg.get("startMs")),
            end_ms=b_citation_data.get("endMs", b_seg.get("endMs")),
        )

        contradictions.append(
            Contradiction(
                a_quote=a_quote,
                a_citation=a_citation,
                b_quote=b_quote,
                b_citation=b_citation,
            )
        )

    # Extract originator and contributors
    originator = data.get("originator")
    contributors = [c.strip() for c in (data.get("contributors") or []) if isinstance(c, str) and c.strip()]  # noqa: E501

    # Extract and validate rubric
    rubric = {}
    rubric_keys = [
        "problem",
        "persona",
        "value",
        "strategy",
        "differentiation",
        "feasibility",
        "data_ai",
        "scope",
        "risk",
        "execution",
    ]
    for key in rubric_keys:
        score_data = (data.get("rubric") or {}).get(key, {})
        if isinstance(score_data, dict):
            score = score_data.get("score", 5)
            reason = score_data.get("note", "")
            try:
                score = max(0, min(10, int(score)))
            except (ValueError, TypeError):
                score = 5
            rubric[key] = {"score": score, "note": str(reason)[:200]}

    return ExtractedIdea(
        title=title,
        summary=summary,
        type=if_type,
        evidence=evidence,
        challenges=challenges,
        gaps=gaps,
        assumptions=assumptions,
        contradictions=contradictions,
        originator=originator,
        contributors=contributors,
        rubric=rubric,
    )
