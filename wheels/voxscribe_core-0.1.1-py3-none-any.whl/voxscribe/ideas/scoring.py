"""Score ideas against a weighted rubric."""

from __future__ import annotations

from ..knowledge.llm_stream import StreamingLLMProvider
from ..meeting.llm_json import complete_json


def score_idea(
    llm: StreamingLLMProvider,
    title: str,
    summary: str,
    evidence_quotes: list[str],
    rubric_keys: list[str] = None,
) -> dict | None:
    """Score an idea against the standard rubric.

    Args:
        llm: streaming LLM provider
        title: idea title
        summary: idea summary
        evidence_quotes: list of evidence quotes supporting the idea
        rubric_keys: optional subset of rubric keys; default is all 10

    Returns:
        dict with scores for each rubric key {key: {score: 0-10, note: str}} or None
    """
    if rubric_keys is None:
        rubric_keys = [
            "problem",
            "persona",
            "value",
            "strategy",
            "differentiation",
            "feasibility",
            "data_ai",
            "scope",
            "risk",
            "execution",
        ]

    evidence_text = "\n".join(f"- {q}" for q in evidence_quotes)

    system_prompt = (
        "Score this idea on each dimension. For each, provide a score 0-10 and a one-line reason. "
        "Output ONLY valid JSON object with keys matching the rubric dimension names, "
        "each with {score: number, note: string}."
    )

    user_prompt = f"""
Idea: {title}

Summary: {summary}

Evidence:
{evidence_text}

Rubric dimensions: {', '.join(rubric_keys)}

Score each dimension 0-10 with a brief reason.
"""

    parsed, raw = complete_json(llm, system_prompt, user_prompt, max_tokens=2048, retries=1)

    if not parsed or not isinstance(parsed, dict):
        return None

    # Validate and normalize scores
    result = {}
    for key in rubric_keys:
        key_data = parsed.get(key, {})
        if isinstance(key_data, dict):
            try:
                score = int(key_data.get("score", 5))
            except (ValueError, TypeError):
                score = 5
            score = max(0, min(10, score))
            note = str(key_data.get("note", ""))[:200]
            result[key] = {"score": score, "note": note}
        else:
            result[key] = {"score": 5, "note": ""}

    return result if result else None


def compute_weighted_score(rubric: dict, weights: dict = None) -> int:
    """Compute weighted total score from rubric.

    Args:
        rubric: {key: {score: int, note: str}, ...}
        weights: optional {key: weight} mapping; default is standard

    Returns:
        weighted score 0-100
    """
    if weights is None:
        weights = {
            "problem": 15,
            "persona": 10,
            "value": 10,
            "strategy": 10,
            "differentiation": 5,
            "feasibility": 10,
            "data_ai": 10,
            "scope": 10,
            "risk": 10,
            "execution": 10,
        }

    total = 0
    weight_sum = 0
    for key, weight in weights.items():
        key_data = rubric.get(key, {})
        if isinstance(key_data, dict):
            score = key_data.get("score", 0)
            try:
                score = int(score)
            except (ValueError, TypeError):
                score = 0
            score = max(0, min(10, score))
            total += score * weight
            weight_sum += weight

    if weight_sum == 0:
        return 0

    # Weights sum to 100, scores are 0-10, so max total is 10*100=1000
    # Weighted average is total/weight_sum (0-10), scale to 0-100
    return int(round(total * 100 / weight_sum / 10))


def score_to_status(score: int) -> str:
    """Map a score 0-100 to a status.

    Thresholds: <40 raw, 40-59 needs_discovery, 60-74 promising,
    75-84 prd_candidate, 85+ delivery_ready.
    """
    if score < 40:
        return "raw"
    elif score < 60:
        return "needs_discovery"
    elif score < 75:
        return "promising"
    elif score < 85:
        return "prd_candidate"
    else:
        return "delivery_ready"
