"""Generate PRD markdown from an idea and its evidence."""

from __future__ import annotations

from ..knowledge.llm_stream import StreamingLLMProvider


def generate_prd(
    llm: StreamingLLMProvider,
    title: str,
    summary: str,
    type_: str,
    evidence: list[dict],
    challenges: list[dict],
    score: int,
) -> str | None:
    """Generate a PRD markdown document grounded in evidence.

    Args:
        llm: streaming LLM provider
        title: idea title
        summary: idea summary
        type_: idea type
        evidence: list of {quote, speaker, citation}
        challenges: list of {category, type, question}
        score: weighted score 0-100

    Returns:
        PRD markdown or None if generation failed
    """
    # Build evidence text with citations
    evidence_text = ""
    for i, ev in enumerate(evidence, 1):
        quote = ev.get("quote", "")
        speaker = ev.get("speaker", "Unknown")
        citation = ev.get("citation", {})
        segment_id = citation.get("segmentId", "")
        evidence_text += f"{i}. {quote} (from {speaker}, {segment_id})\n"

    # Build challenges text
    challenges_text = ""
    for ch in challenges:
        category = ch.get("category", "")
        question = ch.get("question", "")
        challenges_text += f"- {category}: {question}\n"

    system_prompt = (
        "Write a professional PRD (Product Requirements Document) in Markdown. "
        "Include sections: Problem, Personas, Goals and Non-Goals, Requirements, "
        "User Stories with Acceptance Criteria, Risks, Open Questions, Success Metrics. "
        "Ground every claim in the provided evidence. "
        "Output ONLY the Markdown document, starting with a title."
    )

    user_prompt = f"""
Idea: {title}

Summary: {summary}

Type: {type_}

Score: {score}/100

Evidence quotes:
{evidence_text}

Known challenges:
{challenges_text}

Generate a PRD for this idea, grounded in the evidence above. Link evidence by segment ID where applicable.
"""  # noqa: E501

    # For PRD, stream the markdown directly without JSON parsing
    prd_text = "".join(llm.stream(system_prompt, user_prompt, max_tokens=4096))

    if not prd_text or not prd_text.strip():
        return None

    return prd_text.strip()
