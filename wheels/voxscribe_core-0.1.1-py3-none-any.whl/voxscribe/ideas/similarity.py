"""Similarity matching helper for ideas."""

from __future__ import annotations


def cosine_similarity(vec_a: list[float], vec_b: list[float]) -> float:
    """Compute cosine similarity between two vectors.

    Args:
        vec_a: embedding vector
        vec_b: embedding vector

    Returns:
        cosine similarity 0-1
    """
    if not vec_a or not vec_b or len(vec_a) != len(vec_b):
        return 0.0

    dot_product = sum(a * b for a, b in zip(vec_a, vec_b, strict=False))
    mag_a = sum(a * a for a in vec_a) ** 0.5
    mag_b = sum(b * b for b in vec_b) ** 0.5

    if mag_a == 0 or mag_b == 0:
        return 0.0

    return dot_product / (mag_a * mag_b)


def similarity_search(
    query_embedding: list[float],
    existing_embeddings: list[tuple[str, list[float]]],
    threshold: float = 0.8,
) -> str | None:
    """Find the most similar existing idea embedding above threshold.

    Args:
        query_embedding: embedding of new/updated idea
        existing_embeddings: list of (idea_id, embedding) tuples
        threshold: minimum cosine similarity to match (default 0.8)

    Returns:
        ID of most similar existing idea if above threshold, else None
    """
    if not existing_embeddings:
        return None

    best_match = None
    best_score = threshold

    for idea_id, embedding in existing_embeddings:
        similarity = cosine_similarity(query_embedding, embedding)
        if similarity > best_score:
            best_score = similarity
            best_match = idea_id

    return best_match
