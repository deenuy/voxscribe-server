"""The local speak-and-test loop: capture audio, transcribe, clean, report.

This is the first "I can talk to it" milestone. Every piece is pluggable, so
the same loop runs against a real microphone and Whisper, or against fakes in
tests with no audio hardware, model, or network.

Scope note: MicrophoneSource stops recording on an RMS energy gate. That gate
only decides when the *recording* ends so the CLI can hand audio to the ASR —
it is not the kernel's turn policy. Real pause handling (pause bands, no
naive timeout) is CP3 and operates on TranscriptChunks, after this loop.
"""

from __future__ import annotations

import time
from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Protocol

from .audio_providers import ASRProvider
from .context import DictationMode
from .contextual_biasing import bias_terms_to_prompt, build_bias_terms
from .dictionary import PhraseRule as DictPhraseRule
from .lexicon import Lexicon
from .models import TranscriptChunk
from .stream_state import StreamProcessor


class AudioSource(Protocol):
    """Yields one captured utterance as mono float samples."""

    def record(self, max_seconds: float) -> tuple[list[float], int]: ...


class FakeAudioSource:
    """Returns canned samples instantly. Counts calls for tests."""

    def __init__(self, samples: Sequence[float] | None = None, sample_rate: int = 16000):
        self.samples = list(samples) if samples is not None else [0.0] * sample_rate
        self.sample_rate = sample_rate
        self.calls = 0

    def record(self, max_seconds: float) -> tuple[list[float], int]:
        self.calls += 1
        return list(self.samples), self.sample_rate


class MicrophoneSource:
    """Records one utterance from an input device via sounddevice (optional
    dependency, `listen` extra). Import is lazy so constructing this costs
    nothing and the package works with no audio dependencies installed.

    Recording stops at max_seconds, or once speech has been heard and the
    RMS energy stays below the threshold for trailing_silence_s.
    """

    def __init__(
        self,
        sample_rate: int = 16000,
        device: int | None = None,
        energy_threshold: float = 0.01,
        trailing_silence_s: float = 1.2,
        block_s: float = 0.032,
    ):
        self.sample_rate = sample_rate
        self.device = device
        self.energy_threshold = energy_threshold
        self.trailing_silence_s = trailing_silence_s
        self.block_s = block_s

    def record(self, max_seconds: float) -> tuple[list[float], int]:
        try:
            import sounddevice as sd
        except ImportError as exc:
            raise RuntimeError(
                "MicrophoneSource needs sounddevice. Install the listen extra: "
                "pip install 'voxscribe-core[listen]' (or: pip install sounddevice)"
            ) from exc

        block = max(1, int(self.sample_rate * self.block_s))
        max_blocks = max(1, int(max_seconds / self.block_s))
        silence_blocks_needed = max(1, int(self.trailing_silence_s / self.block_s))

        frames: list[float] = []
        speech_heard = False
        silence_run = 0
        with sd.InputStream(
            samplerate=self.sample_rate,
            channels=1,
            dtype="float32",
            device=self.device,
        ) as stream:
            for _ in range(max_blocks):
                data, _overflowed = stream.read(block)
                mono = data[:, 0]
                frames.extend(float(s) for s in mono)
                rms = float((mono**2).mean()) ** 0.5
                if rms >= self.energy_threshold:
                    speech_heard = True
                    silence_run = 0
                elif speech_heard:
                    silence_run += 1
                    if silence_run >= silence_blocks_needed:
                        break
        return frames, self.sample_rate


@dataclass
class ListenReport:
    """Everything the listen-once command prints: the raw transcript, the
    clean text, and where the time went."""

    raw_chunks: list[TranscriptChunk] = field(default_factory=list)
    raw_text: str = ""
    clean_text: str = ""
    used_snippet: bool = False
    used_model: bool = False
    timings_ms: dict[str, float] = field(default_factory=dict)


def listen_once(
    source: AudioSource,
    asr: ASRProvider,
    processor: StreamProcessor,
    mode: DictationMode | None = None,
    session_id: str = "listen-once",
    max_seconds: float = 15.0,
    lexicon: Lexicon | None = None,
) -> ListenReport:
    """capture -> transcribe -> kernel -> report, with per-stage latency."""
    t0 = time.perf_counter()
    samples, sample_rate = source.record(max_seconds)
    t1 = time.perf_counter()
    # Install lexicon scope for this one-shot session so phrase rules and
    # the session lock are active during the dictionary normalize pass.
    dictionary = processor.postprocessor.dictionary
    if lexicon is not None:
        dictionary.load_phrase_rules(
            DictPhraseRule(
                pattern=r.pattern,
                replacement=r.replacement,
                case_insensitive=r.case_insensitive,
                word_boundary=r.word_boundary,
            )
            for r in lexicon.phrase_normalization
        )
        dictionary.seed_session_lock(session_id, (s for s, _ in lexicon.bias_surfaces()))
    dictionary.active_session_id = session_id
    # Soft biasing: the kernel knows the active vocabulary; the ASR consumes
    # it as a hint. Failures here cannot break ASR.
    try:
        if lexicon is not None:
            bias = build_bias_terms(
                dictionary,
                processor.tracker(session_id).active_keywords(),
                lexicon=lexicon,
            )
        else:
            bias = processor.bias_terms(session_id)
        prompt = bias_terms_to_prompt(bias)
    except Exception:
        prompt = ""
    chunks = asr.transcribe(samples, sample_rate, session_id, initial_prompt=prompt or None)
    t2 = time.perf_counter()

    used_snippet = used_model = False
    for chunk in chunks:
        result = processor.feed(chunk, mode)
        used_snippet = used_snippet or result.used_snippet
        used_model = used_model or result.used_model
    # One-shot capture: the utterance is over, so close the session and
    # commit whatever is still provisional.
    final = processor.finalize(session_id)
    used_snippet = used_snippet or final.used_snippet
    used_model = used_model or final.used_model
    t3 = time.perf_counter()

    # Clear the per-session lock so a long-lived processor doesn't carry
    # one session's surfaces into the next.
    dictionary.clear_session_lock(session_id)
    if dictionary.active_session_id == session_id:
        dictionary.active_session_id = None

    return ListenReport(
        raw_chunks=list(chunks),
        raw_text=" ".join(c.text for c in chunks).strip(),
        clean_text=final.stable_text,
        used_snippet=used_snippet,
        used_model=used_model,
        timings_ms={
            "capture": (t1 - t0) * 1000.0,
            "asr": (t2 - t1) * 1000.0,
            "intelligence": (t3 - t2) * 1000.0,
            "total": (t3 - t0) * 1000.0,
        },
    )
