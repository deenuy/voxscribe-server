"""CLI user experience — futuristic, color-aware startup banner, runtime panel
and completion summary.

This module is purely presentation logic. It takes data objects and renders
strings; it does not import VoxScribe internals or make side effects. No
dependencies beyond the Python stdlib.

Four layers:

1. Brand banner          → the colored VoxScribe wordmark/logo, printed first
                           (interactive mode only) the instant a session starts
2. Runtime panel         → box-drawn session "product card" (interactive only)
3. Human logs            → concise pipe-separated operational logs (in cli.py)
4. JSON logs             → Docker/Kubernetes machine-readable logs (in cli.py)

Color is opt-out and TTY-gated: ANSI truecolor is only emitted when stderr is
a terminal, color is enabled in config, and NO_COLOR is unset. The banner and
panel auto-disable entirely when log format is 'json' or stderr is not a TTY
(Docker / pipe / CI), unless explicitly overridden via env.
"""

from __future__ import annotations

import os
import re
import shutil
import sys
from dataclasses import dataclass

# ---- data ------------------------------------------------------------------


@dataclass
class RuntimeSummary:
    """Snapshot of the runtime environment presented in the startup panel.

    All fields are plain strings/booleans so the panel renderer has zero
    knowledge of VoxScribe internals."""

    version: str = ""
    environment: str = ""
    session_id: str = ""
    pid: int = 0
    mode: str = ""
    language: str = ""
    asr_provider: str = ""
    llm_provider: str = ""
    ollama_available: bool | None = None
    ollama_version: str = ""
    report_enabled: bool = False
    report_format: str = ""
    insert_enabled: bool = False
    output_dir: str = ""
    session_log_path: str = ""
    use_unicode: bool = True
    use_color: bool = True
    compact_mode: bool = False


# ---- terminal detection ----------------------------------------------------


def is_interactive_terminal() -> bool:
    """Return True when stderr is connected to a terminal (TTY).

    Panels are for humans, not for log aggregators or Docker."""
    return sys.stderr.isatty()


def terminal_width() -> int:
    """Detect terminal width, defaulting to 80 when not in a TTY."""
    try:
        return shutil.get_terminal_size((80, 24)).columns
    except Exception:
        return 80


# ---- panel visibility ------------------------------------------------------


def should_show_startup_panel(
    cli_config: object,
    log_format: str,
    is_tty: bool,
) -> bool:
    """Decide whether to render the startup banner + panel.

    Rules (in priority order):
    1. If the config explicitly disables, honor that (startup_panel=False).
    2. If log_format is 'json', auto-disable unless env explicitly enables.
    3. If not a TTY, auto-disable unless env explicitly enables.
    """
    explicit = getattr(cli_config, "startup_panel", True)
    if not explicit:
        return False
    # Auto-disable when JSON unless explicitly overridden via env var.
    if log_format == "json":
        env_val = os.environ.get("VOXSCRIBE_CLI_STARTUP_PANEL", "")
        if env_val.strip().lower() not in {"1", "true", "yes", "on"}:
            return False
    # Auto-disable when not a TTY unless explicitly overridden.
    if not is_tty:
        env_val = os.environ.get("VOXSCRIBE_CLI_STARTUP_PANEL", "")
        if env_val.strip().lower() not in {"1", "true", "yes", "on"}:
            return False
    return True


# ---- color support ---------------------------------------------------------

_ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")

_RESET = "\x1b[0m"
_BOLD = "\x1b[1m"
_DIM = "\x1b[2m"


def supports_color(use_color: bool, is_tty: bool) -> bool:
    """Decide whether ANSI color is safe to emit.

    Precedence: NO_COLOR disables; VOXSCRIBE_CLI_COLOR forces on/off; otherwise
    color requires both the config flag and a TTY. Honors the de-facto
    https://no-color.org / FORCE_COLOR conventions."""
    if os.environ.get("NO_COLOR") is not None:
        return False
    forced = os.environ.get("VOXSCRIBE_CLI_COLOR", "").strip().lower()
    if forced in {"1", "true", "yes", "on", "always"}:
        return True
    if forced in {"0", "false", "no", "off", "never"}:
        return False
    if os.environ.get("FORCE_COLOR", "").strip().lower() in {"1", "true", "yes", "on"}:
        return True
    if not use_color:
        return False
    return is_tty


def _fg(r: int, g: int, b: int) -> str:
    """24-bit truecolor foreground escape."""
    return f"\x1b[38;2;{r};{g};{b}m"


def _visible_len(text: str) -> int:
    """Length of a string as the terminal sees it (ANSI codes are zero-width)."""
    return len(_ANSI_RE.sub("", text))


def _pad_right(text: str, width: int) -> str:
    """Left-justify based on *visible* width (color-code-safe)."""
    return text + " " * max(width - _visible_len(text), 0)


def _center(text: str, width: int) -> str:
    """Center based on *visible* width (color-code-safe)."""
    extra = width - _visible_len(text)
    if extra <= 0:
        return text
    left = extra // 2
    return " " * left + text + " " * (extra - left)


# ---- brand gradient --------------------------------------------------------

# Brand gradient stops: electric cyan -> indigo -> magenta. Gives the wordmark
# its "voice spectrum" feel without depending on a 256-color palette.
_BRAND_STOPS = [(34, 211, 238), (129, 140, 248), (244, 114, 182)]


def _lerp(a: tuple[int, int, int], b: tuple[int, int, int], t: float) -> tuple[int, int, int]:
    return tuple(round(a[i] + (b[i] - a[i]) * t) for i in range(3))  # type: ignore[return-value]


def _gradient_rgb(t: float) -> tuple[int, int, int]:
    """Sample the brand gradient at position t in [0, 1]."""
    if t <= 0:
        return _BRAND_STOPS[0]
    if t >= 1:
        return _BRAND_STOPS[-1]
    span = t * (len(_BRAND_STOPS) - 1)
    i = int(span)
    return _lerp(_BRAND_STOPS[i], _BRAND_STOPS[i + 1], span - i)


def _gradient_text(text: str, enabled: bool, bold: bool = False) -> str:
    """Color each glyph along the brand gradient. Spaces stay uncolored."""
    if not enabled:
        return text
    chars = list(text)
    span = max(len([c for c in chars if c != " "]) - 1, 1)
    out: list[str] = []
    lead = _BOLD if bold else ""
    seen = 0
    for ch in chars:
        if ch == " ":
            out.append(ch)
            continue
        r, g, b = _gradient_rgb(seen / span)
        out.append(f"{lead}{_fg(r, g, b)}{ch}")
        seen += 1
    out.append(_RESET)
    return "".join(out)


# ---- theme palette ---------------------------------------------------------


@dataclass
class _Palette:
    enabled: bool
    box: str
    label: str
    value: str
    accent: str
    ok: str
    warn: str
    err: str
    reset: str


def _make_palette(enabled: bool) -> _Palette:
    if not enabled:
        return _Palette(False, "", "", "", "", "", "", "", "")
    return _Palette(
        enabled=True,
        box=_fg(82, 95, 122),  # slate — quiet box chrome
        label=_fg(148, 163, 184),  # muted label text
        value=_fg(226, 232, 240),  # bright value text
        accent=_fg(129, 140, 248),  # indigo accent
        ok=_fg(74, 222, 128),  # green — healthy / listening
        warn=_fg(251, 191, 36),  # amber — degraded
        err=_fg(248, 113, 113),  # red — unreachable
        reset=_RESET,
    )


# ---- box-drawing helpers ---------------------------------------------------


def _box_chars(
    use_unicode: bool, rounded: bool = False
) -> tuple[str, str, str, str, str, str, str, str]:
    """Return (tl, tr, bl, br, h, v, separator_left, separator_right).

    Unicode (optionally rounded corners) or ASCII fallback."""
    if use_unicode:
        tl, tr, bl, br = ("╭", "╮", "╰", "╯") if rounded else ("┌", "┐", "└", "┘")
        return (tl, tr, bl, br, "─", "│", "├", "┤")
    return ("+", "+", "+", "+", "-", "|", "+", "+")


def _ellipsis(value: str, max_chars: int) -> str:
    """Truncate a string to max_chars, appending '…'/'...' if needed."""
    if len(value) <= max_chars:
        return value
    if max_chars <= 1:
        return value[:max_chars]
    return value[: max_chars - 1] + "…"


# ---- brand banner ----------------------------------------------------------

# Big "ANSI Shadow" logo font for the VoxScribe wordmark — the primary mark.
# Each glyph is exactly 6 rows; rows within a glyph share one width. Letters
# are designed to abut (no inter-letter gap), like a real logotype.
_LOGO_GLYPHS: dict[str, list[str]] = {
    "V": ["██╗   ██╗", "██║   ██║", "██║   ██║", "╚██╗ ██╔╝", " ╚████╔╝ ", "  ╚═══╝  "],
    "O": [" ██████╗ ", "██╔═══██╗", "██║   ██║", "██║   ██║", "╚██████╔╝", " ╚═════╝ "],
    "X": ["██╗  ██╗", "╚██╗██╔╝", " ╚███╔╝ ", " ██╔██╗ ", "██╔╝ ██╗", "╚═╝  ╚═╝"],
    "S": ["███████╗", "██╔════╝", "███████╗", "╚════██║", "███████║", "╚══════╝"],
    "C": [" ██████╗", "██╔════╝", "██║     ", "██║     ", "╚██████╗", " ╚═════╝"],
    "R": ["██████╗ ", "██╔══██╗", "██████╔╝", "██╔══██╗", "██║  ██║", "╚═╝  ╚═╝"],
    "I": ["██╗", "██║", "██║", "██║", "██║", "╚═╝"],
    "B": ["██████╗ ", "██╔══██╗", "██████╔╝", "██╔══██╗", "██████╔╝", "╚═════╝ "],
    "E": ["███████╗", "██╔════╝", "█████╗  ", "██╔══╝  ", "███████╗", "╚══════╝"],
}
_LOGO_HEIGHT = 6

# Smaller 5-row block font — fallback when the terminal can't fit the big logo.
_BLOCK_GLYPHS: dict[str, list[str]] = {
    "V": ["█   █", "█   █", "█   █", " █ █ ", "  █  "],
    "O": [" ███ ", "█   █", "█   █", "█   █", " ███ "],
    "X": ["█   █", " █ █ ", "  █  ", " █ █ ", "█   █"],
    "S": [" ████", "█    ", " ███ ", "    █", "████ "],
    "C": [" ████", "█    ", "█    ", "█    ", " ████"],
    "R": ["████ ", "█   █", "████ ", "█  █ ", "█   █"],
    "I": ["███", " █ ", " █ ", " █ ", "███"],
    "B": ["████ ", "█   █", "████ ", "█   █", "████ "],
    "E": ["████", "█   ", "███ ", "█   ", "████"],
}
_BLOCK_HEIGHT = 5
_WORDMARK_LETTERS = "VOXSCRIBE"


def _gradient_row(row: str, enabled: bool) -> str:
    """Color a row of logo art by *column* so the gradient runs
    vertically-consistent across all rows (clean left-to-right brand sweep)."""
    if not enabled:
        return row
    span = max(len(row) - 1, 1)
    out: list[str] = []
    for col, ch in enumerate(row):
        if ch == " ":
            out.append(" ")
            continue
        r, g, b = _gradient_rgb(col / span)
        out.append(f"{_BOLD}{_fg(r, g, b)}{ch}")
    out.append(_RESET)
    return "".join(out)


def _logo_rows(glyphs: dict[str, list[str]], height: int, gap: str, enabled: bool) -> list[str]:
    """Assemble a multi-row wordmark from a glyph font, gradient by column."""
    rows: list[str] = []
    for r in range(height):
        plain = gap.join(glyphs[ch][r] for ch in _WORDMARK_LETTERS)
        rows.append(_gradient_row(plain, enabled))
    return rows


def _logo_width(glyphs: dict[str, list[str]], gap: str) -> int:
    return len(gap.join(glyphs[c][0] for c in _WORDMARK_LETTERS))


def render_brand_banner(
    version: str = "",
    environment: str = "",
    use_unicode: bool = True,
    use_color: bool = True,
    compact_mode: bool = False,
) -> str:
    """Render the VoxScribe logo banner.

    Printed first — the instant a session starts — so the brand greets the
    user before any operational logs. Self-contained: needs nothing but the
    resolved version/environment, so it can render with zero startup latency.

    Tiers by terminal width: big ANSI-shadow logo → smaller block logo →
    single-line wordmark (also the ASCII / non-Unicode fallback).

    ╭──────────────────────────────────────────────────────────────────────╮
    │                                                                      │
    │   ██╗   ██╗ ██████╗ ██╗  ██╗███████╗ ██████╗██████╗ ██╗██████╗ ...    │
    │   ██║   ██║██╔═══██╗╚██╗██╔╝██╔════╝██╔════╝██╔══██╗██║██╔══██╗ ...    │
    │   ...                                                                 │
    │            ▁▂▃▄▅▆▇█▇▆▅▄▃▂▁                                            │
    │     Welcome to VoxScribe v0.0.4 — Your local-first voice intel...     │
    │                                                                      │
    ╰──────────────────────────────────────────────────────────────────────╯
    """
    pal = _make_palette(use_color)
    width = min(terminal_width() - 1, 74)
    inner = width - 2

    # Tagline inside the banner is the welcome message itself.
    meta = render_welcome_line(version, use_color=use_color)
    meta_src = render_welcome_line(version, use_color=False)

    tl, tr, bl, br, h, v, _sl, _sr = _box_chars(use_unicode, rounded=use_unicode)

    def _frame(line: str) -> str:
        bar = f"{pal.box}{v}{pal.reset}" if pal.enabled else v
        return f"{bar}{line}{bar}"

    def _top() -> str:
        return f"{pal.box}{tl}{h * inner}{tr}{pal.reset}" if pal.enabled else f"{tl}{h * inner}{tr}"

    def _bot() -> str:
        return f"{pal.box}{bl}{h * inner}{br}{pal.reset}" if pal.enabled else f"{bl}{h * inner}{br}"

    big_w = _logo_width(_LOGO_GLYPHS, "")
    block_w = _logo_width(_BLOCK_GLYPHS, " ")

    # Tier selection.
    if use_unicode and not compact_mode and inner >= big_w + 2:
        logo_rows = _logo_rows(_LOGO_GLYPHS, _LOGO_HEIGHT, "", pal.enabled)
    elif use_unicode and not compact_mode and inner >= block_w + 2:
        logo_rows = _logo_rows(_BLOCK_GLYPHS, _BLOCK_HEIGHT, " ", pal.enabled)
    else:
        # Single-line wordmark fallback (narrow / ASCII / compact).
        eq_l = "▁▂▃▅▇" if use_unicode else ">>>"
        eq_r = "▇▅▃▂▁" if use_unicode else "<<<"
        small_src = f"{eq_l}  VoxScribe  {eq_r}"
        small = _gradient_text(small_src, pal.enabled, bold=True)
        if width < 50 or compact_mode:
            return f"{small}\n{meta}" if pal.enabled else f"{small_src}  —  {meta_src}"
        return "\n".join(
            [
                _top(),
                _frame(" " * inner),
                _frame(_center(small, inner)),
                _frame(_center(meta, inner)),
                _frame(" " * inner),
                _bot(),
            ]
        )

    # Full logo banner.
    eq = _gradient_row("▁▂▃▄▅▆▇█▇▆▅▄▃▂▁", pal.enabled)
    lines = [_top(), _frame(" " * inner)]
    for row in logo_rows:
        lines.append(_frame(_center(row, inner)))
    lines.append(_frame(" " * inner))
    lines.append(_frame(_center(eq, inner)))
    lines.append(_frame(" " * inner))  # spacing above the welcome tagline
    lines.append(_frame(_center(meta, inner)))
    lines.append(_frame(" " * inner))
    lines.append(_bot())
    return "\n".join(lines)


def render_welcome_line(version: str = "", use_color: bool = True) -> str:
    """One-line greeting with the version injected dynamically.

    Renders: "Welcome to VoxScribe v1.0.1 — Your local-first voice intelligence."
    The version is passed in by the caller (resolved from pyproject/config) so it
    is never hardcoded here. "VoxScribe" is gradient-colored, the version accented.
    """
    pal = _make_palette(use_color)
    name = _gradient_text("VoxScribe", pal.enabled, bold=True)
    ver = f"v{version}" if version else ""
    if pal.enabled and ver:
        ver = f"{pal.accent}{ver}{pal.reset}"
    parts = ["Welcome to", name]
    if ver:
        parts.append(ver)
    return f"{' '.join(parts)} — Your local-first voice intelligence."


# ---- runtime panel ---------------------------------------------------------


def render_startup_panel(summary: RuntimeSummary, width: int | None = None) -> str:
    """Render the runtime "product card" — session details + status.

    Brand lives in the banner above; this card is the operational detail.
    `width` lets the layout shrink the panel to sit beside the banner; when
    omitted it sizes to the terminal (capped at 74).
    Auto-switches to compact mode when the resolved width < 50 characters.
    """
    width = width if width is not None else min(terminal_width() - 1, 74)
    width = max(min(width, 74), 0)
    if width < 50 or summary.compact_mode:
        return render_compact_startup(summary)

    pal = _make_palette(summary.use_color)
    tl, tr, bl, br, h, v, sl, sr = _box_chars(summary.use_unicode, rounded=summary.use_unicode)
    inner = width - 2
    label_width = 14
    # Row layout: V + "  " + label(label_width) + ": " + value(val_width) + V
    val_width = inner - label_width - 4

    def _vbar() -> str:
        return f"{pal.box}{v}{pal.reset}" if pal.enabled else v

    def _row(label: str, value: str, value_color: str = "") -> str:
        display = _ellipsis(value, val_width)
        padded = f"{display:<{val_width}}"
        if pal.enabled:
            lbl = f"{pal.label}{label:<{label_width}}{pal.reset}"
            vcol = value_color or pal.value
            val = f"{vcol}{padded}{pal.reset}"
            sep = f"{pal.box}: {pal.reset}"
            return f"{_vbar()}  {lbl}{sep}{val}{_vbar()}"
        return f"{v}  {label:<{label_width}}: {padded}{v}"

    def _separator() -> str:
        if pal.enabled:
            return f"{pal.box}{sl}{h * inner}{sr}{pal.reset}"
        return f"{sl}{h * inner}{sr}"

    def _top() -> str:
        if pal.enabled:
            return f"{pal.box}{tl}{h * inner}{tr}{pal.reset}"
        return f"{tl}{h * inner}{tr}"

    def _bottom() -> str:
        if pal.enabled:
            return f"{pal.box}{bl}{h * inner}{br}{pal.reset}"
        return f"{bl}{h * inner}{br}"

    def _header(text: str) -> str:
        bar = _vbar()
        return f"{bar}{_center(text, inner)}{bar}"

    lines: list[str] = [_top()]

    # ---- slim accent header (no big logo — banner owns the brand) ----
    head_src = "Session Runtime"
    head = f"{pal.accent}{head_src}{pal.reset}" if pal.enabled else head_src
    lines.append(_header(head))
    lines.append(_separator())

    # ---- session info ----
    lines.append(_row("Session", summary.session_id))
    lines.append(_row("PID", str(summary.pid)))
    lines.append(_row("Mode", summary.mode))
    lines.append(_row("Language", summary.language))
    lines.append(_row("ASR", summary.asr_provider))
    lines.append(_row("LLM", summary.llm_provider))

    # ---- Ollama status (colored by health) ----
    if summary.ollama_available is True and summary.ollama_version:
        ollama_text = f"connected · {summary.ollama_version} · model available"
        ollama_color = pal.ok
    elif summary.ollama_available is True:
        ollama_text = "connected · model available"
        ollama_color = pal.ok
    elif summary.ollama_available is False:
        ollama_text = "unreachable (deterministic fallback)"
        ollama_color = pal.warn
    elif summary.llm_provider.lower().startswith("ollama"):
        ollama_text = "checking…"
        ollama_color = pal.label
    else:
        ollama_text = "n/a"
        ollama_color = pal.label
    lines.append(_row("Ollama", ollama_text, value_color=ollama_color))

    # ---- output behavior ----
    report_text = f"{summary.report_format} on stop" if summary.report_enabled else "off"
    lines.append(_row("Report", report_text))
    lines.append(_row("Cursor Insert", "on" if summary.insert_enabled else "off"))
    lines.append(_row("Output", summary.output_dir))
    lines.append(_row("Session Log", summary.session_log_path or "(none)"))

    # ---- footer (status in green, the headline state) ----
    lines.append(_separator())
    lines.append(
        _row("Status", "● Listening" if summary.use_unicode else "Listening", value_color=pal.ok)
    )
    lines.append(_row("Stop", "make listen-stop or Ctrl-C"))
    lines.append(_bottom())

    return "\n".join(lines)


# ---- startup layout (banner + panel side by side) --------------------------


def _side_by_side(left: str, right: str, gap: int = 3) -> str:
    """Place two multi-line blocks in two columns, vertically centering the
    shorter one. Color-code-safe: padding is computed on *visible* width."""
    L = left.split("\n")
    R = right.split("\n")
    lw = max((_visible_len(x) for x in L), default=0)
    height = max(len(L), len(R))

    def _vcenter(rows: list[str], total: int) -> list[str]:
        extra = total - len(rows)
        top = extra // 2
        return [""] * top + rows + [""] * (extra - top)

    L = _vcenter(L, height)
    R = _vcenter(R, height)
    spacer = " " * gap
    out: list[str] = []
    for left_row, right_row in zip(L, R, strict=False):
        padded = left_row + " " * (lw - _visible_len(left_row))
        out.append(f"{padded}{spacer}{right_row}".rstrip())
    return "\n".join(out)


def _find_blank_row(interior: list[str]) -> str:
    """Return an existing blank framed interior row (border + spaces + border)
    to reuse as vertical filler, preserving the box's border styling/color."""
    for row in interior:
        plain = _ANSI_RE.sub("", row)
        if len(plain) >= 2 and plain[1:-1].strip() == "":
            return row
    return interior[0] if interior else ""


def _pad_box_height(box: str, target_height: int) -> str:
    """Grow a bordered box to target_height by inserting blank interior rows,
    split top/bottom so the content stays vertically centered inside the box."""
    lines = box.split("\n")
    if len(lines) >= target_height or len(lines) < 2:
        return box
    blank = _find_blank_row(lines[1:-1])
    need = target_height - len(lines)
    top = need // 2
    bottom = need - top
    return "\n".join([lines[0]] + [blank] * top + lines[1:-1] + [blank] * bottom + [lines[-1]])


def render_startup_layout(summary: RuntimeSummary, gap: int = 3) -> str:
    """Render the brand banner and the runtime panel together.

    On a wide terminal the two boxes sit side by side and are sized to match —
    same width when there's room for two full boxes, and always the same height
    (the shorter box is padded) so they look like a uniform pair. On a narrower
    terminal they stack vertically. Compact mode always stacks."""
    banner = render_brand_banner(
        version=summary.version,
        environment=summary.environment,
        use_unicode=summary.use_unicode,
        use_color=summary.use_color,
        compact_mode=summary.compact_mode,
    )
    if summary.compact_mode:
        return f"{banner}\n{render_compact_startup(summary)}"

    banner_w = max((_visible_len(x) for x in banner.split("\n")), default=0)
    avail = terminal_width()
    panel_floor = 56  # below this the panel rows get too cramped to read
    panel_budget = avail - banner_w - gap

    if panel_budget >= panel_floor:
        panel = render_startup_panel(summary, width=min(banner_w, panel_budget))
        # Equalize height so both boxes share the same top/bottom edges.
        target_h = max(len(banner.split("\n")), len(panel.split("\n")))
        banner = _pad_box_height(banner, target_h)
        panel = _pad_box_height(panel, target_h)
        return _side_by_side(banner, panel, gap)

    # Not enough room: stack vertically (full-width panel).
    return f"{banner}\n\n{render_startup_panel(summary)}"


# ---- compact startup -------------------------------------------------------


def render_compact_startup(summary: RuntimeSummary) -> str:
    """Render a compact one-to-three-line startup for narrow terminals.

    Format:
      VoxScribe v0.1.0 | session-... | pid=... | prose(default)
      ASR: Whisper/base.en | LLM: ollama/gemma3:4b | Report: markdown | Insert: off
      Output: output/ | Log: logs/sessions/....log.jsonl
      ● Listening. Stop with: make listen-stop or Ctrl-C
    """
    pal = _make_palette(summary.use_color)

    brand = _gradient_text("VoxScribe", pal.enabled, bold=True)
    parts = [
        f"{brand} v{summary.version}",
        summary.session_id,
        f"pid={summary.pid}",
        summary.mode,
    ]
    line1 = " | ".join(parts)

    parts2 = [
        f"ASR: {summary.asr_provider}",
        f"LLM: {summary.llm_provider}",
        f"Report: {summary.report_format if summary.report_enabled else 'off'}",
        f"Insert: {'on' if summary.insert_enabled else 'off'}",
    ]
    if summary.ollama_available is True:
        parts2.append(f"Ollama: connected {summary.ollama_version}".strip())
    elif summary.ollama_available is False:
        parts2.append("Ollama: unreachable")
    line2 = " | ".join(parts2)

    parts3 = [f"Output: {summary.output_dir}"]
    if summary.session_log_path:
        parts3.append(f"Log: {summary.session_log_path}")
    line3 = " | ".join(parts3)

    status_src = "● Listening" if summary.use_unicode else "Listening"
    status = f"{pal.ok}{status_src}{pal.reset}" if pal.enabled else status_src

    lines = [line1]
    if line2:
        lines.append(line2)
    if line3:
        lines.append(line3)
    lines.append(f"{status}. Stop with: make listen-stop or Ctrl-C")
    return "\n".join(lines)


# ---- completion summary ----------------------------------------------------


def _fmt_duration(seconds: float) -> str:
    """Render a duration in a compact human-friendly form: 47s, 2m 51s, 1h 03m."""
    s = max(0.0, float(seconds))
    if s < 60:
        return f"{s:.0f}s"
    if s < 3600:
        m, rem = divmod(int(s), 60)
        return f"{m}m {rem:02d}s"
    h, rem = divmod(int(s), 3600)
    return f"{h}h {rem // 60:02d}m"


def _format_reset_countdown(resets_at: str) -> str:
    """Render "resets in 5d" / "resets in 4h" / "" given an RFC3339Z deadline.

    Empty input or a past deadline returns ''. The countdown is intentionally
    coarse (days when >= 24h, hours otherwise) — a precise timer here would
    be noise."""
    if not resets_at:
        return ""
    try:
        import time as _time

        deadline = _time.strptime(resets_at, "%Y-%m-%dT%H:%M:%SZ")
        seconds_left = int(_time.mktime(deadline) - _time.mktime(_time.gmtime()) + _time.timezone)
    except Exception:  # noqa: BLE001
        return ""
    if seconds_left <= 0:
        return ""
    if seconds_left >= 86400:
        return f"resets in {seconds_left // 86400}d"
    return f"resets in {max(1, seconds_left // 3600)}h"


def render_completion_summary(
    session_id: str,
    txt_path: str,
    jsonl_path: str,
    report_path: str = "",
    session_log_path: str = "",
    stable_spans: int = 0,
    segments_seen: int = 0,
    ticks_seen: int = 0,
    bias_prompts_sent: int = 0,
    timings_ms: dict | None = None,
    provider_fell_back: bool = False,
    use_unicode: bool = True,
    use_color: bool = True,
    compact_mode: bool = False,
    # Customer-facing metrics (added with product-mode billing model).
    # All optional so existing call sites keep working unchanged.
    words_finalized: int = 0,
    chars_finalized: int = 0,
    audio_speech_s: float = 0.0,
    audio_silence_s: float = 0.0,
    avg_confidence: float = 0.0,
    rtf: float = 0.0,
    repetitions_seen: int = 0,
    mode: str = "",
    asr_model: str = "",
    llm_provider: str = "",
    llm_model: str = "",
    llm_requests: int = 0,
    weekly_words_used: int = 0,
    weekly_word_cap: int = 0,
    weekly_resets_at: str = "",
    started_at: str = "",
    ended_at: str = "",
    display_tz: str = "",
) -> str:
    """Render a completion summary after a session ends.

    The panel is organized for two readers: a *user* who wants to see what
    they got (words, audio, accuracy) and a *billing backend* that meters on
    finalized words. Spans / Ticks / Bias Prompts are intentionally absent —
    they remain in the JSONL event log for debugging.
    """
    timings = timings_ms or {}
    width = min(terminal_width() - 1, 74)
    if width < 50 or compact_mode:
        return _compact_completion(
            session_id,
            txt_path,
            jsonl_path,
            report_path,
            session_log_path,
        )

    pal = _make_palette(use_color)
    tl, tr, bl, br, h, v, sl, sr = _box_chars(use_unicode, rounded=use_unicode)
    inner = width - 2
    label_width = 14
    val_width = inner - label_width - 4

    def _vbar() -> str:
        return f"{pal.box}{v}{pal.reset}" if pal.enabled else v

    def _row(label: str, value: str, value_color: str = "") -> str:
        display = _ellipsis(value, val_width)
        padded = f"{display:<{val_width}}"
        if pal.enabled:
            lbl = f"{pal.label}{label:<{label_width}}{pal.reset}"
            vcol = value_color or pal.value
            val = f"{vcol}{padded}{pal.reset}"
            sep = f"{pal.box}: {pal.reset}"
            return f"{_vbar()}  {lbl}{sep}{val}{_vbar()}"
        return f"{v}  {label:<{label_width}}: {padded}{v}"

    def _separator() -> str:
        if pal.enabled:
            return f"{pal.box}{sl}{h * inner}{sr}{pal.reset}"
        return f"{sl}{h * inner}{sr}"

    lines: list[str] = []
    if pal.enabled:
        lines.append(f"{pal.box}{tl}{h * inner}{tr}{pal.reset}")
    else:
        lines.append(f"{tl}{h * inner}{tr}")

    glyph = "✓ " if use_unicode else ""
    head_src = f"{glyph}Session Complete"
    head = f"{pal.ok}{head_src}{pal.reset}" if pal.enabled else head_src
    lines.append(f"{_vbar()}{_center(head, inner)}{_vbar()}")

    has_details = bool(txt_path or jsonl_path or report_path or session_log_path)
    if has_details:
        lines.append(_separator())

    # Artifacts
    lines.append(_row("Transcript", txt_path))
    lines.append(_row("Events", jsonl_path))
    if report_path:
        label = "Markdown" if report_path.endswith(".md") else "Report"
        lines.append(_row(label, report_path))
    if session_log_path:
        lines.append(_row("Session Log", session_log_path))

    # Output (billable line): the unit VoxScribe meters on.
    lines.append(_separator())
    output_val = f"Words: {words_finalized}"
    if chars_finalized:
        output_val += f"   Characters: {chars_finalized}"
    lines.append(_row("Output", output_val))

    # Session length (wall clock from timings.total) vs. Audio captured
    # (speech-bearing audio that passed the silence gate). These two
    # differ whenever the mic recorded long silent stretches the gate
    # dropped — splitting them prevents the "missing hours" surprise that
    # came from labeling the captured-audio value as "Duration".
    session_length_s = float(timings.get("total", 0) or 0) / 1000.0
    audio_total = audio_speech_s + audio_silence_s
    if session_length_s > 0:
        lines.append(_row("Session", f"Length: {_fmt_duration(session_length_s)}"))
    # Started / Ended timestamps are localized via the single canonical
    # `format_display_ts` helper so DST-aware abbreviations (EDT vs EST,
    # PDT vs PST) match the resolved instant. JSONL still stores UTC.
    if started_at or ended_at:
        from .logging_config import format_display_ts as _fmt_ts

        if started_at:
            lines.append(_row("Started", _fmt_ts(started_at, display_tz or None)))
        if ended_at:
            lines.append(_row("Ended", _fmt_ts(ended_at, display_tz or None)))
    if audio_total > 0:
        speech_pct = int(round(100.0 * audio_speech_s / audio_total))
        audio_val = f"Captured: {_fmt_duration(audio_total)}   Speech: {speech_pct}%"
        if mode:
            audio_val += f"   Mode: {mode}"
        lines.append(_row("Audio", audio_val))
    elif mode:
        lines.append(_row("Audio", f"Mode: {mode}"))

    # ASR: RTF + average confidence + model.
    asr_parts: list[str] = []
    if rtf > 0:
        asr_parts.append(f"RTF: {rtf:.2f}x")
    if avg_confidence > 0:
        asr_parts.append(f"Conf: {avg_confidence:.2f}")
    if asr_model:
        asr_parts.append(f"Whisper / {asr_model}")
    if repetitions_seen:
        asr_parts.append(f"Reps: {repetitions_seen}")
    if asr_parts:
        lines.append(_row("ASR", "   ".join(asr_parts)))

    # LLM: request count + provider/model. Tokens/cost are tracked
    # internally; surfaced here once the provider plumbs them through.
    llm_parts: list[str] = []
    if llm_provider or llm_model:
        slug = " / ".join(p for p in (llm_provider, llm_model) if p)
        llm_parts.append(slug)
    if llm_requests:
        llm_parts.append(f"Requests: {llm_requests}")
    if llm_parts:
        lines.append(_row("LLM", "   ".join(llm_parts)))

    # Usage: session contribution + weekly tally / cap + reset countdown.
    if weekly_word_cap > 0 or weekly_words_used > 0:
        usage_val = f"Session: {words_finalized}"
        if weekly_word_cap > 0:
            usage_val += f"   Week: {weekly_words_used} / {weekly_word_cap}"
        else:
            usage_val += f"   Week: {weekly_words_used}"
        reset_text = _format_reset_countdown(weekly_resets_at)
        if reset_text:
            usage_val += f"   {reset_text}"
        lines.append(_row("Usage", usage_val))

    # Timings: kept under the customer-facing block as a single dense line.
    timing_parts = []
    if timings.get("asr"):
        timing_parts.append(f"ASR {timings['asr']:.0f}ms")
    if timings.get("intelligence"):
        timing_parts.append(f"Intel {timings['intelligence']:.0f}ms")
    if timings.get("flush"):
        timing_parts.append(f"Flush {timings['flush']:.0f}ms")
    if timings.get("total"):
        timing_parts.append(f"Total {timings['total'] / 1000:.1f}s")
    if timing_parts:
        lines.append(_row("Timings", " | ".join(timing_parts)))

    if provider_fell_back:
        lines.append(_separator())
        lines.append(
            _row("Note", "Deterministic-only cleanup (LLM unavailable)", value_color=pal.warn)
        )

    if pal.enabled:
        lines.append(f"{pal.box}{bl}{h * inner}{br}{pal.reset}")
    else:
        lines.append(f"{bl}{h * inner}{br}")
    return "\n".join(lines)


def _compact_completion(
    session_id: str,
    txt_path: str,
    jsonl_path: str,
    report_path: str = "",
    session_log_path: str = "",
) -> str:
    """Compact completion summary for narrow terminals."""
    lines = [
        f"Session {session_id} completed.",
        f"Transcript : {txt_path}",
        f"Events     : {jsonl_path}",
    ]
    if report_path:
        label = "Markdown   " if report_path.endswith(".md") else "Report     "
        lines.append(f"{label}: {report_path}")
    if session_log_path:
        lines.append(f"Log        : {session_log_path}")
    return "\n".join(lines)
