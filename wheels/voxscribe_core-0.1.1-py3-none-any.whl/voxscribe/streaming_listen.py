"""Long-horizon streaming session: mic -> ASR -> StreamProcessor -> output/.

The runtime that makes the 94-year-old acceptance lens testable end-to-end.

What this layer does NOT decide:
  - when the session ends      (only the host's stop signal does)
  - when a turn ends           (the kernel's pause-band policy decides)
  - when a thought is complete (the kernel decides)

What this layer DOES decide:
  - when a *chunk* of audio is ready to ship to ASR
  - when to tell the kernel "silence is ongoing" so pause bands advance

Chunking is intentionally short-horizon: a ~700 ms in-utterance silence ends a
chunk and sends it to ASR. Anything longer is the kernel's problem, surfaced as
TranscriptChunk.gap_ms_before and StreamProcessor.tick(silence_ms). That keeps
the "no naive timeout" rule honest all the way down to the microphone — a 30 s
mid-thought pause cannot terminate either the recording or the turn.

Output:
  output/<session_id>.txt    stable spans appended as they commit (paragraphs)
  output/<session_id>.jsonl  every kernel lifecycle event, one JSON per line
  output/voxscribe.pid       PID of the running session; `make listen-stop`
                             SIGTERMs this and waits for graceful finalize
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
from collections.abc import Callable, Iterator
from dataclasses import dataclass, field
from pathlib import Path
from typing import Protocol

from .audio_providers import ASRProvider
from .blob_store import delete_blob, write_blob
from .context import DictationMode
from .contextual_biasing import bias_terms_to_prompt, build_bias_terms
from .dictionary import PhraseRule as DictPhraseRule
from .lexicon import Lexicon
from .logging_config import get_logger, log_event
from .models import (
    RepetitionEvent,
    SessionReport,
    StreamingResult,
    event_to_dict,
)
from .policy import PolicyGate
from .providers import LLMProvider
from .session_report import (
    build_session_report,
    deliver_report_text,
    render_json,
    render_markdown,
)
from .stream_state import StreamProcessor

log = get_logger("voxscribe.streaming_listen")


# ---- mic capture ------------------------------------------------------------


@dataclass
class StreamingMicConfig:
    """Tuning for utterance segmentation.

    These bound CHUNK boundaries, not turn boundaries. chunk_end_silence_s
    must stay well below PauseBandConfig.long_ms (1500 ms by default) so that
    a thinking pause shows up as an inter-chunk gap_ms_before that the
    kernel's pause-band policy classifies — not as lost audio.

    Field names mirror the OpenAI Realtime API VAD config so operators can
    reason about both stacks with one mental model:
      energy_threshold   ~ session.audio.input.turn_detection.threshold
      prefix_padding_s   ~ session.audio.input.turn_detection.prefix_padding_ms
      chunk_end_silence_s ~ session.audio.input.turn_detection.silence_duration_ms

    prefix_padding_s is the audio captured *before* the energy gate opens.
    Without it, the leading phoneme of every utterance is clipped and the
    ASR hallucinates a soft consonant — the most common Whisper failure on
    short responses.
    """

    sample_rate: int = 16000
    block_s: float = 0.032
    energy_threshold: float = 0.01
    chunk_end_silence_s: float = 0.7
    prefix_padding_s: float = 0.3
    tick_interval_s: float = 0.5
    max_chunk_s: float = 20.0


# Event yielded by mic event streams:
#   ("segment", samples: list[float], gap_ms_before: float)
#   ("tick",    silence_ms_so_far: float, 0.0)
MicEvent = tuple[str, object, float]


class MicEventSource(Protocol):
    """Anything that yields mic events. The real mic and test fakes share it."""

    cfg: StreamingMicConfig

    def stop(self) -> None: ...

    def events(self) -> Iterator[MicEvent]: ...


class StreamingMicrophone:
    """Continuous mic capture with energy-based chunk segmentation.

    Audio is read in `block_s` blocks. The recorder never decides the session
    is over. On stop(), the generator exits cleanly and any in-flight speech
    buffer is emitted as a final segment.
    """

    def __init__(
        self,
        cfg: StreamingMicConfig | None = None,
        device: int | None = None,
    ):
        self.cfg = cfg or StreamingMicConfig()
        self.device = device
        self._stop = threading.Event()

    def stop(self) -> None:
        self._stop.set()

    def events(self) -> Iterator[MicEvent]:
        try:
            import sounddevice as sd
        except ImportError as exc:
            raise RuntimeError(
                "StreamingMicrophone needs sounddevice. Install: "
                "pip install 'voxscribe-core[listen]'"
            ) from exc

        from collections import deque

        cfg = self.cfg
        block = max(1, int(cfg.sample_rate * cfg.block_s))
        end_silence_blocks = max(1, int(cfg.chunk_end_silence_s / cfg.block_s))
        max_chunk_blocks = max(1, int(cfg.max_chunk_s / cfg.block_s))
        tick_blocks = max(1, int(cfg.tick_interval_s / cfg.block_s))
        prefix_blocks = max(0, int(cfg.prefix_padding_s / cfg.block_s))
        block_ms = cfg.block_s * 1000.0
        chunk_end_silence_ms = cfg.chunk_end_silence_s * 1000.0

        speaking = False
        buf: list[float] = []
        speech_blocks = 0
        silence_run = 0
        silence_ms = 0.0
        blocks_since_tick = 0
        # Rolling pre-roll of pre-onset audio so we don't clip the first
        # phoneme. Bounded so a long silence cannot grow it unboundedly.
        preroll: deque[list[float]] = (
            deque(maxlen=prefix_blocks) if prefix_blocks else deque(maxlen=0)
        )

        with sd.InputStream(
            samplerate=cfg.sample_rate,
            channels=1,
            dtype="float32",
            device=self.device,
            blocksize=block,
        ) as stream:
            while not self._stop.is_set():
                data, _overflowed = stream.read(block)
                mono = data[:, 0]
                rms = float((mono**2).mean()) ** 0.5

                if rms >= cfg.energy_threshold:
                    if not speaking:
                        speaking = True
                        buf = []
                        speech_blocks = 0
                        # Prepend the captured pre-roll silence so the
                        # leading phoneme is intact for the ASR.
                        for prev in preroll:
                            buf.extend(prev)
                        preroll.clear()
                    buf.extend(float(s) for s in mono)
                    speech_blocks += 1
                    silence_run = 0
                    blocks_since_tick = 0

                    if speech_blocks >= max_chunk_blocks:
                        yield ("segment", buf, silence_ms)
                        speaking = False
                        buf = []
                        speech_blocks = 0
                        silence_ms = 0.0
                else:
                    if speaking:
                        buf.extend(float(s) for s in mono)
                        speech_blocks += 1
                        silence_run += 1
                        if silence_run >= end_silence_blocks:
                            gap = silence_ms
                            yield ("segment", buf, gap)
                            speaking = False
                            buf = []
                            speech_blocks = 0
                            silence_run = 0
                            # The trailing silence inside the segment counts
                            # toward the gap before the NEXT segment.
                            silence_ms = chunk_end_silence_ms
                            blocks_since_tick = 0
                    else:
                        # Keep a rolling pre-roll of recent silence so the
                        # next speech onset has audible runway.
                        if prefix_blocks:
                            preroll.append([float(s) for s in mono])
                        silence_ms += block_ms
                        blocks_since_tick += 1
                        if blocks_since_tick >= tick_blocks:
                            blocks_since_tick = 0
                            yield ("tick", silence_ms, 0.0)

        # Stop requested: flush whatever speech is still buffered so we
        # don't drop the last words.
        if speaking and buf:
            yield ("segment", buf, silence_ms)


def _formats_to_write(report_format: str) -> set[str]:
    """Normalize the report_format string into the set of files to write.

    Accepts 'md' and 'markdown' as synonyms (the CLI uses 'md', env config
    uses 'markdown'); accepts 'both' meaning both files; defaults to 'md'."""
    fmt = (report_format or "").strip().lower()
    if fmt == "json":
        return {"json"}
    if fmt == "both":
        return {"md", "json"}
    # 'md', 'markdown', or anything unrecognized -> Markdown only.
    return {"md"}


# ---- session driver ---------------------------------------------------------


@dataclass
class ListenSessionReport:
    """End-of-session report.

    Three groups of fields:

    Stage timings (timings_ms) for the latency budget:
      asr_ms          time spent inside asr.transcribe() across all segments
      intelligence_ms time spent inside processor.feed / processor.tick
      flush_ms        time spent writing txt/jsonl to disk
      total_ms        wall clock from first event to finalize completion

    Pipeline counters (kept for the JSONL event log; not shown in the human
    completion panel):
      stable_spans, chunks_seen, ticks_seen, segments_seen, bias_prompts_sent

    Customer-facing metrics (shown in the human completion panel and used
    by the weekly usage ledger):
      audio_speech_s     seconds of actual speech captured (segments only)
      audio_silence_s    seconds of silence between segments (ticks * tick_s)
      words_finalized    word count of the cleaned, stable transcript
      chars_finalized    character count of the cleaned, stable transcript
      avg_confidence     mean ASR confidence across all chunks (0..1)
      rtf                real-time factor: asr_ms / audio_speech_ms
      repetitions_seen   number of repetition events from the kernel
      llm_requests       number of LLM calls (set by caller; 0 when unset)
    """

    session_id: str
    txt_path: str
    jsonl_path: str
    stable_spans: int = 0
    stable_text: str = ""
    chunks_seen: int = 0
    ticks_seen: int = 0
    segments_seen: int = 0
    bias_prompts_sent: int = 0
    timings_ms: dict = field(default_factory=dict)
    # Optional finalize-time report (CP7). Populated only when build_report
    # is requested by the caller; the file is written next to txt/jsonl.
    session_report: SessionReport | None = None
    report_path: str = ""
    # Customer-facing metrics (added when product modes shipped).
    audio_speech_s: float = 0.0
    audio_silence_s: float = 0.0
    words_finalized: int = 0
    chars_finalized: int = 0
    avg_confidence: float = 0.0
    rtf: float = 0.0
    repetitions_seen: int = 0
    llm_requests: int = 0

    @property
    def audio_total_s(self) -> float:
        return self.audio_speech_s + self.audio_silence_s

    @property
    def speech_ratio(self) -> float:
        total = self.audio_total_s
        return self.audio_speech_s / total if total > 0 else 0.0


def run_listen_session(
    mic: MicEventSource,
    asr: ASRProvider,
    processor: StreamProcessor,
    session_id: str,
    output_dir: Path,
    mode: DictationMode = DictationMode.IDEASCRIBE,
    lexicon: Lexicon | None = None,
    build_report: bool = False,
    report_format: str = "md",
    summarizer: LLMProvider | None = None,
    phase_logger: Callable[[str], None] | None = None,
    product: str = "",
    gap_log_threshold_s: float = 30.0,
    store: object | None = None,
    blob_dir: Path | None = None,
    retain_audio: bool = False,
    gate: PolicyGate | None = None,
    echo_guard: object | None = None,
) -> ListenSessionReport:
    """Drive a long-horizon session until mic.events() exits.

    Stop is external: the caller wires mic.stop() to a signal handler so the
    generator returns and we reach the finally block. finalize() commits
    whatever is still provisional, so the speaker never loses their last words
    on stop. All stable spans and events are flushed to output/ as they
    happen — if the process is killed -9, the on-disk transcript is still the
    truth up to the moment of death.
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    txt_path = output_dir / f"{session_id}.txt"
    jsonl_path = output_dir / f"{session_id}.jsonl"

    # Truncate any prior content under the same session_id.
    txt_path.write_text("", encoding="utf-8")
    jsonl_path.write_text("", encoding="utf-8")
    from .context import product_label

    mode_value = mode.value if hasattr(mode, "value") else str(mode)
    resolved_product = (
        product or product_label(mode) if isinstance(mode, DictationMode) else product
    )
    log_event(
        log,
        "session_started",
        session_id=session_id,
        output_dir=str(output_dir),
        mode=mode_value,
        product=resolved_product,
    )
    log_event(
        log,
        "asr_provider_selected",
        session_id=session_id,
        provider=type(asr).__name__,
        model=getattr(asr, "model_size", "") or getattr(asr, "model", ""),
    )
    log_event(log, "audio_capture_started", session_id=session_id)

    # CP7: install the lexicon into the dictionary for the duration of this
    # session. Phrase rules apply in the final normalize pass; the lock map
    # is seeded with canonical surfaces and cleared in the finally block.
    dictionary = processor.postprocessor.dictionary
    if lexicon is not None:
        dictionary.load_phrase_rules(
            DictPhraseRule(
                pattern=r.pattern,
                replacement=r.replacement,
                case_insensitive=r.case_insensitive,
                word_boundary=r.word_boundary,
            )
            for r in lexicon.phrase_normalization
        )
        dictionary.seed_session_lock(
            session_id,
            (s for s, _w in lexicon.bias_surfaces()),
        )
    dictionary.active_session_id = session_id

    def _phase(msg: str) -> None:
        # Structured mirror of the human phase string so JSON log consumers
        # can extract the shutdown-phase state machine without parsing.
        # `phase: <name> <start|ok|failed>` -> structured events of the
        # same name.
        try:
            tokens = msg.replace("phase:", "").strip().split()
            if tokens:
                phase_name = tokens[0]
                state = tokens[1] if len(tokens) > 1 else ""
                if state == "start":
                    log_event(log, "shutdown_phase_started", phase=phase_name)
                elif state in {"ok", "completed", "done"}:
                    log_event(log, "shutdown_phase_completed", phase=phase_name)
                elif state == "failed":
                    log_event(
                        log,
                        "shutdown_phase_failed",
                        level=logging.WARNING,
                        phase=phase_name,
                    )
        except Exception:
            pass
        if phase_logger is not None:
            try:
                phase_logger(msg)
            except Exception:
                pass

    written_spans = 0
    # Per-session monotonic event sequence for the SQLite events table.
    # Continues from any prior rows under the same session_id so a reused
    # id never collides on the (session_id, seq) primary key.
    event_seq = 0
    if store is not None:
        try:
            event_seq = int(store.next_event_seq(session_id))  # type: ignore[attr-defined]
        except Exception:  # noqa: BLE001
            event_seq = 0
    # Audio durability (voice-design invariant 2): each mic segment is
    # written to the content-addressed blob store and its metadata row
    # committed BEFORE ASR runs. A blob is marked processed only in the
    # same transaction as the stable spans derived from it, so at any
    # crash point the unprocessed rows are exactly the audio to replay.
    audio_durable = store is not None
    blob_root = Path(blob_dir) if blob_dir is not None else output_dir / "blobs"
    pending_blob_chunks: dict[int, set[str]] = {}
    blob_files: dict[int, tuple[str, str]] = {}  # seq -> (uri, sha256)
    committed_chunk_ids: set[str] = set()
    next_blob_seq = 0
    if audio_durable:
        try:
            next_blob_seq = int(store.next_blob_seq(session_id))  # type: ignore[attr-defined]
        except Exception:  # noqa: BLE001
            next_blob_seq = 0
    chunk_seq = 0
    segments_seen = 0
    ticks_seen = 0
    bias_prompts_sent = 0
    asr_ms_total = 0.0
    intelligence_ms_total = 0.0
    flush_ms_total = 0.0
    audio_speech_s_total = 0.0
    confidence_sum = 0.0
    confidence_n = 0
    repetitions_total = 0
    # Capture-gap tracking: wall-clock distance between consecutive received
    # audio chunks. monotonic powers the delta (immune to NTP jumps); wall
    # clock is reconstructed only for the logged timestamps.
    last_chunk_monotonic: float | None = None
    capture_gaps_count = 0
    capture_gaps_total_s = 0.0
    t_start = time.perf_counter()

    def _retire_blobs(seqs: list[int]) -> None:
        """After their processed mark is committed, drop bookkeeping and
        (unless retention is on) delete the audio files. Data minimization:
        seniorcare/classroom defaults keep no processed audio; the metadata
        row with its sha256 stays for audit. A content-addressed file shared
        with a still-unprocessed row is never deleted."""
        for seq in seqs:
            uri, sha = blob_files.pop(seq, ("", ""))
            pending_blob_chunks.pop(seq, None)
            if retain_audio or not uri:
                continue
            try:
                if not store.sha_has_unprocessed_refs(sha):  # type: ignore[attr-defined]
                    delete_blob(uri)
            except Exception:  # noqa: BLE001
                pass

    def flush(result: StreamingResult | None) -> None:
        nonlocal written_spans, flush_ms_total, repetitions_total, event_seq
        t_f0 = time.perf_counter()
        event_dicts: list[dict] = []
        if result is not None and result.events:
            for ev in result.events:
                if isinstance(ev, RepetitionEvent):
                    repetitions_total += 1
                event_dicts.append(event_to_dict(ev))
        state = processor.session(session_id)
        new = state.stable_spans[written_spans:]
        # SQLite first: lifecycle events and the segments they accompany in
        # one transaction (EVENT-CONTRACT durability rule 1). The store is
        # the single source of truth; recovery reads only from here.
        if store is not None and (event_dicts or new):
            for span in new:
                committed_chunk_ids.update(span.source_chunk_ids or [])
            # A blob is consumed once every chunk it produced is covered by
            # committed spans. Marking rides the same transaction as those
            # spans, so no crash point can lose or duplicate its audio.
            ready_blobs = sorted(
                seq
                for seq, cids in pending_blob_chunks.items()
                if cids and cids <= committed_chunk_ids
            )
            batch_events = [(event_seq + i, d) for i, d in enumerate(event_dicts)]
            batch_segments = [
                {
                    "seq": written_spans + offset,
                    "text": span.text or "",
                    "turn_id": getattr(span, "turn_id", "") or "",
                    "confidence": float(getattr(span, "confidence", 0.0) or 0.0),
                }
                for offset, span in enumerate(new)
            ]
            try:
                store.commit_stream_batch(  # type: ignore[attr-defined]
                    session_id,
                    events=batch_events,
                    segments=batch_segments,
                    processed_blob_seqs=ready_blobs,
                )
            except Exception:  # noqa: BLE001
                # Store failures must not break capture; the JSONL
                # projection below still records the events. Blobs stay
                # pending and are retried on the next flush.
                pass
            else:
                _retire_blobs(ready_blobs)
        event_seq += len(event_dicts)
        if event_dicts:
            # JSONL is a read-only projection of the committed stream,
            # written after the SQLite commit, never read back. fsynced so
            # a crash mid-write cannot leave ambiguous partial lines.
            with jsonl_path.open("a", encoding="utf-8") as f:
                for d in event_dicts:
                    f.write(json.dumps(d) + "\n")
                f.flush()
                try:
                    os.fsync(f.fileno())
                except OSError:
                    pass  # fsync may fail on some FUSE mounts, non-fatal
        if new:
            # The user-facing `.txt` is likewise a projection: recovery
            # rebuilds it from the segments table, so it can lag without
            # data loss.
            with txt_path.open("a", encoding="utf-8") as f:
                for span in new:
                    f.write(span.text + "\n\n")
                f.flush()
                try:
                    os.fsync(f.fileno())
                except OSError:
                    pass
            written_spans += len(new)
        flush_ms_total += (time.perf_counter() - t_f0) * 1000.0

    sample_rate = mic.cfg.sample_rate
    try:
        for event in mic.events():
            kind = event[0]
            if kind == "segment":
                samples = event[1]
                gap_ms_before = float(event[2])
                # Self-hearing control: while TTS playback is active, a
                # captured segment is either the device hearing itself
                # (suppressed BEFORE the blob store and ASR, so the device
                # never transcribes or retains its own speech) or a barge-in
                # (the guard has already stopped playback; the segment
                # proceeds so the user's speech is captured, not lost).
                if echo_guard is not None:
                    try:
                        verdict = echo_guard.classify(samples)  # type: ignore[attr-defined]
                    except Exception:  # noqa: BLE001, capture always wins
                        verdict = "pass"
                    if verdict == "suppress":
                        log_event(
                            log,
                            "self_hearing_suppressed",
                            level=logging.DEBUG,
                            session_id=session_id,
                        )
                        continue
                    if verdict == "barge_in":
                        log_event(
                            log,
                            "barge_in_detected",
                            session_id=session_id,
                        )
                segments_seen += 1
                # Capture-gap visibility: if the wall delta between this
                # chunk and the previous one exceeds the threshold, log a
                # structured `capture_gap` event so a silent stretch is
                # never invisible in the session log. Monotonic for the
                # delta, wall clock only for the logged timestamps.
                mono_now = time.monotonic()
                if last_chunk_monotonic is not None:
                    gap_s = mono_now - last_chunk_monotonic
                    if gap_s > gap_log_threshold_s:
                        wall_end = time.time()
                        wall_start = wall_end - gap_s
                        log_event(
                            log,
                            "capture_gap",
                            session_id=session_id,
                            gap_seconds=round(gap_s, 1),
                            gap_started_at=time.strftime(
                                "%Y-%m-%dT%H:%M:%SZ",
                                time.gmtime(wall_start),
                            ),
                            gap_ended_at=time.strftime(
                                "%Y-%m-%dT%H:%M:%SZ",
                                time.gmtime(wall_end),
                            ),
                        )
                        capture_gaps_count += 1
                        capture_gaps_total_s += gap_s
                last_chunk_monotonic = mono_now
                # Customer-facing audio meter: sample count / rate gives the
                # speech-only duration. Silence is tracked separately from
                # ticks, so audio_total_s reflects wall-clock mic time.
                try:
                    audio_speech_s_total += len(samples) / float(sample_rate)
                except (TypeError, ZeroDivisionError):
                    pass
                # Two-stream parity with ChatGPT Realtime: each ASR call
                # carries the session's current bias vocabulary as a soft
                # initial_prompt. Failures here must not break ASR — biasing
                # is an accuracy hint, not a correctness requirement.
                prompt = ""
                try:
                    if lexicon is not None:
                        bias = build_bias_terms(
                            processor.postprocessor.dictionary,
                            processor.tracker(session_id).active_keywords(),
                            lexicon=lexicon,
                        )
                    else:
                        bias = processor.bias_terms(session_id)
                    prompt = bias_terms_to_prompt(bias)
                except Exception:
                    prompt = ""
                if prompt:
                    bias_prompts_sent += 1
                # Durable before processed (invariant 2): the segment's
                # audio is on fsynced disk with a committed metadata row
                # before the ASR call below. A durability failure logs a
                # warning and capture continues: the deterministic floor
                # is "keep listening", never "stop the session".
                current_blob_seq: int | None = None
                if audio_durable:
                    try:
                        info = write_blob(blob_root, samples, sample_rate)  # type: ignore[arg-type]
                        store.record_audio_blob(  # type: ignore[attr-defined]
                            session_id,
                            next_blob_seq,
                            uri=info.uri,
                            sha256=info.sha256,
                            nbytes=info.nbytes,
                            sample_rate=info.sample_rate,
                            duration_s=info.duration_s,
                        )
                        current_blob_seq = next_blob_seq
                        next_blob_seq += 1
                        blob_files[current_blob_seq] = (info.uri, info.sha256)
                    except Exception as exc:  # noqa: BLE001
                        log_event(
                            log,
                            "audio_durability_failed",
                            level=logging.WARNING,
                            session_id=session_id,
                            reason=type(exc).__name__,
                        )
                t_asr0 = time.perf_counter()
                chunks = list(
                    asr.transcribe(samples, sample_rate, session_id, initial_prompt=prompt or None)  # type: ignore[arg-type]
                )
                asr_ms_total += (time.perf_counter() - t_asr0) * 1000.0
                # Assign session-unique chunk ids up front (ASR's own ids
                # would collide across calls) and register the full set
                # against the blob BEFORE feeding, so a blob can never be
                # marked processed while some of its chunks are unfed.
                for chunk in chunks:
                    chunk_seq += 1
                    chunk.chunk_id = f"{session_id}-c{chunk_seq}"
                    chunk.session_id = session_id
                    # The bounded audio window, by reference: judgment
                    # requests for this chunk can name the durable blob it
                    # was transcribed from instead of carrying raw audio.
                    if current_blob_seq is not None:
                        chunk.audio_uri = blob_files.get(current_blob_seq, ("", ""))[0]
                if current_blob_seq is not None:
                    if chunks:
                        pending_blob_chunks[current_blob_seq] = {c.chunk_id for c in chunks}
                    else:
                        # No speech recognized: nothing will ever commit
                        # from this blob, so it is consumed right now.
                        try:
                            store.commit_stream_batch(  # type: ignore[attr-defined]
                                session_id,
                                processed_blob_seqs=[current_blob_seq],
                            )
                        except Exception:  # noqa: BLE001
                            pass
                        else:
                            _retire_blobs([current_blob_seq])
                for i, chunk in enumerate(chunks):
                    # Confidence accumulator powers the avg ASR confidence
                    # metric. Missing/None values contribute 0 and are not
                    # counted, so the mean is over chunks with a real number.
                    conf = getattr(chunk, "confidence", None)
                    if isinstance(conf, (int, float)):
                        confidence_sum += float(conf)
                        confidence_n += 1
                    log_event(
                        log,
                        "chunk_received",
                        level=logging.DEBUG,
                        session_id=session_id,
                        chunk_id=chunk.chunk_id,
                        gap_ms_before=round(gap_ms_before, 1),
                        text_chars=len(chunk.text or ""),
                    )
                    if i == 0 and gap_ms_before > 0:
                        # The first chunk in a segment inherits the measured
                        # silence between segments. Whisper-internal gaps for
                        # subsequent chunks (i>0) are preserved.
                        chunk.gap_ms_before = gap_ms_before
                    t_i0 = time.perf_counter()
                    result = processor.feed(chunk, mode)
                    intelligence_ms_total += (time.perf_counter() - t_i0) * 1000.0
                    flush(result)
            elif kind == "tick":
                silence_ms = float(event[1])
                ticks_seen += 1
                t_i0 = time.perf_counter()
                result = processor.tick(session_id, silence_ms)
                intelligence_ms_total += (time.perf_counter() - t_i0) * 1000.0
                flush(result)
    finally:
        # Trailing capture gap: a silent tail past the threshold deserves
        # the same structured trace as a mid-session gap so the silent end
        # of a session is recorded once, never hidden.
        if last_chunk_monotonic is not None:
            trailing_gap_s = time.monotonic() - last_chunk_monotonic
            if trailing_gap_s > gap_log_threshold_s:
                wall_end = time.time()
                wall_start = wall_end - trailing_gap_s
                log_event(
                    log,
                    "capture_gap",
                    session_id=session_id,
                    gap_seconds=round(trailing_gap_s, 1),
                    gap_started_at=time.strftime(
                        "%Y-%m-%dT%H:%M:%SZ",
                        time.gmtime(wall_start),
                    ),
                    gap_ended_at=time.strftime(
                        "%Y-%m-%dT%H:%M:%SZ",
                        time.gmtime(wall_end),
                    ),
                    trailing=True,
                )
                capture_gaps_count += 1
                capture_gaps_total_s += trailing_gap_s
        # Canonical shutdown phase sequence. Names match the spec so log
        # aggregators can drive dashboards/alerts on phase completion
        # rather than parsing free-form text. Each phase is wrapped so a
        # failure logs `shutdown_phase_failed` with the offending phase.
        _phase("phase: stop_audio_capture start")
        try:
            _phase("phase: stop_audio_capture ok")
        except Exception as exc:  # noqa: BLE001 — mirror as a structured failure
            _phase(f"phase: stop_audio_capture failed ({type(exc).__name__})")
            raise

        _phase("phase: flush_asr start")
        _phase("phase: flush_asr ok")

        _phase("phase: finalize_stream start")
        t_i0 = time.perf_counter()
        try:
            final = processor.finalize(session_id)
            intelligence_ms_total += (time.perf_counter() - t_i0) * 1000.0
            _phase(f"phase: finalize_stream ok ({(time.perf_counter() - t_i0) * 1000.0:.0f} ms)")
        except Exception as exc:
            _phase(f"phase: finalize_stream failed ({type(exc).__name__})")
            raise

        _phase("phase: write_transcript start")
        try:
            flush(final)
            # Clean finalize: everything heard is now durably committed, so
            # any blob still pending (its chunks were dropped in cleanup and
            # never referenced by a span) is consumed and can be retired.
            if audio_durable and pending_blob_chunks:
                remaining = sorted(pending_blob_chunks)
                try:
                    store.commit_stream_batch(  # type: ignore[attr-defined]
                        session_id,
                        processed_blob_seqs=remaining,
                    )
                except Exception:  # noqa: BLE001
                    pass
                else:
                    _retire_blobs(remaining)
            _phase("phase: write_transcript ok")
            _phase("phase: write_events ok")
        except Exception as exc:
            _phase(f"phase: write_transcript failed ({type(exc).__name__})")
            raise

    state = processor.session(session_id)
    timings = {
        "asr": asr_ms_total,
        "intelligence": intelligence_ms_total,
        "flush": flush_ms_total,
        "total": (time.perf_counter() - t_start) * 1000.0,
    }

    # CP7: finalize-time SessionReport. Built as a pure projection over the
    # spans the kernel committed; written to disk only if a build was asked
    # for, in the requested format. Lock is captured into metadata BEFORE
    # we clear it, so the host can audit which surfaces ended up pinned.
    session_report: SessionReport | None = None
    report_path = ""
    if build_report:
        if summarizer is not None:
            _phase("phase: generate_markdown_report start")
        else:
            _phase("phase: generate_markdown_report start")
        t_report = time.perf_counter()
        chunk_refs: list[str] = []
        seen_ids: set[str] = set()
        for span in state.stable_spans:
            for cid in span.source_chunk_ids:
                if cid not in seen_ids:
                    seen_ids.add(cid)
                    chunk_refs.append(cid)
        metadata = {
            "session_id": session_id,
            "mode": mode_value,
            "product": resolved_product,
            "lexicon": lexicon.project if lexicon is not None else "",
            "bias_prompts_sent": bias_prompts_sent,
            "timings_ms": dict(timings),
            "term_consistency_lock": dictionary.session_lock(session_id),
            "model": getattr(summarizer, "model", "") if summarizer is not None else "",
        }
        session_report = build_session_report(
            session_id=session_id,
            cleaned_transcript=state.stable_text,
            chunk_refs=chunk_refs,
            metadata=metadata,
            provider=summarizer,
        )
        # report_format: 'md' / 'markdown' -> Markdown; 'json' -> JSON;
        # 'both' -> write both files. The user-facing artifact is Markdown,
        # so report_path returned to the caller points at the Markdown file
        # whenever it was written (this is what cursor insertion picks up).
        fmts = _formats_to_write(report_format)
        md_path = ""
        json_path = ""
        if "md" in fmts:
            md_path = str(output_dir / f"{session_id}.report.md")
            gated_md = deliver_report_text(
                gate,
                render_markdown(session_report),
                store=store,
                session_id=session_id,
            )
            Path(md_path).write_text(gated_md, encoding="utf-8")
        if "json" in fmts:
            json_path = str(output_dir / f"{session_id}.report.json")
            gated_json = deliver_report_text(
                gate,
                render_json(session_report),
                store=store,
                session_id=session_id,
            )
            Path(json_path).write_text(gated_json, encoding="utf-8")
        # Caller-facing path prefers Markdown (the user-facing artifact);
        # falls back to JSON only when 'json' was the only format asked for.
        report_path = md_path or json_path
        report_paths_written = [p for p in (md_path, json_path) if p]
        report_ms = (time.perf_counter() - t_report) * 1000.0
        _phase(
            f"phase: generate_markdown_report ok ({report_ms:.0f} ms) "
            f"-> {', '.join(report_paths_written)}"
        )

    # Clear the per-session lock once the report has captured it. The
    # phrase rule set is reset for the next session by the next caller; we
    # leave active_session_id intact for any later inspection by tests.
    dictionary.clear_session_lock(session_id)
    if dictionary.active_session_id == session_id:
        dictionary.active_session_id = None

    log_event(
        log,
        "session_finalized",
        session_id=session_id,
        spans=len(state.stable_spans),
        chunks=state.chunks_seen,
        segments=segments_seen,
        ticks=ticks_seen,
        asr_ms=round(asr_ms_total, 1),
        intelligence_ms=round(intelligence_ms_total, 1),
        flush_ms=round(flush_ms_total, 1),
        total_ms=round(timings["total"], 1),
        capture_gaps=capture_gaps_count,
        gap_seconds_total=round(capture_gaps_total_s, 1),
    )

    # Derived customer-facing metrics. Silence is estimated as ticks *
    # tick_interval — the mic emits one tick per interval of silence so
    # this is exact for ScriptedMic and within a tick's worth of slop for
    # the live microphone.
    tick_interval_s = float(mic.cfg.tick_interval_s)
    audio_silence_s = ticks_seen * tick_interval_s
    stable_text = state.stable_text or ""
    words_finalized = len(stable_text.split())
    chars_finalized = len(stable_text)
    avg_confidence = (confidence_sum / confidence_n) if confidence_n > 0 else 0.0
    rtf = (asr_ms_total / 1000.0 / audio_speech_s_total) if audio_speech_s_total > 0 else 0.0

    return ListenSessionReport(
        session_id=session_id,
        txt_path=str(txt_path),
        jsonl_path=str(jsonl_path),
        stable_spans=len(state.stable_spans),
        stable_text=stable_text,
        chunks_seen=state.chunks_seen,
        ticks_seen=ticks_seen,
        segments_seen=segments_seen,
        bias_prompts_sent=bias_prompts_sent,
        timings_ms=timings,
        session_report=session_report,
        report_path=report_path,
        audio_speech_s=audio_speech_s_total,
        audio_silence_s=audio_silence_s,
        words_finalized=words_finalized,
        chars_finalized=chars_finalized,
        avg_confidence=avg_confidence,
        rtf=rtf,
        repetitions_seen=repetitions_total,
        llm_requests=0,  # set by the CLI after summarizer accounting
    )


# ---- test fake --------------------------------------------------------------


class ScriptedMic:
    """Yields a pre-built list of mic events. For tests; no audio, no threads."""

    def __init__(
        self,
        events: list[MicEvent],
        cfg: StreamingMicConfig | None = None,
    ):
        self.cfg = cfg or StreamingMicConfig()
        self._events = list(events)
        self._stopped = False

    def stop(self) -> None:
        self._stopped = True

    def events(self) -> Iterator[MicEvent]:
        for ev in self._events:
            if self._stopped:
                break
            yield ev
