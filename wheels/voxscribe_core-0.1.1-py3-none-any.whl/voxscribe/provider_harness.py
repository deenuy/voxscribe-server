"""Provider comparison harness: accuracy and latency across providers.

Runs the same set of AudioJudgmentRequests against multiple
AudioUnderstandingProvider implementations and compares results. Designed
for evaluating candidate audio foundation models (e.g., Gemma 4 Audio vs
heuristic-only) before promoting one to production.

The harness is offline/test-only — it never runs on the hot path. Each
provider is called with the same requests; latency and accuracy are recorded
per provider, and a summary report ranks providers by accuracy first, then
by mean latency.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field

from .audio_providers import AudioUnderstandingProvider
from .models import AudioJudgmentRequest


@dataclass
class HarnessCase:
    """One labeled judgment request with the expected answer.

    `tolerance` allows fuzzy matching: an answer that contains the expected
    substring (case-insensitive) counts as correct. Set to 0.0 for exact
    match, 1.0 for any non-empty answer.
    """

    label: str
    request: AudioJudgmentRequest
    expected_answer: str
    tolerance: float = 0.0  # 0 = exact match, >0 = substring match threshold


@dataclass
class ProviderResult:
    """Per-provider aggregate results from a harness run."""

    provider_name: str
    total: int = 0
    correct: int = 0
    total_latency_ms: float = 0.0
    latencies_ms: list[float] = field(default_factory=list)
    per_case: list[CaseResult] = field(default_factory=list)

    @property
    def accuracy(self) -> float:
        return self.correct / self.total if self.total > 0 else 0.0

    @property
    def mean_latency_ms(self) -> float:
        return self.total_latency_ms / self.total if self.total > 0 else 0.0

    @property
    def p95_latency_ms(self) -> float:
        if not self.latencies_ms:
            return 0.0
        sorted_lat = sorted(self.latencies_ms)
        idx = int(len(sorted_lat) * 0.95)
        return sorted_lat[min(idx, len(sorted_lat) - 1)]


@dataclass
class CaseResult:
    """Per-case per-provider result."""

    label: str
    provider_name: str
    answer: str
    expected: str
    correct: bool
    latency_ms: float


@dataclass
class HarnessReport:
    """Complete comparison report, ranked by accuracy then latency."""

    test_count: int
    results: list[ProviderResult] = field(default_factory=list)
    # Ranked: best first
    rankings: list[str] = field(default_factory=list)

    @property
    def winner(self) -> str | None:
        return self.rankings[0] if self.rankings else None


def _is_correct(answer: str, expected: str, tolerance: float) -> bool:
    """Check if answer matches expected, with optional fuzzy tolerance."""
    if not answer.strip():
        return False
    if tolerance >= 1.0:
        return True  # any non-empty answer counts
    a_lower = answer.strip().lower()
    e_lower = expected.strip().lower()
    if tolerance == 0.0:
        return a_lower == e_lower
    # Substring match: either contains the other
    return e_lower in a_lower or a_lower in e_lower


def run_harness(
    providers: list[AudioUnderstandingProvider],
    cases: list[HarnessCase],
) -> HarnessReport:
    """Run all test cases against all providers and produce a ranked report.

    Each provider is called sequentially with each case. Latency is measured
    per call (wall-clock). The report ranks providers by accuracy (descending)
    then by mean latency (ascending).

    This is an offline/test function — never call on the hot path.
    """
    results: dict[str, ProviderResult] = {}

    for provider in providers:
        pr = ProviderResult(
            provider_name=provider.name if hasattr(provider, "name") else type(provider).__name__
        )
        results[pr.provider_name] = pr

        for case in cases:
            t0 = time.perf_counter()
            judgment = provider.judge(case.request)
            elapsed_ms = (time.perf_counter() - t0) * 1000.0

            correct = _is_correct(judgment.answer, case.expected_answer, case.tolerance)
            cr = CaseResult(
                label=case.label,
                provider_name=pr.provider_name,
                answer=judgment.answer,
                expected=case.expected_answer,
                correct=correct,
                latency_ms=elapsed_ms,
            )
            pr.total += 1
            if correct:
                pr.correct += 1
            pr.total_latency_ms += elapsed_ms
            pr.latencies_ms.append(elapsed_ms)
            pr.per_case.append(cr)

    # Rank: accuracy descending, then mean latency ascending
    ranked = sorted(
        results.values(),
        key=lambda r: (r.accuracy, -r.mean_latency_ms),
        reverse=True,
    )
    return HarnessReport(
        test_count=len(cases),
        results=list(ranked),
        rankings=[r.provider_name for r in ranked],
    )


def compare(
    provider_a: AudioUnderstandingProvider,
    provider_b: AudioUnderstandingProvider,
    cases: list[HarnessCase],
) -> HarnessReport:
    """Convenience: compare two providers head-to-head."""
    return run_harness([provider_a, provider_b], cases)
