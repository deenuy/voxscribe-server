"""Local SQLite store: the device-side durable layer.

Phase 0 of the persistence design.  This module owns:

  * `sessions` — one row per listen session, including state machine
    (recording → finalizing → completed | recovered | failed) and the
    metrics already exposed by `ListenSessionReport`.
  * `segments` — the durable write-ahead log: every committed turn is
    appended here, with sequence + timing + confidence.  Crash recovery
    rebuilds the `.txt` transcript from this table.
  * `usage_records` — idempotent billing line items.  A `PRIMARY KEY` on
    `session_id` prevents double-counting on retry.
  * `sync_outbox` — append-only handoff to a future server consumer.
    Rows are written now and never drained in this phase.

Design choices that are *not* accidental:

  * stdlib `sqlite3` only; no ORM; no schema framework — see DESIGN doc.
  * WAL mode + `synchronous=NORMAL` for crash durability without paying
    the full fsync-per-write cost.  Each commit is durable; we batch
    writes inside transactions to keep throughput reasonable.
  * No weekly rollup table.  Weekly totals are a SQL query.  Anything we
    cache adds a place where the cache can lie.
  * Migration from `logs/usage.json` v2 is one-shot and idempotent: on
    first successful import we record it in `meta` and rename the source
    file so re-runs do nothing.
"""

from __future__ import annotations

import json
import sqlite3
import time
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path

# ---- schema ----------------------------------------------------------------


SCHEMA_VERSION = 3

# Version of the event wire format persisted in `events.schema_version`.
# Governed by docs/EVENT-CONTRACT.md; bump only with a contract change.
EVENT_SCHEMA_VERSION = 1


_SCHEMA_STATEMENTS = [
    "CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT)",
    """
    CREATE TABLE IF NOT EXISTS sessions(
        id TEXT PRIMARY KEY,
        account_id TEXT,
        device_id TEXT,
        product TEXT,
        mode TEXT,
        language TEXT,
        state TEXT,
        started_at TEXT,
        ended_at TEXT,
        heartbeat_at TEXT,
        pid INTEGER,
        counted INTEGER,
        uncounted_reason TEXT,
        words INTEGER,
        chars INTEGER,
        ai_actions INTEGER,
        audio_seconds REAL,
        rtf REAL,
        avg_confidence REAL,
        repetitions INTEGER,
        llm_requests INTEGER,
        asr_model TEXT,
        llm_model TEXT,
        app_version TEXT,
        transcript_path TEXT,
        report_path TEXT,
        events_path TEXT,
        created_at TEXT,
        updated_at TEXT
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS segments(
        session_id TEXT NOT NULL,
        seq INTEGER NOT NULL,
        turn_id TEXT,
        text TEXT,
        t_start REAL,
        t_end REAL,
        confidence REAL,
        created_at TEXT,
        PRIMARY KEY (session_id, seq),
        FOREIGN KEY (session_id) REFERENCES sessions(id)
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_segments_session ON segments(session_id)",
    """
    CREATE TABLE IF NOT EXISTS events(
        session_id TEXT NOT NULL,
        seq INTEGER NOT NULL,
        event_type TEXT NOT NULL,
        kind TEXT,
        payload TEXT NOT NULL,
        schema_version INTEGER NOT NULL,
        created_at TEXT,
        PRIMARY KEY (session_id, seq),
        FOREIGN KEY (session_id) REFERENCES sessions(id)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS audio_blobs(
        session_id TEXT NOT NULL,
        seq INTEGER NOT NULL,
        uri TEXT NOT NULL,
        sha256 TEXT NOT NULL,
        bytes INTEGER NOT NULL,
        sample_rate INTEGER,
        duration_s REAL,
        created_at TEXT,
        processed_at TEXT,
        PRIMARY KEY (session_id, seq),
        FOREIGN KEY (session_id) REFERENCES sessions(id)
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_audio_blobs_unprocessed"
    " ON audio_blobs(session_id) WHERE processed_at IS NULL",
    """
    CREATE TABLE IF NOT EXISTS safety_ledger(
        session_id TEXT NOT NULL,
        seq INTEGER NOT NULL,
        kind TEXT NOT NULL,
        category TEXT,
        outcome TEXT,
        candidate_hash TEXT,
        policy_version TEXT,
        rule TEXT,
        chunk_id TEXT,
        payload TEXT NOT NULL,
        created_at TEXT,
        PRIMARY KEY (session_id, seq),
        FOREIGN KEY (session_id) REFERENCES sessions(id)
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_safety_ledger_session ON safety_ledger(session_id)",
    """
    CREATE TABLE IF NOT EXISTS retention_records(
        session_id TEXT NOT NULL,
        seq INTEGER NOT NULL,
        surface TEXT NOT NULL,
        blob_seq INTEGER,
        kept INTEGER NOT NULL,
        expires_at TEXT,
        purged_at TEXT,
        policy_version TEXT NOT NULL,
        created_at TEXT,
        PRIMARY KEY (session_id, seq),
        FOREIGN KEY (session_id) REFERENCES sessions(id)
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_retention_session ON retention_records(session_id)",
    """
    CREATE TABLE IF NOT EXISTS access_records(
        session_id TEXT NOT NULL,
        seq INTEGER NOT NULL,
        blob_seq INTEGER,
        accessor TEXT NOT NULL,
        reason TEXT NOT NULL,
        created_at TEXT,
        PRIMARY KEY (session_id, seq),
        FOREIGN KEY (session_id) REFERENCES sessions(id)
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_access_session ON access_records(session_id)",
    """
    CREATE TABLE IF NOT EXISTS usage_records(
        session_id TEXT PRIMARY KEY,
        account_id TEXT,
        iso_week TEXT,
        words INTEGER,
        ai_actions INTEGER,
        audio_seconds REAL,
        counted INTEGER,
        created_at TEXT
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_usage_account_week ON usage_records(account_id, iso_week)",
    """
    CREATE TABLE IF NOT EXISTS sync_outbox(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        entity TEXT,
        entity_id TEXT,
        op TEXT,
        payload TEXT,
        created_at TEXT,
        sent_at TEXT
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_outbox_pending ON sync_outbox(sent_at) WHERE sent_at IS NULL",
]


# ---- small helpers ---------------------------------------------------------


def _now_iso(at: float | None = None) -> str:
    """RFC3339 UTC timestamp matching the rest of the codebase."""
    t = at if at is not None else time.time()
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(t))


def _row_to_dict(row: sqlite3.Row | None) -> dict | None:
    return dict(row) if row is not None else None


# ---- store -----------------------------------------------------------------


@dataclass
class SegmentRow:
    """A single committed-turn row as it lives in `segments`."""

    session_id: str
    seq: int
    turn_id: str = ""
    text: str = ""
    t_start: float = 0.0
    t_end: float = 0.0
    confidence: float = 0.0
    created_at: str = ""


@dataclass
class WeeklyTotals:
    account_id: str
    iso_week: str
    words: int = 0
    ai_actions: int = 0
    audio_seconds: float = 0.0
    sessions: int = 0
    first_at: str = ""
    last_at: str = ""


class Store:
    """Thin wrapper around `sqlite3.Connection`.

    Instances are intentionally cheap to create; the CLI keeps one open
    for the duration of a session and closes it at exit. The connection
    is configured for crash durability (WAL + `synchronous=NORMAL`) and
    `Row` factory so DAO returns behave like read-only dicts."""

    def __init__(self, path: Path, *, conn: sqlite3.Connection):
        self.path = Path(path)
        self.conn = conn

    # ---- lifecycle --------------------------------------------------------

    def close(self) -> None:
        try:
            self.conn.close()
        except sqlite3.Error:  # pragma: no cover — best-effort close
            pass

    @contextmanager
    def transaction(self):
        """Context manager for explicit transactions.

        sqlite3's autocommit + `with conn:` is ambiguous in some Python
        versions; using BEGIN/COMMIT around mutations keeps the durability
        contract obvious."""
        try:
            self.conn.execute("BEGIN")
            yield self.conn
            self.conn.execute("COMMIT")
        except Exception:
            self.conn.execute("ROLLBACK")
            raise

    # ---- meta -------------------------------------------------------------

    def get_meta(self, key: str) -> str | None:
        row = self.conn.execute(
            "SELECT value FROM meta WHERE key=?",
            (key,),
        ).fetchone()
        return row["value"] if row else None

    def set_meta(self, key: str, value: str) -> None:
        with self.transaction() as c:
            c.execute(
                "INSERT INTO meta(key,value) VALUES(?,?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (key, value),
            )

    # ---- sessions ---------------------------------------------------------

    def start_session(
        self,
        session_id: str,
        *,
        account_id: str = "",
        device_id: str = "",
        product: str = "",
        mode: str = "",
        language: str = "",
        pid: int | None = None,
        asr_model: str = "",
        llm_model: str = "",
        app_version: str = "",
        transcript_path: str = "",
        events_path: str = "",
        at: float | None = None,
    ) -> None:
        """Insert (or replace) a session row in `recording` state.

        `INSERT OR REPLACE` is used so an explicit `--session-id` reuse
        cleanly overwrites the stub of a prior aborted session, which is
        the only path that produces a collision."""
        now = _now_iso(at)
        with self.transaction() as c:
            c.execute(
                "INSERT OR REPLACE INTO sessions("
                " id, account_id, device_id, product, mode, language,"
                " state, started_at, heartbeat_at, pid,"
                " asr_model, llm_model, app_version,"
                " transcript_path, events_path,"
                " created_at, updated_at"
                ") VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    session_id,
                    account_id,
                    device_id,
                    product,
                    mode,
                    language,
                    "recording",
                    now,
                    now,
                    pid,
                    asr_model,
                    llm_model,
                    app_version,
                    transcript_path,
                    events_path,
                    now,
                    now,
                ),
            )

    def heartbeat(self, session_id: str, *, at: float | None = None) -> None:
        """Bump the heartbeat timestamp.  Called from the listen loop so
        recovery can tell a hung process from a happily-running one."""
        now = _now_iso(at)
        with self.transaction() as c:
            c.execute(
                "UPDATE sessions SET heartbeat_at=?, updated_at=? WHERE id=?",
                (now, now, session_id),
            )

    def set_state(self, session_id: str, state: str, *, at: float | None = None) -> None:
        now = _now_iso(at)
        with self.transaction() as c:
            c.execute(
                "UPDATE sessions SET state=?, updated_at=? WHERE id=?",
                (state, now, session_id),
            )

    def finalize_session(
        self,
        session_id: str,
        *,
        state: str = "completed",
        words: int = 0,
        chars: int = 0,
        ai_actions: int = 0,
        audio_seconds: float = 0.0,
        rtf: float = 0.0,
        avg_confidence: float = 0.0,
        repetitions: int = 0,
        llm_requests: int = 0,
        counted: bool = True,
        uncounted_reason: str = "",
        transcript_path: str = "",
        report_path: str = "",
        events_path: str = "",
        ended_at: str | None = None,
        at: float | None = None,
    ) -> None:
        """Move the session out of `recording` and stamp the final metrics."""
        now = _now_iso(at)
        ended = ended_at or now
        with self.transaction() as c:
            c.execute(
                "UPDATE sessions SET "
                " state=?, ended_at=?, updated_at=?,"
                " words=?, chars=?, ai_actions=?, audio_seconds=?,"
                " rtf=?, avg_confidence=?, repetitions=?, llm_requests=?,"
                " counted=?, uncounted_reason=?,"
                " transcript_path=COALESCE(NULLIF(?, ''), transcript_path),"
                " report_path=COALESCE(NULLIF(?, ''), report_path),"
                " events_path=COALESCE(NULLIF(?, ''), events_path)"
                " WHERE id=?",
                (
                    state,
                    ended,
                    now,
                    words,
                    chars,
                    ai_actions,
                    audio_seconds,
                    rtf,
                    avg_confidence,
                    repetitions,
                    llm_requests,
                    1 if counted else 0,
                    uncounted_reason or "",
                    transcript_path,
                    report_path,
                    events_path,
                    session_id,
                ),
            )

    def get_session(self, session_id: str) -> dict | None:
        return _row_to_dict(
            self.conn.execute(
                "SELECT * FROM sessions WHERE id=?",
                (session_id,),
            ).fetchone()
        )

    def list_incomplete_sessions(self) -> list[dict]:
        """Rows still in `recording` or `finalizing`.  The caller decides
        whether each is genuinely abandoned (dead pid / stale heartbeat)."""
        rows = self.conn.execute(
            "SELECT * FROM sessions WHERE state IN ('recording','finalizing') ORDER BY started_at",
        ).fetchall()
        return [dict(r) for r in rows]

    # ---- segments ---------------------------------------------------------

    def append_segment(
        self,
        session_id: str,
        seq: int,
        text: str,
        *,
        turn_id: str = "",
        t_start: float = 0.0,
        t_end: float = 0.0,
        confidence: float = 0.0,
        at: float | None = None,
    ) -> None:
        """Durable WAL append.  `INSERT OR IGNORE` makes a replayed write
        a no-op so recovery + crash + restart never doubles a turn."""
        now = _now_iso(at)
        with self.transaction() as c:
            c.execute(
                "INSERT OR IGNORE INTO segments("
                " session_id, seq, turn_id, text,"
                " t_start, t_end, confidence, created_at"
                ") VALUES(?,?,?,?,?,?,?,?)",
                (session_id, seq, turn_id, text, t_start, t_end, confidence, now),
            )

    def get_segments(self, session_id: str) -> list[SegmentRow]:
        rows = self.conn.execute(
            "SELECT * FROM segments WHERE session_id=? ORDER BY seq",
            (session_id,),
        ).fetchall()
        return [SegmentRow(**dict(r)) for r in rows]

    # ---- events (docs/EVENT-CONTRACT.md) -----------------------------------

    @staticmethod
    def _event_discriminator(event: dict) -> str:
        """The contract's per-type discriminator: kind, reason, or category."""
        for key in ("kind", "reason", "category"):
            value = event.get(key)
            if value:
                return str(value)
        return ""

    def _insert_event(
        self,
        c: sqlite3.Connection,
        session_id: str,
        seq: int,
        event: dict,
        now: str,
    ) -> None:
        """INSERT OR IGNORE so a replayed (session_id, seq) is a no-op,
        matching the contract's crash-and-retry rule."""
        c.execute(
            "INSERT OR IGNORE INTO events("
            " session_id, seq, event_type, kind, payload,"
            " schema_version, created_at"
            ") VALUES(?,?,?,?,?,?,?)",
            (
                session_id,
                seq,
                str(event.get("event_type", "")),
                self._event_discriminator(event),
                json.dumps(event, default=str),
                EVENT_SCHEMA_VERSION,
                now,
            ),
        )

    def append_event(
        self,
        session_id: str,
        seq: int,
        event: dict,
        *,
        at: float | None = None,
    ) -> None:
        """Persist one serialized lifecycle event (event_to_dict output).

        Standalone form for events with no accompanying domain write in this
        store (session boundary events); in-stream events go through
        commit_stream_batch so they share the segment transaction."""
        with self.transaction() as c:
            self._insert_event(c, session_id, seq, event, _now_iso(at))

    def get_events(self, session_id: str) -> list[dict]:
        rows = self.conn.execute(
            "SELECT payload FROM events WHERE session_id=? ORDER BY seq",
            (session_id,),
        ).fetchall()
        return [json.loads(r["payload"]) for r in rows]

    def next_event_seq(self, session_id: str) -> int:
        row = self.conn.execute(
            "SELECT MAX(seq) AS m FROM events WHERE session_id=?",
            (session_id,),
        ).fetchone()
        return int(row["m"]) + 1 if row["m"] is not None else 0

    def commit_stream_batch(
        self,
        session_id: str,
        *,
        events: list[tuple[int, dict]] | None = None,
        segments: list[dict] | None = None,
        processed_blob_seqs: list[int] | None = None,
        at: float | None = None,
    ) -> None:
        """One flush from the streaming loop, atomically.

        Events and the segments they accompany land in a single transaction
        (EVENT-CONTRACT durability rule 1): a crash either persists the whole
        batch or none of it, never events without their domain write. The
        heartbeat rides along so recovery sees the session as live.

        `processed_blob_seqs` marks audio blobs as fully consumed in the
        SAME transaction as the spans derived from them: a crash can never
        leave a blob processed while its text is uncommitted (which would
        lose speech) nor committed text with a replayable blob (which would
        duplicate spans on replay).

        `events` is [(seq, event_to_dict output)]; `segments` is a list of
        dicts with the append_segment field names (seq, text, turn_id,
        t_start, t_end, confidence)."""
        now = _now_iso(at)
        with self.transaction() as c:
            for seq, event in events or []:
                self._insert_event(c, session_id, seq, event, now)
            for blob_seq in processed_blob_seqs or []:
                c.execute(
                    "UPDATE audio_blobs SET processed_at=?"
                    " WHERE session_id=? AND seq=? AND processed_at IS NULL",
                    (now, session_id, int(blob_seq)),
                )
            for seg in segments or []:
                c.execute(
                    "INSERT OR IGNORE INTO segments("
                    " session_id, seq, turn_id, text,"
                    " t_start, t_end, confidence, created_at"
                    ") VALUES(?,?,?,?,?,?,?,?)",
                    (
                        session_id,
                        int(seg["seq"]),
                        str(seg.get("turn_id", "")),
                        str(seg.get("text", "")),
                        float(seg.get("t_start", 0.0)),
                        float(seg.get("t_end", 0.0)),
                        float(seg.get("confidence", 0.0)),
                        now,
                    ),
                )
            c.execute(
                "UPDATE sessions SET heartbeat_at=?, updated_at=? WHERE id=?",
                (now, now, session_id),
            )

    # ---- audio blobs (durable-before-processed, invariant 2) ---------------

    def record_audio_blob(
        self,
        session_id: str,
        seq: int,
        *,
        uri: str,
        sha256: str,
        nbytes: int,
        sample_rate: int = 0,
        duration_s: float = 0.0,
        at: float | None = None,
    ) -> None:
        """Record a durably-written blob BEFORE ASR runs on it.

        This row is the checkpoint: once committed, the audio survives any
        crash and recovery will replay it if it never reaches processed.
        The heartbeat rides in the same transaction because the checkpoint
        advances on durable audio, not on turn commit."""
        now = _now_iso(at)
        with self.transaction() as c:
            c.execute(
                "INSERT OR IGNORE INTO audio_blobs("
                " session_id, seq, uri, sha256, bytes,"
                " sample_rate, duration_s, created_at, processed_at"
                ") VALUES(?,?,?,?,?,?,?,?,NULL)",
                (
                    session_id,
                    int(seq),
                    uri,
                    sha256,
                    int(nbytes),
                    int(sample_rate),
                    float(duration_s),
                    now,
                ),
            )
            c.execute(
                "UPDATE sessions SET heartbeat_at=?, updated_at=? WHERE id=?",
                (now, now, session_id),
            )

    def next_blob_seq(self, session_id: str) -> int:
        row = self.conn.execute(
            "SELECT MAX(seq) AS m FROM audio_blobs WHERE session_id=?",
            (session_id,),
        ).fetchone()
        return int(row["m"]) + 1 if row["m"] is not None else 0

    def unprocessed_blobs(self, session_id: str) -> list[dict]:
        """Blobs captured but never fully consumed: the replay worklist."""
        rows = self.conn.execute(
            "SELECT * FROM audio_blobs"
            " WHERE session_id=? AND processed_at IS NULL ORDER BY seq",
            (session_id,),
        ).fetchall()
        return [dict(r) for r in rows]

    def get_audio_blobs(self, session_id: str) -> list[dict]:
        rows = self.conn.execute(
            "SELECT * FROM audio_blobs WHERE session_id=? ORDER BY seq",
            (session_id,),
        ).fetchall()
        return [dict(r) for r in rows]

    def sha_has_unprocessed_refs(self, sha256: str) -> bool:
        """True while any session still needs this content-addressed file.
        Guards the data-minimization delete: identical audio dedups to one
        file, so the file may only go when no unprocessed row points at it."""
        row = self.conn.execute(
            "SELECT COUNT(*) AS n FROM audio_blobs"
            " WHERE sha256=? AND processed_at IS NULL",
            (sha256,),
        ).fetchone()
        return int(row["n"] or 0) > 0

    # ---- safety audit ledger (invariants 5, 5a) ---------------------------

    def next_safety_seq(self, session_id: str) -> int:
        row = self.conn.execute(
            "SELECT MAX(seq) AS m FROM safety_ledger WHERE session_id=?",
            (session_id,),
        ).fetchone()
        return int(row["m"]) + 1 if row["m"] is not None else 0

    def append_safety_ledger(
        self,
        session_id: str,
        *,
        kind: str,
        payload: dict,
        category: str = "",
        outcome: str = "",
        candidate_hash: str = "",
        policy_version: str = "",
        rule: str = "",
        chunk_id: str = "",
        at: float | None = None,
    ) -> int:
        """Append one audit row and return its seq. Rows are append-only:
        every safety signal, gate decision, and escalation lands here with
        candidate_hash + policy_version + rule so audit-replay can
        reconstruct heard / decided / policy / rationale for any moment.

        `kind` is one of: safety_signal, response_gated,
        policy_version_applied, escalation_emitted."""
        now = _now_iso(at)
        with self.transaction() as c:
            row = c.execute(
                "SELECT MAX(seq) AS m FROM safety_ledger WHERE session_id=?",
                (session_id,),
            ).fetchone()
            seq = int(row["m"]) + 1 if row["m"] is not None else 0
            c.execute(
                "INSERT INTO safety_ledger("
                " session_id, seq, kind, category, outcome,"
                " candidate_hash, policy_version, rule, chunk_id,"
                " payload, created_at"
                ") VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                (
                    session_id,
                    seq,
                    kind,
                    category or None,
                    outcome or None,
                    candidate_hash or None,
                    policy_version or None,
                    rule or None,
                    chunk_id or None,
                    json.dumps(payload, default=str),
                    now,
                ),
            )
        return seq

    def get_safety_ledger(self, session_id: str) -> list[dict]:
        rows = self.conn.execute(
            "SELECT * FROM safety_ledger WHERE session_id=? ORDER BY seq",
            (session_id,),
        ).fetchall()
        return [dict(r) for r in rows]

    # ---- retention + access (invariant 5a voice-audit) --------------------

    def record_retention(
        self,
        session_id: str,
        *,
        surface: str,
        blob_seq: int | None = None,
        kept: bool,
        expires_at: str = "",
        policy_version: str = "",
        at: float | None = None,
    ) -> int:
        """Record a retention decision for one artifact (audio blob or
        transcript surface). Keyed to a session_id + monotonic seq so
        purge and access rows can reference it."""
        now = _now_iso(at)
        with self.transaction() as c:
            row = c.execute(
                "SELECT MAX(seq) AS m FROM retention_records WHERE session_id=?",
                (session_id,),
            ).fetchone()
            seq = int(row["m"]) + 1 if row["m"] is not None else 0
            c.execute(
                "INSERT INTO retention_records("
                " session_id, seq, surface, blob_seq, kept,"
                " expires_at, purged_at, policy_version, created_at"
                ") VALUES(?,?,?,?,?,?,?,?,?)",
                (
                    session_id,
                    seq,
                    surface,
                    int(blob_seq) if blob_seq is not None else None,
                    1 if kept else 0,
                    expires_at or None,
                    None,
                    policy_version or "",
                    now,
                ),
            )
        return seq

    def mark_retention_purged(
        self,
        session_id: str,
        seq: int,
        *,
        at: float | None = None,
    ) -> None:
        """Flip a retention row to purged. Content is gone from disk; the
        row stays as an auditable trace that the retention window ran
        out and the artifact was removed under policy."""
        now = _now_iso(at)
        with self.transaction() as c:
            c.execute(
                "UPDATE retention_records SET purged_at=?"
                " WHERE session_id=? AND seq=? AND purged_at IS NULL",
                (now, session_id, int(seq)),
            )

    def get_retention_records(self, session_id: str) -> list[dict]:
        rows = self.conn.execute(
            "SELECT * FROM retention_records WHERE session_id=? ORDER BY seq",
            (session_id,),
        ).fetchall()
        return [dict(r) for r in rows]

    def record_access(
        self,
        session_id: str,
        *,
        accessor: str,
        reason: str,
        blob_seq: int | None = None,
        at: float | None = None,
    ) -> int:
        """Record that a component touched retained audio or transcript.
        Compliance reviewers reconstruct the access trail from this table."""
        now = _now_iso(at)
        with self.transaction() as c:
            row = c.execute(
                "SELECT MAX(seq) AS m FROM access_records WHERE session_id=?",
                (session_id,),
            ).fetchone()
            seq = int(row["m"]) + 1 if row["m"] is not None else 0
            c.execute(
                "INSERT INTO access_records("
                " session_id, seq, blob_seq, accessor, reason, created_at"
                ") VALUES(?,?,?,?,?,?)",
                (
                    session_id,
                    seq,
                    int(blob_seq) if blob_seq is not None else None,
                    accessor,
                    reason,
                    now,
                ),
            )
        return seq

    def get_access_records(self, session_id: str) -> list[dict]:
        rows = self.conn.execute(
            "SELECT * FROM access_records WHERE session_id=? ORDER BY seq",
            (session_id,),
        ).fetchall()
        return [dict(r) for r in rows]

    # ---- audit-replay -----------------------------------------------------

    def audit_replay(self, session_id: str) -> dict:
        """One-call reconstruction: heard / decided / policy / rationale
        for any session moment. Joins events (what was heard/said), the
        safety ledger (what the gate decided and why), retention records
        (what was kept and when it expires), and access records (who
        touched the retained artifact).

        This is the read half of DoD line 'audit-replay test passes'."""
        return {
            "session_id": session_id,
            "events": self.get_events(session_id),
            "safety_ledger": self.get_safety_ledger(session_id),
            "retention_records": self.get_retention_records(session_id),
            "access_records": self.get_access_records(session_id),
            "audio_blobs": self.get_audio_blobs(session_id),
        }

    # ---- usage ------------------------------------------------------------

    def record_usage(
        self,
        session_id: str,
        *,
        account_id: str = "",
        iso_week: str = "",
        words: int = 0,
        ai_actions: int = 0,
        audio_seconds: float = 0.0,
        counted: bool = True,
        at: float | None = None,
    ) -> None:
        """Idempotent on `session_id`.  Re-recording the same session_id
        replaces the row in place (PRIMARY KEY enforces uniqueness)."""
        now = _now_iso(at)
        with self.transaction() as c:
            c.execute(
                "INSERT INTO usage_records("
                " session_id, account_id, iso_week, words, ai_actions,"
                " audio_seconds, counted, created_at"
                ") VALUES(?,?,?,?,?,?,?,?) "
                "ON CONFLICT(session_id) DO UPDATE SET "
                " account_id=excluded.account_id,"
                " iso_week=excluded.iso_week,"
                " words=excluded.words,"
                " ai_actions=excluded.ai_actions,"
                " audio_seconds=excluded.audio_seconds,"
                " counted=excluded.counted",
                (
                    session_id,
                    account_id,
                    iso_week,
                    max(0, int(words)),
                    max(0, int(ai_actions)),
                    max(0.0, float(audio_seconds)),
                    1 if counted else 0,
                    now,
                ),
            )

    def weekly_summary(
        self,
        account_id: str,
        iso_week: str,
    ) -> WeeklyTotals:
        """SQL-derived totals for one account+week.  No cache, no rollup —
        sum the counted rows and return."""
        row = self.conn.execute(
            "SELECT "
            " COALESCE(SUM(words),0) AS words,"
            " COALESCE(SUM(ai_actions),0) AS ai_actions,"
            " COALESCE(SUM(audio_seconds),0) AS audio_seconds,"
            " COUNT(*) AS sessions,"
            " MIN(created_at) AS first_at,"
            " MAX(created_at) AS last_at "
            "FROM usage_records "
            "WHERE account_id=? AND iso_week=? AND counted=1",
            (account_id, iso_week),
        ).fetchone()
        return WeeklyTotals(
            account_id=account_id,
            iso_week=iso_week,
            words=int(row["words"] or 0),
            ai_actions=int(row["ai_actions"] or 0),
            audio_seconds=float(row["audio_seconds"] or 0.0),
            sessions=int(row["sessions"] or 0),
            first_at=str(row["first_at"] or ""),
            last_at=str(row["last_at"] or ""),
        )

    # ---- outbox -----------------------------------------------------------

    def enqueue_outbox(
        self,
        entity: str,
        entity_id: str,
        op: str,
        payload: dict | str,
        *,
        at: float | None = None,
    ) -> int:
        """Append a row that a future server consumer will drain.  In this
        phase nothing reads from `sync_outbox` — it is written, observed
        by tests, and left pending."""
        body = payload if isinstance(payload, str) else json.dumps(payload, default=str)
        now = _now_iso(at)
        with self.transaction() as c:
            cur = c.execute(
                "INSERT INTO sync_outbox(entity, entity_id, op, payload, created_at, sent_at) "
                "VALUES(?,?,?,?,?,NULL)",
                (entity, entity_id, op, body, now),
            )
            return int(cur.lastrowid)

    def pending_outbox(self, *, limit: int = 100) -> list[dict]:
        rows = self.conn.execute(
            "SELECT * FROM sync_outbox WHERE sent_at IS NULL ORDER BY id LIMIT ?",
            (limit,),
        ).fetchall()
        return [dict(r) for r in rows]


# ---- open + bootstrap ------------------------------------------------------


def open_store(
    db_path: str | Path,
    *,
    usage_json_path: str | Path | None = None,
) -> Store:
    """Open (or create) the local store with WAL + crash-safe pragmas.

    Side effects:
      1. Schema is created idempotently and `meta.schema_version` set.
      2. A sibling `usage.json` v2 file is imported into the store on
         first open, then renamed `usage.json.imported` so a second open
         is a no-op.  The migration path is the only place the v1/v2 JSON
         format leaks into this module.
    """
    path = Path(db_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path), isolation_level=None, timeout=30.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA foreign_keys=ON")
    for stmt in _SCHEMA_STATEMENTS:
        conn.execute(stmt)

    store = Store(path, conn=conn)
    if store.get_meta("schema_version") != str(SCHEMA_VERSION):
        store.set_meta("schema_version", str(SCHEMA_VERSION))

    resolved_usage_json = (
        Path(usage_json_path) if usage_json_path is not None else path.parent / "usage.json"
    )
    _import_usage_json_if_present(store, resolved_usage_json)
    return store


# ---- usage.json migration --------------------------------------------------


_LEGACY_ACCOUNT_ID = "legacy"


def _import_usage_json_if_present(store: Store, json_path: Path) -> bool:
    """One-shot import of a v2 `usage.json` into the store.

    Returns True if an import ran. Idempotent: the `meta` flag and the
    `.imported` rename together ensure a re-run does nothing."""
    if store.get_meta("usage_json_imported"):
        return False
    if not json_path.exists():
        return False
    # If sessions is already populated, the operator has manually staged
    # the store; refuse to clobber it.
    row = store.conn.execute("SELECT COUNT(*) AS n FROM sessions").fetchone()
    if int(row["n"] or 0) > 0:
        store.set_meta("usage_json_imported", _now_iso())
        return False

    try:
        data = json.loads(json_path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        # A corrupt ledger should not block a fresh store.
        store.set_meta("usage_json_imported", _now_iso())
        return False

    if data.get("version") not in (1, 2):
        store.set_meta("usage_json_imported", _now_iso())
        return False

    # v1 only has weekly aggregates — fold them under `legacy`.
    if data.get("version") == 1:
        for week_key, week in (data.get("weeks") or {}).items():
            _import_legacy_week(store, _LEGACY_ACCOUNT_ID, week_key, week)
    else:
        # v2: per-session entries + per-account weekly cache. The cache
        # is recomputable from the entries; we only import entries.
        for sid, row in (data.get("sessions") or {}).items():
            if not isinstance(row, dict):
                continue
            _import_v2_session(store, sid, row)
        # The legacy aggregate (carried through v1→v2 migration) lives
        # under data["weeks"]["legacy"] and has no per-session rows.
        legacy = (data.get("weeks") or {}).get(_LEGACY_ACCOUNT_ID, {})
        for week_key, week in legacy.items():
            _import_legacy_week(store, _LEGACY_ACCOUNT_ID, week_key, week)

    store.set_meta("usage_json_imported", _now_iso())
    try:
        json_path.rename(json_path.with_suffix(json_path.suffix + ".imported"))
    except OSError:
        # A read-only filesystem must not block the import: the `meta`
        # flag is enough to keep this idempotent.
        pass
    return True


def _import_v2_session(store: Store, session_id: str, row: dict) -> None:
    """Insert a v2 ledger session as a completed sessions row + usage row."""
    counted = bool(row.get("counted", True))
    started = str(row.get("started_at") or "")
    ended = str(row.get("ended_at") or started)
    account = str(row.get("account_id") or "")
    device = str(row.get("device_id") or "")
    mode = str(row.get("mode") or "")
    iso_week = str(row.get("iso_week") or "")
    words = max(0, int(row.get("words") or 0))
    audio_s = max(0.0, float(row.get("audio_seconds") or 0.0))
    ai_actions = max(0, int(row.get("ai_actions") or 0))
    reason = str(row.get("uncounted_reason") or "")

    with store.transaction() as c:
        c.execute(
            "INSERT OR REPLACE INTO sessions("
            " id, account_id, device_id, mode, state,"
            " started_at, ended_at, words, audio_seconds, ai_actions,"
            " counted, uncounted_reason, created_at, updated_at"
            ") VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (
                session_id,
                account,
                device,
                mode,
                "completed",
                started,
                ended,
                words,
                audio_s,
                ai_actions,
                1 if counted else 0,
                reason,
                started or _now_iso(),
                _now_iso(),
            ),
        )
        c.execute(
            "INSERT OR REPLACE INTO usage_records("
            " session_id, account_id, iso_week, words, ai_actions,"
            " audio_seconds, counted, created_at"
            ") VALUES(?,?,?,?,?,?,?,?)",
            (
                session_id,
                account,
                iso_week,
                words,
                ai_actions,
                audio_s,
                1 if counted else 0,
                started or _now_iso(),
            ),
        )


def _import_legacy_week(
    store: Store,
    account_id: str,
    week_key: str,
    week: dict,
) -> None:
    """Carry a v1 weekly aggregate forward as a synthetic legacy row.

    We cannot split the aggregate into per-session entries — the v1 file
    never stored them — so we record one usage_records row keyed by
    `legacy-<week>` so weekly_summary totals are preserved."""
    if not isinstance(week, dict):
        return
    synth_id = f"legacy-{week_key}"
    words = max(0, int(week.get("words") or 0))
    audio_s = max(0.0, float(week.get("audio_seconds") or 0.0))
    ai = max(0, int(week.get("ai_actions") or 0))
    created = str(week.get("first_at") or _now_iso())
    with store.transaction() as c:
        c.execute(
            "INSERT OR IGNORE INTO usage_records("
            " session_id, account_id, iso_week, words, ai_actions,"
            " audio_seconds, counted, created_at"
            ") VALUES(?,?,?,?,?,?,?,?)",
            (synth_id, account_id, week_key, words, ai, audio_s, 1, created),
        )
