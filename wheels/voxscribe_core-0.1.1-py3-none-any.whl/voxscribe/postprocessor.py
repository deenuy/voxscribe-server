"""The Flow Intelligence orchestrator.

Order is deliberate:
  1. Snippet check first. If the whole utterance is a known voice cue, expand
     it instantly with no model call. Lowest latency for the most common cues.
  2. LLM pass. The model does the fuzzy work: filler, backtrack, lists,
     punctuation, casing inference, mode-specific formatting.
  3. Dictionary normalization last. Deterministic enforcement of known-term
     spelling on the model output, so "supabase" always becomes "Supabase"
     regardless of what the model did.

This split keeps the unreliable model away from the strings that must be exact,
and keeps the deterministic layers from fighting the model on the fuzzy parts.
"""

from __future__ import annotations

from dataclasses import dataclass

from .context import DictationMode
from .dictionary import Dictionary
from .prompts import system_prompt
from .providers import LLMProvider


@dataclass
class Result:
    text: str
    mode: DictationMode
    used_snippet: bool = False
    used_model: bool = False


class PostProcessor:
    def __init__(self, provider: LLMProvider, dictionary: Dictionary | None = None):
        self.provider = provider
        self.dictionary = dictionary or Dictionary()

    def process(self, raw_transcript: str, mode: DictationMode) -> Result:
        text = raw_transcript.strip()
        if not text:
            return Result(text="", mode=mode)

        # 1. Snippet shortcut: whole-utterance match, no model call.
        expansion = self.dictionary.expand_snippet(text)
        if expansion is not None:
            return Result(text=expansion, mode=mode, used_snippet=True)

        # 2. Model intelligence pass.
        cleaned = self.provider.complete(
            system=system_prompt(mode),
            prompt=text,
        ).strip()

        # 3. Deterministic dictionary normalization.
        cleaned = self.dictionary.normalize(cleaned)

        return Result(text=cleaned, mode=mode, used_model=True)
