"""Per-session streaming state and the StreamProcessor.

CP3 replaced the per-chunk turn close from CP1 with the real policy: pause
bands plus thought completeness decide turn boundaries, never a single
silence timeout. Text accumulates as a provisional buffer until a commit
boundary (soft commit, close, finalize); the full snippet -> model ->
dictionary pipeline runs only at those boundaries, so the per-chunk hot path
stays deterministic and model-free.

The host drives the kernel with three calls:

  feed(chunk)              a new transcript chunk arrived
  tick(session_id, ms)     silence is ongoing (host VAD reports no speech)
  finalize(session_id)     the user ended the session (hotkey released)

Output contract: stable spans are immutable and only ever appended.
Provisional text grows by appending; when a commit rewrites it, the change
is announced as a RevisionEvent against the turn's provisional span id so
the host can retract safely.
"""

from __future__ import annotations

import time
from collections import deque
from collections.abc import Callable
from dataclasses import dataclass, field

from .cleanup import flow_clean
from .context import DictationMode
from .contextual_biasing import build_bias_terms
from .memory import MemoryManager, TurnRecord
from .models import (
    AudioJudgmentRequest,
    JudgmentKind,
    RevisionEvent,
    RevisionReason,
    SafetySignal,
    SessionEvent,
    SessionEventKind,
    SpanStatus,
    StreamingResult,
    TextSpan,
    TranscriptChunk,
    TurnEvent,
    TurnEventKind,
)
from .postprocessor import PostProcessor
from .silence_policy import (
    Completeness,
    PauseBandConfig,
    assess_completeness,
    classify,
)
from .topic_tracker import TopicTracker
from .topic_tracker import keywords as extract_keywords
from .turn_taking import (
    ChunkAction,
    SilenceAction,
    TurnTakingConfig,
    on_chunk,
    on_silence,
)
from .uncertainty import UncertaintyRouter


@dataclass
class ConversationSessionState:
    """Everything the kernel keeps for one session.

    The provisional buffer is bounded by TurnTakingConfig.max_provisional_chars.
    The chunk ledger is the traceability record; CP6 moves it to SQLite-backed
    storage with hot-state budgets so long sessions stay memory-safe.
    """

    session_id: str
    mode: DictationMode = DictationMode.IDEASCRIBE
    turn_counter: int = 0
    span_counter: int = 0
    chunks_seen: int = 0
    # Hot window of recent raw chunks. The full transcript lives in the
    # MemoryManager's SQLite ledger; this deque is bounded by construction.
    chunk_ledger: deque = field(default_factory=lambda: deque(maxlen=64))
    stable_spans: list[TextSpan] = field(default_factory=list)
    open_turn_id: str | None = None
    turn_chunks: list[TranscriptChunk] = field(default_factory=list)  # uncommitted
    # Effective text per buffered chunk: identical to chunk.text unless an
    # accepted transcript-repair hint replaced it. The raw chunk is immutable.
    turn_texts: list[str] = field(default_factory=list)
    # Non-final (partial) ASR chunks that may later be revised. Tracked
    # as (index into turn_texts, original text) so a final revision can
    # retract the old provisional text and emit a RevisionEvent.
    non_final_slots: list[tuple[int, str]] = field(default_factory=list)
    holding: bool = False  # HELD_POSSIBLE_CONTINUATION already announced
    ended: bool = False

    @property
    def provisional_text(self) -> str:
        return " ".join(self.turn_texts).strip()

    @property
    def stable_text(self) -> str:
        # Spans of the same turn join with a space; turns are paragraphs.
        pieces: list[str] = []
        prev_turn: str | None = None
        for span in self.stable_spans:
            if not pieces:
                pieces.append(span.text)
            elif span.turn_id and span.turn_id == prev_turn:
                pieces.append(" " + span.text)
            else:
                pieces.append("\n" + span.text)
            prev_turn = span.turn_id
        return "".join(pieces)


class StreamProcessor:
    """The streaming kernel: turn policy, span bookkeeping, commit boundaries."""

    def __init__(
        self,
        postprocessor: PostProcessor,
        router: UncertaintyRouter | None = None,
        pause_config: PauseBandConfig | None = None,
        turn_config: TurnTakingConfig | None = None,
        memory: MemoryManager | None = None,
        safety_scanner: Callable[[str, str], list[SafetySignal]] | None = None,
    ):
        self.postprocessor = postprocessor
        self.router = router or UncertaintyRouter()
        self.pause_config = pause_config or PauseBandConfig()
        self.turn_config = turn_config or TurnTakingConfig()
        self.memory = memory or MemoryManager()
        self.safety_scanner = safety_scanner  # None = safety scan disabled
        self._sessions: dict[str, ConversationSessionState] = {}
        self._trackers: dict[str, TopicTracker] = {}

    def session(self, session_id: str) -> ConversationSessionState:
        state = self._sessions.get(session_id)
        if state is None:
            state = ConversationSessionState(session_id=session_id)
            state.chunk_ledger = deque(maxlen=self.memory.hot_chunks)
            self._sessions[session_id] = state
        return state

    def tracker(self, session_id: str) -> TopicTracker:
        tracker = self._trackers.get(session_id)
        if tracker is None:
            tracker = TopicTracker()
            self._trackers[session_id] = tracker
        return tracker

    def bias_terms(self, session_id: str):
        """Current vocabulary biasing terms for the host's ASR / prompts."""
        return build_bias_terms(
            self.postprocessor.dictionary,
            self.tracker(session_id).active_keywords(),
        )

    def session_summary(self, session_id: str) -> dict:
        """Long-horizon view of the session: thread, topics, open intents."""
        tracker = self.tracker(session_id)
        state = self.session(session_id)
        return {
            "primary_topic": tracker.primary_topic_id,
            "active_topic": tracker.active_id,
            "topic_stack": list(tracker.stack),
            "topics": {
                tid: [w for w, _ in t.keyword_counts.most_common(8)]
                for tid, t in tracker.topics.items()
            },
            "unresolved_intents": [i.text for i in tracker.unresolved_intents()],
            "hot_chunks": len(state.chunk_ledger),
            "memory": self.memory.stats(session_id),
        }

    # ---- host entry points ----

    def feed(
        self,
        chunk: TranscriptChunk,
        mode: DictationMode | None = None,
    ) -> StreamingResult:
        t0 = time.perf_counter()
        state = self.session(chunk.session_id)
        if mode is not None:
            state.mode = mode

        events: list = []
        if state.chunks_seen == 0:
            events.append(SessionEvent(SessionEventKind.SESSION_STARTED, state.session_id))
        state.chunks_seen += 1
        state.chunk_ledger.append(chunk)
        self.memory.record_chunk(chunk)

        # Safety signal scan: read-only metadata, never mutates output.
        if self.safety_scanner is not None:
            events.extend(self.safety_scanner(chunk.text, chunk.chunk_id))

        if not chunk.text.strip():
            return self._result(state, events, [], False, False, t0)

        # Hot-path discipline (Sprint 4): feed() makes zero provider calls.
        # Low-confidence chunks are repaired at pre-promotion (_commit), a
        # boundary where the user is already waiting on judgment, never
        # synchronously mid-stream. The raw chunk stays immutable in the
        # ledger regardless.
        effective_text = chunk.text

        band = classify(chunk.gap_ms_before, self.pause_config)
        completeness = self._assess(state)
        action = on_chunk(state.open_turn_id is not None, band, completeness, self.turn_config)

        committed: list[TextSpan] = []
        used_snippet = used_model = False

        if action is ChunkAction.OPEN_NEW:
            self._open_turn(state, events, [chunk.chunk_id])
        elif action is ChunkAction.SOFT_COMMIT_THEN_EXTEND:
            span, us, um = self._commit(state, events, soft=True, band_label=band.value)
            if span:
                committed.append(span)
            used_snippet, used_model = used_snippet or us, used_model or um
        elif action in (ChunkAction.HOLD_THEN_EXTEND, ChunkAction.RESUME_THEN_EXTEND):
            if not state.holding:
                events.append(
                    TurnEvent(
                        TurnEventKind.HELD_POSSIBLE_CONTINUATION,
                        state.open_turn_id or "",
                        [],
                        band.value,
                    )
                )
            events.append(
                TurnEvent(
                    TurnEventKind.RESUMED,
                    state.open_turn_id or "",
                    [chunk.chunk_id],
                    band.value,
                )
            )
        elif action is ChunkAction.CLOSE_THEN_OPEN:
            span, us, um = self._commit(state, events, soft=False, band_label=band.value)
            if span:
                committed.append(span)
            used_snippet, used_model = used_snippet or us, used_model or um
            self._open_turn(state, events, [chunk.chunk_id])
        # EXTEND: nothing to decide, the buffer just grows.

        state.holding = False

        # CP6 (Live ASR Retry): handle partial (non-final) ASR chunks.
        # When a final chunk's text starts with a recent non-final chunk's
        # text, the final replaces the partial in the provisional buffer,
        # and a RevisionEvent tells the host to retract the old rendering.
        revised_non_final = False
        if not chunk.is_final:
            # Track the slot this partial occupies in turn_texts.
            state.non_final_slots.append((len(state.turn_texts), effective_text))
            state.turn_chunks.append(chunk)
            state.turn_texts.append(effective_text)
        else:
            # Check whether this final subsumes any non-final slot.
            old_prov = state.provisional_text
            keep_slots: list[tuple[int, str]] = []
            for idx, old_text in state.non_final_slots:
                if effective_text.startswith(old_text) and effective_text != old_text:
                    # This final replaces the partial at this slot.
                    if idx < len(state.turn_texts):
                        state.turn_texts[idx] = effective_text
                    revised_non_final = True
                else:
                    keep_slots.append((idx, old_text))
            state.non_final_slots = keep_slots
            if revised_non_final:
                events.append(
                    RevisionEvent(
                        span_id=f"{state.open_turn_id}-prov",
                        old_text=old_prov,
                        new_text=state.provisional_text,
                        reason=RevisionReason.TRANSCRIPT_REPAIR,
                        chunk_ids=[chunk.chunk_id],
                    )
                )
                # The effective_text was placed into the existing slot; don't
                # append it again. The raw chunk still goes into the ledger.
                state.turn_chunks.append(chunk)
            else:
                # Normal append: this final doesn't replace any partial.
                state.turn_chunks.append(chunk)
                state.turn_texts.append(effective_text)

        # Memory safety: an unbroken monologue cannot grow hot state forever.
        if len(state.provisional_text) > self.turn_config.max_provisional_chars:
            span, us, um = self._commit(state, events, soft=True, band_label="buffer_cap")
            if span:
                committed.append(span)
            used_snippet, used_model = used_snippet or us, used_model or um

        return self._result(state, events, committed, used_snippet, used_model, t0)

    def tick(self, session_id: str, silence_ms: float) -> StreamingResult:
        """The host reports ongoing silence with no new chunk."""
        t0 = time.perf_counter()
        state = self.session(session_id)
        events: list = []
        committed: list[TextSpan] = []
        used_snippet = used_model = False

        if state.open_turn_id is not None:
            band = classify(silence_ms, self.pause_config)
            # A tick IS a pause boundary: the one place completeness may
            # consult the audio lane while the user is already waiting.
            completeness = self._assess(state, at_boundary=True)
            action = on_silence(band, completeness, silence_ms, self.turn_config)

            if action is SilenceAction.SOFT_COMMIT and state.turn_chunks:
                span, used_snippet, used_model = self._commit(
                    state, events, soft=True, band_label=band.value
                )
                if span:
                    committed.append(span)
            elif action is SilenceAction.HOLD:
                if not state.holding:
                    events.append(
                        TurnEvent(
                            TurnEventKind.HELD_POSSIBLE_CONTINUATION,
                            state.open_turn_id,
                            [],
                            band.value,
                        )
                    )
                    state.holding = True
            elif action is SilenceAction.CLOSE:
                span, used_snippet, used_model = self._commit(
                    state, events, soft=False, band_label=band.value
                )
                if span:
                    committed.append(span)
            elif action is SilenceAction.CLOSE_INCOMPLETE:
                span, used_snippet, used_model = self._commit(
                    state, events, soft=False, band_label=band.value, incomplete=True
                )
                if span:
                    committed.append(span)

        return self._result(state, events, committed, used_snippet, used_model, t0)

    def finalize(self, session_id: str) -> StreamingResult:
        """Explicit end of session: commit whatever is open."""
        t0 = time.perf_counter()
        state = self.session(session_id)
        events: list = []
        committed: list[TextSpan] = []
        used_snippet = used_model = False

        if state.open_turn_id is not None:
            span, used_snippet, used_model = self._commit(
                state, events, soft=False, band_label="finalize"
            )
            if span:
                committed.append(span)
        events.append(SessionEvent(SessionEventKind.SESSION_ENDED, state.session_id))
        state.ended = True

        return self._result(state, events, committed, used_snippet, used_model, t0)

    # ---- internals ----

    def _assess(
        self,
        state: ConversationSessionState,
        *,
        at_boundary: bool = False,
    ) -> Completeness:
        """Thought completeness: deterministic heuristic first. Only at a
        pause boundary (at_boundary=True, the tick path) may the router
        replace a low-confidence verdict with a more confident
        audio-grounded one; the per-chunk feed path never routes, so the
        hot path stays model-free."""
        completeness = assess_completeness(state.provisional_text)
        cfg = self.router.config
        if (
            not at_boundary
            or not cfg.enabled
            or self.router.provider is None
            or not state.turn_chunks
        ):
            return completeness
        judgment = self.router.route(
            AudioJudgmentRequest(
                request_id=f"{state.session_id}-comp{state.chunks_seen}",
                kind=JudgmentKind.THOUGHT_COMPLETION,
                chunk_ids=[c.chunk_id for c in state.turn_chunks],
                text_window=state.provisional_text,
                heuristic_answer="complete" if completeness.complete else "incomplete",
                heuristic_confidence=completeness.confidence,
                session_id=state.session_id,
                audio_uri=getattr(state.turn_chunks[-1], "audio_uri", "") or "",
                questions=["completion_hint", "should_hold_provisional"],
            )
        )
        if judgment.source != "deterministic":
            # should_hold_provisional is the safest hint: it can only delay
            # promotion, never destroy content.
            if judgment.should_hold_provisional:
                return Completeness(
                    complete=False,
                    confidence=judgment.confidence,
                    reason="audio hint: hold provisional",
                )
            verdict = (judgment.completion_hint or judgment.answer).strip().lower()
            return Completeness(
                complete=verdict in ("complete", "finished"),
                confidence=judgment.confidence,
                reason=f"audio hint: {judgment.evidence or judgment.source}",
            )
        return completeness

    def _open_turn(
        self,
        state: ConversationSessionState,
        events: list,
        chunk_ids: list[str],
    ) -> None:
        state.turn_counter += 1
        state.open_turn_id = f"{state.session_id}-t{state.turn_counter}"
        events.append(TurnEvent(TurnEventKind.OPENED, state.open_turn_id, list(chunk_ids)))

    def _commit(
        self,
        state: ConversationSessionState,
        events: list,
        *,
        soft: bool,
        band_label: str,
        incomplete: bool = False,
    ) -> tuple[TextSpan | None, bool, bool]:
        """Run the full pipeline on the buffered turn text and freeze it as a
        stable span. The only place the model can be invoked."""
        turn_id = state.open_turn_id or ""
        text = state.provisional_text
        chunk_ids = [c.chunk_id for c in state.turn_chunks]

        if not text:
            if not soft and state.open_turn_id is not None:
                events.append(TurnEvent(TurnEventKind.CLOSED, turn_id, chunk_ids, band_label))
                state.open_turn_id = None
                state.turn_chunks = []
                state.turn_texts = []
                state.holding = False
            return None, False, False

        # Pre-promotion transcript repair (Sprint 4 firing rule): the one
        # place low-confidence audio may be re-examined before its text is
        # promoted to a stable span. Bounded window: the turn buffer, never
        # the session. The router enforces the acceptance margin over ASR
        # confidence; an accepted repair is provenance-flagged with a
        # TRANSCRIPT_REPAIR revision so review can compare heard vs inferred.
        cfg = self.router.config
        if cfg.enabled and self.router.provider is not None and state.turn_chunks:
            low = [c for c in state.turn_chunks if c.confidence < cfg.asr_confidence_floor]
            if low:
                worst = min(low, key=lambda c: c.confidence)
                judgment = self.router.route(
                    AudioJudgmentRequest(
                        request_id=f"{turn_id}-repair",
                        kind=JudgmentKind.TRANSCRIPT_REPAIR,
                        chunk_ids=[c.chunk_id for c in low],
                        text_window=text,
                        heuristic_answer=text,
                        heuristic_confidence=worst.confidence,
                        session_id=state.session_id,
                        audio_uri=getattr(worst, "audio_uri", "") or "",
                        questions=["transcript_repair_candidates"],
                    )
                )
                repaired = judgment.answer.strip()
                if judgment.source != "deterministic" and repaired not in ("", text):
                    events.append(
                        RevisionEvent(
                            span_id=f"{turn_id}-prov",
                            old_text=text,
                            new_text=repaired,
                            reason=RevisionReason.TRANSCRIPT_REPAIR,
                            chunk_ids=chunk_ids,
                        )
                    )
                    text = repaired

        # CP4: the deterministic floor — fillers, backtracks, repetition,
        # spoken punctuation, lists, dev syntax — runs before the model, so
        # output is meaning-correct even when the model is unavailable.
        cleanup = flow_clean(text, state.mode)
        for reason, old, new in cleanup.revisions:
            events.append(
                RevisionEvent(
                    span_id=f"{turn_id}-prov",
                    old_text=old,
                    new_text=new,
                    reason=reason,
                    chunk_ids=chunk_ids,
                )
            )
        for rep in cleanup.repetitions:
            rep.chunk_ids = chunk_ids
            events.append(rep)
        pre = cleanup.text

        # CP5 (flag-gated): weak correction markers the heuristics would not
        # touch may be resolved by an audio-grounded judgment. This is also
        # a pre-promotion boundary, so routing here obeys the firing rule.
        if cleanup.residual_markers and cfg.enabled and self.router.provider is not None:
            judgment = self.router.route(
                AudioJudgmentRequest(
                    request_id=f"{turn_id}-corr",
                    kind=JudgmentKind.CORRECTION_AMBIGUITY,
                    chunk_ids=chunk_ids,
                    text_window=pre,
                    heuristic_answer=pre,  # heuristic stance: no further correction
                    heuristic_confidence=cfg.ambiguous_marker_confidence,
                    session_id=state.session_id,
                    questions=["correction_hint"],
                )
            )
            hinted = judgment.answer.strip()
            if judgment.source != "deterministic" and hinted not in ("", pre):
                events.append(
                    RevisionEvent(
                        span_id=f"{turn_id}-prov",
                        old_text=pre,
                        new_text=hinted,
                        reason=RevisionReason.BACKTRACK,
                        chunk_ids=chunk_ids,
                    )
                )
                pre = hinted

        result = self.postprocessor.process(pre, state.mode)
        clean = result.text
        if clean != pre:
            events.append(
                RevisionEvent(
                    span_id=f"{turn_id}-prov",
                    old_text=pre,
                    new_text=clean,
                    reason=RevisionReason.MODEL_CLEANUP,
                    chunk_ids=chunk_ids,
                )
            )

        span: TextSpan | None = None
        if clean:
            state.span_counter += 1
            span = TextSpan(
                span_id=f"{state.session_id}-s{state.span_counter}",
                text=clean,
                status=SpanStatus.STABLE,
                source_chunk_ids=chunk_ids,
                uncertainty=0.4 if incomplete else 0.0,
                uncertainty_reason=(
                    "turn closed in extended silence with an apparently incomplete thought"
                    if incomplete
                    else ""
                ),
                turn_id=turn_id,
            )
            state.stable_spans.append(span)

            # CP6: long-horizon layers. Topic tracking and warm memory run
            # only here, at commit boundaries — never on the per-chunk path.
            topic_id, topic_events = self.tracker(state.session_id).observe_turn(turn_id, clean)
            for topic_event in topic_events:
                if hasattr(topic_event, "chunk_ids"):
                    topic_event.chunk_ids = chunk_ids
                events.append(topic_event)
            self.memory.record_turn(
                TurnRecord(
                    session_id=state.session_id,
                    turn_id=turn_id,
                    text=clean,
                    chunk_ids=chunk_ids,
                    topic_id=topic_id,
                    keywords=extract_keywords(clean),
                )
            )

        state.turn_chunks = []
        state.turn_texts = []
        state.holding = False
        events.append(
            TurnEvent(
                TurnEventKind.SOFT_COMMITTED if soft else TurnEventKind.CLOSED,
                turn_id,
                chunk_ids,
                band_label,
            )
        )
        if not soft:
            state.open_turn_id = None
        return span, result.used_snippet, result.used_model

    def _result(
        self,
        state: ConversationSessionState,
        events: list,
        committed: list[TextSpan],
        used_snippet: bool,
        used_model: bool,
        t0: float,
    ) -> StreamingResult:
        spans = list(committed)
        if state.turn_chunks and state.open_turn_id:
            spans.append(
                TextSpan(
                    span_id=f"{state.open_turn_id}-prov",
                    text=state.provisional_text,
                    status=SpanStatus.PROVISIONAL,
                    source_chunk_ids=[c.chunk_id for c in state.turn_chunks],
                    turn_id=state.open_turn_id,
                )
            )
        return StreamingResult(
            session_id=state.session_id,
            stable_text=state.stable_text,
            provisional_text=state.provisional_text,
            spans=spans,
            events=events,
            used_snippet=used_snippet,
            used_model=used_model,
            timings_ms={"total": (time.perf_counter() - t0) * 1000.0},
        )
