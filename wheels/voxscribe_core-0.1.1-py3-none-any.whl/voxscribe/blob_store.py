"""Content-addressed local filesystem blob store for captured audio.

Voice-design invariant 2 (durable before processed): every mic segment is
written here and fsynced before ASR ever sees it, so a crash at any point
can replay exactly what was heard. Blobs are addressed by the sha256 of
their encoded bytes:

    <root>/<sha256[:2]>/<sha256>.wav

Writes are atomic (temp file + fsync + rename + directory fsync), and a
blob that already exists is never rewritten, so identical audio dedups to
one file. The store records a metadata row per capture (uri, sha256,
bytes, session id) in SQLite; this module owns only the file bytes.

Encoding is 16-bit PCM mono WAV via the stdlib `wave` module: replayable
by any ASR provider and inspectable with any audio tool. No new
dependencies.
"""

from __future__ import annotations

import array
import hashlib
import io
import os
import wave
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class BlobInfo:
    """What the caller persists as the blob's metadata row."""

    uri: str
    sha256: str
    nbytes: int
    sample_rate: int
    duration_s: float


def encode_wav(samples: list[float], sample_rate: int) -> bytes:
    """Encode float samples in [-1, 1] as 16-bit PCM mono WAV bytes."""
    pcm = array.array("h")
    for s in samples:
        v = max(-1.0, min(1.0, float(s)))
        pcm.append(int(v * 32767))
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(int(sample_rate))
        w.writeframes(pcm.tobytes())
    return buf.getvalue()


def decode_wav(data: bytes) -> tuple[list[float], int]:
    """Inverse of encode_wav: bytes back to float samples + sample rate."""
    with wave.open(io.BytesIO(data), "rb") as w:
        rate = w.getframerate()
        frames = w.readframes(w.getnframes())
    pcm = array.array("h")
    pcm.frombytes(frames)
    return [s / 32767.0 for s in pcm], rate


def _fsync_dir(path: Path) -> None:
    """fsync a directory so the rename that landed in it is durable.
    Best-effort: some filesystems refuse directory fds."""
    try:
        fd = os.open(str(path), os.O_RDONLY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
    except OSError:
        pass


def write_blob(root: str | Path, samples: list[float], sample_rate: int) -> BlobInfo:
    """Durably write one captured segment; returns its metadata.

    The returned BlobInfo is only handed back after the bytes are fsynced
    and atomically renamed into place, so the caller may treat the blob as
    crash-durable the moment this function returns."""
    data = encode_wav(samples, sample_rate)
    digest = hashlib.sha256(data).hexdigest()
    root = Path(root)
    path = root / digest[:2] / f"{digest}.wav"
    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.parent / f".{digest}.{os.getpid()}.tmp"
        with open(tmp, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
        _fsync_dir(path.parent)
    duration_s = len(samples) / float(sample_rate) if sample_rate > 0 else 0.0
    return BlobInfo(
        uri=str(path),
        sha256=digest,
        nbytes=len(data),
        sample_rate=int(sample_rate),
        duration_s=duration_s,
    )


def read_blob(uri: str | Path) -> tuple[list[float], int]:
    """Load a blob back as (samples, sample_rate) for replay through ASR."""
    return decode_wav(Path(uri).read_bytes())


def delete_blob(uri: str | Path) -> bool:
    """Remove a blob file (data-minimization path). Missing file is fine:
    deletion is idempotent. Returns True when a file was removed."""
    try:
        Path(uri).unlink()
        return True
    except FileNotFoundError:
        return False
    except OSError:
        return False
