"""Routes low-confidence heuristic answers to the audio-understanding lane.

Deterministic by default. With the lane disabled (the default) or no provider
configured, every request resolves to the heuristic's own answer, so CP3 and
CP4 behavior is identical with audio understanding on or off. When the lane
is enabled, a provider judgment is accepted only when it clearly beats the
heuristic (for transcript repairs, by a required margin over the ASR
confidence, never mere improvement) — the router proposes nothing of its own
and never touches output text. This is the single gate through which
audio-model hints enter the kernel.

Firing discipline (Sprint 4 conformance):

  - The router fires only where the user is already waiting on judgment,
    not text: pause boundaries and pre-promotion. The per-chunk hot path
    never routes; feed() makes zero provider calls.
  - A sliding per-session judgment budget: chronically soft speech
    degrades to more conservative deterministic behavior (hold longer,
    mark uncertainty), never always-on inference.
  - Hysteresis on the confidence trigger, tracked per (session, kind):
    after a firing, the same decision class does not fire again until a
    clearly-confident heuristic passes through and re-arms it, so the
    router cannot thrash at the threshold.
  - budget_ms is enforced: a provider answer that arrives after the
    request's budget is discarded and the deterministic answer stands
    (failure policy: the floor is always the deterministic behavior).

Tuned values (budget, hysteresis band, repair margin) are deployment
configuration on AudioUnderstandingConfig, not kernel constants, and are
deliberately not restated in public docs.
"""

from __future__ import annotations

import time
from dataclasses import dataclass

from .audio_providers import AudioUnderstandingProvider
from .models import AudioJudgment, AudioJudgmentRequest, JudgmentKind


@dataclass
class RouterConfig:
    enabled: bool = False  # audio lane is opt-in, flag-gated
    confidence_floor: float = 0.65  # heuristics at/above this never route
    asr_confidence_floor: float = 0.6  # chunks below this may request repair
    ambiguous_marker_confidence: float = (
        0.55  # heuristic confidence assigned when weak correction markers remain
    )
    # Sliding per-session judgment budget; 0 means unlimited (tests only).
    session_budget: int = 12
    # Re-arm band above the floor for the hysteresis trigger.
    hysteresis: float = 0.08
    # Required margin of audio-grounded confidence over ASR confidence
    # before a transcript repair is accepted.
    repair_margin: float = 0.1
    # Discard provider answers that exceed the request's budget_ms.
    enforce_budget_ms: bool = True

    @classmethod
    def from_config(cls, cfg: object) -> RouterConfig:
        """Build from a VoxScribeConfig.audio_understanding section
        (duck-typed to avoid a circular import)."""
        au = getattr(cfg, "audio_understanding", None)
        if au is None:
            return cls()
        return cls(
            enabled=bool(getattr(au, "enabled", False)),
            session_budget=int(getattr(au, "session_budget", cls.session_budget)),
            hysteresis=float(getattr(au, "hysteresis", cls.hysteresis)),
            repair_margin=float(getattr(au, "repair_margin", cls.repair_margin)),
            enforce_budget_ms=bool(getattr(au, "enforce_budget_ms", True)),
        )


class UncertaintyRouter:
    def __init__(
        self,
        provider: AudioUnderstandingProvider | None = None,
        config: RouterConfig | None = None,
    ):
        self.provider = provider
        self.config = config or RouterConfig()
        # Per-session fired-judgment counts (the sliding budget).
        self._session_counts: dict[str, int] = {}
        # Hysteresis state per (session_id, kind): present means disarmed.
        self._disarmed: set[tuple[str, str]] = set()

    def judgments_fired(self, session_id: str) -> int:
        return self._session_counts.get(session_id, 0)

    def route(self, request: AudioJudgmentRequest) -> AudioJudgment:
        deterministic = AudioJudgment(
            request_id=request.request_id,
            kind=request.kind,
            answer=request.heuristic_answer,
            confidence=request.heuristic_confidence,
            evidence="heuristic",
            source="deterministic",
        )
        cfg = self.config
        if not cfg.enabled or self.provider is None:
            return deterministic

        key = (request.session_id, request.kind.value)
        if request.heuristic_confidence >= cfg.confidence_floor:
            # A clearly-confident heuristic re-arms this decision class.
            if request.heuristic_confidence >= cfg.confidence_floor + cfg.hysteresis:
                self._disarmed.discard(key)
            return deterministic

        # Budget exhausted: conservative deterministic behavior, no call.
        fired = self._session_counts.get(request.session_id, 0)
        if cfg.session_budget > 0 and fired >= cfg.session_budget:
            return deterministic
        # Hysteresis (band > 0 only): this decision class fired already
        # and has not been re-armed; do not thrash at the threshold.
        if cfg.hysteresis > 0 and key in self._disarmed:
            return deterministic

        t0 = time.perf_counter()
        try:
            judgment = self.provider.judge(request)
        except Exception:  # noqa: BLE001, provider failure -> the floor
            self._session_counts[request.session_id] = fired + 1
            self._disarmed.add(key)
            return deterministic
        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        self._session_counts[request.session_id] = fired + 1
        self._disarmed.add(key)

        # A late answer is a wrong answer: the pending decision has moved on.
        if cfg.enforce_budget_ms and elapsed_ms > request.budget_ms:
            return deterministic

        required = request.heuristic_confidence
        if request.kind is JudgmentKind.TRANSCRIPT_REPAIR:
            required += cfg.repair_margin
        if judgment.confidence <= required:
            return deterministic
        return judgment
