"""System prompts per product mode.

Each mode owns a prompt file under `voxscribe/resources_data/prompts/<mode>.md`
(path configurable via config.yaml -> modes.<mode>.prompt_file). The file is
loaded once per process and cached. For development, place custom prompts at
`cwd/data/prompts/<mode>.md` to override the packaged version.

When a prompt file is missing or unreadable, the module falls back to a
built-in safe default for that mode so the post-processor never raises
during startup. The fallback prompts are intentionally minimal — the
authoritative prompt content lives in the data files so product teams can
iterate without code changes.

The finalize-time SessionReport prompt remains a single shared constant; it
is the same regardless of product mode (only the front-matter and report
heading change per product).
"""

from __future__ import annotations

import logging
from pathlib import Path

from .context import DictationMode
from .logging_config import get_logger, log_event

log = get_logger("voxscribe.prompts")


# ---- built-in fallback prompts --------------------------------------------
#
# These run when the configured prompt file cannot be read. They are kept
# small on purpose; product teams own the canonical prompts in
# voxscribe/resources_data/prompts/ (packaged) or cwd/data/prompts/ (override).


_NOISE_RULE = (
    "The transcript may come from a noisy environment. Drop obvious "
    "non-word artifacts and stray single letters that are clearly "
    "mis-hears, but never guess at words that were not spoken."
)


_FALLBACK_IDEASCRIBE = (
    "You clean speech from a product manager brainstorming ideas, PRDs, "
    "and feature work items. Preserve contradictions, hedges, qualifiers, "
    "and disagreements — those are evidence for downstream extraction. "
    "Remove only clear filler (um, uh, er). Do not resolve corrections "
    "unless stated explicitly (scratch that, correction). Keep the full "
    f"content of what was said.\n{_NOISE_RULE}\n"
    "Return the cleaned transcript. No preamble, no explanation."
)


_FALLBACK_CLASSROOM = (
    "You clean speech from a classroom lecture or lesson into structured "
    "study notes. Steps:\n"
    "1. BACKTRACK. Resolve correction markers (actually, wait, no, I mean, "
    "scratch that, correction). Keep only the corrected intent.\n"
    "2. FILLER. Remove um, uh, er, like (filler), you know.\n"
    "3. LISTS. When the speaker numbers items, format a clean markdown list.\n"
    "4. PUNCTUATION. Add periods, commas, question marks from sentence "
    "structure. Apply spoken punctuation when named.\n"
    "5. NO ADDITIONS. Never add facts not spoken. Do not paraphrase.\n"
    f"{_NOISE_RULE}\n"
    "Return only the cleaned text. No preamble, no quotes, no explanation."
)


_FALLBACK_SENIORCARE = (
    "You clean speech from a caregiver recording daily routines, "
    "medications, family updates, and care observations for a senior. "
    "Be gentle: preserve every observation, every medication name, every "
    "time, every name. Remove only clear filler (um, uh, er). Do not "
    "paraphrase. Do not infer medical advice. Keep names and dosages "
    "exactly as spoken.\n"
    f"{_NOISE_RULE}\n"
    "Return the cleaned transcript. No preamble, no explanation."
)


_FALLBACK_PROMPTS: dict[DictationMode, str] = {
    DictationMode.IDEASCRIBE: _FALLBACK_IDEASCRIBE,
    DictationMode.CLASSROOM: _FALLBACK_CLASSROOM,
    DictationMode.SENIORCARE: _FALLBACK_SENIORCARE,
}


# ---- finalize-time prompt --------------------------------------------------


SESSION_REPORT_MARKDOWN_PROMPT = (
    "You are VoxScribe's final formatting layer. Convert the transcript into "
    "structured notes the user will paste into their editor.\n"
    "\n"
    "Rules:\n"
    "- Preserve meaning. Do not invent facts.\n"
    "- Do not add claims that are not supported by the transcript.\n"
    "- Fix obvious punctuation and paragraphing.\n"
    "- Keep uncertain phrases conservative. If a phrase appears misheard, "
    "  keep it as-is or mark it uncertain rather than rewriting confidently.\n"
    "- Use short, factual entries drawn only from the transcript.\n"
    "\n"
    "Respond ONLY with a single JSON object — no prose, no code fences.\n"
    "Required keys: topic_name (string, <= 8 words), description "
    "(1-3 sentences), speaker_key_notes (array of strings), key_themes "
    "(array of strings), takeaways (array of strings)."
)


# ---- public API ------------------------------------------------------------


_prompt_cache: dict[DictationMode, str] = {}


def _resolve_prompt_path(mode: DictationMode, cfg: object) -> Path | None:
    """Look up the prompt file path for `mode` from config. None if unset.

    If the path is relative and not found, tries the resource resolver."""
    modes_cfg = getattr(cfg, "modes", None)
    if modes_cfg is None:
        return None
    mode_entry = getattr(modes_cfg, mode.value, None)
    if mode_entry is None:
        return None
    raw = getattr(mode_entry, "prompt_file", "") or ""
    if not raw:
        return None

    path = Path(raw)
    # If it's a relative path that doesn't exist, try the resource resolver
    if not path.is_absolute() and not path.exists():
        try:
            from .resources import resolve
            # Map data/prompts/mode.md to resources_data/prompts/mode.md
            if raw.startswith("data/"):
                resource_path = "resources_" + raw
                return resolve(resource_path)
        except Exception:
            pass

    return path


def system_prompt(mode: DictationMode, cfg: object = None) -> str:
    """Return the system prompt for `mode`.

    Reads from the configured prompt file when `cfg` is provided OR when the
    global cached config (from `get_config()`) is available. Falls back to
    the built-in safe prompt when the file is missing or unreadable.
    Prompts are cached per-mode after the first successful read."""
    if mode in _prompt_cache:
        return _prompt_cache[mode]

    fallback = _FALLBACK_PROMPTS.get(mode, _FALLBACK_CLASSROOM)

    if cfg is None:
        # Try the cached singleton config so PostProcessor's call site stays
        # zero-config. If config loading fails for any reason, fall back to
        # the built-in prompt without caching so a later explicit call with
        # cfg= still picks up the file-sourced version.
        try:
            from .utils.config_loader import get_config

            cfg = get_config()
        except Exception:  # noqa: BLE001
            return fallback

    path = _resolve_prompt_path(mode, cfg)
    if path is None:
        _prompt_cache[mode] = fallback
        return fallback

    try:
        text = path.read_text(encoding="utf-8").strip()
    except OSError as exc:
        log_event(
            log,
            "prompt_file_unavailable",
            level=logging.WARNING,
            mode=mode.value,
            path=str(path),
            reason=type(exc).__name__,
            fallback="builtin",
        )
        _prompt_cache[mode] = fallback
        return fallback

    if not text:
        log_event(
            log,
            "prompt_file_empty",
            level=logging.WARNING,
            mode=mode.value,
            path=str(path),
            fallback="builtin",
        )
        _prompt_cache[mode] = fallback
        return fallback

    log_event(log, "prompt_loaded", mode=mode.value, path=str(path), chars=len(text))
    _prompt_cache[mode] = text
    return text


def clear_prompt_cache() -> None:
    """Drop the per-process prompt cache. Tests use this to swap prompt
    files between cases without restarting the interpreter."""
    _prompt_cache.clear()
