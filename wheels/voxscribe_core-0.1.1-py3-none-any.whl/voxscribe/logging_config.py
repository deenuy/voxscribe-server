"""Docker-first, Kubernetes-ready structured logging for VoxScribe.

Layer 1 (primary): stdout/stderr stream handler — `human` for `make listen`,
`json` for Docker / container log aggregators (Datadog, CloudWatch, Loki,
GCP Cloud Logging, OpenTelemetry collectors). One JSON object per line.

Layer 2 (optional): per-session JSONL file at
`logs/sessions/<session_id>.log.jsonl`. Opt-in via
`VOXSCRIBE_SESSION_LOG_ENABLED=true`; off by default in Docker so the
container is stateless. The same `session_id` connects the four artifacts
that exist for one listen session:

    output/<session_id>.txt              transcript
    output/<session_id>.jsonl            kernel events
    output/<session_id>.report.md        Markdown report
    logs/sessions/<session_id>.log.jsonl optional session log

Correlation works via `contextvars`. The CLI calls `set_log_context(...)`
once at session start; every downstream `log_event(...)` inherits the
session_id (and any future SaaS fields — tenant_id, request_id, trace_id —
left empty when unset so the same shape works in a single-tenant local
CLI and a multi-tenant Kubernetes pod). No code needs to thread session_id
through call signatures.

Service metadata (service, service_version, environment) is stamped on
every record from env so K8s pod logs are self-identifying without any
external enrichment.

No new pip dependencies. The stdlib `logging` module is the entire stack.
"""

from __future__ import annotations

import contextvars
import json
import logging
import os
import sys
import time
from contextvars import ContextVar
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

try:
    from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
except ImportError:  # pragma: no cover — zoneinfo ships in Python 3.9+
    ZoneInfo = None  # type: ignore[assignment]
    ZoneInfoNotFoundError = Exception  # type: ignore[assignment,misc]


# ---- display timezone resolution ------------------------------------------
#
# Friendly aliases are accepted alongside raw IANA names so a user can write
# `display.timezone: EST` in config.yaml instead of `America/New_York`. Any
# value not in the map is passed through to ZoneInfo as an IANA zone name.
# Stored timestamps (JSONL events, session log file, usage ledger) remain
# canonical UTC ISO 8601 — this layer is presentation-only.

DISPLAY_TZ_ALIASES: dict[str, str] = {
    "UTC": "UTC",
    "GMT": "UTC",
    "EST": "America/New_York",
    "EDT": "America/New_York",
    "PST": "America/Los_Angeles",
    "PDT": "America/Los_Angeles",
    "IST": "Asia/Kolkata",
}

_resolved_tz_cache: dict[str, Any] = {}
_warned_invalid_tz: set[str] = set()


def _resolve_display_tz(tz_name: str | None) -> Any:
    """Resolve a tz name (alias or IANA) to a tzinfo. Falls back to UTC and
    warns once per unique invalid value so a typo in config.yaml does not
    spam the log line by line."""
    raw = (tz_name or "").strip() or "UTC"
    if raw in _resolved_tz_cache:
        return _resolved_tz_cache[raw]
    iana = DISPLAY_TZ_ALIASES.get(raw.upper(), raw)
    tz: Any = timezone.utc
    if ZoneInfo is not None:
        try:
            tz = ZoneInfo(iana)
        except ZoneInfoNotFoundError:
            if raw not in _warned_invalid_tz:
                _warned_invalid_tz.add(raw)
                logging.getLogger("voxscribe.logging_config").warning(
                    "",
                    extra={
                        "event": "display_tz_invalid",
                        "configured": raw,
                        "fallback": "UTC",
                    },
                )
            tz = timezone.utc
    _resolved_tz_cache[raw] = tz
    return tz


def format_display_ts(
    value: datetime | str | None,
    tz_name: str | None = None,
) -> str:
    """Render a human-readable, localized timestamp.

    Accepts an aware datetime, a UTC ISO 8601 string (with or without 'Z'),
    or None (returns ""). Output is the form `Jun 20, 2026 02:43:38 AM EDT`
    with the actual zone abbreviation for the resolved instant — so a
    summer Eastern timestamp prints `EDT` and a winter one prints `EST`.

    This helper is the single canonical formatter for human-facing
    timestamps. JSONL and the usage ledger continue to store UTC ISO 8601."""
    if value is None or value == "":
        return ""
    if isinstance(value, str):
        s = value.strip()
        if not s:
            return ""
        try:
            dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
        except ValueError:
            return s  # unparseable: surface verbatim, never crash a banner
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
    elif isinstance(value, datetime):
        dt = value if value.tzinfo else value.replace(tzinfo=timezone.utc)
    else:
        return str(value)
    tz = _resolve_display_tz(tz_name or LogConfig.display_tz)
    local = dt.astimezone(tz)
    return local.strftime("%b %d, %Y %I:%M:%S %p %Z").strip()


# ---- env helpers -----------------------------------------------------------


def _env_str(name: str, default: str) -> str:
    raw = (os.environ.get(name) or "").strip()
    return raw or default


def _env_bool(name: str, default: bool) -> bool:
    raw = os.environ.get(name)
    if raw is None or raw == "":
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _env_int(name: str, default: int) -> int:
    raw = os.environ.get(name)
    if not raw:
        return default
    try:
        return int(raw.strip())
    except ValueError:
        return default


# ---- config snapshot ------------------------------------------------------


class LogConfig:
    """Snapshot of environment-driven logging configuration.

    Held as module-level state so helpers (safe_preview, log_event) can
    consult the active settings without taking it as a parameter. Tests
    monkeypatch env then call `configure_logging(force=True)` to refresh."""

    level: str = "INFO"
    fmt: str = "human"
    include_transcript: bool = False
    max_text_chars: int = 300
    include_components: bool = True

    # Human-mode field truncation limits.
    max_field_chars: int = 80
    max_message_chars: int = 180
    max_path_chars: int = 120
    hyperlink_paths: bool = False

    # Configurable display timezone for human-facing output (console log
    # `[HH:MM:SS]` prefix + CLI banner timestamps). Accepts aliases (EST,
    # PST, IST, UTC, GMT) or a raw IANA name. Stored timestamps (JSONL,
    # ledger) stay UTC ISO 8601 regardless.
    display_tz: str = "EST"

    # Service identity. Datadog / GCP / OTel all key on these names, so
    # we mirror the convention exactly to avoid translation later.
    service: str = "voxscribe-core"
    service_version: str = "0.1.0"
    environment: str = "local"

    # Optional session JSONL file (Layer 2).
    session_log_enabled: bool = True
    session_log_dir: str = "logs/sessions"

    @classmethod
    def load(cls) -> LogConfig:
        cls.level = _env_str("VOXSCRIBE_LOG_LEVEL", "INFO").upper()
        cls.fmt = _env_str("VOXSCRIBE_LOG_FORMAT", "human").lower()
        if cls.fmt not in {"human", "json"}:
            cls.fmt = "human"
        cls.include_transcript = _env_bool("VOXSCRIBE_LOG_INCLUDE_TRANSCRIPT", False)
        cls.max_text_chars = max(0, _env_int("VOXSCRIBE_LOG_MAX_TEXT_CHARS", 300))
        cls.include_components = _env_bool("VOXSCRIBE_LOG_COMPONENTS", True)

        cls.max_field_chars = max(10, _env_int("VOXSCRIBE_LOG_MAX_FIELD_CHARS", 80))
        cls.max_message_chars = max(10, _env_int("VOXSCRIBE_LOG_MAX_MESSAGE_CHARS", 180))
        cls.max_path_chars = max(10, _env_int("VOXSCRIBE_LOG_MAX_PATH_CHARS", 120))
        cls.hyperlink_paths = _env_bool("VOXSCRIBE_LOG_HYPERLINK_PATHS", False)
        cls.display_tz = _env_str("VOXSCRIBE_DISPLAY_TIMEZONE", "EST")

        cls.service = _env_str("VOXSCRIBE_SERVICE_NAME", "voxscribe-core")
        cls.service_version = _env_str("VOXSCRIBE_SERVICE_VERSION", "0.1.0")
        cls.environment = _env_str("VOXSCRIBE_ENVIRONMENT", "local")

        cls.session_log_enabled = _env_bool("VOXSCRIBE_SESSION_LOG_ENABLED", True)
        cls.session_log_dir = _env_str("VOXSCRIBE_SESSION_LOG_DIR", "logs/sessions")
        return cls


# ---- context (contextvars + future-ready optional SaaS fields) -----------


# A single dict-shaped contextvar so set/get are atomic across asyncio
# tasks and signal handlers. None means "no correlation context"; a mutable
# default dict would be shared across contexts, so the empty case is None.
_log_context: ContextVar[dict] = ContextVar("_log_context", default={})  # noqa: B039

# Known correlation keys. Anything in this set propagates onto every log
# record via the ContextFilter. Unknown keys also propagate, but this list
# documents the SaaS-ready surface so callers don't have to guess.
KNOWN_CONTEXT_KEYS = (
    "session_id",
    "command",
    "pid",
    # Future SaaS fields. Left empty unless explicitly set or supplied by
    # the deployment environment via env vars (read at configure time).
    "tenant_id",
    "user_id_hash",
    "workspace_id",
    "request_id",
    "trace_id",
    "deployment_id",
    "pod_name",
    "container_name",
    "node_name",
)


# Mapping from environment variable -> context key for future SaaS fields.
# Reading from env at configure time means a K8s Downward API or sidecar
# injector can set these without any code change here.
_ENV_CONTEXT_BINDINGS = {
    "VOXSCRIBE_TENANT_ID": "tenant_id",
    "VOXSCRIBE_USER_ID_HASH": "user_id_hash",
    "VOXSCRIBE_WORKSPACE_ID": "workspace_id",
    "VOXSCRIBE_REQUEST_ID": "request_id",
    "VOXSCRIBE_TRACE_ID": "trace_id",
    "VOXSCRIBE_DEPLOYMENT_ID": "deployment_id",
    # K8s Downward API conventions: spec.nodeName, metadata.name, etc.
    "POD_NAME": "pod_name",
    "HOSTNAME": "container_name",
    "NODE_NAME": "node_name",
}


def set_log_context(**fields: Any) -> contextvars.Token:
    """Merge fields into the current logging context.

    Returns a token so callers can `reset_log_context(token)` to restore
    the prior state — useful for unit tests and for nested contexts.
    Values that are None or empty strings are dropped so the merged dict
    stays compact."""
    current = dict(_log_context.get() or {})
    for k, v in fields.items():
        if v is None or v == "":
            current.pop(k, None)
        else:
            current[k] = v
    return _log_context.set(current)


def get_log_context() -> dict[str, Any]:
    """Read-only snapshot of the current logging context."""
    return dict(_log_context.get() or {})


def reset_log_context(token: contextvars.Token) -> None:
    """Restore the context to the state captured by a prior set_log_context."""
    _log_context.reset(token)


def clear_log_context() -> None:
    """Drop all context. Tests use this to start clean."""
    _log_context.set({})


# ---- record enrichment --------------------------------------------------


# Fields that always appear on every LogRecord; everything else attached
# via `extra=` or our filter is structured payload we want to emit.
_RESERVED = {
    "args",
    "asctime",
    "created",
    "exc_info",
    "exc_text",
    "filename",
    "funcName",
    "levelname",
    "levelno",
    "lineno",
    "message",
    "msecs",
    "msg",
    "name",
    "module",
    "pathname",
    "process",
    "processName",
    "relativeCreated",
    "stack_info",
    "thread",
    "threadName",
    "taskName",
}


class _ContextFilter(logging.Filter):
    """Stamp service identity + correlation context onto every LogRecord.

    Runs as a filter (not a formatter) so both stdout/stderr and the
    session-file handler see the same enriched record. Anything already
    on the record (passed via `extra={}` at call time) wins over context,
    so a per-call override of `session_id` is honored."""

    def __init__(self, env_context: dict[str, Any] | None = None):
        super().__init__()
        self.env_context = env_context or {}

    def filter(self, record: logging.LogRecord) -> bool:
        # Service metadata: present on every record so K8s pod logs are
        # self-identifying with zero collector-side enrichment.
        for attr, value in (
            ("service", LogConfig.service),
            ("service_version", LogConfig.service_version),
            ("environment", LogConfig.environment),
        ):
            if not hasattr(record, attr):
                setattr(record, attr, value)

        # Env-bound future-ready fields (tenant_id, pod_name, …) merged
        # under correlation context. Per-record `extra=` still wins.
        for key, value in self.env_context.items():
            if value and not hasattr(record, key):
                setattr(record, key, value)

        # Contextvar correlation. set_log_context(session_id=...) here.
        for key, value in _log_context.get().items():
            if value and not hasattr(record, key):
                setattr(record, key, value)
        return True


def _record_extras(record: logging.LogRecord) -> dict[str, Any]:
    """Pull user + filter-added structured fields off a LogRecord."""
    out: dict[str, Any] = {}
    for k, v in record.__dict__.items():
        if k in _RESERVED or k.startswith("_"):
            continue
        out[k] = v
    return out


# ---- human formatter helpers -----------------------------------------------


# Maps Python logger names to human-friendly component labels shown in the
# pipe-separated human log format.
_COMPONENT_MAP: dict[str, str] = {
    "voxscribe": "VoxScribe",
    "voxscribe.cli": "CLI",
    "voxscribe.streaming_listen": "Listen",
    "voxscribe.providers": "LLM",
    "voxscribe.provider_harness": "LLM",
    "voxscribe.audio_providers": "ASR",
    "voxscribe.output_delivery": "Output",
    "voxscribe.session_report": "Report",
    "voxscribe.logging_config": "Logs",
    "voxscribe.session_metadata": "Session",
    "voxscribe.stream_state": "Runtime",
    "voxscribe.ollama": "Ollama",
}

# Short-form word overrides applied when converting snake_case event names to
# Title Case event titles.  Keys are lowercase; values are the display form.
_TITLE_WORDS: dict[str, str] = {
    "cli": "CLI",
    "id": "ID",
    "asr": "ASR",
    "llm": "LLM",
    "pid": "PID",
    "url": "URL",
    "api": "API",
    "ollama": "Ollama",
    "jsonl": "JSONL",
}

# These fields are suppressed from the human key=value section.  session_id
# appears in its own column; service metadata is K8s noise for operators;
# command and pid are context-contamination that repeats on every line.
_HUMAN_SUPPRESS = frozenset(
    {
        "session_id",
        "service",
        "service_version",
        "environment",
        "command",
        "pid",
    }
)

# Value fields whose content is a file-system path and should receive
# middle-truncation (prefix…/filename) rather than suffix-truncation.
_PATH_KEYS = frozenset(
    {
        "path",
        "file",
        "session_log_path",
        "txt_path",
        "jsonl_path",
        "report_path",
        "log_dir",
    }
)


def _logger_to_component(name: str) -> str:
    if name in _COMPONENT_MAP:
        return _COMPONENT_MAP[name]
    # Unknown logger: take the last dot segment, capitalize.
    return name.rsplit(".", 1)[-1].replace("_", " ").title()


def _event_to_title(event: str) -> str:
    """Convert a snake_case event name to a human-readable Title Case string."""
    words = event.replace("_", " ").split()
    return " ".join(_TITLE_WORDS.get(w, w.capitalize()) for w in words)


def _truncate_path_middle(path: str, max_chars: int) -> str:
    """Truncate a path in the middle, always preserving the filename."""
    if len(path) <= max_chars:
        return path
    slash = path.rfind("/")
    if slash < 0:
        return path[: max_chars - 3] + "..."
    fname = path[slash + 1 :]
    prefix_budget = max_chars - len(fname) - 4  # 4 = len("/...")
    if prefix_budget <= 0:
        return "..." + fname
    return path[:prefix_budget] + "/..." + fname


def _truncate_str(value: str, max_chars: int) -> str:
    if len(value) <= max_chars:
        return value
    return value[: max_chars - 3] + "..."


def _human_kv(key: str, value: Any, max_field: int, max_path: int) -> str:
    """Render a single key=value pair for the human log format."""
    raw = str(value) if not isinstance(value, bool) else ("true" if value else "false")
    if key in _PATH_KEYS:
        raw = _truncate_path_middle(raw, max_path)
    else:
        raw = _truncate_str(raw, max_field)
    if any(c.isspace() for c in raw):
        raw = '"' + raw.replace('"', '\\"') + '"'
    return f"{key}={raw}"


# ---- formatters ---------------------------------------------------------


class JsonFormatter(logging.Formatter):
    """One JSON object per line. Field order: timestamp, level, service,
    component, event, then everything else. Compatible with Datadog,
    CloudWatch, GCP, Loki, and OTel collectors without translation."""

    def format(self, record: logging.LogRecord) -> str:
        extras = _record_extras(record)
        # Pull canonical fields up front so they always sort first.
        payload: dict[str, Any] = {
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(record.created))
            + f".{int(record.msecs):03d}Z",
            "level": record.levelname,
            "service": extras.pop("service", LogConfig.service),
            "service_version": extras.pop("service_version", LogConfig.service_version),
            "environment": extras.pop("environment", LogConfig.environment),
            "component": record.name,
            "event": extras.pop("event", ""),
        }
        msg = record.getMessage()
        if msg:
            payload["message"] = msg
        # Everything else (session_id, provider, model, …). Emit in
        # alphabetic order so downstream diffs of two log lines are
        # stable.
        for key in sorted(extras):
            payload[key] = extras[key]
        if record.exc_info:
            payload["exc"] = self.formatException(record.exc_info)
        return json.dumps(payload, default=str, ensure_ascii=False)


class HumanFormatter(logging.Formatter):
    """Pipe-separated human-readable formatter.

    Format: [HH:MM:SS] LEVEL | Component | Session | Event Title | key=val | ...

    - session_id is shown in its own column (or '-' when absent).
    - Event name is converted from snake_case to Title Case.
    - Logger name is mapped to a friendly component label.
    - Service metadata, session_id, command, and pid are suppressed from
      key=value pairs — they clutter every line without adding readability.
    - Path-like values receive middle truncation (preserves filename).
    - All other values are suffix-truncated to max_field_chars.
    - JSON logs are unaffected; this formatter is only for human mode."""

    def format(self, record: logging.LogRecord) -> str:
        extras = _record_extras(record)

        # Human console timestamp honors the configured display tz so the
        # `[HH:MM:SS]` prefix matches the user's wall clock, not the host's.
        ts = datetime.fromtimestamp(
            record.created,
            tz=_resolve_display_tz(LogConfig.display_tz),
        ).strftime("%H:%M:%S")
        level = record.levelname[:5].ljust(5)
        component = _logger_to_component(record.name)
        session = str(extras.pop("session_id", "") or "") or "-"
        event = str(extras.pop("event", ""))
        title = _event_to_title(event) if event else (record.getMessage() or "Log")

        for k in _HUMAN_SUPPRESS - {"session_id"}:
            extras.pop(k, None)

        max_field = LogConfig.max_field_chars
        max_path = LogConfig.max_path_chars
        details: list[str] = []
        for k, v in extras.items():
            if v is None or v == "":
                continue
            details.append(_human_kv(k, v, max_field, max_path))

        msg = record.getMessage()
        if msg:
            msg_text = _truncate_str(msg, LogConfig.max_message_chars)
            if any(c.isspace() for c in msg_text):
                details.append(f'msg="{msg_text}"')
            else:
                details.append(f"msg={msg_text}")

        parts = [f"[{ts}] {level}", component, session, title] + details
        line = " | ".join(parts)
        if record.exc_info:
            line += "\n" + self.formatException(record.exc_info)
        return line


def _compact(value: Any) -> str:
    """Render an extra value for the human format. Quote anything with
    whitespace; truthy/non-string values pass through `str()`."""
    if isinstance(value, bool):
        return "true" if value else "false"
    text = str(value)
    if any(c.isspace() for c in text):
        return '"' + text.replace('"', '\\"') + '"'
    return text


# ---- public API ----------------------------------------------------------


_configured = False
_stream_handler: logging.Handler | None = None
_session_handler: logging.Handler | None = None
_context_filter: _ContextFilter | None = None


def _read_env_context() -> dict[str, Any]:
    out: dict[str, Any] = {}
    for env_name, key in _ENV_CONTEXT_BINDINGS.items():
        val = os.environ.get(env_name)
        if val:
            out[key] = val
    return out


def _sync_log_config_from_config(config: Any) -> None:
    """Update LogConfig class attrs from a VoxScribeConfig (duck-typed)."""
    lc = getattr(config, "logging", None)
    ac = getattr(config, "app", None)
    dc = getattr(config, "display", None)
    if lc is not None:
        level = str(getattr(lc, "level", "INFO")).upper()
        fmt = str(getattr(lc, "format", "human")).lower()
        LogConfig.level = level
        LogConfig.fmt = fmt if fmt in {"human", "json"} else "human"
        LogConfig.include_transcript = bool(getattr(lc, "include_transcript", False))
        LogConfig.max_text_chars = max(0, int(getattr(lc, "max_text_chars", 300)))
        LogConfig.session_log_enabled = bool(getattr(lc, "session_log_enabled", True))
        LogConfig.session_log_dir = str(getattr(lc, "session_log_dir", "logs/sessions"))
        LogConfig.max_field_chars = max(10, int(getattr(lc, "max_field_chars", 80)))
        LogConfig.max_message_chars = max(10, int(getattr(lc, "max_message_chars", 180)))
        LogConfig.max_path_chars = max(10, int(getattr(lc, "max_path_chars", 120)))
        LogConfig.hyperlink_paths = bool(getattr(lc, "hyperlink_paths", False))
    if dc is not None:
        LogConfig.display_tz = str(getattr(dc, "timezone", "") or "EST")
    if ac is not None:
        LogConfig.service = str(getattr(ac, "service_name", "voxscribe-core"))
        LogConfig.service_version = str(getattr(ac, "version", "0.1.0"))
        LogConfig.environment = str(getattr(ac, "environment", "local"))


def configure_logging(
    *,
    force: bool = False,
    stream=None,
    config: Any = None,
) -> None:
    """Install the VoxScribe stream handler on the `voxscribe` logger.

    Idempotent: subsequent calls are no-ops unless `force=True`. The
    session-file handler is NOT installed here — call `enable_session_log`
    once the session_id is known.

    Pass `config` (a VoxScribeConfig from load_config()) to use YAML-sourced
    settings. Without it, falls back to reading env vars via LogConfig.load()."""
    global _configured, _stream_handler, _context_filter
    if _configured and not force:
        return

    if config is not None:
        _sync_log_config_from_config(config)
    else:
        LogConfig.load()
    # LogConfig class attrs are now up-to-date regardless of which path ran.

    root = logging.getLogger("voxscribe")
    root.setLevel(getattr(logging, LogConfig.level, logging.INFO))

    # Reset prior VoxScribe handlers so re-configuration is deterministic.
    # The host application's root logger is untouched.
    for h in list(root.handlers):
        root.removeHandler(h)

    # The context filter must live on EACH handler — Python's logging
    # only runs logger-level filters for direct calls on that logger,
    # NOT for records propagated from children. Attaching it to the
    # handler ensures the enrichment runs no matter which child logger
    # produced the record.
    _context_filter = _ContextFilter(env_context=_read_env_context())

    _stream_handler = logging.StreamHandler(stream or sys.stderr)
    if LogConfig.fmt == "json":
        _stream_handler.setFormatter(JsonFormatter())
    else:
        _stream_handler.setFormatter(HumanFormatter())
    _stream_handler.addFilter(_context_filter)
    root.addHandler(_stream_handler)

    # Propagate so caplog and host-app handlers can observe records. The
    # Python root logger has no handler by default, so no duplication.
    root.propagate = True
    _configured = True


def enable_session_log(
    session_id: str,
    *,
    log_dir: str | None = None,
) -> str | None:
    """Attach a per-session JSONL file handler.

    Returns the full path of the session log file, or None when session
    logging is disabled by config. Idempotent: replaces any prior session
    handler so a `listen-stop` reattach doesn't double-write."""
    global _session_handler
    if not LogConfig.session_log_enabled:
        return None

    directory = Path(log_dir or LogConfig.session_log_dir)
    try:
        directory.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        # File-system failures are non-fatal — stdout/stderr logs remain
        # the source of truth in Docker.
        get_logger("voxscribe.logging_config").warning(
            "",
            extra={
                "event": "session_log_dir_unavailable",
                "session_id": session_id,
                "path": str(directory),
                "reason": type(exc).__name__,
            },
        )
        return None

    path = directory / f"{session_id}.log.jsonl"
    root = logging.getLogger("voxscribe")

    if _session_handler is not None:
        try:
            root.removeHandler(_session_handler)
            _session_handler.close()
        except Exception:  # noqa: BLE001
            pass
        _session_handler = None

    handler = logging.FileHandler(path, encoding="utf-8")
    handler.setFormatter(JsonFormatter())  # session files are always JSON.
    if _context_filter is not None:
        handler.addFilter(_context_filter)
    root.addHandler(handler)
    _session_handler = handler
    return str(path)


def disable_session_log() -> None:
    """Detach the per-session file handler. Safe to call when none is
    attached."""
    global _session_handler
    if _session_handler is None:
        return
    root = logging.getLogger("voxscribe")
    try:
        root.removeHandler(_session_handler)
        _session_handler.close()
    except Exception:  # noqa: BLE001
        pass
    _session_handler = None


def get_logger(component: str) -> logging.Logger:
    """Return the namespaced logger for a VoxScribe component."""
    if not component.startswith("voxscribe"):
        component = f"voxscribe.{component}"
    return logging.getLogger(component)


# ---- privacy helpers ------------------------------------------------------


def safe_preview(text: str | None) -> str | None:
    """Truncated text preview gated on VOXSCRIBE_LOG_INCLUDE_TRANSCRIPT.

    Always safe to call: returns None when transcripts are disabled, so
    the caller can pass it straight into structured extras."""
    if not text:
        return None
    if not LogConfig.include_transcript:
        return None
    max_chars = LogConfig.max_text_chars
    if max_chars <= 0:
        return None
    if len(text) <= max_chars:
        return text
    return text[:max_chars] + "…"


def text_chars(text: str | None) -> int:
    """Length of text in characters, or 0 when empty/None."""
    return len(text) if text else 0


def log_event(
    logger: logging.Logger,
    event: str,
    *,
    level: int = logging.INFO,
    **fields: Any,
) -> None:
    """Emit a structured event. Drops None/empty fields and avoids
    clashing with reserved LogRecord attribute names."""
    safe: dict[str, Any] = {}
    for k, v in fields.items():
        if v is None or v == "":
            continue
        key = k if k not in _RESERVED and k != "message" else f"{k}_"
        safe[key] = v
    safe["event"] = event
    logger.log(level, "", extra=safe)
