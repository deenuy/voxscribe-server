"""Personal dictionary and voice snippets.

Design choice that matters: known terms and snippets are handled
deterministically, not by the model. LLMs are unreliable for exact-string
fidelity (casing, dotted names) and add latency. So the model handles the
fuzzy work (filler, backtrack, punctuation, lists) and this module enforces
exact spelling of known terms as a fast post-pass, and expands snippets
before any model call. Zero hallucination on the words you care about most.

Storage is SQLite to match the PRD. Pass ":memory:" for tests.
"""

from __future__ import annotations

import re
import sqlite3
from collections.abc import Iterable
from dataclasses import dataclass

SCHEMA = """
CREATE TABLE IF NOT EXISTS user_dictionary (
  id INTEGER PRIMARY KEY,
  input_form TEXT NOT NULL,
  output_form TEXT NOT NULL,
  source TEXT DEFAULT 'user',
  tenant_id TEXT,
  use_count INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(input_form, tenant_id)
);
CREATE TABLE IF NOT EXISTS snippets (
  id INTEGER PRIMARY KEY,
  trigger TEXT NOT NULL,
  expansion TEXT NOT NULL,
  tenant_id TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(trigger, tenant_id)
);
"""

# Spoken forms map to written forms. Multi-token spoken spellings are included
# because ASR emits them literally ("fast a p i", "next j s").
#
# Curation rule: only add a term when (a) the spoken form is unambiguous in
# isolation and (b) the written form has casing/spelling the ASR routinely
# botches. Ordinary words ("data", "okay") stay out — the model handles them.
BUILTIN_TERMS = [
    # --- Cloud / infra ---
    ("supabase", "Supabase"),
    ("vercel", "Vercel"),
    ("cloudflare", "Cloudflare"),
    ("kubernetes", "Kubernetes"),
    ("docker", "Docker"),
    ("github", "GitHub"),
    ("databricks", "Databricks"),
    ("lakeflow", "Lakeflow"),
    ("zero bus", "Zero Bus"),
    ("alteryx", "Alteryx"),
    ("salesforce", "Salesforce"),
    ("workday", "Workday"),
    ("netsuite", "NetSuite"),
    # --- Languages / frameworks ---
    ("typescript", "TypeScript"),
    ("javascript", "JavaScript"),
    ("postgresql", "PostgreSQL"),
    ("postgres", "Postgres"),
    ("graphql", "GraphQL"),
    ("arango d b", "ArangoDB"),
    ("arangodb", "ArangoDB"),
    ("fast a p i", "FastAPI"),
    ("fastapi", "FastAPI"),
    ("next j s", "Next.js"),
    ("nextjs", "Next.js"),
    ("react native", "React Native"),
    ("apache kafka", "Apache Kafka"),
    ("apache flink", "Apache Flink"),
    ("apache spark", "Apache Spark"),
    # --- AI / ML systems ---
    # "AGI" is left out on purpose: it's a real word the model should keep.
    # "agentic" is added because Whisper base/small routinely hears it as "AGI"
    # or "agent ic"; the normalization runs case-insensitive on a word boundary.
    ("agentic", "agentic"),
    ("rag", "RAG"),
    ("llm", "LLM"),
    ("a s r", "ASR"),
    ("t t s", "TTS"),
    ("anthropic", "Anthropic"),
    ("claude", "Claude"),
    ("open a i", "OpenAI"),
    ("openai", "OpenAI"),
    ("chat g p t", "ChatGPT"),
    ("chatgpt", "ChatGPT"),
    ("gemini", "Gemini"),
    ("gemma", "Gemma"),
    ("whisper", "Whisper"),
    ("ollama", "Ollama"),
    ("hugging face", "Hugging Face"),
    ("pytorch", "PyTorch"),
    ("tensorflow", "TensorFlow"),
    # --- Common all-caps acronyms that ASR mishears ---
    # GA (general availability) → "G8" or "great"; bracket with the boundary
    # rule so it only matches the standalone token. We register both the
    # spaced ("a p i") and contiguous ("api") spoken forms because Whisper
    # picks one or the other depending on prosody, and we want either to
    # land on the canonical written form.
    ("g a", "GA"),
    ("a p i", "API"),
    ("api", "API"),
    ("c p u", "CPU"),
    ("cpu", "CPU"),
    ("g p u", "GPU"),
    ("gpu", "GPU"),
    ("s d k", "SDK"),
    ("sdk", "SDK"),
    ("c l i", "CLI"),
    ("u r l", "URL"),
    ("url", "URL"),
    # http / json / sql intentionally only register the spaced spoken form.
    # The joined forms ("http", "json", "sql") collide with real lowercase
    # usage as URL schemes and file extensions (package.json, schema.sql);
    # word-boundary regex isn't sensitive enough to disambiguate, so we
    # only normalize when the speaker explicitly spelled the acronym out.
    ("h t t p", "HTTP"),
    ("j s o n", "JSON"),
    ("s q l", "SQL"),
]


def _normalize_key(text: str) -> str:
    return re.sub(r"\s+", " ", text.strip().lower())


def _strip_for_match(text: str) -> str:
    """Lowercase and drop surrounding punctuation for snippet trigger match."""
    return re.sub(r"[^\w\s]", "", text).strip().lower()


@dataclass
class PhraseRule:
    """A deterministic multi-token substitution applied in the final
    dictionary pass. Wider than the BUILTIN_TERMS path because it accepts
    arbitrary patterns with optional word-boundary anchoring; narrower in
    intent because it only fires on lexicon-loaded rules."""

    pattern: str
    replacement: str
    case_insensitive: bool = True
    word_boundary: bool = True


@dataclass
class Dictionary:
    db_path: str = ":memory:"
    tenant_id: str | None = None

    def __post_init__(self) -> None:
        self._conn = sqlite3.connect(self.db_path)
        self._conn.executescript(SCHEMA)
        self.seed_builtins()
        # Multi-token phrase rules from a loaded lexicon. Applied longest-
        # first inside normalize() so "turns widget" wins over "turns".
        self._phrase_rules: list[PhraseRule] = []
        # Per-session canonical surface forms. Once a term resolves to a
        # specific casing (via lexicon or a confident first rendering), pin
        # it so every later mention in the same session renders the same.
        # Map: session_id -> { lowercased_form: canonical_surface }.
        self._session_locks: dict[str, dict[str, str]] = {}
        # The session whose lock + phrase rules should apply when callers
        # don't pass session_id explicitly. PostProcessor.normalize() runs
        # without a session_id, so streaming_listen sets this at session
        # start and clears it at session end.
        self.active_session_id: str | None = None

    # ---- seeding and writes ----

    def seed_builtins(self) -> None:
        for input_form, output_form in BUILTIN_TERMS:
            self._conn.execute(
                "INSERT OR IGNORE INTO user_dictionary "
                "(input_form, output_form, source, tenant_id) VALUES (?, ?, 'builtin', ?)",
                (_normalize_key(input_form), output_form, self.tenant_id),
            )
        self._conn.commit()

    def learn(self, input_form: str, output_form: str, source: str = "user") -> None:
        """Auto-learn a correction. Called when the user fixes VoxScribe output."""
        self._conn.execute(
            "INSERT INTO user_dictionary (input_form, output_form, source, tenant_id) "
            "VALUES (?, ?, ?, ?) "
            "ON CONFLICT(input_form, tenant_id) DO UPDATE SET "
            "output_form=excluded.output_form, use_count=use_count+1",
            (_normalize_key(input_form), output_form, source, self.tenant_id),
        )
        self._conn.commit()

    def add_snippet(self, trigger: str, expansion: str) -> None:
        self._conn.execute(
            "INSERT INTO snippets (trigger, expansion, tenant_id) VALUES (?, ?, ?) "
            "ON CONFLICT(trigger, tenant_id) DO UPDATE SET expansion=excluded.expansion",
            (_strip_for_match(trigger), expansion, self.tenant_id),
        )
        self._conn.commit()

    # ---- reads ----

    def _terms(self) -> Iterable[tuple[str, str]]:
        cur = self._conn.execute(
            "SELECT input_form, output_form FROM user_dictionary "
            "WHERE tenant_id IS ? ORDER BY LENGTH(input_form) DESC",
            (self.tenant_id,),
        )
        return cur.fetchall()

    def expand_snippet(self, utterance: str) -> str | None:
        """If the whole utterance is a snippet trigger, return its expansion."""
        key = _strip_for_match(utterance)
        if not key:
            return None
        row = self._conn.execute(
            "SELECT expansion FROM snippets WHERE trigger = ? AND tenant_id IS ?",
            (key, self.tenant_id),
        ).fetchone()
        return row[0] if row else None

    def normalize(self, text: str, session_id: str | None = None) -> str:
        """Enforce known-term spelling. Longest spoken forms win, word-boundary,
        case-insensitive. Runs as a post-pass after the model.

        When session_id is provided (or active_session_id is set), lexicon
        phrase rules and the per-session canonical-form lock also apply, in
        this order: (1) phrase rules, (2) builtin/learned terms, (3) session
        lock. The lock runs last so a freshly resolved term backfills earlier
        mentions within the same session.
        """
        if session_id is None:
            session_id = self.active_session_id
        result = text

        # 1. Lexicon-loaded multi-token phrase rules. Longest pattern first
        # so "turns widget" beats "turns".
        for rule in sorted(self._phrase_rules, key=lambda r: -len(r.pattern)):
            result = self._apply_phrase_rule(result, rule)

        # 2. Builtin / learned single-token (or spoken-spelled) terms.
        for input_form, output_form in self._terms():
            # \b does not behave well across spaces, so match the phrase with
            # boundaries on each end of the whole token sequence.
            pattern = r"(?<!\w)" + re.escape(input_form).replace(r"\ ", r"\s+") + r"(?!\w)"
            result = re.sub(pattern, output_form, result, flags=re.IGNORECASE)

        # 3. Session term-consistency lock: pin the first canonical form
        # for each lock entry across the session.
        if session_id is not None:
            result = self._apply_session_lock(result, session_id)
            # Learn from the post-normalization output so later mentions get
            # backfilled even if the lexicon didn't have an explicit rule.
            self._learn_session_surfaces(result, session_id)

        return result

    @staticmethod
    def _apply_phrase_rule(text: str, rule: PhraseRule) -> str:
        flags = re.IGNORECASE if rule.case_insensitive else 0
        pat = re.escape(rule.pattern).replace(r"\ ", r"\s+")
        if rule.word_boundary:
            pat = r"(?<!\w)" + pat + r"(?!\w)"
        return re.sub(pat, rule.replacement, text, flags=flags)

    # ---- lexicon + session lock ----

    def load_phrase_rules(self, rules: Iterable[PhraseRule]) -> None:
        """Replace the active phrase-rule set (typically once per session)."""
        self._phrase_rules = list(rules)

    def seed_session_lock(self, session_id: str, canonical_terms: Iterable[str]) -> None:
        """Pre-populate the session's canonical surfaces from a lexicon.

        Anything later seen in any case (e.g. 'BRIDGEMIND') is normalized to
        the surface form here on a word-boundary match."""
        lock = self._session_locks.setdefault(session_id, {})
        for surface in canonical_terms:
            if not surface:
                continue
            lock[surface.lower()] = surface

    def session_lock(self, session_id: str) -> dict[str, str]:
        """Read-only view of the session's resolved canonical forms."""
        return dict(self._session_locks.get(session_id, {}))

    def clear_session_lock(self, session_id: str) -> None:
        self._session_locks.pop(session_id, None)

    def _apply_session_lock(self, text: str, session_id: str) -> str:
        lock = self._session_locks.get(session_id)
        if not lock:
            return text
        result = text
        # Longest canonical surface first so "BridgeMind UI" wins over
        # "BridgeMind".
        for key in sorted(lock.keys(), key=len, reverse=True):
            canonical = lock[key]
            pat = r"(?<!\w)" + re.escape(key).replace(r"\ ", r"\s+") + r"(?!\w)"
            result = re.sub(pat, canonical, result, flags=re.IGNORECASE)
        return result

    def _learn_session_surfaces(self, text: str, session_id: str) -> None:
        """Opportunistically pin proper-noun-shaped tokens.

        Only conservative shapes are auto-learned: internal-caps tokens
        ('BridgeMind', 'ChatGPT'), tokens with digits/dots ('K2.7', 'GPT-5.5'),
        and adjacent two-token capitalized phrases ('Kimi K2.7'). Plain
        title-case words at sentence start are skipped — those are too common
        to safely lock from one observation.

        Lexicon-seeded surfaces always win over learned ones (setdefault)."""
        lock = self._session_locks.setdefault(session_id, {})

        def shape_is_pinable(token: str) -> bool:
            if len(token) < 2:
                return False
            if any(ch.isdigit() for ch in token):
                return True
            # Internal capital letter after the first character.
            return any(ch.isupper() for ch in token[1:])

        token_re = re.compile(r"[A-Za-z][\w\.\-]*")
        tokens = list(token_re.finditer(text))
        i = 0
        while i < len(tokens):
            tok = tokens[i].group(0)
            # Try a two-token capitalized phrase first (longest match wins).
            if (
                i + 1 < len(tokens)
                and tok[:1].isupper()
                and tokens[i + 1].group(0)[:1].isupper()
                and shape_is_pinable(tokens[i + 1].group(0))
                and tokens[i + 1].start() - tokens[i].end() == 1
            ):
                phrase = text[tokens[i].start() : tokens[i + 1].end()]
                lock.setdefault(phrase.lower(), phrase)
                i += 2
                continue
            if tok[:1].isupper() and shape_is_pinable(tok):
                lock.setdefault(tok.lower(), tok)
            i += 1

    def close(self) -> None:
        self._conn.close()
