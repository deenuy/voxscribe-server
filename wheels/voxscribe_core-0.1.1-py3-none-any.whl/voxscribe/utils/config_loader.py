"""Centralized config loader for VoxScribe Core.

Precedence (lowest → highest):
  1. built-in dataclass defaults
  2. config/config.yaml
  3. config/config.local.yaml  (gitignored, local developer overrides)
  4. .env file                 (local secrets; gitignored)
  5. environment variables     (wins in Docker / Kubernetes / CI)

Non-secret runtime config lives in config.yaml.
Secrets (API keys, tokens) come from environment variables or Kubernetes Secrets.
config.yaml is safe to commit; .env and config.local.yaml are gitignored.

Kubernetes path:
  - config.yaml → ConfigMap mounted at /app/config/config.yaml
  - secrets → env vars from Kubernetes Secrets
  - logs → stdout/stderr (json format)
  - session log files → optional, disabled by default in Docker/K8s

PyYAML is the only added dependency. All other config parsing uses stdlib.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

try:
    import yaml as _yaml

    _YAML_AVAILABLE = True
except ImportError:
    _YAML_AVAILABLE = False


# ---- config section dataclasses -------------------------------------------


@dataclass
class AppConfig:
    service_name: str = "voxscribe-core"
    environment: str = "local"
    version: str = "0.1.0"


@dataclass
class PathsConfig:
    output_dir: str = "output"
    logs_dir: str = "logs"
    session_log_dir: str = "logs/sessions"
    lexicon_dir: str = "data/lexicons"


@dataclass
class BackendConfig:
    host: str = "0.0.0.0"
    port: int = 8000
    enable_api: bool = False


@dataclass
class ListenConfig:
    default_mode: str = "prose"
    stop_timeout_seconds: int = 30
    listen_once_timeout_seconds: int = 30
    # When the wall-clock gap between two received audio chunks exceeds
    # this many seconds, a `capture_gap` event is logged so silent stretches
    # leave a structured trace in the session log. Default 30s.
    gap_log_threshold_s: float = 30.0


@dataclass
class ASRConfig:
    provider: str = "faster_whisper"
    model: str = "base.en"
    device: str = "auto"
    compute_type: str = "auto"
    initial_prompt_enabled: bool = True


@dataclass
class LLMConfig:
    provider: str = "ollama"
    model: str = "gemma3:4b"
    temperature: float = 0.2
    timeout_seconds: int = 60
    use_fallback: bool = True


@dataclass
class AudioUnderstandingConfig:
    enabled: bool = False
    provider: str = "gemma_audio"
    model: str = "gemma-audio"
    timeout_seconds: int = 30
    # Judgment-lane tuning (UncertaintyRouter). These are deployment
    # config, deliberately not restated in public docs or config.yaml.
    session_budget: int = 12
    hysteresis: float = 0.08
    repair_margin: float = 0.1
    enforce_budget_ms: bool = True


@dataclass
class TTSConfig:
    """Lane 7 voice output. Disabled by default; the listen-only product is
    unchanged until a deployment turns it on. The voice catalog and the
    per-mode selection are config so switching voices or backends is zero
    code change (same pattern as personas and lexicons).

    Voice catalog entries are dicts:
      voice_id   backend voice name (e.g. a Piper .onnx voice)
      language   two-letter code
      speed      prosody knob the product layer may set
      pitch      prosody knob the product layer may set
      kind       open_source (default) | cloud | cloned | real_person
      cloud_opt_in  explicit per-tenant opt-in, required for kind: cloud

    Policy boundaries enforced by the voice registry, not here:
    cloud voices are rejected in seniorcare and classroom; cloned and
    real-person voices are rejected everywhere (deferred for legal
    review: consent, likeness, and biometric surface)."""

    enabled: bool = False
    provider: str = "piper"  # piper | fake | none
    model_path: str = ""  # path to the on-device voice model file
    # Acoustic echo control (self-hearing): while TTS plays, capture is
    # gated so the device never transcribes its own speech; a captured
    # segment with energy above the barge-in threshold releases the gate
    # instantly and stops playback (fast release). Phase 0 ships capture
    # gating; reference-signal AEC is a future refinement behind the same
    # flag.
    echo_suppression_enabled: bool = True
    barge_in_energy_threshold: float = 0.05
    # Per-mode voice selection: mode name -> catalog voice name.
    mode_voices: dict = field(
        default_factory=lambda: {
            "seniorcare": "warm_unhurried",
            "classroom": "age_appropriate",
            "dictation": "neutral",
            "ideascribe": "neutral",
        }
    )
    # Named open-source voice catalog (Piper voices unless kind says else).
    voices: dict = field(
        default_factory=lambda: {
            "warm_unhurried": {
                "voice_id": "en_US-lessac-medium",
                "language": "en",
                "speed": 0.85,
                "pitch": 0.0,
                "kind": "open_source",
            },
            "age_appropriate": {
                "voice_id": "en_US-amy-medium",
                "language": "en",
                "speed": 1.0,
                "pitch": 0.0,
                "kind": "open_source",
            },
            "neutral": {
                "voice_id": "en_US-ryan-medium",
                "language": "en",
                "speed": 1.0,
                "pitch": 0.0,
                "kind": "open_source",
            },
        }
    )


@dataclass
class SessionReportConfig:
    enabled_on_stop: bool = True
    format: str = "markdown"
    use_llm: bool = True
    fallback_enabled: bool = True


@dataclass
class OutputDeliveryConfig:
    insert_at_cursor: bool = False
    insert_method: str = "auto"
    insert_format: str = "markdown"
    restore_clipboard: bool = True
    insert_timeout_ms: int = 3000
    target_mode: str = "active"
    focus_delay_ms: int = 2000


@dataclass
class LoggingConfig:
    level: str = "INFO"
    format: str = "human"
    include_transcript: bool = False
    max_text_chars: int = 300
    session_log_enabled: bool = True
    session_log_dir: str = "logs/sessions"
    max_field_chars: int = 80
    max_message_chars: int = 180
    max_path_chars: int = 120
    hyperlink_paths: bool = False


@dataclass
class ObservabilityConfig:
    trace_id_enabled: bool = True
    request_id_enabled: bool = True


@dataclass
class CLIConfig:
    """CLI user experience settings. Controls the startup panel, compact mode,
    runtime log visibility, and Unicode/ASCII box-drawing style.

    The startup panel is auto-disabled when log format is 'json' or stdout is
    not a TTY (Docker), unless explicitly overridden via env var."""

    startup_panel: bool = True
    compact_startup_panel: bool = False
    show_runtime_logs: bool = True
    use_unicode: bool = True


@dataclass
class DockerConfig:
    default_log_format: str = "json"
    session_log_enabled: bool = False


@dataclass
class DisplayConfig:
    """Presentation-only settings (console log + CLI banners).

    `timezone` accepts friendly aliases (EST, PST, IST, UTC, GMT) or any
    IANA name. Stored timestamps (JSONL events, session log file, usage
    ledger) remain UTC ISO 8601 regardless — this is display only."""

    timezone: str = "EST"


@dataclass
class StorageConfig:
    """Local durable store (SQLite). Path is overridable for tests; the
    CLI uses the default. No other knobs in phase 0 — keep it boring."""

    db_path: str = "logs/voxscribe.db"


@dataclass
class BillingConfig:
    """Customer-facing usage metering.

    VoxScribe meters on finalized words (Wispr Flow precedent). The
    weekly word cap is shown in the completion panel; `enforce_cap`
    decides whether the CLI blocks once the cap is reached. v1 ships
    measurement only — enforcement is a future change.

    `account_id` is the billing identity; empty means anonymous local
    use (the CLI will derive a stable random id and persist it next to
    the ledger). `week_reset_tz` controls when the weekly counter rolls
    over so the boundary lines up with the user's billing cycle rather
    than naive UTC midnight Sunday."""

    account_id: str = ""  # empty = anonymous local
    weekly_word_cap: int = 2000  # Wispr Basic parity
    enforce_cap: bool = False  # measure-only in v1
    week_reset_tz: str = "America/Los_Angeles"
    ledger_path: str = "logs/usage.json"


@dataclass
class ModeEntry:
    """One product mode: its prompt file and user-facing product name."""

    prompt_file: str = ""
    product: str = ""


@dataclass
class ModesConfig:
    """Per-mode prompt file paths and product labels.

    Default entries mirror the three product startups VoxScribe serves.
    Override individual fields in config.yaml under the `modes:` section."""

    ideascribe: ModeEntry = field(
        default_factory=lambda: ModeEntry(
            prompt_file="data/prompts/ideascribe.md",
            product="IdeaScribe",
        )
    )
    classroom: ModeEntry = field(
        default_factory=lambda: ModeEntry(
            prompt_file="data/prompts/classroom.md",
            product="ClassroomScribe",
        )
    )
    seniorcare: ModeEntry = field(
        default_factory=lambda: ModeEntry(
            prompt_file="data/prompts/seniorcare.md",
            product="SeniorCareScribe",
        )
    )


@dataclass
class VoxScribeConfig:
    """Top-level config object. All fields are populated from yaml + env."""

    app: AppConfig = field(default_factory=AppConfig)
    paths: PathsConfig = field(default_factory=PathsConfig)
    backend: BackendConfig = field(default_factory=BackendConfig)
    listen: ListenConfig = field(default_factory=ListenConfig)
    asr: ASRConfig = field(default_factory=ASRConfig)
    llm: LLMConfig = field(default_factory=LLMConfig)
    audio_understanding: AudioUnderstandingConfig = field(default_factory=AudioUnderstandingConfig)
    tts: TTSConfig = field(default_factory=TTSConfig)
    session_report: SessionReportConfig = field(default_factory=SessionReportConfig)
    output_delivery: OutputDeliveryConfig = field(default_factory=OutputDeliveryConfig)
    logging: LoggingConfig = field(default_factory=LoggingConfig)
    observability: ObservabilityConfig = field(default_factory=ObservabilityConfig)
    cli: CLIConfig = field(default_factory=CLIConfig)
    docker: DockerConfig = field(default_factory=DockerConfig)
    modes: ModesConfig = field(default_factory=ModesConfig)
    billing: BillingConfig = field(default_factory=BillingConfig)
    display: DisplayConfig = field(default_factory=DisplayConfig)
    storage: StorageConfig = field(default_factory=StorageConfig)


# ---- env var → config field mapping ----------------------------------------


def _parse_bool(value: str) -> bool:
    return value.strip().lower() in {"1", "true", "yes", "on"}


# (env_var, section_attr_on_VoxScribeConfig, field_name, type_fn)
_ENV_OVERRIDES: list[tuple[str, str, str, Any]] = [
    ("VOXSCRIBE_ENVIRONMENT", "app", "environment", str),
    ("VOXSCRIBE_SERVICE_NAME", "app", "service_name", str),
    ("VOXSCRIBE_OUTPUT_DIR", "paths", "output_dir", str),
    ("VOXSCRIBE_LOG_LEVEL", "logging", "level", str),
    ("VOXSCRIBE_LOG_FORMAT", "logging", "format", str),
    ("VOXSCRIBE_LOG_INCLUDE_TRANSCRIPT", "logging", "include_transcript", _parse_bool),
    ("VOXSCRIBE_LOG_MAX_TEXT_CHARS", "logging", "max_text_chars", int),
    ("VOXSCRIBE_SESSION_LOG_ENABLED", "logging", "session_log_enabled", _parse_bool),
    ("VOXSCRIBE_SESSION_LOG_DIR", "logging", "session_log_dir", str),
    ("VOXSCRIBE_LOG_MAX_FIELD_CHARS", "logging", "max_field_chars", int),
    ("VOXSCRIBE_LOG_MAX_MESSAGE_CHARS", "logging", "max_message_chars", int),
    ("VOXSCRIBE_LOG_MAX_PATH_CHARS", "logging", "max_path_chars", int),
    ("VOXSCRIBE_LOG_HYPERLINK_PATHS", "logging", "hyperlink_paths", _parse_bool),
    ("VOXSCRIBE_INSERT_AT_CURSOR", "output_delivery", "insert_at_cursor", _parse_bool),
    ("VOXSCRIBE_INSERT_METHOD", "output_delivery", "insert_method", str),
    ("VOXSCRIBE_INSERT_FORMAT", "output_delivery", "insert_format", str),
    ("VOXSCRIBE_RESTORE_CLIPBOARD", "output_delivery", "restore_clipboard", _parse_bool),
    ("VOXSCRIBE_INSERT_TIMEOUT_MS", "output_delivery", "insert_timeout_ms", int),
    ("VOXSCRIBE_INSERT_TARGET_MODE", "output_delivery", "target_mode", str),
    ("VOXSCRIBE_INSERT_FOCUS_DELAY_MS", "output_delivery", "focus_delay_ms", int),
    ("VOXSCRIBE_REPORT_ON_STOP", "session_report", "enabled_on_stop", _parse_bool),
    ("VOXSCRIBE_REPORT_FORMAT", "session_report", "format", str),
    ("VOXSCRIBE_REPORT_USE_LLM", "session_report", "use_llm", _parse_bool),
    ("VOXSCRIBE_ASR_PROVIDER", "asr", "provider", str),
    ("VOXSCRIBE_ASR_MODEL", "asr", "model", str),
    ("VOXSCRIBE_LLM_PROVIDER", "llm", "provider", str),
    ("VOXSCRIBE_OLLAMA_MODEL", "llm", "model", str),
    ("VOXSCRIBE_LLM_TEMPERATURE", "llm", "temperature", float),
    ("VOXSCRIBE_LLM_TIMEOUT_SECONDS", "llm", "timeout_seconds", int),
    ("VOXSCRIBE_AUDIO_UNDERSTANDING_ENABLED", "audio_understanding", "enabled", _parse_bool),
    ("VOXSCRIBE_AUDIO_UNDERSTANDING_PROVIDER", "audio_understanding", "provider", str),
    ("VOXSCRIBE_AUDIO_UNDERSTANDING_MODEL", "audio_understanding", "model", str),
    ("VOXSCRIBE_TTS_ENABLED", "tts", "enabled", _parse_bool),
    ("VOXSCRIBE_TTS_PROVIDER", "tts", "provider", str),
    ("VOXSCRIBE_TTS_MODEL_PATH", "tts", "model_path", str),
    ("VOXSCRIBE_TTS_ECHO_SUPPRESSION", "tts", "echo_suppression_enabled", _parse_bool),
    ("VOXSCRIBE_CLI_STARTUP_PANEL", "cli", "startup_panel", _parse_bool),
    ("VOXSCRIBE_CLI_COMPACT_STARTUP_PANEL", "cli", "compact_startup_panel", _parse_bool),
    ("VOXSCRIBE_CLI_SHOW_RUNTIME_LOGS", "cli", "show_runtime_logs", _parse_bool),
    ("VOXSCRIBE_CLI_USE_UNICODE", "cli", "use_unicode", _parse_bool),
    ("VOXSCRIBE_BILLING_WEEKLY_WORD_CAP", "billing", "weekly_word_cap", int),
    ("VOXSCRIBE_BILLING_ENFORCE_CAP", "billing", "enforce_cap", _parse_bool),
    ("VOXSCRIBE_BILLING_LEDGER_PATH", "billing", "ledger_path", str),
    ("VOXSCRIBE_BILLING_ACCOUNT_ID", "billing", "account_id", str),
    ("VOXSCRIBE_BILLING_WEEK_RESET_TZ", "billing", "week_reset_tz", str),
    ("VOXSCRIBE_LISTEN_GAP_LOG_THRESHOLD_S", "listen", "gap_log_threshold_s", float),
    ("VOXSCRIBE_DISPLAY_TIMEZONE", "display", "timezone", str),
    ("VOXSCRIBE_DB_PATH", "storage", "db_path", str),
]


# ---- internal helpers -------------------------------------------------------


def _load_yaml_file(path: Path) -> dict:
    if not path.exists():
        return {}
    if not _YAML_AVAILABLE:
        raise RuntimeError(
            f"PyYAML is required to load {path}. "
            "Run: pip install pyyaml  (or: pip install 'voxscribe-core[config]')"
        )
    with path.open(encoding="utf-8") as fh:
        try:
            data = _yaml.safe_load(fh)
        except _yaml.YAMLError as exc:
            raise ValueError(f"YAML parse error in {path}: {exc}") from exc
    if data is None:
        return {}
    if not isinstance(data, dict):
        raise ValueError(
            f"Config file {path} must be a YAML mapping at the top level, got {type(data).__name__}"
        )
    return data


_SECTION_MAP = {
    "app": "app",
    "paths": "paths",
    "backend": "backend",
    "listen": "listen",
    "asr": "asr",
    "llm": "llm",
    "audio_understanding": "audio_understanding",
    "tts": "tts",
    "session_report": "session_report",
    "output_delivery": "output_delivery",
    "logging": "logging",
    "observability": "observability",
    "cli": "cli",
    "docker": "docker",
    "billing": "billing",
    "display": "display",
    "storage": "storage",
}


def _merge_yaml(cfg: VoxScribeConfig, data: dict) -> None:
    for yaml_key, attr_name in _SECTION_MAP.items():
        if yaml_key not in data:
            continue
        section_data = data[yaml_key]
        if not isinstance(section_data, dict):
            continue
        section_obj = getattr(cfg, attr_name)
        for field_name, value in section_data.items():
            if hasattr(section_obj, field_name):
                setattr(section_obj, field_name, value)
    # `modes:` has one level of nesting (mode name -> {prompt_file, product})
    # that the flat merge above cannot express. Merge it explicitly.
    modes_data = data.get("modes")
    if isinstance(modes_data, dict):
        for mode_key, entry_data in modes_data.items():
            mode_entry = getattr(cfg.modes, mode_key, None)
            if mode_entry is None or not isinstance(entry_data, dict):
                continue
            for field_name, value in entry_data.items():
                if hasattr(mode_entry, field_name):
                    setattr(mode_entry, field_name, value)


def _load_dotenv(env_path: Path) -> None:
    """Parse .env and set any env vars not already in os.environ.

    Env vars already in the environment win — .env is a local development
    convenience that does not override CI/Kubernetes env injection."""
    if not env_path.exists():
        return
    with env_path.open(encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" not in line:
                continue
            key, _, value = line.partition("=")
            key = key.strip()
            value = value.strip()
            if len(value) >= 2 and value[0] == value[-1] and value[0] in ('"', "'"):
                value = value[1:-1]
            if key and key not in os.environ:
                os.environ[key] = value


def _apply_env_overrides(cfg: VoxScribeConfig) -> None:
    for env_var, section_attr, field_name, type_fn in _ENV_OVERRIDES:
        raw = os.environ.get(env_var)
        if raw is None or raw.strip() == "":
            continue
        section = getattr(cfg, section_attr)
        try:
            setattr(section, field_name, type_fn(raw.strip()))
        except (ValueError, TypeError):
            pass


# ---- public API ------------------------------------------------------------


def _default_config_path() -> Path:
    """Resolve the default config.yaml path with resource resolver."""
    from ..resources import resolve
    # Check for legacy override first
    legacy = Path("config") / "config.yaml"
    if legacy.is_file():
        return legacy
    # Use packaged resource
    try:
        return resolve("resources_config/config.yaml")
    except FileNotFoundError:
        # Last resort: use legacy path even if missing (load will handle it)
        return legacy


DEFAULT_CONFIG_PATH = None  # Lazy-resolved


_config: VoxScribeConfig | None = None


def _build_config(
    config_path: Path | None = None,
    *,
    local_config_path: Path | None = None,
    env_path: Path | None = None,
) -> VoxScribeConfig:
    """Build a fully-resolved VoxScribeConfig. Does NOT update the singleton."""
    cfg = VoxScribeConfig()

    # Step 2: main config.yaml
    resolved_config = config_path if config_path is not None else _default_config_path()
    main_data = _load_yaml_file(resolved_config)
    _merge_yaml(cfg, main_data)

    # Step 3: config.local.yaml
    if local_config_path is None and resolved_config.exists():
        local_config_path = resolved_config.parent / "config.local.yaml"
    if local_config_path is not None:
        local_data = _load_yaml_file(local_config_path)
        _merge_yaml(cfg, local_data)

    # Step 4: .env file
    dotenv = env_path if env_path is not None else Path(".env")
    _load_dotenv(dotenv)

    # Step 5: environment variable overrides
    _apply_env_overrides(cfg)

    return cfg


def load_config(
    config_path: str | Path | None = None,
    *,
    env_path: str | Path | None = None,
) -> VoxScribeConfig:
    """Load and cache a fully-resolved VoxScribeConfig.

    Subsequent calls replace the singleton. Use get_config() when you want
    the already-loaded config without re-reading files."""
    global _config
    _config = _build_config(
        config_path=Path(config_path) if config_path else None,
        env_path=Path(env_path) if env_path else None,
    )
    return _config


def get_config() -> VoxScribeConfig:
    """Return the cached config, loading defaults if not yet loaded.

    Safe to call from any module without knowing whether load_config() has
    run — falls back to built-in defaults + env vars if no config was loaded."""
    global _config
    if _config is None:
        _config = _build_config()
    return _config


def reload_config(
    config_path: str | Path | None = None,
    *,
    env_path: str | Path | None = None,
) -> VoxScribeConfig:
    """Force a fresh load, bypassing the singleton cache.

    Useful in tests and in long-running processes that need to pick up
    config changes without a restart."""
    global _config
    _config = _build_config(
        config_path=Path(config_path) if config_path else None,
        env_path=Path(env_path) if env_path else None,
    )
    return _config
