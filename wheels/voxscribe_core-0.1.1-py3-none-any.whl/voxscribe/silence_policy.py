"""Pause bands and thought-completeness cues — the inputs to turn-taking.

The kernel never uses a single silence timeout. Silence duration is
classified into bands, and what a band means depends on whether the text so
far reads as a complete thought. A 20-second pause mid-sentence holds the
turn open; a 7-second pause after a finished sentence closes it.

Heuristics here return an answer plus a confidence, not a bare answer, so a
low-confidence call can route to the audio-understanding lane (CP5) instead
of being trusted blindly. Everything in this module is pure and runs on
every chunk, so it must stay deterministic and allocation-light.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from enum import Enum


class PauseBand(str, Enum):
    MICRO = "micro"  # intra-phrase; not a boundary signal
    SHORT = "short"  # clause boundary; punctuation hint at most
    LONG = "long"  # thinking pause; possible continuation, hold open
    EXTENDED = "extended"  # turn may end — but only if the thought is complete


@dataclass
class PauseBandConfig:
    """Band edges in ms. Tune per environment the way VADConfig does; these
    defaults assume conversational dictation, where 10-30s thinking pauses
    are normal and must not end the turn."""

    short_ms: float = 400.0
    long_ms: float = 1500.0
    extended_ms: float = 6000.0


# ---- adaptive calibration (infrastructure, awaiting real-world data) ----


@dataclass
class SpeakerPauseStats:
    """Accumulated pause observations for one speaker.

    Collects gap durations from the kernel's silence policy as it classifies
    each chunk. The host feeds these observations; when enough data exists,
    `suggest_bands()` returns percentile-based thresholds that replace the
    fixed PauseBandConfig defaults.

    The minimum observation count (default 30) gates calibration so a single
    rambling turn doesn't distort the thresholds.
    """

    gaps_ms: list[float] = field(default_factory=list)
    speaker_id: str = "default"
    min_observations: int = 30

    def record_gap(self, gap_ms: float) -> None:
        """Feed one observed inter-chunk gap. Only non-negative values are
        accepted; the caller should filter out start-of-session gaps."""
        if gap_ms >= 0:
            self.gaps_ms.append(gap_ms)

    @property
    def ready(self) -> bool:
        """True when enough observations exist to suggest calibration."""
        return len(self.gaps_ms) >= self.min_observations

    def suggest_bands(self) -> PauseBandConfig | None:
        """Percentile-based band thresholds from observed gaps.

        Returns None when not enough observations exist (caller falls back to
        the fixed defaults). Otherwise:

          short_ms    ≈ 50th percentile (median) — half of gaps are micro,
                       half are at least short
          long_ms     ≈ 75th percentile — thinking-pause boundary
          extended_ms ≈ 95th percentile — turn-end boundary

        The percentiles are deliberately simple. A more sophisticated approach
        (clustering, per-band regression) belongs in a future iteration when
        real-world data justifies it.
        """
        if not self.ready:
            return None
        sorted_gaps = sorted(self.gaps_ms)
        n = len(sorted_gaps)
        return PauseBandConfig(
            short_ms=max(100.0, _percentile(sorted_gaps, n, 0.50)),
            long_ms=max(300.0, _percentile(sorted_gaps, n, 0.75)),
            extended_ms=max(1000.0, _percentile(sorted_gaps, n, 0.95)),
        )

    def reset(self) -> None:
        """Clear accumulated observations (e.g., speaker changed)."""
        self.gaps_ms.clear()


def _percentile(sorted_values: list[float], n: int, p: float) -> float:
    """Linear-interpolation percentile of already-sorted values."""
    if n == 0:
        return 0.0
    idx = p * (n - 1)
    lo = int(math.floor(idx))
    hi = int(math.ceil(idx))
    if lo == hi:
        return sorted_values[lo]
    frac = idx - lo
    return sorted_values[lo] * (1.0 - frac) + sorted_values[hi] * frac


def calibrate_from_stats(stats: SpeakerPauseStats) -> PauseBandConfig | None:
    """Convenience: suggest bands from a stats collector, or None if not ready."""
    return stats.suggest_bands()


def classify(gap_ms: float, config: PauseBandConfig | None = None) -> PauseBand:
    cfg = config or PauseBandConfig()
    if gap_ms < cfg.short_ms:
        return PauseBand.MICRO
    if gap_ms < cfg.long_ms:
        return PauseBand.SHORT
    if gap_ms < cfg.extended_ms:
        return PauseBand.LONG
    return PauseBand.EXTENDED


# Words that almost never end a finished spoken thought. A text-only proxy
# for trailing intonation: first-pass filter, not final truth.
_CONTINUATION_TAILS = {
    "and",
    "but",
    "or",
    "so",
    "because",
    "with",
    "to",
    "the",
    "a",
    "an",
    "of",
    "for",
    "in",
    "on",
    "at",
    "my",
    "your",
    "our",
    "their",
    "his",
    "her",
    "is",
    "are",
    "was",
    "were",
    "like",
    "then",
    "also",
    "plus",
    "if",
    "when",
    "that",
    "which",
    "who",
    "i",
    "we",
    "they",
}
_CONTINUATION_PHRASES = ("i mean", "such as", "you know", "kind of", "sort of")


@dataclass
class Completeness:
    """A heuristic verdict with its own confidence, ready for the
    UncertaintyRouter when the audio lane arrives."""

    complete: bool
    confidence: float
    reason: str


def assess_completeness(text: str) -> Completeness:
    stripped = text.strip()
    if not stripped:
        return Completeness(True, 1.0, "empty")
    lowered = stripped.lower()

    for phrase in _CONTINUATION_PHRASES:
        if lowered.endswith(phrase):
            return Completeness(False, 0.85, f"ends with '{phrase}'")
    if lowered.endswith(","):
        return Completeness(False, 0.9, "trailing comma")
    if lowered.endswith((".", "!", "?")):
        return Completeness(True, 0.9, "terminal punctuation")

    words = re.findall(r"[\w']+", lowered)
    if words and words[-1] in _CONTINUATION_TAILS:
        return Completeness(False, 0.85, f"ends with continuation word '{words[-1]}'")
    if words and re.fullmatch(r"\d+", words[-1]):
        return Completeness(False, 0.8, "dangling number, possible list item")

    # No cue either way: raw ASR text usually lacks punctuation, so a plain
    # word ending is weakly complete. Low confidence by design.
    return Completeness(True, 0.6, "no continuation cue")
