"""Shared data contracts for the streaming voice kernel.

The rule that governs every type here: providers propose, the deterministic
controller disposes. These are pure data shapes — none carries behavior that
mutates text, closes a turn, or emits a revision. Every type round-trips
through JSON-safe dicts (string-valued enums, no custom types) so the Swift
host, a sidecar process, or voxscribe-server can exchange the same shapes
without importing this package.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any

# ---- transcript input ----


@dataclass
class WordTiming:
    """Per-word timing from the ASR, when the provider supplies it."""

    word: str
    t_start_ms: float
    t_end_ms: float
    confidence: float = 1.0


@dataclass
class TranscriptChunk:
    """One ASR emission: the immutable raw record.

    Downstream stages never edit a chunk; clean output traces back to chunk
    ids through span provenance. `gap_ms_before` is the silence preceding
    this chunk — the input signal for pause-band classification (CP3).
    `is_final` is ASR-level finality (partial vs final hypothesis), distinct
    from the kernel's stable/provisional decision.
    """

    chunk_id: str
    session_id: str
    text: str
    t_start_ms: float = 0.0
    t_end_ms: float = 0.0
    confidence: float = 1.0
    is_final: bool = True
    gap_ms_before: float = 0.0
    words: list[WordTiming] = field(default_factory=list)
    # Content-addressed URI of the durable audio blob this chunk was
    # transcribed from (Sprint 1 blob store). Empty when durability is off.
    # Lets a judgment request carry the bounded audio window by reference.
    audio_uri: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> TranscriptChunk:
        d = dict(d)
        d["words"] = [WordTiming(**w) for w in d.get("words", [])]
        return cls(**d)


# ---- output spans ----


class SpanStatus(str, Enum):
    STABLE = "stable"  # frozen; the host may rely on it, never retracted
    PROVISIONAL = "provisional"  # may be revised by a later RevisionEvent


@dataclass
class TextSpan:
    """One piece of output text with provenance and uncertainty.

    Stable spans are immutable. Only provisional spans are ever the target
    of a RevisionEvent. `uncertainty` > 0 marks text the host UI may flag;
    it never blocks output.
    """

    span_id: str
    text: str
    status: SpanStatus
    source_chunk_ids: list[str] = field(default_factory=list)
    uncertainty: float = 0.0
    uncertainty_reason: str = ""
    turn_id: str = ""  # spans of one turn render as one paragraph

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["status"] = self.status.value
        return d

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> TextSpan:
        d = dict(d)
        d["status"] = SpanStatus(d["status"])
        return cls(**d)


# ---- lifecycle events ----


class SessionEventKind(str, Enum):
    SESSION_STARTED = "session_started"
    SESSION_ENDED = "session_ended"


@dataclass
class SessionEvent:
    kind: SessionEventKind
    session_id: str


class TurnEventKind(str, Enum):
    OPENED = "opened"
    HELD_POSSIBLE_CONTINUATION = "held_possible_continuation"
    SOFT_COMMITTED = "soft_committed"
    CLOSED = "closed"
    RESUMED = "resumed"


@dataclass
class TurnEvent:
    """A turn-boundary decision made by the kernel's turn-taking policy.
    Only the deterministic controller emits these; no model closes a turn."""

    kind: TurnEventKind
    turn_id: str
    chunk_ids: list[str] = field(default_factory=list)
    pause_band: str = ""  # named band that triggered the decision (CP3)


class RevisionReason(str, Enum):
    RESTART = "restart"
    BACKTRACK = "backtrack"
    REPETITION_COLLAPSE = "repetition_collapse"
    MODEL_CLEANUP = "model_cleanup"
    TRANSCRIPT_REPAIR = "transcript_repair"  # accepted audio-grounded repair hint


@dataclass
class RevisionEvent:
    """Provisional text changed. The host applies this to retract or replace
    injected provisional text; a stable span is never the target."""

    span_id: str
    old_text: str
    new_text: str
    reason: RevisionReason
    chunk_ids: list[str] = field(default_factory=list)


class RepetitionKind(str, Enum):
    STUTTER = "stutter"  # adjacent restart noise: collapse it
    EMPHASIS = "emphasis"  # deliberate ("very very"): preserve it
    EXACT = "exact"  # same phrase said again later
    NEAR = "near"  # same idea revisited later (idea-level, CP6)


@dataclass
class RepetitionEvent:
    """A repetition was recognized. `collapsed` records what the controller
    did about it — detection never implies deletion."""

    kind: RepetitionKind
    phrase: str
    count: int = 2
    collapsed: bool = False
    chunk_ids: list[str] = field(default_factory=list)


class TopicEventKind(str, Enum):
    SHIFT = "shift"
    RESUME = "resume"


@dataclass
class TopicEvent:
    """The conversation moved to a different topic, or returned to a
    suspended one. Resume restores that topic's vocabulary context."""

    kind: TopicEventKind
    topic_id: str
    keywords: list[str] = field(default_factory=list)
    resumed_from_turn_id: str = ""


@dataclass
class VocabularyBiasTerm:
    """A term the ASR / prompt layer should favor right now."""

    term: str
    weight: float = 1.0
    source: str = "dictionary"  # dictionary | topic | learned
    ttl_turns: int = 0  # 0 = no expiry


# ---- safety signals (metadata-only, never mutates output) ----


class SafetyCategory(str, Enum):
    """Keyword/pattern categories for safety visibility in the host dashboard.
    These are metadata events only — no category ever mutates, redacts, or
    withholds output text."""

    SELF_HARM = "self_harm"
    VIOLENCE = "violence"
    HATE = "hate"
    HARASSMENT = "harassment"
    SEXUAL_CONTENT = "sexual_content"
    CHILD_SAFETY = "child_safety"
    PERSONAL_DATA = "personal_data"
    WEAPONS = "weapons"
    ILLICIT_SUBSTANCES = "illicit_substances"
    MEDICAL_CLAIMS = "medical_claims"


@dataclass
class SafetySignal:
    """A read-only metadata event: a keyword or pattern matched in raw chunk
    text. Carries category + severity + chunk_id + character offsets so the
    host can highlight or log without the kernel ever mutating the output."""

    category: SafetyCategory
    severity: float
    chunk_id: str
    text: str
    start_char: int
    end_char: int
    evidence: str = ""

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["category"] = self.category.value
        return d

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> SafetySignal:
        d = dict(d)
        d["category"] = SafetyCategory(d["category"])
        return cls(**d)


# ---- policy / response-gate events (invariants 5, 5a, 5b) ------------------


class PolicyEventKind(str, Enum):
    APPLIED = "policy_version_applied"
    RESPONSE_GATED = "response_gated"
    ESCALATION_EMITTED = "escalation_emitted"


@dataclass
class PolicyEvent:
    """Lifecycle events from the safety subsystem: policy version stamped at
    session start, every response-gate decision, and every escalation handoff.
    Kernel-emitted only; escalation delivery lives in the product layer."""

    kind: PolicyEventKind
    session_id: str = ""
    policy_version: str = ""
    posture: str = ""  # allowlist | denylist (APPLIED)
    mode: str = ""  # seniorcare | classroom | dictation | ideascribe (APPLIED)
    outcome: str = ""  # allow | deny | fallback (RESPONSE_GATED)
    candidate_hash: str = ""  # RESPONSE_GATED
    surface: str = ""  # session_report | cursor_insert | tts (RESPONSE_GATED)
    rule: str = ""  # matched rule id or reason string (RESPONSE_GATED)
    category: str = ""  # safety category (ESCALATION_EMITTED)
    severity: float = 0.0  # ESCALATION_EMITTED
    target: str = ""  # caregiver | teacher | guardian (ESCALATION_EMITTED)


class TTSEventKind(str, Enum):
    REQUESTED = "tts_requested"
    COMPLETED = "tts_completed"
    INTERRUPTED = "interruption"


@dataclass
class TTSEvent:
    """Lifecycle events from the response lane (Lane 7). One REQUESTED per
    gated spoken candidate, one COMPLETED when playback ends (status ok,
    failed, or interrupted), one INTERRUPTED the instant barge-in stops
    playback. Payloads carry hashes and ids, never spoken text or audio."""

    kind: TTSEventKind
    session_id: str = ""
    voice_id: str = ""
    candidate_hash: str = ""  # sha256[:16] of the pre-gate candidate
    policy_version: str = ""
    outcome: str = ""  # gate outcome: allow | deny | fallback
    status: str = ""  # COMPLETED: ok | failed | interrupted
    duration_ms: float = 0.0  # COMPLETED: synthesis + playback time
    reason: str = ""  # INTERRUPTED: barge_in; COMPLETED failed: error class


def event_to_dict(event: Any) -> dict[str, Any]:
    """Tag-and-serialize any lifecycle event for transport."""
    if isinstance(event, TurnEvent):
        d = asdict(event)
        d["kind"] = event.kind.value
        d["event_type"] = "turn"
    elif isinstance(event, RevisionEvent):
        d = asdict(event)
        d["reason"] = event.reason.value
        d["event_type"] = "revision"
    elif isinstance(event, SessionEvent):
        d = asdict(event)
        d["kind"] = event.kind.value
        d["event_type"] = "session"
    elif isinstance(event, RepetitionEvent):
        d = asdict(event)
        d["kind"] = event.kind.value
        d["event_type"] = "repetition"
    elif isinstance(event, TopicEvent):
        d = asdict(event)
        d["kind"] = event.kind.value
        d["event_type"] = "topic"
    elif isinstance(event, SafetySignal):
        d = asdict(event)
        d["category"] = event.category.value
        d["event_type"] = "safety_signal"
    elif isinstance(event, PolicyEvent):
        d = asdict(event)
        d["kind"] = event.kind.value
        d["event_type"] = event.kind.value
    elif isinstance(event, TTSEvent):
        d = asdict(event)
        d["kind"] = event.kind.value
        d["event_type"] = event.kind.value
    else:
        raise TypeError(f"not a lifecycle event: {type(event).__name__}")
    return d


def event_from_dict(d: dict[str, Any]) -> Any:
    d = dict(d)
    tag = d.pop("event_type")
    if tag == "turn":
        d["kind"] = TurnEventKind(d["kind"])
        return TurnEvent(**d)
    if tag == "revision":
        d["reason"] = RevisionReason(d["reason"])
        return RevisionEvent(**d)
    if tag == "session":
        d["kind"] = SessionEventKind(d["kind"])
        return SessionEvent(**d)
    if tag == "repetition":
        d["kind"] = RepetitionKind(d["kind"])
        return RepetitionEvent(**d)
    if tag == "topic":
        d["kind"] = TopicEventKind(d["kind"])
        return TopicEvent(**d)
    if tag == "safety_signal":
        d["category"] = SafetyCategory(d["category"])
        return SafetySignal(**d)
    if tag in {kind.value for kind in PolicyEventKind}:
        d["kind"] = PolicyEventKind(tag)
        return PolicyEvent(**d)
    if tag in {kind.value for kind in TTSEventKind}:
        d["kind"] = TTSEventKind(tag)
        return TTSEvent(**d)
    raise ValueError(f"unknown event_type: {tag}")


# ---- audio-understanding lane ----


class JudgmentKind(str, Enum):
    THOUGHT_COMPLETION = "thought_completion"
    CORRECTION_AMBIGUITY = "correction_ambiguity"
    REPETITION_INTENT = "repetition_intent"
    TRANSCRIPT_REPAIR = "transcript_repair"
    PUNCTUATION = "punctuation"
    EMPHASIS = "emphasis"


@dataclass
class AudioJudgmentRequest:
    """A narrow question the kernel asks the audio-understanding lane when a
    heuristic's own confidence is low. It carries the heuristic's answer so
    the UncertaintyRouter can always fall back to it deterministically.

    `audio_uri` references the bounded audio window (a content-addressed
    blob from the durable store), never the whole session. `questions`
    names only the hints the pending decision needs, so the provider is
    never asked open-ended. `session_id` keys the router's per-session
    budget and hysteresis state."""

    request_id: str
    kind: JudgmentKind
    chunk_ids: list[str]
    text_window: str
    heuristic_answer: str
    heuristic_confidence: float
    budget_ms: float = 250.0
    session_id: str = ""
    audio_uri: str = ""
    questions: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["kind"] = self.kind.value
        return d

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> AudioJudgmentRequest:
        d = dict(d)
        d["kind"] = JudgmentKind(d["kind"])
        return cls(**d)


# Hint-bundle fields present on AudioJudgment but not yet read by the
# controller. They widen incrementally (staged trust): a hint moves off
# this record only after the eval harness validates its per-hint
# precision. Recorded here per the Sprint 4 incremental-widening rule.
STUBBED_JUDGMENT_HINTS = (
    "continuation_hint",
    "correction_hint",
    "repetition_hint",
    "emphasis_hint",
    "uncertainty_hint",
    "topic_resume_hint",
    "punctuation_hint",
)


@dataclass
class AudioJudgment:
    """A structured hint, nothing more. The deterministic controller decides
    whether to act on it; a judgment never mutates output text directly.

    Implemented hints (read by the controller): `completion_hint`,
    `should_hold_provisional`, `transcript_repair_candidates`. The fields
    named in STUBBED_JUDGMENT_HINTS are carried but not acted on yet."""

    request_id: str
    kind: JudgmentKind
    answer: str
    confidence: float
    evidence: str = ""  # the provider's stated audio-level grounds
    source: str = "deterministic"  # "deterministic" or the provider's name
    # ---- hint bundle (implemented) ----
    completion_hint: str = ""  # finished | trailing | thinking
    should_hold_provisional: bool = False  # safest hint: only delays promotion
    # [(span_text, candidate_text, confidence)] tuples serialize as lists
    transcript_repair_candidates: list = field(default_factory=list)
    # ---- hint bundle (stubbed, see STUBBED_JUDGMENT_HINTS) ----
    continuation_hint: str = ""
    correction_hint: str = ""
    repetition_hint: str = ""  # stutter | emphasis | thinking_repeat | idea_restatement
    emphasis_hint: str = ""
    uncertainty_hint: str = ""
    topic_resume_hint: str = ""
    punctuation_hint: str = ""

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["kind"] = self.kind.value
        return d

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> AudioJudgment:
        d = dict(d)
        d["kind"] = JudgmentKind(d["kind"])
        return cls(**d)


# ---- streaming output ----


# ---- finalize-time session report (CP7) ----


@dataclass
class SessionReport:
    """Finalize-time projection over a completed session.

    Pure data: built by session_report.build_session_report() from collected
    chunks, events, and the cleaned transcript. No transport or CLI state.
    """

    session_id: str
    topic_name: str
    description: str
    speaker_key_notes: list[str]
    key_themes: list[str]
    keywords: list[str]
    takeaways: list[str]
    original_transcript: str
    chunk_refs: list[str]
    metadata: dict = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class StreamingResult:
    """What one StreamProcessor.feed() call returns: cumulative stable text,
    the current provisional tail, this tick's lifecycle events, and
    provenance via spans. Supersets the utterance-mode Result so a one-chunk
    stream expresses today's PostProcessor behavior exactly."""

    session_id: str
    stable_text: str = ""
    provisional_text: str = ""
    spans: list[TextSpan] = field(default_factory=list)
    events: list[Any] = field(default_factory=list)
    used_snippet: bool = False
    used_model: bool = False
    timings_ms: dict[str, float] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "session_id": self.session_id,
            "stable_text": self.stable_text,
            "provisional_text": self.provisional_text,
            "spans": [s.to_dict() for s in self.spans],
            "events": [event_to_dict(e) for e in self.events],
            "used_snippet": self.used_snippet,
            "used_model": self.used_model,
            "timings_ms": dict(self.timings_ms),
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> StreamingResult:
        return cls(
            session_id=d["session_id"],
            stable_text=d.get("stable_text", ""),
            provisional_text=d.get("provisional_text", ""),
            spans=[TextSpan.from_dict(s) for s in d.get("spans", [])],
            events=[event_from_dict(e) for e in d.get("events", [])],
            used_snippet=d.get("used_snippet", False),
            used_model=d.get("used_model", False),
            timings_ms=dict(d.get("timings_ms", {})),
        )
