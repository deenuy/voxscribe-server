"""SeniorCare product-layer features.

All classes here are product-layer against the event contract. No kernel
module is imported or modified; all speaking goes through the Sprint 4
ResponseLoop so every utterance passes the mandatory gate.

CheckInScheduler    -- timed wellbeing check-ins.
BackchannelController -- scripted conversational presence during thinking pauses.
PlaybackManager     -- audio-content playback with voice control.
"""

from __future__ import annotations

from dataclasses import dataclass, field

# Surface constants for the three new Sprint 6 product-layer surfaces.
SURFACE_CHECKIN = "wellbeing_checkin"
SURFACE_BACKCHANNEL = "backchannel"
SURFACE_PLAYBACK = "audio_playback"

# Minimum silence before a backchannel may fire (ms). Prevents interrupting
# the first syllable of a natural intra-sentence pause.
_BACKCHANNEL_MIN_SILENCE_MS = 5_000.0


# ---- wellbeing check-in scheduler -------------------------------------------


@dataclass
class CheckInScheduler:
    """Triggers scheduled wellbeing check-ins on a configurable interval.

    The scheduler is driven by the session driver's main loop: call tick()
    with the current session elapsed time on each iteration. When the
    interval has passed since the last check-in, speak() is called on the
    ResponseLoop with the next scripted line on the wellbeing_checkin surface.

    Every line passes the Sprint 3 mandatory gate before synthesis; a denied
    or fail-closed gate plays the pack's scripted fallback, never the candidate.
    Scheduling is the product layer's responsibility: the kernel does not decide
    when to check in."""

    loop: object  # ResponseLoop
    interval_ms: float
    scripted_lines: tuple[str, ...]
    _started: bool = field(default=False, repr=False)
    _last_checkin_ms: float = field(default=0.0, repr=False)
    _count: int = field(default=0, repr=False)

    def tick(self, session_elapsed_ms: float) -> object | None:
        """Fire a check-in if the interval has elapsed. Returns the SpeakResult
        or None when no check-in was triggered this tick.

        The first tick anchors the baseline time; subsequent ticks measure
        elapsed time against that anchor. This prevents double-anchoring when
        session_elapsed_ms=0.0 on the first call."""
        if not self._started:
            self._started = True
            self._last_checkin_ms = session_elapsed_ms
            return None
        if session_elapsed_ms - self._last_checkin_ms < self.interval_ms:
            return None
        line = self.scripted_lines[self._count % len(self.scripted_lines)]
        self._last_checkin_ms = session_elapsed_ms
        self._count += 1
        return self.loop.speak(line, surface=SURFACE_CHECKIN)


# ---- backchannel controller --------------------------------------------------


@dataclass
class BackchannelController:
    """Scripted conversational presence during long thinking pauses.

    Policy invariants:
      - Disabled by default in all modes except seniorcare. Pass enabled=True
        only when the mode's policy pack lists `backchannel` in allowed_surfaces.
      - Fires ONLY when an open thinking pause exists (is_open_turn=True) and
        no speech is currently in progress (speech_active=False). Backchannels
        never interrupt active speech.
      - Rate-limited: min_interval_ms controls the minimum gap between any two
        consecutive backchannels in the same session.
      - No model involved. Lines rotate round-robin from scripted_lines, which
        come from the policy pack's backchannel_lines field.
      - Every utterance passes the gated TTS path with surface=backchannel.

    The caller (streaming driver or product-layer orchestrator) must gate on
    is_open_turn and speech_active from its own turn-tracking state. The
    BackchannelController does not read kernel internal state."""

    loop: object  # ResponseLoop
    scripted_lines: tuple[str, ...]
    min_interval_ms: float = 30_000.0
    enabled: bool = True
    _last_ms: float = field(default=float("-inf"), repr=False)
    _count: int = field(default=0, repr=False)

    def maybe_speak(
        self,
        *,
        silence_ms: float,
        is_open_turn: bool,
        speech_active: bool,
        session_elapsed_ms: float,
    ) -> object | None:
        """Consider firing a backchannel. Returns SpeakResult or None.

        Returns None (no backchannel) when:
          - disabled (enabled=False)
          - speech is active (speech_active=True)
          - no open thinking turn (is_open_turn=False)
          - the silence band is too short (< _BACKCHANNEL_MIN_SILENCE_MS)
          - rate limit not yet cleared
          - no scripted lines configured"""
        if not self.enabled or not self.scripted_lines:
            return None
        if speech_active:
            return None
        if not is_open_turn:
            return None
        if silence_ms < _BACKCHANNEL_MIN_SILENCE_MS:
            return None
        if session_elapsed_ms - self._last_ms < self.min_interval_ms:
            return None
        line = self.scripted_lines[self._count % len(self.scripted_lines)]
        self._count += 1
        self._last_ms = session_elapsed_ms
        return self.loop.speak(line, surface=SURFACE_BACKCHANNEL)


# ---- audio-content playback manager -----------------------------------------


@dataclass
class PlaybackManager:
    """Audio-content (audiobook) playback with voice control.

    The manager holds a content queue and responds to voice commands extracted
    from the live transcript. The listening path continues uninterrupted while
    playback is active: the ResponseLoop's EchoGuard handles self-hearing and
    barge-in at the audio level.

    Voice commands recognized: play/start, pause/stop, resume/continue/go on.
    These are matched case-insensitively against each finalized turn's text.

    All content goes through the gated TTS path with surface=audio_playback;
    a denied segment plays the policy pack fallback. The caller must ensure
    audio_playback is listed in the mode's allowed_surfaces."""

    loop: object  # ResponseLoop
    content: list[str]
    _position: int = field(default=0, repr=False)
    _paused: bool = field(default=False, repr=False)
    _active: bool = field(default=False, repr=False)

    # --- playback state ---------------------------------------------------------

    @property
    def is_active(self) -> bool:
        return self._active and not self._paused

    def play(self) -> object | None:
        """Start or advance playback. Returns SpeakResult or None when
        content is exhausted."""
        if not self.content:
            return None
        self._paused = False
        self._active = True
        line = self.content[self._position % len(self.content)]
        self._position += 1
        return self.loop.speak(line, surface=SURFACE_PLAYBACK)

    def pause(self) -> None:
        """Pause playback. Capture continues; no TTS is spoken."""
        self._paused = True
        self._active = False

    def resume(self) -> object | None:
        """Resume from a paused position. Speaks the next content line."""
        if not self.content:
            return None
        self._paused = False
        self._active = True
        line = self.content[self._position % len(self.content)]
        self._position += 1
        return self.loop.speak(line, surface=SURFACE_PLAYBACK)

    def on_voice_command(self, transcript_text: str) -> object:
        """Detect and handle a voice command from a finalized transcript turn.

        Returns the SpeakResult when playback action occurred, the string
        "paused" on pause, or None when the text is not a recognized command."""
        cmd = (transcript_text or "").lower().strip()
        if any(w in cmd for w in ("play", "start")):
            return self.play()
        if any(w in cmd for w in ("pause", "stop")):
            self.pause()
            return "paused"
        if any(w in cmd for w in ("resume", "continue", "go on")):
            return self.resume()
        return None
