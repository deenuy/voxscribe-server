"""Lane 7 response loop: speak gate-approved text, yield instantly to barge-in.

The loop owns three things and nothing else:

  ResponseLoop.speak(candidate)
      Runs every spoken candidate through the Sprint 3 response gate on the
      `tts` surface (ledger row, response_gated event, retention row), then
      synthesizes and plays the gate-approved text. A denied or fail-closed
      candidate is never synthesized; the policy pack's scripted fallback
      line is spoken instead. Provider failure is contained: the event
      stream records it and the session continues unchanged.

  EchoGuard
      Acoustic self-hearing control (Phase 0 form: capture gating during
      playback with fast release on barge-in, behind the
      tts.echo_suppression_enabled config flag). While playback is active,
      captured segments below the barge-in energy threshold are classified
      as the device hearing itself and are suppressed BEFORE the blob store
      and ASR, so the device never transcribes its own speech and never
      retains its own audio as user audio. A segment at or above the
      threshold is user speech: the guard stops playback instantly (fast
      release) and the segment proceeds to capture, so barge-in speech is
      transcribed, not lost. Reference-signal AEC is the future refinement
      behind the same flag.

  Barge-in (invariant 8: speaking never overrides listening)
      barge_in() stops the sink immediately, emits an `interruption` event
      and a `tts_completed` with status interrupted, and releases the
      capture gate. The response lane cannot hold the turn or delay capture.

What the loop never does: decide WHAT to say (product-layer dialogue
policy), speak ungated text, or block the listening path. Logging carries
ids and hashes only, never spoken text or audio.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Protocol

from .logging_config import get_logger, log_event
from .models import TTSEvent, TTSEventKind, event_to_dict
from .policy import PolicyGate, deliver_gated_decision

log = get_logger("voxscribe.response_loop")


TTS_SURFACE = "tts"


# ---- playback sink -----------------------------------------------------------


class AudioSink(Protocol):
    """Playback device seam. play() starts playback and returns without
    blocking the listening path; stop() halts immediately."""

    def play(self, frames: list[float], sample_rate: int) -> None: ...

    def stop(self) -> None: ...

    def is_playing(self) -> bool: ...


class FakeAudioSink:
    """In-memory sink for tests: records plays and stops, playback stays
    active until stop() or finish() is called explicitly."""

    def __init__(self) -> None:
        self.played: list[tuple[int, int]] = []  # (frame_count, sample_rate)
        self.stop_calls = 0
        self._playing = False

    def play(self, frames: list[float], sample_rate: int) -> None:
        self.played.append((len(frames), sample_rate))
        self._playing = True

    def stop(self) -> None:
        self.stop_calls += 1
        self._playing = False

    def finish(self) -> None:
        """Test helper: playback ran to its natural end."""
        self._playing = False

    def is_playing(self) -> bool:
        return self._playing


# ---- echo guard (self-hearing control) ---------------------------------------


@dataclass
class EchoGuard:
    """Capture gating during TTS playback with fast release on barge-in.

    classify(samples) verdicts:
      pass       no playback active; the segment is normal user speech
      suppress   playback active and energy below the barge-in threshold:
                 the device hearing itself; drop before blob store and ASR
      barge_in   playback active and energy at/above threshold: user is
                 talking over the device; playback has been stopped via
                 on_barge_in before this returns, and the segment proceeds

    Disabled (enabled=False) means every segment passes and playback is
    never gated; the flag exists so deployments with hardware AEC can turn
    the software gate off."""

    enabled: bool = True
    barge_in_energy_threshold: float = 0.05
    on_barge_in: object = None  # Callable[[], None] set by the ResponseLoop
    _playing: bool = field(default=False, repr=False)

    def playback_started(self) -> None:
        self._playing = True

    def playback_stopped(self) -> None:
        self._playing = False

    def is_gating(self) -> bool:
        return self.enabled and self._playing

    @staticmethod
    def _rms(samples) -> float:
        try:
            n = len(samples)
            if n == 0:
                return 0.0
            return (sum(float(s) * float(s) for s in samples) / n) ** 0.5
        except TypeError:
            return 0.0

    def classify(self, samples) -> str:
        if not self.is_gating():
            return "pass"
        if self._rms(samples) >= self.barge_in_energy_threshold:
            # Fast release: stop playback before the segment is processed
            # so capture wins the very frame the user starts talking.
            self._playing = False
            if self.on_barge_in is not None:
                try:
                    self.on_barge_in()
                except Exception:  # noqa: BLE001, capture must never fail
                    pass
            return "barge_in"
        return "suppress"


# ---- response loop -----------------------------------------------------------


@dataclass
class SpeakResult:
    """One speak() call's outcome, for the caller's own bookkeeping."""

    ok: bool
    outcome: str  # gate outcome: allow | deny | fallback
    spoken_hash: str  # candidate_hash of the pre-gate candidate
    status: str  # ok | failed | interrupted | empty
    error: str = ""


class ResponseLoop:
    """Speaks one gated candidate at a time through a TTSProvider + AudioSink.

    Composition: the product layer decides what to say and calls speak()
    during user silence (synthesis overlaps silence by construction: the
    caller invokes it when no capture is in flight). The loop's EchoGuard
    is handed to the streaming driver so capture gating and barge-in are
    wired to the same playback state."""

    def __init__(
        self,
        tts,
        sink: AudioSink,
        *,
        gate: PolicyGate | None = None,
        store: object | None = None,
        session_id: str = "",
        echo_guard: EchoGuard | None = None,
    ):
        self.tts = tts
        self.sink = sink
        self.gate = gate
        self.store = store
        self.session_id = session_id
        self.echo_guard = echo_guard or EchoGuard()
        self.echo_guard.on_barge_in = self.barge_in
        self._active_hash = ""
        self._active_outcome = ""
        self._t_speak_start = 0.0

    # ---- event emission ----

    def _emit(self, kind: TTSEventKind, **fields) -> None:
        """Append one TTS lifecycle event to the events table. Best-effort:
        a store failure never blocks or corrupts the speaking path."""
        event = TTSEvent(
            kind=kind,
            session_id=self.session_id,
            voice_id=str(getattr(self.tts, "voice_id", "") or ""),
            **fields,
        )
        if self.store is not None:
            try:
                seq = self.store.next_event_seq(self.session_id)
                self.store.append_event(self.session_id, seq, event_to_dict(event))
            except Exception:  # noqa: BLE001
                pass
        log_event(
            log,
            kind.value,
            session_id=self.session_id,
            voice_id=str(getattr(self.tts, "voice_id", "") or ""),
            candidate_hash=fields.get("candidate_hash", ""),
            outcome=fields.get("outcome", ""),
            status=fields.get("status", ""),
        )

    # ---- speaking ----

    def speak(self, candidate: str, *, surface: str = TTS_SURFACE) -> SpeakResult:
        """Gate, synthesize, and start playback of one candidate.

        The gate decision (with its ledger, retention, and response_gated
        records) happens before any synthesis; the synthesized text is the
        gate's delivered_text, so a denied candidate is never synthesized
        and the scripted fallback plays instead.

        `surface` overrides the default TTS surface tag so product-layer
        callers (wellbeing_checkin, backchannel, audio_playback) stamp the
        correct surface on the audit row without duplicating gate logic."""
        decision = deliver_gated_decision(
            self.gate,
            candidate,
            surface=surface,
            store=self.store,
            session_id=self.session_id,
        )
        self._active_hash = decision.candidate_hash
        self._active_outcome = decision.outcome
        self._emit(
            TTSEventKind.REQUESTED,
            candidate_hash=decision.candidate_hash,
            policy_version=decision.policy_version,
            outcome=decision.outcome,
        )
        text = decision.delivered_text
        if not text.strip():
            self._emit(
                TTSEventKind.COMPLETED,
                candidate_hash=decision.candidate_hash,
                status="empty",
            )
            return SpeakResult(
                ok=False,
                outcome=decision.outcome,
                spoken_hash=decision.candidate_hash,
                status="empty",
            )

        self._t_speak_start = time.perf_counter()
        try:
            audio = self.tts.synthesize(text)
        except Exception as exc:  # noqa: BLE001, provider failure is contained
            self._emit(
                TTSEventKind.COMPLETED,
                candidate_hash=decision.candidate_hash,
                status="failed",
                reason=type(exc).__name__,
                duration_ms=(time.perf_counter() - self._t_speak_start) * 1000.0,
            )
            return SpeakResult(
                ok=False,
                outcome=decision.outcome,
                spoken_hash=decision.candidate_hash,
                status="failed",
                error=str(exc)[:200],
            )

        self.echo_guard.playback_started()
        try:
            self.sink.play(audio.frames, audio.sample_rate)
        except Exception as exc:  # noqa: BLE001, sink failure also contained
            self.echo_guard.playback_stopped()
            self._emit(
                TTSEventKind.COMPLETED,
                candidate_hash=decision.candidate_hash,
                status="failed",
                reason=type(exc).__name__,
                duration_ms=(time.perf_counter() - self._t_speak_start) * 1000.0,
            )
            return SpeakResult(
                ok=False,
                outcome=decision.outcome,
                spoken_hash=decision.candidate_hash,
                status="failed",
                error=str(exc)[:200],
            )
        return SpeakResult(
            ok=True,
            outcome=decision.outcome,
            spoken_hash=decision.candidate_hash,
            status="ok",
        )

    def barge_in(self) -> None:
        """Stop playback immediately and yield to capture (invariant 8)."""
        try:
            self.sink.stop()
        except Exception:  # noqa: BLE001, yielding must never fail
            pass
        self.echo_guard.playback_stopped()
        self._emit(
            TTSEventKind.INTERRUPTED,
            candidate_hash=self._active_hash,
            reason="barge_in",
        )
        self._emit(
            TTSEventKind.COMPLETED,
            candidate_hash=self._active_hash,
            status="interrupted",
            duration_ms=(time.perf_counter() - self._t_speak_start) * 1000.0,
        )

    def playback_finished(self) -> None:
        """The sink reports playback ran to its natural end."""
        self.echo_guard.playback_stopped()
        self._emit(
            TTSEventKind.COMPLETED,
            candidate_hash=self._active_hash,
            status="ok",
            duration_ms=(time.perf_counter() - self._t_speak_start) * 1000.0,
        )
