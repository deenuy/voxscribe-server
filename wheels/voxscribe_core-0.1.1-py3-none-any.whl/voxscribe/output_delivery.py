"""Insert the finalized session text at the user's active cursor location.

This is an output-delivery feature, deliberately isolated from VoxScribe's
intelligence layers. The kernel, post-processor, dictionary, and report
modules do not know this exists. The CLI calls into it AFTER the existing
file export has succeeded — failure here never fails listen-stop.

Design:

  TextInserter Protocol
      One method: insert_text(text) -> InsertResult.

  ClipboardPasteInserter
      Shared high-level flow: stash old clipboard (optional) -> write new
      clipboard -> send the platform paste keystroke -> restore. The
      clipboard ops and the keystroke are delegated to a `ClipboardBackend`
      so platform adapters only describe the *how*, and tests inject a
      fake backend with zero real OS automation.

  MacOSTextInserter / WindowsTextInserter / LinuxTextInserter
      Each constructs a ClipboardPasteInserter with its platform backend.
      Built lazily so that importing this module on the wrong platform
      does not blow up.

  Auto selection
      select_inserter(config) maps sys.platform to the right adapter, or
      returns a NoopTextInserter with an unsupported message.

The platform backends use subprocess + the OS's built-in clipboard tools
(pbcopy, clip.exe / PowerShell, xclip/xsel/wl-copy). No new pip
dependencies are introduced.
"""

from __future__ import annotations

import logging
import os
import shutil
import subprocess
import sys
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Protocol

from .logging_config import get_logger, log_event
from .policy import PolicyGate, deliver_gated

logger = get_logger("voxscribe.output_delivery")


CURSOR_INSERT_SURFACE = "cursor_insert"


def deliver_cursor_insert_text(
    gate: PolicyGate | None,
    payload: str,
    *,
    store: object | None,
    session_id: str,
    at: float | None = None,
) -> str:
    """Run a cursor-insertion payload through the response gate. Callers
    hand the returned text to the inserter as-is; deny / fail-closed
    outcomes deliver the pack's scripted fallback rather than the payload.
    Ledger + retention + response_gated event are recorded here."""
    return deliver_gated(
        gate,
        payload,
        surface=CURSOR_INSERT_SURFACE,
        store=store,
        session_id=session_id,
        at=at,
    )


# ---- config ----------------------------------------------------------------


def _env_bool(name: str, default: bool) -> bool:
    raw = os.environ.get(name)
    if raw is None or raw == "":
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _env_str(name: str, default: str, choices: set[str] | None = None) -> str:
    raw = (os.environ.get(name) or "").strip().lower()
    if not raw:
        return default
    if choices is not None and raw not in choices:
        return default
    return raw


def _env_int(name: str, default: int) -> int:
    raw = os.environ.get(name)
    if not raw:
        return default
    try:
        return int(raw.strip())
    except ValueError:
        return default


@dataclass
class InsertConfig:
    """Env-driven config for cursor insertion.

    Defaults preserve existing behavior: insertion is OFF unless the user
    explicitly opts in via VOXSCRIBE_INSERT_AT_CURSOR=true.

    target_mode shapes WHERE the paste lands:
      - "active"             — paste immediately into whatever is focused. Only
                               correct when the stop trigger does not steal
                               focus (global hotkey, menubar button). With CLI
                               `make listen-stop`, the focused app is Terminal,
                               so this mode will rarely land where the user
                               wanted. A warning is printed in that case.
      - "refocus_delay"      — print a countdown, sleep focus_delay_ms, then
                               paste into whatever is focused after the delay.
                               Designed for CLI-driven stop: the user has time
                               to click back into Notion / Notes / Slack / VSCode.
      - "last_focused_app"   — scaffold only. Cross-platform focused-window
                               restoration is its own project; this returns a
                               clear unsupported message for now.
    """

    enabled: bool = False
    method: str = "auto"  # auto | clipboard_paste | none
    fmt: str = "markdown"  # markdown | plain_text
    restore_clipboard: bool = True
    timeout_ms: int = 3000
    target_mode: str = "active"  # active | refocus_delay | last_focused_app
    focus_delay_ms: int = 2000

    @classmethod
    def from_env(cls) -> InsertConfig:
        return cls(
            enabled=_env_bool("VOXSCRIBE_INSERT_AT_CURSOR", False),
            method=_env_str(
                "VOXSCRIBE_INSERT_METHOD",
                "auto",
                {"auto", "clipboard_paste", "none"},
            ),
            fmt=_env_str(
                "VOXSCRIBE_INSERT_FORMAT",
                "markdown",
                {"markdown", "plain_text"},
            ),
            restore_clipboard=_env_bool("VOXSCRIBE_RESTORE_CLIPBOARD", True),
            timeout_ms=_env_int("VOXSCRIBE_INSERT_TIMEOUT_MS", 3000),
            target_mode=_env_str(
                "VOXSCRIBE_INSERT_TARGET_MODE",
                "active",
                {"active", "refocus_delay", "last_focused_app"},
            ),
            focus_delay_ms=_env_int("VOXSCRIBE_INSERT_FOCUS_DELAY_MS", 2000),
        )

    @classmethod
    def from_config(cls, cfg: object) -> InsertConfig:
        """Build from a VoxScribeConfig (duck-typed to avoid circular import)."""
        od = getattr(cfg, "output_delivery", None)
        if od is None:
            return cls.from_env()
        return cls(
            enabled=bool(getattr(od, "insert_at_cursor", False)),
            method=str(getattr(od, "insert_method", "auto")),
            fmt=str(getattr(od, "insert_format", "markdown")),
            restore_clipboard=bool(getattr(od, "restore_clipboard", True)),
            timeout_ms=int(getattr(od, "insert_timeout_ms", 3000)),
            target_mode=str(getattr(od, "target_mode", "active")),
            focus_delay_ms=int(getattr(od, "focus_delay_ms", 2000)),
        )


# ---- result + protocol -----------------------------------------------------


@dataclass
class InsertResult:
    success: bool
    platform: str
    method: str
    message: str | None = None
    error: str | None = None


class TextInserter(Protocol):
    def insert_text(self, text: str) -> InsertResult: ...


# ---- noop / fake -----------------------------------------------------------


@dataclass
class NoopTextInserter:
    """Returned when insertion is disabled or unsupported. Records nothing,
    does nothing, never raises. The `message` flows through so the CLI can
    show a single uniform line regardless of why insertion was skipped."""

    platform: str = ""
    reason: str = "disabled"

    def insert_text(self, text: str) -> InsertResult:
        return InsertResult(
            success=False,
            platform=self.platform or sys.platform,
            method="noop",
            message=self.reason,
        )


@dataclass
class FakeTextInserter:
    """Test double. Records exact inserted text and lets the test decide
    whether to fail. Never touches the OS."""

    platform: str = "fake"
    succeed: bool = True
    error_message: str = "fake failure"
    inserted: list[str] = field(default_factory=list)

    def insert_text(self, text: str) -> InsertResult:
        self.inserted.append(text)
        if not self.succeed:
            return InsertResult(
                success=False,
                platform=self.platform,
                method="fake",
                error=self.error_message,
            )
        return InsertResult(
            success=True,
            platform=self.platform,
            method="fake",
            message="inserted (fake)",
        )


# ---- clipboard backend -----------------------------------------------------


class ClipboardBackend(Protocol):
    """OS-level clipboard + paste keystroke. One Protocol so platform
    adapters share the same insertion flow and tests inject a fake."""

    name: str

    def get_clipboard(self) -> str | None: ...
    def set_clipboard(self, text: str) -> None: ...
    def send_paste(self) -> None: ...


class FakeClipboardBackend:
    """In-memory clipboard for tests. Records every call so a test can
    assert paste happened and clipboard was restored."""

    name = "fake"

    def __init__(self, initial: str = "", *, fail_paste: bool = False):
        self.value: str | None = initial
        self.history: list[str] = [initial]
        self.paste_calls = 0
        self.fail_paste = fail_paste

    def get_clipboard(self) -> str | None:
        return self.value

    def set_clipboard(self, text: str) -> None:
        self.value = text
        self.history.append(text)

    def send_paste(self) -> None:
        self.paste_calls += 1
        if self.fail_paste:
            raise RuntimeError("fake paste failed")


# ---- shared clipboard-paste inserter ---------------------------------------


@dataclass
class ClipboardPasteInserter:
    """Stash -> write -> paste -> (optional) restore. The OS specifics live
    in the injected ClipboardBackend; this class owns the orchestration so
    every platform has the same failure semantics."""

    backend: ClipboardBackend
    platform: str
    restore_clipboard: bool = True
    permission_hint: str | None = None
    # Brief pauses are sometimes needed so the OS registers the new
    # clipboard content before the paste keystroke fires. We expose it as a
    # field so tests can set it to 0 and avoid any real-time sleep.
    pre_paste_delay_s: float = 0.05

    def insert_text(self, text: str) -> InsertResult:
        if not text:
            return InsertResult(
                success=False,
                platform=self.platform,
                method=self.backend.name,
                error="empty text; nothing to insert",
            )

        method = self.backend.name
        previous: str | None = None

        log_event(
            logger,
            "cursor_insertion_attempt",
            platform=self.platform,
            method=method,
            text_chars=len(text),
        )

        if self.restore_clipboard:
            try:
                previous = self.backend.get_clipboard()
            except Exception as exc:  # noqa: BLE001
                logger.warning("clipboard read failed: %s", exc)
                previous = None

        try:
            self.backend.set_clipboard(text)
        except Exception as exc:  # noqa: BLE001
            log_event(
                logger,
                "cursor_insertion_failed",
                level=logging.WARNING,
                platform=self.platform,
                method=method,
                reason=f"clipboard_write:{type(exc).__name__}",
                success=False,
            )
            return InsertResult(
                success=False,
                platform=self.platform,
                method=method,
                error=f"clipboard write failed: {exc}",
            )

        if self.pre_paste_delay_s:
            try:
                import time

                time.sleep(self.pre_paste_delay_s)
            except Exception:
                pass

        try:
            self.backend.send_paste()
        except PermissionError as exc:
            log_event(
                logger,
                "cursor_insertion_failed",
                level=logging.WARNING,
                platform=self.platform,
                method=method,
                reason="permission_denied",
                success=False,
            )
            self._maybe_restore(previous)
            return InsertResult(
                success=False,
                platform=self.platform,
                method=method,
                error=self._with_hint(f"paste keystroke not permitted: {exc}"),
            )
        except Exception as exc:  # noqa: BLE001
            log_event(
                logger,
                "cursor_insertion_failed",
                level=logging.WARNING,
                platform=self.platform,
                method=method,
                reason=f"paste_keystroke:{type(exc).__name__}",
                success=False,
            )
            self._maybe_restore(previous)
            return InsertResult(
                success=False,
                platform=self.platform,
                method=method,
                error=self._with_hint(f"paste keystroke failed: {exc}"),
            )

        log_event(
            logger,
            "cursor_insertion_succeeded",
            platform=self.platform,
            method=method,
            success=True,
        )
        self._maybe_restore(previous)
        return InsertResult(
            success=True,
            platform=self.platform,
            method=method,
            message="inserted at active cursor location",
        )

    def _maybe_restore(self, previous: str | None) -> None:
        if not self.restore_clipboard or previous is None:
            return
        log_event(logger, "clipboard_restore_attempt", level=logging.DEBUG, platform=self.platform)
        try:
            self.backend.set_clipboard(previous)
            log_event(
                logger, "clipboard_restore_succeeded", level=logging.DEBUG, platform=self.platform
            )
        except Exception as exc:  # noqa: BLE001
            log_event(
                logger,
                "clipboard_restore_failed",
                level=logging.WARNING,
                platform=self.platform,
                reason=type(exc).__name__,
            )
            logger.warning("clipboard restore failed: %s", exc)

    def _with_hint(self, msg: str) -> str:
        if self.permission_hint:
            return f"{msg}\n{self.permission_hint}"
        return msg


# ---- subprocess helpers ----------------------------------------------------


def _run(cmd: list[str], *, input_text: str | None = None, timeout: float) -> None:
    """Run a subprocess; raise RuntimeError with a tidy message on failure."""
    try:
        completed = subprocess.run(
            cmd,
            input=input_text.encode("utf-8") if input_text is not None else None,
            capture_output=True,
            timeout=timeout,
        )
    except FileNotFoundError as exc:
        raise RuntimeError(f"required tool not found: {cmd[0]}") from exc
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError(f"timed out running {cmd[0]}") from exc
    if completed.returncode != 0:
        stderr = completed.stderr.decode("utf-8", errors="ignore").strip()
        raise RuntimeError(f"{cmd[0]} exited with {completed.returncode}: {stderr}")


# ---- macOS backend ---------------------------------------------------------


class _MacOSClipboardBackend:
    name = "macos_pbcopy_osascript"

    def __init__(self, timeout_ms: int = 3000):
        self.timeout = max(0.1, timeout_ms / 1000.0)

    def get_clipboard(self) -> str | None:
        try:
            out = subprocess.run(
                ["pbpaste"],
                capture_output=True,
                timeout=self.timeout,
            )
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return None
        if out.returncode != 0:
            return None
        return out.stdout.decode("utf-8", errors="ignore")

    def set_clipboard(self, text: str) -> None:
        _run(["pbcopy"], input_text=text, timeout=self.timeout)

    def send_paste(self) -> None:
        _run(
            [
                "osascript",
                "-e",
                'tell application "System Events" to keystroke "v" using command down',
            ],
            timeout=self.timeout,
        )


# ---- Windows backend -------------------------------------------------------


class _WindowsClipboardBackend:
    """PowerShell-based clipboard + SendKeys paste. No extra deps required."""

    name = "windows_powershell"

    def __init__(self, timeout_ms: int = 3000):
        self.timeout = max(0.1, timeout_ms / 1000.0)

    def _ps(self, script: str) -> subprocess.CompletedProcess:
        return subprocess.run(
            ["powershell", "-NoProfile", "-Command", script],
            capture_output=True,
            timeout=self.timeout,
        )

    def get_clipboard(self) -> str | None:
        try:
            out = self._ps("Get-Clipboard -Raw")
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return None
        if out.returncode != 0:
            return None
        return out.stdout.decode("utf-8", errors="ignore")

    def set_clipboard(self, text: str) -> None:
        # Use stdin piping via Set-Clipboard to avoid quoting hazards.
        try:
            completed = subprocess.run(
                ["powershell", "-NoProfile", "-Command", "Set-Clipboard"],
                input=text.encode("utf-8"),
                capture_output=True,
                timeout=self.timeout,
            )
        except FileNotFoundError as exc:
            raise RuntimeError("powershell not found on PATH") from exc
        except subprocess.TimeoutExpired as exc:
            raise RuntimeError("timed out writing clipboard") from exc
        if completed.returncode != 0:
            raise RuntimeError(
                completed.stderr.decode("utf-8", errors="ignore").strip() or "Set-Clipboard failed"
            )

    def send_paste(self) -> None:
        script = (
            "Add-Type -AssemblyName System.Windows.Forms; "
            "[System.Windows.Forms.SendKeys]::SendWait('^v')"
        )
        try:
            completed = self._ps(script)
        except FileNotFoundError as exc:
            raise RuntimeError("powershell not found on PATH") from exc
        if completed.returncode != 0:
            raise RuntimeError(
                completed.stderr.decode("utf-8", errors="ignore").strip() or "SendKeys paste failed"
            )


# ---- Linux backend (X11 / Wayland) -----------------------------------------


class _LinuxClipboardBackend:
    """Probes for the available clipboard tool at construction time so
    that the failure path surfaces a single clear 'install X or Y' hint
    instead of cascading subprocess errors at insert time."""

    name = "linux"

    def __init__(self, timeout_ms: int = 3000):
        self.timeout = max(0.1, timeout_ms / 1000.0)
        # Prefer Wayland tools if WAYLAND_DISPLAY is set; otherwise X11.
        self.is_wayland = bool(os.environ.get("WAYLAND_DISPLAY"))
        if self.is_wayland:
            self.clip_set = ["wl-copy"] if shutil.which("wl-copy") else None
            self.clip_get = ["wl-paste", "--no-newline"] if shutil.which("wl-paste") else None
            self.paste_cmd = (
                ["wtype", "-M", "ctrl", "v", "-m", "ctrl"] if shutil.which("wtype") else None
            )
            self.name = "linux_wayland"
        else:
            if shutil.which("xclip"):
                self.clip_set = ["xclip", "-selection", "clipboard"]
                self.clip_get = ["xclip", "-selection", "clipboard", "-o"]
            elif shutil.which("xsel"):
                self.clip_set = ["xsel", "--clipboard", "--input"]
                self.clip_get = ["xsel", "--clipboard", "--output"]
            else:
                self.clip_set = None
                self.clip_get = None
            self.paste_cmd = (
                ["xdotool", "key", "--clearmodifiers", "ctrl+v"]
                if shutil.which("xdotool")
                else None
            )
            self.name = "linux_x11"

    def _ensure_tools(self) -> None:
        missing = []
        if self.clip_set is None:
            missing.append("wl-copy (Wayland)" if self.is_wayland else "xclip or xsel (X11)")
        if self.paste_cmd is None:
            missing.append("wtype (Wayland)" if self.is_wayland else "xdotool (X11)")
        if missing:
            raise RuntimeError("missing required Linux automation tools: " + ", ".join(missing))

    def get_clipboard(self) -> str | None:
        if self.clip_get is None:
            return None
        try:
            out = subprocess.run(
                self.clip_get,
                capture_output=True,
                timeout=self.timeout,
            )
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return None
        if out.returncode != 0:
            return None
        return out.stdout.decode("utf-8", errors="ignore")

    def set_clipboard(self, text: str) -> None:
        self._ensure_tools()
        _run(self.clip_set, input_text=text, timeout=self.timeout)  # type: ignore[arg-type]

    def send_paste(self) -> None:
        self._ensure_tools()
        _run(self.paste_cmd, timeout=self.timeout)  # type: ignore[arg-type]


# ---- platform-specific public adapters -------------------------------------


def MacOSTextInserter(config: InsertConfig | None = None) -> ClipboardPasteInserter:
    cfg = config or InsertConfig.from_env()
    return ClipboardPasteInserter(
        backend=_MacOSClipboardBackend(timeout_ms=cfg.timeout_ms),
        platform="darwin",
        restore_clipboard=cfg.restore_clipboard,
        permission_hint=(
            "VoxScribe exported files successfully, but could not insert text. "
            "Enable Accessibility permission for your terminal or VoxScribe app "
            "in macOS Settings → Privacy & Security → Accessibility."
        ),
    )


def WindowsTextInserter(config: InsertConfig | None = None) -> ClipboardPasteInserter:
    cfg = config or InsertConfig.from_env()
    return ClipboardPasteInserter(
        backend=_WindowsClipboardBackend(timeout_ms=cfg.timeout_ms),
        platform="win32",
        restore_clipboard=cfg.restore_clipboard,
        permission_hint=(
            "VoxScribe exported files successfully, but could not insert text. "
            "Make sure the target text field is focused and that Windows "
            "allows the automation method being used."
        ),
    )


def LinuxTextInserter(config: InsertConfig | None = None) -> ClipboardPasteInserter:
    cfg = config or InsertConfig.from_env()
    return ClipboardPasteInserter(
        backend=_LinuxClipboardBackend(timeout_ms=cfg.timeout_ms),
        platform="linux",
        restore_clipboard=cfg.restore_clipboard,
        permission_hint=(
            "VoxScribe exported files successfully, but could not insert text. "
            "Install the required clipboard/paste tools for your Linux display "
            "server (xclip+xdotool on X11, wl-copy+wtype on Wayland), or "
            "disable cursor insertion."
        ),
    )


# ---- sleeper + delayed-refocus wrapper -------------------------------------


class Sleeper(Protocol):
    """Time-passing primitive. Real impl uses time.sleep; tests inject a
    fake so refocus_delay tests do not actually wait."""

    def sleep(self, seconds: float) -> None: ...


class RealSleeper:
    def sleep(self, seconds: float) -> None:
        import time as _time

        _time.sleep(max(0.0, seconds))


class FakeSleeper:
    """Records every sleep call; never actually sleeps."""

    def __init__(self) -> None:
        self.calls: list[float] = []

    def sleep(self, seconds: float) -> None:
        self.calls.append(seconds)


@dataclass
class DelayedInserter:
    """Wrap any TextInserter with a pre-paste delay so the user can refocus
    the target app before paste. Prints a single countdown line to stderr
    so it lands in the running listen session's terminal."""

    inner: TextInserter
    delay_seconds: float
    sleeper: Sleeper = field(default_factory=RealSleeper)
    notifier: Callable[[str], None] | None = None  # called with the countdown message

    def insert_text(self, text: str) -> InsertResult:
        msg = f"Focus the target app/text field now. Inserting in {self.delay_seconds:.0f} seconds…"
        if self.notifier is not None:
            try:
                self.notifier(msg)
            except Exception:  # noqa: BLE001 — never let a notifier kill insertion
                pass
        else:
            print(msg, file=sys.stderr, flush=True)
        self.sleeper.sleep(self.delay_seconds)
        result = self.inner.insert_text(text)
        # Tag the result so the diagnostics block clearly shows the mode used.
        if result.message and "refocus" not in result.message:
            result.message = f"{result.message} (refocus_delay)"
        elif not result.message and result.success:
            result.message = "inserted after refocus delay"
        return result


# ---- auto selection --------------------------------------------------------


def select_inserter(
    config: InsertConfig | None = None,
    *,
    platform: str | None = None,
    sleeper: Sleeper | None = None,
    notifier: Callable[[str], None] | None = None,
) -> TextInserter:
    """Pick the right inserter for the platform, config, and target mode.

    Returns a NoopTextInserter when:
      - insertion is disabled,
      - the configured method is 'none',
      - target_mode == 'last_focused_app' (scaffold only), or
      - the platform is unsupported.

    When target_mode == 'refocus_delay', the platform inserter is wrapped
    with a DelayedInserter that prints a countdown and waits the configured
    focus_delay_ms before delegating.
    """
    cfg = config or InsertConfig.from_env()
    plat = platform if platform is not None else sys.platform

    log_event(
        logger,
        "cursor_insertion_config_loaded",
        enabled=cfg.enabled,
        method=cfg.method,
        fmt=cfg.fmt,
        target_mode=cfg.target_mode,
        focus_delay_ms=cfg.focus_delay_ms,
        restore_clipboard=cfg.restore_clipboard,
    )

    if not cfg.enabled:
        log_event(
            logger,
            "cursor_insertion_disabled",
            platform=plat,
            reason="VOXSCRIBE_INSERT_AT_CURSOR=false",
        )
        return NoopTextInserter(platform=plat, reason="cursor insertion disabled")
    if cfg.method == "none":
        log_event(logger, "cursor_insertion_disabled", platform=plat, reason="method=none")
        return NoopTextInserter(platform=plat, reason="insert method is 'none'")

    if cfg.target_mode == "last_focused_app":
        return NoopTextInserter(
            platform=plat,
            reason=(
                "target_mode=last_focused_app is a scaffold only in this "
                "release. Use 'refocus_delay' for CLI-driven stop, or 'active' "
                "with a global hotkey/menubar trigger."
            ),
        )

    if plat == "darwin":
        base: TextInserter = MacOSTextInserter(cfg)
    elif plat == "win32":
        base = WindowsTextInserter(cfg)
    elif plat.startswith("linux"):
        base = LinuxTextInserter(cfg)
    else:
        return NoopTextInserter(
            platform=plat,
            reason="cursor insertion is not supported on this platform yet",
        )

    log_event(
        logger,
        "cursor_insertion_adapter_selected",
        platform=plat,
        adapter=type(base).__name__,
        target_mode=cfg.target_mode,
    )
    if cfg.target_mode == "refocus_delay":
        return DelayedInserter(
            inner=base,
            delay_seconds=max(0.0, cfg.focus_delay_ms / 1000.0),
            sleeper=sleeper or RealSleeper(),
            notifier=notifier,
        )
    return base


# ---- diagnostics + CLI-warning helpers -------------------------------------


def render_diagnostics(config: InsertConfig, inserter: TextInserter, payload: str) -> list[str]:
    """Multi-line pre-paste diagnostics so the user can see exactly which
    adapter and which payload are about to be used."""
    platform_name = getattr(inserter, "platform", sys.platform)
    if isinstance(inserter, DelayedInserter):
        adapter = type(inserter.inner).__name__
        method = getattr(inserter.inner, "platform", platform_name)
    else:
        adapter = type(inserter).__name__
        method = platform_name
    return [
        "Cursor insertion: enabled",
        f"  target mode    : {config.target_mode}"
        + (f" ({config.focus_delay_ms} ms)" if config.target_mode == "refocus_delay" else ""),
        f"  adapter        : {adapter} ({method})",
        f"  format         : {config.fmt}",
        f"  payload length : {len(payload)} chars",
        f"  restore clip   : {config.restore_clipboard}",
    ]


def cli_focus_warning(config: InsertConfig) -> str | None:
    """When the user is about to drive insertion from a terminal command but
    chose 'active' mode, surface the focus-stealing pitfall before the paste
    happens. Returns None when the warning does not apply."""
    if not config.enabled:
        return None
    if config.target_mode != "active":
        return None
    return (
        "Cursor insertion is running from a terminal stop command.\n"
        "If the target app is not focused at paste time (Terminal will be "
        "focused if you ran `make listen-stop`), use:\n"
        "  VOXSCRIBE_INSERT_TARGET_MODE=refocus_delay\n"
        "  VOXSCRIBE_INSERT_FOCUS_DELAY_MS=2000"
    )


# ---- format helper + CLI-facing message renderer ---------------------------


def choose_payload(fmt: str, *, markdown_text: str | None, plain_text: str) -> str:
    """Pick the text we will hand to the inserter.

    Preference rules:
      - 'markdown' fmt -> use the rendered markdown report when available,
        otherwise fall back to plain text (so insertion still works when
        the user did not pass --report).
      - 'plain_text' fmt -> always the cleaned stable transcript.
    """
    if fmt == "markdown" and markdown_text:
        return markdown_text
    return plain_text


def format_user_message(config: InsertConfig, result: InsertResult) -> str:
    """One uniform user-facing line per spec, based on the InsertResult."""
    if not config.enabled:
        return "Cursor insertion disabled. Set VOXSCRIBE_INSERT_AT_CURSOR=true to enable."
    if result.success:
        return "Inserted VoxScribe output at active cursor location."
    if result.method == "noop":
        return (
            f"VoxScribe exported files successfully, but cursor insertion is "
            f"not supported on this platform yet ({result.platform})."
        )
    reason = result.error or result.message or "unknown error"
    return (
        "VoxScribe exported files successfully, but could not insert text at "
        f"the active cursor location.\nReason: {reason}"
    )
