"""Per-project lexicon: bias terms and deterministic phrase rules.

Two layers, kept distinct on purpose:

  bias_terms
    High-weight strings the ASR's initial_prompt should favor. Surfaced
    through build_bias_terms() as a dictionary-tier source so they ride the
    same topic_quota budget as the rest of the live vocabulary. Prevents
    the error at the source (Kimi, Turnstile, BridgeMind, CAPTCHA).

  phrase_normalization
    Deterministic, word-boundary, case-insensitive multi-token substitutions
    applied in the final dictionary pass (after Flow Intelligence cleanup,
    before output). Fixes predictable multi-word mis-renderings that slip
    past biasing ("turn style" -> "Turnstile").

  low_confidence_candidates
    Acoustic garbles that cannot be safely string-matched (e.g. "Avcade 2.6"
    for "Kimi K2.6"). Recorded for visibility and possible promotion to bias
    terms, but NEVER applied as hard substitutions — the precision risk is
    the same reason the dictionary excludes 'json'/'sql'/'http' joined forms.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class BiasEntry:
    surface: str
    weight: float = 1.0
    aliases: list[str] = field(default_factory=list)


@dataclass
class PhraseRule:
    pattern: str
    replacement: str
    case_insensitive: bool = True
    word_boundary: bool = True


@dataclass
class LowConfidenceCandidate:
    heard: str
    suggested: str
    note: str = ""


@dataclass
class Lexicon:
    """Project-scoped vocabulary loaded from a JSON file at session start."""

    project: str = ""
    bias_terms: list[BiasEntry] = field(default_factory=list)
    phrase_normalization: list[PhraseRule] = field(default_factory=list)
    low_confidence_candidates: list[LowConfidenceCandidate] = field(default_factory=list)

    def bias_surfaces(self) -> list[tuple[str, float]]:
        """Flat (surface, weight) pairs including aliases. Aliases inherit
        the parent term's weight; deduped by lowercase surface."""
        seen: set[str] = set()
        out: list[tuple[str, float]] = []
        for entry in self.bias_terms:
            for surface in (entry.surface, *entry.aliases):
                key = surface.lower()
                if not surface or key in seen:
                    continue
                seen.add(key)
                out.append((surface, entry.weight))
        return out


def load_lexicon(path: str | Path) -> Lexicon:
    """Load a lexicon from JSON. Unknown keys are ignored so the file
    format can grow forward-compatibly."""
    p = Path(path)
    data = json.loads(p.read_text(encoding="utf-8"))
    return _from_dict(data)


def _from_dict(data: dict) -> Lexicon:
    bias = [
        BiasEntry(
            surface=str(b.get("surface", "")).strip(),
            weight=float(b.get("weight", 1.0)),
            aliases=[str(a) for a in b.get("aliases", []) if str(a).strip()],
        )
        for b in data.get("bias_terms", [])
        if str(b.get("surface", "")).strip()
    ]
    phrases = [
        PhraseRule(
            pattern=str(p.get("pattern", "")),
            replacement=str(p.get("replacement", "")),
            case_insensitive=bool(p.get("case_insensitive", True)),
            word_boundary=bool(p.get("word_boundary", True)),
        )
        for p in data.get("phrase_normalization", [])
        if str(p.get("pattern", ""))
    ]
    candidates = [
        LowConfidenceCandidate(
            heard=str(c.get("heard", "")),
            suggested=str(c.get("suggested", "")),
            note=str(c.get("note", "")),
        )
        for c in data.get("low_confidence_candidates", [])
    ]
    return Lexicon(
        project=str(data.get("project", "")),
        bias_terms=bias,
        phrase_normalization=phrases,
        low_confidence_candidates=candidates,
    )


# Convenience: not exported, used by tests that want to build a lexicon
# inline without a file.
def lexicon_from_dict(data: dict) -> Lexicon:
    return _from_dict(data)
