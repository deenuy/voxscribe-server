"""VoxScribe core: the local-first Flow Intelligence post-processor.

This package is the language-agnostic brain of VoxScribe. It takes a raw ASR
transcript plus the active app context and returns clean, formatted text.
The native Swift menu-bar app drives this same logic over the local Ollama
endpoint, so the intelligence is proven and tested here once, in one place.

Pipeline (see postprocessor.PostProcessor):
  1. Snippet check      deterministic, instant, no model call
  2. LLM intelligence   filler, backtrack, punctuation, lists, casing
  3. Dictionary pass    deterministic enforcement of known-term spelling
"""

try:
    from importlib.metadata import version as _pkg_version
    __version__ = _pkg_version("voxscribe-core")
except Exception:
    __version__ = "0.1.1"

from .audio_providers import (
    ASRProvider,
    AudioUnderstandingProvider,
    FakeASRProvider,
    FakeAudioUnderstandingProvider,
    WhisperASRProvider,
)
from .cleanup import CleanupResult, flow_clean
from .context import ContextDetector, DictationMode
from .contextual_biasing import build_bias_terms
from .dictionary import Dictionary
from .gemma_audio import GemmaAudioProvider
from .listen import (
    AudioSource,
    FakeAudioSource,
    ListenReport,
    MicrophoneSource,
    listen_once,
)
from .memory import MemoryManager, ProseSummary, TurnRecord
from .models import (
    AudioJudgment,
    AudioJudgmentRequest,
    JudgmentKind,
    RepetitionEvent,
    RepetitionKind,
    RevisionEvent,
    RevisionReason,
    SafetyCategory,
    SafetySignal,
    SessionEvent,
    SessionEventKind,
    SpanStatus,
    StreamingResult,
    TextSpan,
    TopicEvent,
    TopicEventKind,
    TranscriptChunk,
    TurnEvent,
    TurnEventKind,
    VocabularyBiasTerm,
    event_from_dict,
    event_to_dict,
)
from .postprocessor import PostProcessor
from .provider_harness import (
    CaseResult,
    HarnessCase,
    HarnessReport,
    ProviderResult,
    compare,
    run_harness,
)
from .providers import ClaudeProvider, DeterministicFallback, LLMProvider, OllamaProvider
from .safety_signals import scan as safety_scan
from .silence_policy import (
    Completeness,
    PauseBand,
    PauseBandConfig,
    SpeakerPauseStats,
    assess_completeness,
    calibrate_from_stats,
)
from .stream_state import ConversationSessionState, StreamProcessor
from .streaming_listen import (
    ListenSessionReport,
    ScriptedMic,
    StreamingMicConfig,
    StreamingMicrophone,
    run_listen_session,
)
from .topic_tracker import TopicTracker
from .turn_taking import ChunkAction, SilenceAction, TurnTakingConfig
from .uncertainty import RouterConfig, UncertaintyRouter

__all__ = [
    # version
    "__version__",
    # existing
    "DictationMode",
    "ContextDetector",
    "Dictionary",
    "PostProcessor",
    "OllamaProvider",
    "ClaudeProvider",
    "LLMProvider",
    # models
    "TranscriptChunk",
    "TextSpan",
    "SpanStatus",
    "StreamingResult",
    "JudgmentKind",
    "AudioJudgmentRequest",
    "AudioJudgment",
    "RepetitionEvent",
    "RepetitionKind",
    "RevisionEvent",
    "RevisionReason",
    "SafetyCategory",
    "SafetySignal",
    "SessionEvent",
    "SessionEventKind",
    "TopicEvent",
    "TopicEventKind",
    "TurnEvent",
    "TurnEventKind",
    "VocabularyBiasTerm",
    "event_from_dict",
    "event_to_dict",
    # audio providers
    "ASRProvider",
    "AudioUnderstandingProvider",
    "FakeASRProvider",
    "FakeAudioUnderstandingProvider",
    "WhisperASRProvider",
    # uncertainty
    "RouterConfig",
    "UncertaintyRouter",
    # streaming kernel
    "ConversationSessionState",
    "StreamProcessor",
    "TurnTakingConfig",
    "ChunkAction",
    "SilenceAction",
    "Completeness",
    "PauseBand",
    "PauseBandConfig",
    "SpeakerPauseStats",
    "assess_completeness",
    "calibrate_from_stats",
    # LLM fallback
    "DeterministicFallback",
    # listen-once
    "AudioSource",
    "FakeAudioSource",
    "MicrophoneSource",
    "ListenReport",
    "listen_once",
    # long-horizon streaming session
    "StreamingMicrophone",
    "StreamingMicConfig",
    "ScriptedMic",
    "ListenSessionReport",
    "run_listen_session",
    # CP5 audio foundation
    "GemmaAudioProvider",
    # CP6 long-horizon
    "MemoryManager",
    "ProseSummary",
    "TurnRecord",
    "TopicTracker",
    "build_bias_terms",
    # deterministic cleanup
    "CleanupResult",
    "flow_clean",
    # safety signals
    "safety_scan",
    # provider harness
    "HarnessCase",
    "CaseResult",
    "ProviderResult",
    "HarnessReport",
    "run_harness",
    "compare",
]
