"""Finalize-time SessionReport: projection, optional summarization, renderer.

Three responsibilities, kept separate so any transport can call them:

  build_session_report()    pure projection over the cleaned transcript and
                            chunk refs. No transport, no CLI state.
  render_markdown()         the spec layout (Topic / Description / Speaker
                            Key Notes / Key Themes / Keywords / Takeaways /
                            Original Transcript) emitted verbatim.
  render_json()             dict form for hosts that want structured output.

The summarization step is a SINGLE finalize-time LLM call routed through the
existing LLMProvider Protocol — no model is imported here. If the provider is
None or raises, the deterministic extractive fallback runs so `--report`
never hard-fails. The summarizer ALWAYS receives the cleaned, term-normalized
transcript, never the raw ASR text, so it benefits from the lexicon fixes.
"""

from __future__ import annotations

import json
import logging
import os
import re
import time
from dataclasses import dataclass

from .logging_config import get_logger, log_event
from .models import SessionReport
from .policy import PolicyGate, deliver_gated
from .prompts import SESSION_REPORT_MARKDOWN_PROMPT
from .providers import LLMProvider
from .topic_tracker import keywords as extract_keywords

log = get_logger("voxscribe.session_report")


# ---- report config (env-driven) -------------------------------------------


def _env_bool(name: str, default: bool) -> bool:
    raw = os.environ.get(name)
    if raw is None or raw == "":
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _env_choice(name: str, default: str, choices: set[str]) -> str:
    raw = (os.environ.get(name) or "").strip().lower()
    return raw if raw in choices else default


@dataclass
class ReportConfig:
    """Env-driven defaults for finalize-time report generation.

    The user-facing artifact (Markdown) should exist by default. Disabling it
    is a deliberate opt-out — the opposite of the CP7-era default. CLI flags
    still override env when supplied explicitly."""

    on_stop: bool = True
    fmt: str = "markdown"  # markdown | json | both
    use_llm: bool = True

    @classmethod
    def from_env(cls) -> ReportConfig:
        return cls(
            on_stop=_env_bool("VOXSCRIBE_REPORT_ON_STOP", True),
            fmt=_env_choice(
                "VOXSCRIBE_REPORT_FORMAT",
                "markdown",
                {"markdown", "json", "both"},
            ),
            use_llm=_env_bool("VOXSCRIBE_REPORT_USE_LLM", True),
        )

    @classmethod
    def from_config(cls, cfg: object) -> ReportConfig:
        """Build from a VoxScribeConfig (duck-typed to avoid circular import)."""
        sr = getattr(cfg, "session_report", None)
        if sr is None:
            return cls.from_env()
        fmt = str(getattr(sr, "format", "markdown")).lower()
        if fmt not in {"markdown", "json", "both"}:
            fmt = "markdown"
        return cls(
            on_stop=bool(getattr(sr, "enabled_on_stop", True)),
            fmt=fmt,
            use_llm=bool(getattr(sr, "use_llm", True)),
        )


# Bounded token budget for the summarizer prompt. Approximate: ~12k chars is
# roughly 3k tokens for English prose, well under typical local-model context.
DEFAULT_MAX_INPUT_CHARS = 12000


# Back-compat alias; the prompt itself lives in prompts.py.
SUMMARIZER_SYSTEM = SESSION_REPORT_MARKDOWN_PROMPT


def build_session_report(
    *,
    session_id: str,
    cleaned_transcript: str,
    chunk_refs: list[str],
    metadata: dict | None = None,
    provider: LLMProvider | None = None,
    max_input_chars: int = DEFAULT_MAX_INPUT_CHARS,
) -> SessionReport:
    """Project a finished session into a SessionReport.

    The transcript MUST already be cleaned (Flow Intelligence + lexicon
    phrase normalization + session lock). Callers prepare it; this layer
    treats it as the source of truth and never re-tokenizes the ASR output.

    When `provider` is set, one LLM call enriches topic_name / description /
    speaker notes / themes / takeaways. On any failure (bad JSON, network,
    timeout) the deterministic extractive fallback fills the same fields.
    """
    metadata = dict(metadata or {})
    cleaned = (cleaned_transcript or "").strip()
    derived_keywords = extract_keywords(cleaned) if cleaned else []
    log_event(
        log,
        "report_generation_started",
        session_id=session_id,
        provider=type(provider).__name__ if provider is not None else "",
        transcript_chars=len(cleaned),
    )

    summary: dict | None = None
    if provider is not None and cleaned:
        t0 = time.perf_counter()
        bounded = cleaned[:max_input_chars]
        try:
            raw = provider.complete(
                system=SUMMARIZER_SYSTEM,
                prompt=bounded,
                max_tokens=1024,
            ).strip()
            summary = _parse_summary_json(raw)
            metadata.setdefault("summarizer", "llm")
            metadata["summarizer_ms"] = (time.perf_counter() - t0) * 1000.0
            log_event(
                log,
                "report_llm_used",
                session_id=session_id,
                duration_ms=round(metadata["summarizer_ms"], 1),
                response_chars=len(raw),
            )
        except Exception as exc:  # noqa: BLE001 — never let summarize break report
            metadata["summarizer_error"] = str(exc)[:200]
            log_event(
                log,
                "report_generation_failed",
                level=logging.WARNING,
                session_id=session_id,
                reason=type(exc).__name__,
            )

    if summary is None:
        summary = _extractive_summary(cleaned, derived_keywords)
        metadata.setdefault("summarizer", "extractive")
        log_event(log, "report_fallback_used", session_id=session_id)

    keywords = summary.get("keywords") or derived_keywords
    return SessionReport(
        session_id=session_id,
        topic_name=summary.get("topic_name") or _default_topic_name(derived_keywords),
        description=summary.get("description") or "",
        speaker_key_notes=list(summary.get("speaker_key_notes") or []),
        key_themes=list(summary.get("key_themes") or []),
        keywords=list(keywords),
        takeaways=list(summary.get("takeaways") or []),
        original_transcript=cleaned,
        chunk_refs=list(chunk_refs),
        metadata=metadata,
    )


def render_markdown(report: SessionReport) -> str:
    """Emit the spec layout, paragraph-broken and provenance-aware.

    Long transcripts get split into sentence-bounded paragraphs so a 5-minute
    monologue doesn't paste as one wall of text. When the summarizer was the
    deterministic extractive fallback, a clear notice is appended so the
    reader knows fluency did NOT exceed evidence — the layout reflects what
    the LLM could not enrich.

    Front-matter: when the SessionReport.metadata carries `mode` and/or
    `product`, a minimal YAML front-matter block is emitted so downstream
    tooling can route the report by product surface (IdeaScribe / Classroom
    / SeniorCare). The block is suppressed entirely when neither field is
    present so the format stays compatible with consumers that expected the
    pre-product-mode layout."""
    lines: list[str] = []

    mode_tag = str(report.metadata.get("mode") or "").strip()
    product_tag = str(report.metadata.get("product") or "").strip()
    if mode_tag or product_tag:
        lines.append("---")
        lines.append(f"session_id: {report.session_id}")
        if mode_tag:
            lines.append(f"mode: {mode_tag}")
        if product_tag:
            lines.append(f"product: {product_tag}")
        lines.append("---")
        lines.append("")

    lines.append(f"# {report.topic_name}")
    lines.append("")
    lines.append("## Description")
    lines.append(report.description or "")
    lines.append("")
    lines.append("## Speaker Key Notes")
    for note in report.speaker_key_notes:
        lines.append(f"- {note}")
    if not report.speaker_key_notes:
        lines.append("-")
    lines.append("")
    lines.append("## Key Themes")
    for theme in report.key_themes:
        lines.append(f"- {theme}")
    if not report.key_themes:
        lines.append("-")
    lines.append("")
    lines.append("## Keywords")
    lines.append(", ".join(report.keywords))
    lines.append("")
    lines.append("## Takeaways")
    for takeaway in report.takeaways:
        lines.append(f"- {takeaway}")
    if not report.takeaways:
        lines.append("-")
    lines.append("")
    lines.append("## Original Transcript")
    paragraphs = _paragraphs_for_markdown(report.original_transcript)
    if paragraphs:
        for i, para in enumerate(paragraphs):
            if i:
                lines.append("")
            lines.append(para)
    else:
        lines.append("")

    notice = _fallback_notice(report)
    if notice:
        lines.append("")
        lines.append("---")
        lines.append(notice)

    return "\n".join(lines).rstrip() + "\n"


# Sentence-aware paragraphing: every PARA_SENTENCES sentences OR when an
# accumulated paragraph exceeds PARA_CHAR_BUDGET we close it at the next
# sentence boundary. The thresholds are tuned for readable monologue;
# they're not parameters because the spec wants "useful structure", not
# tunables.
PARA_SENTENCES = 4
PARA_CHAR_BUDGET = 500


def _paragraphs_for_markdown(text: str) -> list[str]:
    """Break a long stable transcript into readable paragraphs.

    Respects existing blank-line separators (stable-span boundaries) first;
    then within each block, packs sentences into paragraphs."""
    if not text:
        return []
    blocks = [b.strip() for b in re.split(r"\n\s*\n", text) if b.strip()]
    paragraphs: list[str] = []
    for block in blocks:
        sentences = _split_sentences(block)
        if not sentences:
            paragraphs.append(block)
            continue
        current: list[str] = []
        current_chars = 0
        for sent in sentences:
            current.append(sent)
            current_chars += len(sent) + 1
            if len(current) >= PARA_SENTENCES or current_chars >= PARA_CHAR_BUDGET:
                paragraphs.append(" ".join(current))
                current = []
                current_chars = 0
        if current:
            paragraphs.append(" ".join(current))
    return paragraphs


def _fallback_notice(report: SessionReport) -> str:
    """Render a transparency notice into the markdown when the report was
    not produced by the LLM. Conservative on purpose: the user must be able
    to tell at a glance whether they are reading an LLM-enriched summary or
    a deterministic extract."""
    summarizer = (report.metadata or {}).get("summarizer", "")
    if summarizer == "llm":
        return ""
    if summarizer == "extractive":
        err = (report.metadata or {}).get("summarizer_error")
        if err:
            return (
                f"_LLM summary unavailable; rendered with the deterministic "
                f"extractive fallback. Reason: {err}_"
            )
        return "_LLM summary not requested; rendered with the deterministic extractive fallback._"
    return ""


def render_json(report: SessionReport) -> str:
    return json.dumps(report.to_dict(), indent=2)


# ---- gated delivery (invariant 5b) ----------------------------------------


SESSION_REPORT_SURFACE = "session_report"


def deliver_report_text(
    gate: PolicyGate | None,
    rendered: str,
    *,
    store: object | None,
    session_id: str,
    at: float | None = None,
) -> str:
    """Run the rendered session report through the response gate before
    delivery. The caller writes the returned text to disk verbatim; on a
    deny or fail-closed outcome that text is the pack's scripted fallback,
    never the candidate. Ledger + retention + policy event are all recorded
    inside deliver_gated so this seam stays a single line at every call site."""
    return deliver_gated(
        gate,
        rendered,
        surface=SESSION_REPORT_SURFACE,
        store=store,
        session_id=session_id,
        at=at,
    )


# ---- internals --------------------------------------------------------------


_SENT_SPLIT = re.compile(r"(?<=[.!?])\s+")


def _split_sentences(text: str) -> list[str]:
    return [s.strip() for s in _SENT_SPLIT.split(text) if s.strip()]


def _default_topic_name(keywords: list[str]) -> str:
    if not keywords:
        return "Untitled session"
    head = [w.capitalize() for w in keywords[:3]]
    return " / ".join(head)


def _extractive_summary(cleaned: str, keywords: list[str]) -> dict:
    """Deterministic fallback when no LLM is available.

    Surfaces the highest keyword-density sentences as notes and themes,
    the first sentence as description, and the last as takeaway. Crude but
    predictable, and most importantly — never raises."""
    sentences = _split_sentences(cleaned)
    if not sentences:
        return {
            "topic_name": _default_topic_name(keywords),
            "description": "",
            "speaker_key_notes": [],
            "key_themes": list(keywords[:6]),
            "takeaways": [],
            "keywords": keywords,
        }

    kw_set = set(keywords)

    def density(sent: str) -> int:
        words = re.findall(r"[A-Za-z]+", sent.lower())
        return sum(1 for w in words if w in kw_set)

    ranked = sorted(
        ((density(s), idx, s) for idx, s in enumerate(sentences)),
        key=lambda t: (-t[0], t[1]),
    )
    notes = [s for _, _, s in ranked[:3] if s]
    takeaway = sentences[-1] if sentences else ""
    description = sentences[0]
    return {
        "topic_name": _default_topic_name(keywords),
        "description": description,
        "speaker_key_notes": notes,
        "key_themes": list(keywords[:6]),
        "takeaways": [takeaway] if takeaway else [],
        "keywords": keywords,
    }


def _parse_summary_json(raw: str) -> dict | None:
    """Tolerant JSON parse for the summarizer call.

    Accepts a bare JSON object or one wrapped in code fences. Returns None
    on any failure so the caller falls back to extractive."""
    if not raw:
        return None
    # Strip common code-fence wrapping (``` or ```json).
    stripped = raw.strip()
    if stripped.startswith("```"):
        stripped = stripped.strip("`")
        if stripped.lower().startswith("json"):
            stripped = stripped[4:]
        stripped = stripped.strip()
    # Find the outermost JSON object.
    start = stripped.find("{")
    end = stripped.rfind("}")
    if start == -1 or end <= start:
        return None
    try:
        data = json.loads(stripped[start : end + 1])
    except (ValueError, TypeError):
        return None
    if not isinstance(data, dict):
        return None

    # Coerce shapes — drop anything obviously wrong, let defaults fill.
    def _as_list(v) -> list[str]:
        if isinstance(v, list):
            return [str(x).strip() for x in v if str(x).strip()]
        if isinstance(v, str) and v.strip():
            return [v.strip()]
        return []

    return {
        "topic_name": str(data.get("topic_name") or "").strip(),
        "description": str(data.get("description") or "").strip(),
        "speaker_key_notes": _as_list(data.get("speaker_key_notes")),
        "key_themes": _as_list(data.get("key_themes")),
        "takeaways": _as_list(data.get("takeaways")),
        "keywords": _as_list(data.get("keywords")),
    }
