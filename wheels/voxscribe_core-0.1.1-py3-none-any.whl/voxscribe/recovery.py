"""Crash recovery for incomplete sessions.

Run at the top of `make listen` (or via `--recover`).  For each session
left in `recording` or `finalizing` whose process is gone, we first replay
any durable audio that never finished processing (voice-design invariant 2:
the blob store + `audio_blobs` checkpoint means a kill between capture and
commit loses nothing), then rebuild the `.txt` transcript from the durable
`segments` WAL, mark the session `recovered`, record usage, and enqueue an
outbox row.  Replay needs an ASR provider; when none is passed, recovery
still saves everything already committed and leaves the unprocessed blobs
in place for a later replay.  No LLM is required.

Idempotency is built in at two layers:

  * `list_incomplete_sessions()` only returns rows in `recording` or
    `finalizing`; a session we already recovered is in `recovered` state
    and is skipped.
  * `record_usage()` is keyed on `session_id`, so a re-run of recovery
    against the same session does not double-count.

This module is intentionally pure: pass it a `Store` and (optionally) a
clock + a "is this pid alive" probe so tests can drive every branch
without spawning real processes.
"""

from __future__ import annotations

import calendar
import logging
import os
import time
from collections.abc import Callable
from pathlib import Path

from .blob_store import delete_blob, read_blob
from .context import DictationMode
from .logging_config import get_logger, log_event
from .models import event_to_dict
from .store import Store

log = get_logger("voxscribe.recovery")


# Heartbeat is bumped per turn; a session whose heartbeat is older than
# this is presumed dead even if `pid` lookup is inconclusive.  Generous
# default — false positives waste work but never lose data.
DEFAULT_STALE_HEARTBEAT_S = 120.0


def _default_pid_alive(pid: int | None) -> bool:
    """`os.kill(pid, 0)` raises ProcessLookupError when the process is
    gone.  A missing pid (None / 0) is treated as dead so the recovery
    path still runs on rows from pre-pid-tracking sessions."""
    if not pid:
        return False
    try:
        os.kill(int(pid), 0)
        return True
    except (ProcessLookupError, ValueError):
        return False
    except PermissionError:
        # The process exists but is owned by another user — treat as
        # alive: refusing to recover is the safe failure mode here.
        return True


def _heartbeat_is_stale(
    heartbeat_at: str,
    *,
    now: float,
    threshold_s: float,
) -> bool:
    """A row with no heartbeat at all is treated as stale (we cannot
    distinguish "old code that never wrote a heartbeat" from "dead")."""
    if not heartbeat_at:
        return True
    try:
        ts = time.strptime(heartbeat_at, "%Y-%m-%dT%H:%M:%SZ")
        # calendar.timegm is the inverse of time.gmtime — returns UTC
        # epoch from a struct_time without depending on local tz.
        epoch = calendar.timegm(ts)
    except (ValueError, OverflowError):
        return True
    return (now - epoch) > threshold_s


def _rebuild_transcript(segments_text: str, path: Path) -> None:
    """Write the concatenated segments to the canonical `.txt` path.

    We overwrite rather than append: the WAL is the source of truth, so
    a partial `.txt` written before the crash would otherwise produce a
    duplicated transcript after recovery."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(segments_text, encoding="utf-8")


def _mode_from_row(row: dict) -> DictationMode:
    try:
        return DictationMode(str(row.get("mode") or ""))
    except ValueError:
        return DictationMode.IDEASCRIBE


def replay_unprocessed_audio(
    store: Store,
    session_id: str,
    asr,
    processor,
    mode: DictationMode = DictationMode.IDEASCRIBE,
    *,
    blob_reader: Callable[[str], tuple[list[float], int]] = read_blob,
    retain_audio: bool = False,
) -> int:
    """Replay durable audio the crashed process never finished processing.

    Feeds every unprocessed blob (in capture order) through ASR and a fresh
    StreamProcessor, finalizes, and commits the resulting spans, their
    lifecycle events, and the processed marks in ONE transaction, appended
    after the crashed run's committed segments.  Returns the number of
    spans recovered.

    Crash-floor guarantees:
      * zero audio lost: every unprocessed blob is either replayed or
        logged unreadable; the processed mark commits atomically with the
        recovered spans, so a crash during replay just replays again.
      * zero duplicate spans: a blob that straddled a turn boundary can
        re-produce text whose first turn already committed pre-crash;
        replayed spans whose exact text already exists in `segments` are
        skipped.

    Replay chunk ids use an `-r` namespace (`<session>-r1`, ...) so they
    can never collide with the crashed run's `-c` ids in provenance."""
    blobs = store.unprocessed_blobs(session_id)
    if not blobs:
        return 0

    existing = store.get_segments(session_id)
    existing_texts = {seg.text for seg in existing if (seg.text or "").strip()}
    next_seg_seq = max((seg.seq for seg in existing), default=-1) + 1
    next_event_seq = store.next_event_seq(session_id)

    events_out: list = []
    chunk_n = 0
    replayed_seqs: list[int] = []
    for blob in blobs:
        replayed_seqs.append(int(blob["seq"]))
        try:
            samples, rate = blob_reader(blob["uri"])
        except (OSError, ValueError) as exc:
            # Unreadable audio cannot be replayed; mark it consumed anyway
            # (retrying forever would block recovery) but leave a trace.
            log_event(
                log,
                "recovery_blob_unreadable",
                level=logging.WARNING,
                session_id=session_id,
                path=str(blob["uri"]),
                reason=type(exc).__name__,
            )
            continue
        for chunk in asr.transcribe(samples, rate, session_id):
            chunk_n += 1
            chunk.chunk_id = f"{session_id}-r{chunk_n}"
            chunk.session_id = session_id
            result = processor.feed(chunk, mode)
            if result is not None and result.events:
                events_out.extend(result.events)
    final = processor.finalize(session_id)
    if final is not None and final.events:
        events_out.extend(final.events)

    state = processor.session(session_id)
    new_segments: list[dict] = []
    for span in state.stable_spans:
        text = span.text or ""
        if text in existing_texts:
            continue  # committed pre-crash by a straddling blob
        new_segments.append(
            {
                "seq": next_seg_seq + len(new_segments),
                "text": text,
                "turn_id": getattr(span, "turn_id", "") or "",
                "confidence": float(getattr(span, "confidence", 0.0) or 0.0),
            }
        )
    batch_events = [
        (next_event_seq + i, event_to_dict(ev)) for i, ev in enumerate(events_out)
    ]
    store.commit_stream_batch(
        session_id,
        events=batch_events,
        segments=new_segments,
        processed_blob_seqs=replayed_seqs,
    )
    if not retain_audio:
        for blob in blobs:
            try:
                if not store.sha_has_unprocessed_refs(str(blob["sha256"])):
                    delete_blob(str(blob["uri"]))
            except OSError:
                pass
    log_event(
        log,
        "recovery_audio_replayed",
        session_id=session_id,
        blobs=len(blobs),
        spans_recovered=len(new_segments),
    )
    return len(new_segments)


def recover_incomplete(
    store: Store,
    *,
    pid_alive: Callable[[int | None], bool] = _default_pid_alive,
    stale_heartbeat_s: float = DEFAULT_STALE_HEARTBEAT_S,
    now: float | None = None,
    app_version: str = "",
    asr=None,
    processor_factory: Callable[[], object] | None = None,
) -> list[str]:
    """Scan + recover.  Returns the list of session ids that were rebuilt.

    A session is considered abandoned when:
      * its pid is missing or dead, OR
      * its heartbeat hasn't been bumped within `stale_heartbeat_s`.
    """
    epoch = now if now is not None else time.time()
    rebuilt: list[str] = []

    for row in store.list_incomplete_sessions():
        sid = row["id"]
        pid = row.get("pid")
        hb = row.get("heartbeat_at") or ""

        alive = pid_alive(pid)
        stale = _heartbeat_is_stale(hb, now=epoch, threshold_s=stale_heartbeat_s)
        if alive and not stale:
            # Healthy session — leave it alone.
            continue

        # Replay first, so the transcript rebuild below already includes
        # spans recovered from durable-but-unprocessed audio. Without an
        # ASR the blobs stay in place for a later replay; a replay failure
        # must never block saving what is already committed.
        if asr is not None and processor_factory is not None:
            try:
                replay_unprocessed_audio(
                    store,
                    sid,
                    asr,
                    processor_factory(),
                    _mode_from_row(row),
                )
            except Exception as exc:  # noqa: BLE001
                log_event(
                    log,
                    "recovery_replay_failed",
                    level=logging.WARNING,
                    session_id=sid,
                    reason=type(exc).__name__,
                )

        segments = store.get_segments(sid)
        # Concatenate one turn per paragraph, matching the live writer.
        if segments:
            body = "".join((seg.text or "") + "\n\n" for seg in segments)
        else:
            body = ""
        words = len(body.split())
        chars = len(body)
        counted = words > 0
        reason = "" if counted else "no_speech"

        transcript_path = row.get("transcript_path") or ""
        if transcript_path:
            try:
                _rebuild_transcript(body, Path(transcript_path))
            except OSError as exc:
                # Disk failure is non-fatal — the DB row is the source
                # of truth.  Log and move on so other sessions still
                # recover.
                log_event(
                    log,
                    "recovery_transcript_write_failed",
                    level=logging.WARNING,
                    session_id=sid,
                    path=transcript_path,
                    reason=type(exc).__name__,
                )

        iso_week = ""
        # Re-derive iso_week from `started_at`. The billing layer's tz
        # rules apply at write time; on recovery we use the simple ISO
        # week the v2 ledger would have computed if the session had
        # finished normally.  The store keeps both started_at and the
        # iso_week field on usage_records, so a future recompute can
        # canonicalize later if needed.
        started = row.get("started_at") or ""
        if started:
            try:
                iso_week = time.strftime(
                    "%G-W%V",
                    time.strptime(started, "%Y-%m-%dT%H:%M:%SZ"),
                )
            except ValueError:
                iso_week = ""

        store.record_usage(
            sid,
            account_id=row.get("account_id") or "",
            iso_week=iso_week,
            words=words,
            ai_actions=0,
            audio_seconds=float(row.get("audio_seconds") or 0.0),
            counted=counted,
        )
        store.finalize_session(
            sid,
            state="recovered",
            words=words,
            chars=chars,
            audio_seconds=float(row.get("audio_seconds") or 0.0),
            counted=counted,
            uncounted_reason=reason,
            transcript_path=transcript_path,
        )
        store.enqueue_outbox(
            "session",
            sid,
            "upsert",
            {
                "session_id": sid,
                "account_id": row.get("account_id") or "",
                "state": "recovered",
                "words": words,
                "audio_seconds": float(row.get("audio_seconds") or 0.0),
                "counted": counted,
                "app_version": app_version,
            },
        )
        log_event(
            log,
            "session_recovered",
            session_id=sid,
            words=words,
            counted=counted,
            uncounted_reason=reason,
            segments=len(segments),
        )
        rebuilt.append(sid)

    return rebuilt
