"""Data resources: prompts and lexicons."""
