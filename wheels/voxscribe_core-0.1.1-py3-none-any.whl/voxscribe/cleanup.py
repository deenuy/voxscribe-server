"""The deterministic Flow Intelligence floor that runs at commit boundaries.

Order: fillers -> backtrack corrections -> repetition -> spoken punctuation
-> numbered lists. The model pass, when available, runs *after* this floor
and polishes what is left (casing, implied punctuation, nuanced fillers);
when the model is unavailable the floor alone produces correct, meaning-
preserving text. Dictionary normalization stays the final pass, in
PostProcessor, after everything here and after the model.

IDEASCRIBE mode is deliberately conservative: only strong correction markers
apply, and repetitions are reported but never collapsed — contradictions and
restatements are the signal downstream PRD extraction depends on.
CLASSROOM and SENIORCARE collapse repetitions and apply the full backtrack
set so notes read cleanly.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from .context import DictationMode
from .corrections import apply_backtracks
from .models import RepetitionEvent, RevisionReason
from .repetition import collapse_repetitions

_FILLERS = re.compile(r"(?:^|\s)(?:um+|uh+|er+|erm+|hmm+)\b[,.]?", re.I)

_FILE_EXTS = "tsx|ts|jsx|js|py|json|md|yml|yaml|toml|css|html|sh|swift|rs|go|txt|csv"
_FILE_REF = re.compile(rf"\b([\w-]+)\s+dot\s+({_FILE_EXTS})\b", re.I)

_LIST_SPLIT = re.compile(r"\b(\d{1,2})[.,]\s+")


def strip_fillers(text: str) -> str:
    out = _FILLERS.sub(" ", text)
    out = re.sub(r"\s+", " ", out).strip()
    return re.sub(r"\s+([,.!?])", r"\1", out)


def spoken_punctuation(text: str) -> str:
    out = re.sub(r"\s*\bnew (?:line|paragraph)\b\s*", "\n", text, flags=re.I)
    out = re.sub(r"\s*\bcomma\b", ",", out, flags=re.I)
    out = re.sub(r"\s*\bquestion mark\b", "?", out, flags=re.I)
    out = re.sub(r"\s*\bexclamation (?:mark|point)\b", "!", out, flags=re.I)
    out = re.sub(r"\s*\bfull stop\b", ".", out, flags=re.I)
    # "period" is a real word ("trial period"), so only the end-of-utterance
    # position is safe to replace deterministically; the model owns the rest.
    out = re.sub(r"\s*\bperiod\b\s*$", ".", out, flags=re.I)
    return out


def format_numbered_list(text: str) -> str:
    """Format "1. apples 2. bananas" as list lines. Requires punctuation
    after each number and a 1..n sequence, so "I have 1 dog and 2 cats"
    never triggers."""
    parts = _LIST_SPLIT.split(text)
    if len(parts) < 5:  # prefix + at least two (number, item) pairs
        return text
    nums = parts[1::2]
    items = [p.strip().rstrip(".,") for p in parts[2::2]]
    if nums != [str(i + 1) for i in range(len(nums))] or not all(items):
        return text
    intro = parts[0].strip()
    lines = [f"{i + 1}. {item}" for i, item in enumerate(items)]
    return (intro + "\n" if intro else "") + "\n".join(lines)


def join_file_references(text: str) -> str:
    return _FILE_REF.sub(r"\1.\2", text)


@dataclass
class CleanupResult:
    text: str
    # (reason, old, new) per meaning-relevant transformation, in order
    revisions: list[tuple[RevisionReason, str, str]] = field(default_factory=list)
    repetitions: list[RepetitionEvent] = field(default_factory=list)
    residual_markers: bool = False  # ambiguous correction markers remain


def flow_clean(text: str, mode: DictationMode) -> CleanupResult:
    revisions: list[tuple[RevisionReason, str, str]] = []

    out = strip_fillers(text)

    # IDEASCRIBE preserves all but the strongest explicit corrections so
    # downstream PRD extraction still sees the original idea + the revision.
    strong_only = mode is DictationMode.IDEASCRIBE
    correction = apply_backtracks(out, strong_only=strong_only)
    if correction.applied:
        revisions.append((RevisionReason.BACKTRACK, out, correction.text))
    out = correction.text

    # IDEASCRIBE keeps repetitions as evidence (a PM repeating a feature
    # name is a signal of importance). CLASSROOM and SENIORCARE collapse
    # them so notes read cleanly.
    collapse = mode is not DictationMode.IDEASCRIBE
    collapsed, repetitions = collapse_repetitions(out, collapse=collapse)
    if collapsed != out:
        revisions.append((RevisionReason.REPETITION_COLLAPSE, out, collapsed))
    out = collapsed

    out = spoken_punctuation(out)
    out = format_numbered_list(out)

    return CleanupResult(
        text=out,
        revisions=revisions,
        repetitions=repetitions,
        residual_markers=correction.residual_markers,
    )
