"""Product-mode selection.

VoxScribe serves three product surfaces:

  IDEASCRIBE  Product managers brainstorming PRDs and work items. Preserves
              contradictions and hedges as signal for downstream extraction.
  CLASSROOM   Students capturing lectures and lessons into clean notes.
              Aggressive prose cleanup with structured headings preserved.
  SENIORCARE  Caregivers recording daily routines, medications, and family
              updates. Gentle prose cleanup that preserves what was said.

The active mode decides which system prompt the post-processor loads and how
the deterministic Flow Intelligence floor behaves at commit boundaries. The
mode is set at session start from config.yaml (listen.default_mode) or via
the --mode CLI flag.

Bundle-id-driven auto-detection from the previous register-mode era has been
removed: products are chosen, not detected.
"""

from __future__ import annotations

from enum import Enum


class DictationMode(str, Enum):
    """Product-mode tag for a VoxScribe session.

    Values are stable: they appear in config.yaml, on the CLI as --mode, in
    JSONL event records, and in report front-matter. Renaming a value is a
    breaking change for downstream tooling."""

    IDEASCRIBE = "ideascribe"
    CLASSROOM = "classroom"
    SENIORCARE = "seniorcare"


# Display label per mode. Used in human logs, report front-matter, and on
# the CLI summary line. Kept here next to the enum so adding a new mode is
# a single-file change.
PRODUCT_LABELS: dict[DictationMode, str] = {
    DictationMode.IDEASCRIBE: "IdeaScribe",
    DictationMode.CLASSROOM: "ClassroomScribe",
    DictationMode.SENIORCARE: "SeniorCareScribe",
}


def product_label(mode: DictationMode) -> str:
    """Return the user-facing product name for a mode."""
    return PRODUCT_LABELS.get(mode, mode.value)


class ContextDetector:
    """Returns the default mode. Kept as a stub for backwards compatibility
    with hosts that still call mode_for() or current_mode() — both return
    IDEASCRIBE because product mode is a user choice, not an auto-detection."""

    def mode_for(self, bundle_id: str | None) -> DictationMode:
        return DictationMode.IDEASCRIBE

    def current_mode(self) -> DictationMode:
        return DictationMode.IDEASCRIBE
