"""The turn-taking policy: pure decisions, no side effects.

Silence alone never closes a turn. A turn closes only when an EXTENDED pause
coincides with a thought that reads complete, when ongoing silence outlasts
the hard hold cap, or when the host finalizes the session. Everything else
holds the turn open as a possible continuation — this is what lets a speaker
pause 10-30 seconds mid-thought and keep the thread.

Two entry points mirror the two ways the kernel learns about silence:
  on_chunk    a chunk arrived; its gap tells us what the silence before it was
  on_silence  the host reports silence still in progress (no chunk yet)

Both are pure functions of (band, completeness, config) so the policy is
exhaustively testable without any session state.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from .silence_policy import Completeness, PauseBand


class ChunkAction(Enum):
    OPEN_NEW = "open_new"  # no open turn: start one
    EXTEND = "extend"  # same turn, buffer grows
    SOFT_COMMIT_THEN_EXTEND = "soft_commit_then_extend"  # commit finished thought, turn stays open
    HOLD_THEN_EXTEND = "hold_then_extend"  # thinking pause ended, same thought resumes
    RESUME_THEN_EXTEND = "resume_then_extend"  # very long pause, but thought was incomplete
    CLOSE_THEN_OPEN = "close_then_open"  # finished thought + extended pause: new turn


class SilenceAction(Enum):
    NONE = "none"
    SOFT_COMMIT = "soft_commit"  # thought reads finished: promote to stable, keep turn open
    HOLD = "hold"  # possible continuation: do nothing irreversible
    CLOSE = "close"  # extended silence after a complete thought
    CLOSE_INCOMPLETE = "close_incomplete"  # hold cap exhausted; close and mark uncertainty


@dataclass
class TurnTakingConfig:
    soft_commit_confidence: float = 0.75  # completeness confidence needed to soft-commit
    hold_cap_ms: float = 30000.0  # absolute ceiling on holding an open turn in silence
    max_provisional_chars: int = 4000  # memory safety: force a soft commit past this


def on_chunk(
    turn_open: bool,
    band: PauseBand,
    completeness: Completeness,
    config: TurnTakingConfig,
) -> ChunkAction:
    if not turn_open:
        return ChunkAction.OPEN_NEW
    if band in (PauseBand.MICRO, PauseBand.SHORT):
        return ChunkAction.EXTEND
    if band is PauseBand.LONG:
        if completeness.complete and completeness.confidence >= config.soft_commit_confidence:
            return ChunkAction.SOFT_COMMIT_THEN_EXTEND
        return ChunkAction.HOLD_THEN_EXTEND
    # EXTENDED: a complete thought followed by a very long pause is a new
    # turn; an incomplete one is the speaker finding their thread again.
    if completeness.complete:
        return ChunkAction.CLOSE_THEN_OPEN
    return ChunkAction.RESUME_THEN_EXTEND


def on_silence(
    band: PauseBand,
    completeness: Completeness,
    silence_ms: float,
    config: TurnTakingConfig,
) -> SilenceAction:
    if band in (PauseBand.MICRO, PauseBand.SHORT):
        return SilenceAction.NONE
    if band is PauseBand.LONG:
        if completeness.complete and completeness.confidence >= config.soft_commit_confidence:
            return SilenceAction.SOFT_COMMIT
        return SilenceAction.HOLD
    # EXTENDED
    if completeness.complete:
        return SilenceAction.CLOSE
    if silence_ms >= config.hold_cap_ms:
        return SilenceAction.CLOSE_INCOMPLETE
    return SilenceAction.HOLD
