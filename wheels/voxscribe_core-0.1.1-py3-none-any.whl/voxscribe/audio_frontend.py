"""Audio front-end: noise robustness lives here, not in the text layer.

The honest engineering answer to "handle traffic, plant floor, driving, poor
mic" is a three-stage front-end before any text exists:

  1. Denoise   suppress steady and transient background noise on the raw PCM
  2. VAD gate  decide what is speech vs noise, drop the rest, find utterance ends
  3. Robust ASR Parakeet v3 is trained on noisy far-field speech and degrades
                gracefully; the cloud tier (ElevenLabs Scribe) is the fallback
                when local accuracy is not enough in extreme noise

This module owns stages 1 and 2 as testable logic plus a clean interface. The
real DSP for the denoiser runs in the native audio thread (or a sidecar). The
text post-processor adds a final, smaller safety net via the noise rule in its
prompt: it drops obvious mis-hears without inventing words.

Recommended denoiser implementations (swap behind the Denoiser protocol):
  - DeepFilterNet: real-time, CPU-friendly, strong on non-stationary noise
    (good for traffic and plant floor). Apache 2.0.
  - RNNoise: tiny and fast, good for steady noise and mic hiss.
  - Silero denoiser: pairs naturally with Silero VAD.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from enum import Enum
from typing import Protocol


class Denoiser(Protocol):
    """Processes one PCM chunk and returns a denoised chunk of the same size."""

    def process(self, samples: list[float], sample_rate: int) -> list[float]: ...


class PassthroughDenoiser:
    """No-op default. Replace with DeepFilterNet or RNNoise in the host app."""

    def process(self, samples: list[float], sample_rate: int) -> list[float]:
        return samples


@dataclass
class VADConfig:
    """VAD gate tuning. Raise thresholds in noisy environments so background
    energy does not falsely trigger speech."""

    chunk_ms: int = 32  # one audio chunk, matches a 512-sample frame at 16k
    start_threshold: float = 0.5  # prob to begin counting toward speech
    end_threshold: float = 0.35  # prob below which we count toward silence
    start_chunks: int = 2  # consecutive chunks above start_threshold
    end_silence_ms: int = 1500  # trailing silence that ends an utterance


class NoiseProfile(Enum):
    """Presets for the kinds of environments the PRD calls out."""

    QUIET = "quiet"
    OFFICE = "office"
    MOBILE = "mobile"  # driving, walking outside, traffic
    PLANT_FLOOR = "plant_floor"  # heavy steady industrial noise


def config_for(profile: NoiseProfile) -> VADConfig:
    if profile is NoiseProfile.QUIET:
        return VADConfig(start_threshold=0.45, end_threshold=0.30)
    if profile is NoiseProfile.OFFICE:
        return VADConfig(start_threshold=0.50, end_threshold=0.35)
    if profile is NoiseProfile.MOBILE:
        # More trailing silence so road noise gaps do not cut utterances short.
        return VADConfig(start_threshold=0.60, end_threshold=0.45, end_silence_ms=1800)
    # PLANT_FLOOR: hardest case. Demand strong, sustained speech to trigger.
    return VADConfig(start_threshold=0.70, end_threshold=0.55, start_chunks=3, end_silence_ms=2000)


class VADGate:
    """Hysteresis gate over per-chunk speech probabilities.

    Feed it the Silero VAD probability for each chunk. It emits "speech_start"
    when speech begins and "speech_end" when an utterance completes, so the
    host knows exactly when to flush accumulated audio to the ASR. Pure logic,
    no audio, fully testable.
    """

    def __init__(self, config: VADConfig | None = None):
        self.cfg = config or VADConfig()
        self._speaking = False
        self._above_run = 0
        self._silence_run = 0
        self._end_silence_chunks = max(1, math.ceil(self.cfg.end_silence_ms / self.cfg.chunk_ms))

    def process(self, prob: float) -> str | None:
        if not self._speaking:
            if prob >= self.cfg.start_threshold:
                self._above_run += 1
                if self._above_run >= self.cfg.start_chunks:
                    self._speaking = True
                    self._above_run = 0
                    self._silence_run = 0
                    return "speech_start"
            else:
                self._above_run = 0
            return None

        # Currently speaking: look for sustained silence to end the utterance.
        if prob < self.cfg.end_threshold:
            self._silence_run += 1
            if self._silence_run >= self._end_silence_chunks:
                self._speaking = False
                self._silence_run = 0
                return "speech_end"
        else:
            self._silence_run = 0
        return None

    @property
    def speaking(self) -> bool:
        return self._speaking
