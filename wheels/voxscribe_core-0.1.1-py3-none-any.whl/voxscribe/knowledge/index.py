"""SQLite-backed knowledge index with hybrid retrieval (vector + FTS5)."""

from __future__ import annotations

import hashlib
import sqlite3
import threading
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol


@dataclass
class Hit:
    """One retrieval result."""

    chunk_id: str
    source_id: str
    text: str
    locator: str
    score: float  # composite score


class KnowledgeIndexProtocol(Protocol):
    """Protocol for knowledge index backends (SQLite, PostgreSQL, etc.)."""

    def add_source(
        self,
        source_id: str,
        filename: str,
        mime_type: str,
        chunks_with_vecs: list[tuple[str, str, list[float]]],
    ) -> None:
        """Add a source and chunks to the index."""
        ...

    def replace_source(
        self,
        source_id: str,
        filename: str,
        mime_type: str,
        chunks_with_vecs: list[tuple[str, str, list[float]]],
    ) -> None:
        """Replace a source (idempotent by content hash)."""
        ...

    def remove_source(self, source_id: str) -> None:
        """Remove a source and its chunks."""
        ...

    def list_chunks(
        self, source_id: str | None = None
    ) -> list[tuple[str, str, str, str]]:
        """List chunks: (chunk_id, text, locator, source_id)."""
        ...

    def search(
        self,
        query_vec: list[float],
        query_text: str,
        k: int = 10,
        source_ids: list[str] | None = None,
    ) -> list[Hit]:
        """Search for relevant chunks."""
        ...

    def get_source_filename(self, source_id: str) -> str | None:
        """Get source filename for display."""
        ...


class KnowledgeIndex:
    """SQLite index with brute-force vector search and FTS5 keyword search."""

    def __init__(self, db_path: str | Path | None = None):
        if db_path is None:
            self.conn = sqlite3.connect(":memory:")
        else:
            db_path = Path(db_path)
            db_path.parent.mkdir(parents=True, exist_ok=True)
            self.conn = sqlite3.connect(str(db_path))
        self.lock = threading.RLock()
        self._init_schema()

    def _init_schema(self):
        """Create tables if they don't exist."""
        with self.conn:
            self.conn.execute(
                """
                CREATE TABLE IF NOT EXISTS sources (
                    id TEXT PRIMARY KEY,
                    filename TEXT,
                    mime_type TEXT,
                    content_hash TEXT UNIQUE,
                    created_at TEXT
                )
                """
            )
            self.conn.execute(
                """
                CREATE TABLE IF NOT EXISTS chunks (
                    id TEXT PRIMARY KEY,
                    source_id TEXT NOT NULL,
                    ordinal INTEGER,
                    text TEXT,
                    locator TEXT,
                    created_at TEXT,
                    FOREIGN KEY (source_id) REFERENCES sources(id),
                    UNIQUE(source_id, ordinal)
                )
                """
            )
            self.conn.execute(
                """
                CREATE TABLE IF NOT EXISTS chunk_vectors (
                    chunk_id TEXT PRIMARY KEY,
                    vector BLOB,
                    FOREIGN KEY (chunk_id) REFERENCES chunks(id)
                )
                """
            )
            try:
                self.conn.execute(
                    """
                    CREATE VIRTUAL TABLE IF NOT EXISTS chunk_fts
                    USING fts5(text, locator, chunk_id UNINDEXED)
                    """
                )
            except sqlite3.OperationalError as e:
                if "no such module: fts5" in str(e):
                    raise RuntimeError(
                        "SQLite FTS5 module is required but not available. "
                        "Rebuild SQLite with --enable-fts5 or use a newer SQLite version."
                    ) from e
                raise
            self.conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_chunks_source ON chunks(source_id)"
            )

    @contextmanager
    def transaction(self):
        """Context manager for transactions."""
        with self.lock:
            try:
                yield self.conn
                self.conn.commit()
            except Exception:
                self.conn.rollback()
                raise

    def add_source(
        self,
        source_id: str,
        filename: str,
        mime_type: str,
        chunks_with_vecs: list[tuple[str, str, list[float]]],
    ) -> None:
        """Add a source and its chunks with embeddings.

        chunks_with_vecs: list of (text, locator, embedding_vec)
        """

        text = "".join(text for text, _, _ in chunks_with_vecs)
        content_hash = hashlib.sha256(text.encode()).hexdigest()

        with self.transaction() as conn:
            try:
                conn.execute(
                    """
                    INSERT INTO sources (id, filename, mime_type, content_hash, created_at)
                    VALUES (?, ?, ?, ?, datetime('now'))
                    """,
                    (source_id, filename, mime_type, content_hash),
                )
            except sqlite3.IntegrityError:
                return

            for ordinal, (text, locator, vec) in enumerate(chunks_with_vecs):
                chunk_id = f"{source_id}#{ordinal}"
                conn.execute(
                    """
                    INSERT OR REPLACE INTO chunks
                    (id, source_id, ordinal, text, locator, created_at)
                    VALUES (?, ?, ?, ?, ?, datetime('now'))
                    """,
                    (chunk_id, source_id, ordinal, text, locator),
                )
                vec_bytes = _serialize_vector(vec)
                conn.execute(
                    """
                    INSERT OR REPLACE INTO chunk_vectors (chunk_id, vector)
                    VALUES (?, ?)
                    """,
                    (chunk_id, vec_bytes),
                )
                conn.execute(
                    """
                    INSERT INTO chunk_fts (text, locator, chunk_id)
                    VALUES (?, ?, ?)
                    """,
                    (text, locator, chunk_id),
                )

    def replace_source(
        self,
        source_id: str,
        filename: str,
        mime_type: str,
        chunks_with_vecs: list[tuple[str, str, list[float]]],
    ) -> None:
        """Replace a source (idempotent by content hash)."""
        with self.transaction() as conn:
            conn.execute("DELETE FROM chunks WHERE source_id = ?", (source_id,))
            conn.execute("DELETE FROM sources WHERE id = ?", (source_id,))
        self.add_source(source_id, filename, mime_type, chunks_with_vecs)

    def remove_source(self, source_id: str) -> None:
        """Remove a source and its chunks/vectors."""
        with self.transaction() as conn:
            chunks = conn.execute(
                "SELECT id FROM chunks WHERE source_id = ?", (source_id,)
            ).fetchall()
            for (chunk_id,) in chunks:
                conn.execute("DELETE FROM chunk_vectors WHERE chunk_id = ?", (chunk_id,))
            conn.execute("DELETE FROM chunks WHERE source_id = ?", (source_id,))
            conn.execute("DELETE FROM sources WHERE id = ?", (source_id,))

    def list_chunks(
        self, source_id: str | None = None
    ) -> list[tuple[str, str, str, str]]:
        """List chunks: (chunk_id, text, locator, source_id)."""
        with self.lock:
            if source_id:
                rows = self.conn.execute(
                    """
                    SELECT id, text, locator, source_id FROM chunks
                    WHERE source_id = ? ORDER BY ordinal
                    """,
                    (source_id,),
                ).fetchall()
            else:
                rows = self.conn.execute(
                    "SELECT id, text, locator, source_id FROM chunks ORDER BY source_id, ordinal"
                ).fetchall()
        return rows

    def search(
        self,
        query_vec: list[float],
        query_text: str,
        k: int = 10,
        source_ids: list[str] | None = None,
    ) -> list[Hit]:
        """Hybrid search: cosine similarity + FTS5 BM25, merged by RRF.

        Returns top-k results scored by reciprocal rank fusion.
        """

        with self.lock:
            vec_results = self._vector_search(query_vec, k * 3, source_ids)
            fts_results = self._fts_search(query_text, k * 3, source_ids)

        scores = {}
        for rank, (chunk_id, _score) in enumerate(vec_results):
            scores.setdefault(chunk_id, 0)
            scores[chunk_id] += 1.0 / (rank + 1)

        for rank, (chunk_id, _score) in enumerate(fts_results):
            scores.setdefault(chunk_id, 0)
            scores[chunk_id] += 1.0 / (rank + 1)

        sorted_results = sorted(scores.items(), key=lambda x: -x[1])[:k]

        with self.lock:
            hits = []
            for chunk_id, score in sorted_results:
                row = self.conn.execute(
                    """
                    SELECT c.text, c.locator, c.source_id FROM chunks c
                    WHERE c.id = ?
                    """,
                    (chunk_id,),
                ).fetchone()
                if row:
                    text, locator, source_id = row
                    hits.append(
                        Hit(
                            chunk_id=chunk_id,
                            source_id=source_id,
                            text=text,
                            locator=locator,
                            score=score,
                        )
                    )

        return hits

    def _vector_search(
        self,
        query_vec: list[float],
        limit: int,
        source_ids: list[str] | None = None,
    ) -> list[tuple[str, float]]:
        """Brute-force cosine similarity."""
        with self.lock:
            if source_ids:
                placeholders = ",".join("?" * len(source_ids))
                rows = self.conn.execute(
                    f"""
                    SELECT c.id, cv.vector FROM chunks c
                    JOIN chunk_vectors cv ON c.id = cv.chunk_id
                    WHERE c.source_id IN ({placeholders})
                    """,
                    source_ids,
                ).fetchall()
            else:
                rows = self.conn.execute(
                    """
                    SELECT c.id, cv.vector FROM chunks c
                    JOIN chunk_vectors cv ON c.id = cv.chunk_id
                    """
                ).fetchall()

        results = []
        for chunk_id, vec_bytes in rows:
            vec = _deserialize_vector(vec_bytes)
            score = _cosine_sim(query_vec, vec)
            results.append((chunk_id, score))

        results.sort(key=lambda x: -x[1])
        return results[:limit]

    def _fts_search(
        self, query_text: str, limit: int, source_ids: list[str] | None = None
    ) -> list[tuple[str, float]]:
        """Full-text search using FTS5 BM25 ranking."""
        import re

        sanitized_query = re.sub(r'[^\w\s]', ' ', query_text)

        with self.lock:
            if source_ids:
                placeholders = ",".join("?" * len(source_ids))
                rows = self.conn.execute(
                    f"""
                    SELECT fts.chunk_id, rank
                    FROM chunk_fts fts
                    JOIN chunks c ON fts.chunk_id = c.id
                    WHERE fts.text MATCH ?
                      AND c.source_id IN ({placeholders})
                    ORDER BY rank
                    LIMIT ?
                    """,
                    [sanitized_query, *source_ids, limit],
                ).fetchall()
            else:
                rows = self.conn.execute(
                    """
                    SELECT chunk_id, rank
                    FROM chunk_fts
                    WHERE chunk_fts MATCH ?
                    ORDER BY rank
                    LIMIT ?
                    """,
                    (sanitized_query, limit),
                ).fetchall()

        return [(chunk_id, rank) for chunk_id, rank in rows]

    def get_source_filename(self, source_id: str) -> str | None:
        """Get source filename for display."""
        with self.lock:
            row = self.conn.execute(
                "SELECT filename FROM sources WHERE id = ?", (source_id,)
            ).fetchone()
        return row[0] if row else None

    def close(self):
        """Close the database connection."""
        self.conn.close()


def _serialize_vector(vec: list[float]) -> bytes:
    """Serialize vector to bytes."""
    import struct

    return struct.pack(f"{len(vec)}f", *vec)


def _deserialize_vector(data: bytes) -> list[float]:
    """Deserialize vector from bytes."""
    import struct

    return list(struct.unpack(f"{len(data) // 4}f", data))


def _cosine_sim(a: list[float], b: list[float]) -> float:
    """Cosine similarity."""
    import math

    dot = sum(x * y for x, y in zip(a, b, strict=True))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(x * x for x in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)
