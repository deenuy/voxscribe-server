"""Embedding provider protocol and implementations.

Two providers:
  FakeEmbeddingProvider    deterministic hashed bag-of-words for testing
  OllamaEmbeddingProvider  local inference via Ollama
"""

from __future__ import annotations

import hashlib
import json
import logging
import math
import urllib.error
import urllib.request
from typing import Protocol

from ..logging_config import get_logger, log_event

log = get_logger("voxscribe.knowledge.embeddings")


class ProviderUnavailable(RuntimeError):
    """Raised when a provider is unreachable or fails."""

    pass


class EmbeddingProvider(Protocol):
    """Minimal contract every embedding provider honors."""

    @property
    def dim(self) -> int:
        """Embedding dimension."""
        ...

    @property
    def name(self) -> str:
        """Provider name for diagnostics."""
        ...

    def embed(self, texts: list[str]) -> list[list[float]]:
        """Embed a list of strings to normalized vectors."""
        ...


class FakeEmbeddingProvider:
    """Deterministic embedding via hashed bag-of-words.

    Tokenizes on whitespace, hashes each token to a fixed-size vector,
    sums them, and normalizes. Same text always produces same embedding;
    similar texts score higher on cosine similarity.
    """

    def __init__(self, dim: int = 384):
        self._dim = dim

    @property
    def dim(self) -> int:
        return self._dim

    @property
    def name(self) -> str:
        return f"fake:bag-of-words:{self._dim}"

    def embed(self, texts: list[str]) -> list[list[float]]:
        """Embed texts deterministically."""
        embeddings = []
        for text in texts:
            tokens = text.lower().split()
            vec = [0.0] * self._dim
            seen_tokens = set()

            for token in tokens:
                if token in seen_tokens:
                    continue
                seen_tokens.add(token)

                h = hashlib.sha256(token.encode()).digest()
                for i in range(self._dim):
                    byte_val = h[i % len(h)]
                    vec[i] += (byte_val / 256.0) - 0.5

            norm = math.sqrt(sum(v * v for v in vec))
            if norm > 0:
                vec = [v / norm for v in vec]
            else:
                vec = [1.0 / math.sqrt(self._dim)] * self._dim
            embeddings.append(vec)
        return embeddings


class OllamaEmbeddingProvider:
    """Local embedding via Ollama.

    Posts to /api/embed on an Ollama instance. Raises ProviderUnavailable
    if Ollama is unreachable or the model is not found.
    """

    def __init__(
        self,
        model: str = "nomic-embed-text",
        host: str = "http://localhost:11434",
        timeout: float = 30.0,
    ):
        self.model = model
        self.url = f"{host.rstrip('/')}/api/embed"
        self.timeout = timeout
        self._dim = None
        log_event(
            log,
            "embedding_provider_selected",
            provider="ollama",
            model=model,
        )

    @property
    def dim(self) -> int:
        if self._dim is None:
            test_vec = self.embed(["test"])
            if test_vec and test_vec[0]:
                self._dim = len(test_vec[0])
        return self._dim or 384

    @property
    def name(self) -> str:
        return f"ollama:{self.model}"

    def embed(self, texts: list[str]) -> list[list[float]]:
        """Embed texts via Ollama."""
        embeddings = []
        for text in texts:
            body = {"model": self.model, "input": text}
            data = json.dumps(body).encode("utf-8")
            req = urllib.request.Request(
                self.url,
                data=data,
                headers={"Content-Type": "application/json"},
            )
            log_event(
                log,
                "embedding_call_started",
                level=logging.DEBUG,
                model=self.model,
                text_len=len(text),
            )
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                    payload = json.loads(resp.read().decode("utf-8"))
            except urllib.error.HTTPError as exc:
                if exc.code == 404:
                    log_event(
                        log,
                        "embedding_api_not_found",
                        level=logging.DEBUG,
                        model=self.model,
                    )
                    raise ProviderUnavailable(
                        "Ollama /api/embed not found. Upgrade Ollama."
                    ) from exc
                raise ProviderUnavailable(
                    f"Ollama error: {exc.code} {exc.reason}"
                ) from exc
            except urllib.error.URLError as exc:
                log_event(
                    log,
                    "embedding_call_failed",
                    level=logging.WARNING,
                    model=self.model,
                    reason=type(exc).__name__,
                )
                raise ProviderUnavailable(
                    f"Ollama unreachable at {self.url}. Is `ollama serve` running?"
                ) from exc

            embeddings_list = payload.get("embeddings", [])
            if not embeddings_list:
                raise ProviderUnavailable(
                    f"Ollama returned no embeddings for model '{self.model}'"
                )

            vec = (
                embeddings_list[0]
                if isinstance(embeddings_list[0], list)
                else embeddings_list
            )
            norm = math.sqrt(sum(v * v for v in vec))
            if norm > 0:
                vec = [v / norm for v in vec]
            embeddings.append(vec)
            log_event(
                log,
                "embedding_call_completed",
                level=logging.DEBUG,
                model=self.model,
                dim=len(vec),
            )

        return embeddings
