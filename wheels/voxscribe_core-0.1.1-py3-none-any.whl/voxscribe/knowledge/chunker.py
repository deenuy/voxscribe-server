"""Structure-aware chunking for different file types.

Each chunk carries a locator (e.g., "## Heading", "p.3", "Sheet1!A1:F20")
so retrieved context can point back to the source.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class Chunk:
    """One piece of text with location context."""

    text: str
    locator: str  # e.g., "## Heading", "p.3", "Sheet1!A1:F20"
    token_approx: int = 0  # approximate word count


def chunk_markdown(text: str, target_tokens: int = 512, overlap: int = 50) -> list[Chunk]:
    """Chunk markdown, respecting headings.

    Headings become part of the locator so context retrieval can point back.
    """
    lines = text.split("\n")
    chunks = []
    current_heading = ""
    current_text = []
    current_tokens = 0

    for line in lines:
        if line.startswith("#"):
            if current_text and current_tokens > 0:
                text_joined = "\n".join(current_text)
                chunks.append(
                    Chunk(
                        text=text_joined,
                        locator=current_heading,
                        token_approx=current_tokens,
                    )
                )
                current_text = current_text[-overlap:] if overlap > 0 else []
                current_tokens = len(" ".join(current_text).split())

            current_heading = line.strip()
            current_text = [current_heading]
            current_tokens = len(current_heading.split())
        else:
            current_text.append(line)
            current_tokens += len(line.split())
            if current_tokens >= target_tokens:
                text_joined = "\n".join(current_text)
                chunks.append(
                    Chunk(
                        text=text_joined,
                        locator=current_heading,
                        token_approx=current_tokens,
                    )
                )
                current_text = current_text[-overlap:] if overlap > 0 else []
                current_tokens = len(" ".join(current_text).split())

    if current_text:
        text_joined = "\n".join(current_text)
        chunks.append(
            Chunk(
                text=text_joined,
                locator=current_heading or "document",
                token_approx=current_tokens,
            )
        )

    return chunks


def chunk_plain_text(text: str, target_tokens: int = 512, overlap: int = 50) -> list[Chunk]:
    """Chunk plain text into fixed-size pieces.

    The overlap is capped at a quarter of the chunk size so the window always
    moves forward (an overlap at or above the chunk size would never advance).
    """
    if target_tokens < 1:
        raise ValueError("target_tokens must be at least 1")
    overlap = max(0, min(overlap, target_tokens // 4))
    words = text.split()
    chunks = []
    i = 0
    while i < len(words):
        chunk_words = words[i : i + target_tokens]
        chunk_text = " ".join(chunk_words)
        chunks.append(
            Chunk(
                text=chunk_text,
                locator=f"line {i // target_tokens + 1}",
                token_approx=len(chunk_words),
            )
        )
        i += target_tokens - overlap

    return chunks


def chunk_csv(
    text: str, target_tokens: int = 512, overlap: int = 50, headers: bool = True
) -> list[Chunk]:
    """Chunk CSV, keeping rows together with repeated headers."""
    lines = text.split("\n")
    if not lines:
        return []

    header_line = lines[0] if headers else ""
    chunks = []
    current_chunk = []
    current_tokens = len(header_line.split()) if headers else 0

    for i, line in enumerate(lines[1:] if headers else lines, start=1):
        if not line.strip():
            continue
        line_tokens = len(line.split())
        if current_tokens + line_tokens >= target_tokens and current_chunk:
            chunk_text = "\n".join([header_line] + current_chunk) if headers else "\n".join(
                current_chunk
            )
            chunks.append(
                Chunk(
                    text=chunk_text,
                    locator=f"rows {i - len(current_chunk)}-{i}",
                    token_approx=current_tokens,
                )
            )
            current_chunk = []
            current_tokens = len(header_line.split()) if headers else 0

        current_chunk.append(line)
        current_tokens += line_tokens

    if current_chunk:
        chunk_text = "\n".join([header_line] + current_chunk) if headers else "\n".join(
            current_chunk
        )
        chunks.append(
            Chunk(
                text=chunk_text,
                locator=f"rows {len(lines) - len(current_chunk)}-{len(lines)}",
                token_approx=current_tokens,
            )
        )

    return chunks


def chunk_html(text: str, target_tokens: int = 512, overlap: int = 50) -> list[Chunk]:
    """Chunk HTML, tracking context from tags.

    Simple heuristic: extract text from common tags, keep tag context.
    """
    import re

    chunks = []
    current_text = []
    current_tokens = 0
    current_context = ""

    tag_pattern = r"<(h[1-6]|p|div|section)>(.+?)</\1>"
    for match in re.finditer(tag_pattern, text, re.DOTALL | re.IGNORECASE):
        tag = match.group(1).lower()
        content = match.group(2)
        content = re.sub(r"<[^>]+>", "", content)
        content = content.strip()

        if tag.startswith("h"):
            if current_text and current_tokens > 0:
                chunk_str = "\n".join(current_text)
                chunks.append(
                    Chunk(
                        text=chunk_str,
                        locator=current_context,
                        token_approx=current_tokens,
                    )
                )
                current_text = []
                current_tokens = 0
            current_context = content
        else:
            current_text.append(content)
            current_tokens += len(content.split())

            if current_tokens >= target_tokens:
                chunk_str = "\n".join(current_text)
                chunks.append(
                    Chunk(
                        text=chunk_str,
                        locator=current_context,
                        token_approx=current_tokens,
                    )
                )
                current_text = []
                current_tokens = 0

    if current_text and current_tokens > 0:
        chunk_str = "\n".join(current_text)
        chunks.append(
            Chunk(
                text=chunk_str,
                locator=current_context or "document",
                token_approx=current_tokens,
            )
        )

    return chunks
