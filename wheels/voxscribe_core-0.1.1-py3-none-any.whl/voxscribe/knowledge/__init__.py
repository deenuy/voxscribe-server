"""Knowledge subpackage: retrieval, ingestion, grounded Q&A.

Product-agnostic embedding, chunking, parsing, indexing, and retrieval.
"""

from .answer import AnswerComposer, Citation
from .chunker import Chunk, chunk_csv, chunk_html, chunk_markdown, chunk_plain_text
from .embeddings import EmbeddingProvider, FakeEmbeddingProvider, OllamaEmbeddingProvider
from .embeddings import ProviderUnavailable as EmbeddingProviderUnavailable
from .index import Hit, KnowledgeIndex, KnowledgeIndexProtocol
from .ingest import ingest_path, scan_folder
from .llm_stream import (
    FakeStreamingLLM,
    OllamaStreamingLLM,
    StreamingLLMProvider,
)
from .llm_stream import ProviderUnavailable as LLMProviderUnavailable
from .parsers import (
    MissingOptionalDependency,
    ParsedDocument,
    UnsupportedFileType,
    parse,
)
from .retriever import RetrievedChunk, Retriever

__all__ = [
    "AnswerComposer",
    "Chunk",
    "Citation",
    "EmbeddingProvider",
    "EmbeddingProviderUnavailable",
    "FakeEmbeddingProvider",
    "FakeStreamingLLM",
    "Hit",
    "KnowledgeIndex",
    "KnowledgeIndexProtocol",
    "LLMProviderUnavailable",
    "MissingOptionalDependency",
    "OllamaEmbeddingProvider",
    "OllamaStreamingLLM",
    "ParsedDocument",
    "ProviderUnavailable",
    "RetrievedChunk",
    "Retriever",
    "StreamingLLMProvider",
    "UnsupportedFileType",
    "chunk_csv",
    "chunk_html",
    "chunk_markdown",
    "chunk_plain_text",
    "ingest_path",
    "parse",
    "scan_folder",
]
