"""Streaming LLM provider protocol and implementations.

Providers stream tokens one at a time for grounded Q&A and other tasks
where incremental output is useful.
"""

from __future__ import annotations

import json
import logging
import urllib.error
import urllib.request
from collections.abc import Iterator
from typing import Protocol

from ..logging_config import get_logger, log_event

log = get_logger("voxscribe.knowledge.llm_stream")


class ProviderUnavailable(RuntimeError):
    """Raised when a provider is unreachable or fails."""

    pass


class StreamingLLMProvider(Protocol):
    """Protocol for streaming LLM providers."""

    @property
    def name(self) -> str:
        """Provider name for diagnostics."""
        ...

    def stream(
        self,
        system: str,
        prompt: str,
        max_tokens: int = 2048,
    ) -> Iterator[str]:
        """Stream tokens from the LLM. Each yield is a single token.

        Raises ProviderUnavailable if the provider is unreachable.
        """
        ...


class FakeStreamingLLM:
    """Deterministic streaming LLM for testing.

    Returns a fixed response token by token.
    """

    def __init__(self, response: str = "No information found."):
        self.response = response

    @property
    def name(self) -> str:
        return "fake:streaming"

    def stream(
        self,
        system: str,
        prompt: str,
        max_tokens: int = 2048,
    ) -> Iterator[str]:
        """Yield tokens from the fixed response."""
        words = self.response.split()
        for word in words:
            yield word + " "


class OllamaStreamingLLM:
    """Local streaming LLM via Ollama.

    Posts to /api/generate with stream=true. Raises ProviderUnavailable
    if Ollama is unreachable or the model is not found.
    """

    def __init__(
        self,
        model: str = "gemma4:e4b",
        host: str = "http://localhost:11434",
        temperature: float = 0.3,
        timeout: float = 300.0,
    ):
        self.model = model
        self.url = f"{host.rstrip('/')}/api/generate"
        self.temperature = temperature
        self.timeout = timeout
        log_event(
            log,
            "llm_provider_selected",
            provider="ollama",
            model=model,
        )

    @property
    def name(self) -> str:
        return f"ollama:{self.model}"

    def stream(
        self,
        system: str,
        prompt: str,
        max_tokens: int = 2048,
    ) -> Iterator[str]:
        """Stream tokens from Ollama."""
        body = {
            "model": self.model,
            "system": system,
            "prompt": prompt,
            "stream": True,
            "options": {
                "temperature": self.temperature,
                "top_p": 0.9,
                "num_predict": max_tokens,
            },
        }
        data = json.dumps(body).encode("utf-8")
        req = urllib.request.Request(
            self.url,
            data=data,
            headers={"Content-Type": "application/json"},
        )
        log_event(
            log,
            "llm_stream_started",
            level=logging.DEBUG,
            model=self.model,
            prompt_chars=len(prompt),
            max_tokens=max_tokens,
        )
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                for line in resp:
                    payload = json.loads(line.decode("utf-8"))
                    token = payload.get("response", "")
                    if token:
                        yield token
                    log_event(
                        log,
                        "llm_stream_chunk",
                        level=logging.DEBUG,
                        model=self.model,
                        done=payload.get("done", False),
                    )
        except urllib.error.URLError as exc:
            log_event(
                log,
                "llm_stream_failed",
                level=logging.WARNING,
                model=self.model,
                reason=type(exc).__name__,
            )
            raise ProviderUnavailable(
                f"Ollama unreachable at {self.url}. Is `ollama serve` running "
                f"and is model '{self.model}' pulled?"
            ) from exc
