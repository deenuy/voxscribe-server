"""Grounded Q&A composer using retrieval."""

from __future__ import annotations

from collections.abc import Iterator
from dataclasses import dataclass

from .llm_stream import StreamingLLMProvider
from .retriever import Retriever


@dataclass
class Citation:
    """Citation reference to a source or transcript."""

    kind: str  # "source" or "transcript"
    source_id: str | None = None
    chunk_id: str | None = None
    title: str | None = None
    locator: str | None = None
    segment_id: str | None = None
    start_ms: int | None = None
    end_ms: int | None = None

    def to_dict(self) -> dict:
        """Convert to contract Citation shape."""
        if self.kind == "source":
            return {
                "kind": "source",
                "sourceId": self.source_id,
                "chunkId": self.chunk_id,
                "title": self.title,
                "locator": self.locator,
            }
        else:
            return {
                "kind": "transcript",
                "segmentId": self.segment_id,
                "startMs": self.start_ms,
                "endMs": self.end_ms,
            }


class AnswerComposer:
    """Grounded Q&A over retrieved context."""

    def __init__(
        self,
        llm: StreamingLLMProvider,
        retriever: Retriever,
        min_score_threshold: float = 0.3,
        max_context_tokens: int = 2000,
        min_overlap: float = 0.3,
        min_query_terms_covered: int = 1,
        cosine_rel_threshold: float = 0.2,
        use_fake_embedder: bool = False,
    ):
        self.llm = llm
        self.retriever = retriever
        self.min_score_threshold = min_score_threshold
        self.max_context_tokens = max_context_tokens
        # Tuned defaults for fake vs real embedders
        if use_fake_embedder:
            self.min_overlap = 0.5
            self.min_query_terms_covered = 2
            self.cosine_rel_threshold = 0.3
        else:
            self.min_overlap = min_overlap
            self.min_query_terms_covered = min_query_terms_covered
            self.cosine_rel_threshold = cosine_rel_threshold

    def _get_stop_words(self) -> set:
        """Common English stop words for query term coverage calculation."""
        return {
            "a", "an", "and", "are", "as", "at", "be", "by", "do", "for",
            "from", "has", "he", "how", "i", "in", "is", "it", "no", "of",
            "on", "or", "so", "the", "to", "up", "was", "what", "when",
            "where", "why", "will", "with", "you"
        }

    def _count_query_terms_covered(self, query: str, text: str) -> int:
        """Count how many non-stop-word query terms appear in text."""
        stop_words = self._get_stop_words()
        query_words = {w.lower() for w in query.split() if w.lower() not in stop_words}
        text_words = {w.lower() for w in text.lower().split()}
        covered = query_words & text_words
        return len(covered)

    def _has_query_overlap(self, query: str, text: str) -> float:
        """Check fraction of query terms that appear in text."""
        query_words = set(query.lower().split())
        text_words = set(text.lower().split())
        overlap = len(query_words & text_words)
        return overlap / len(query_words) if query_words else 0.0

    def stream(
        self,
        query: str,
        scope_source_ids: list[str] | None = None,
    ) -> tuple[Iterator[str], list[Citation]]:
        """Stream answer tokens and return citations.

        Returns: (token_iterator, citations)

        Uses combined signals (score distribution, lexical overlap, query term coverage)
        to decide whether sources are grounded. If no good sources found, returns
        a "no source found" message without calling the LLM.
        """
        chunks = self.retriever.retrieve(
            query, k=5, scope_source_ids=scope_source_ids
        )

        if not chunks:
            citations = []

            def no_source_gen():
                yield "I could not find relevant sources for that question."

            return no_source_gen(), citations

        best_score = chunks[0].score
        rest_scores = [c.score for c in chunks[1:]] if len(chunks) > 1 else []
        avg_rest = sum(rest_scores) / len(rest_scores) if rest_scores else 0.0

        best_overlap = max(
            (self._has_query_overlap(query, c.text) for c in chunks),
            default=0.0,
        )

        best_terms_covered = max(
            (self._count_query_terms_covered(query, c.text) for c in chunks),
            default=0,
        )

        cosine_rel = (best_score - avg_rest) / max(best_score, 0.001)

        has_score_signal = best_score >= self.min_score_threshold
        has_overlap_signal = best_overlap >= self.min_overlap
        has_terms_signal = best_terms_covered >= self.min_query_terms_covered
        has_cosine_signal = cosine_rel >= self.cosine_rel_threshold

        signals_met = sum(
            [has_score_signal, has_overlap_signal, has_terms_signal,
             has_cosine_signal]
        )

        if signals_met < 2:
            citations = []

            def no_source_gen():
                yield "I could not find relevant sources for that question."

            return no_source_gen(), citations

        context_text = ""
        context_tokens = 0
        used_chunks = []

        for i, chunk in enumerate(chunks, start=1):
            chunk_tokens = len(chunk.text.split())
            if context_tokens + chunk_tokens > self.max_context_tokens:
                break
            context_text += f"\n[{i}] {chunk.title} ({chunk.locator}):\n{chunk.text}\n"
            context_tokens += chunk_tokens
            used_chunks.append(chunk)

        system_prompt = (
            "You are a helpful assistant answering questions based on provided context. "
            "Cite your sources by referencing the [1], [2], etc. numbers in the text. "
            "If the context does not contain relevant information, say so."
        )

        user_prompt = f"Context:\n{context_text}\n\nQuestion: {query}"

        citations = [
            Citation(
                kind="source",
                source_id=chunk.source_id,
                chunk_id=chunk.chunk_id,
                title=chunk.title,
                locator=chunk.locator,
            )
            for chunk in used_chunks
        ]

        token_stream = self.llm.stream(system_prompt, user_prompt)

        return token_stream, citations
