"""Retriever for knowledge base queries."""

from __future__ import annotations

from dataclasses import dataclass

from .embeddings import EmbeddingProvider
from .index import KnowledgeIndex


@dataclass
class RetrievedChunk:
    """One retrieved result with full metadata."""

    chunk_id: str
    source_id: str
    title: str  # filename
    text: str
    locator: str
    score: float


class Retriever:
    """Retriever for knowledge queries."""

    def __init__(self, index: KnowledgeIndex, embedder: EmbeddingProvider):
        self.index = index
        self.embedder = embedder

    def retrieve(
        self,
        query: str,
        k: int = 5,
        scope_source_ids: list[str] | None = None,
    ) -> list[RetrievedChunk]:
        """Retrieve relevant chunks for a query.

        Args:
            query: user query text
            k: number of results
            scope_source_ids: if provided, search only these sources

        Returns:
            list of RetrievedChunk sorted by score descending
        """
        query_vec = self.embedder.embed([query])[0]
        hits = self.index.search(
            query_vec=query_vec,
            query_text=query,
            k=k,
            source_ids=scope_source_ids,
        )

        results = []
        for hit in hits:
            source_row = self.index.conn.execute(
                "SELECT filename FROM sources WHERE id = ?", (hit.source_id,)
            ).fetchone()
            title = source_row[0] if source_row else "unknown"

            results.append(
                RetrievedChunk(
                    chunk_id=hit.chunk_id,
                    source_id=hit.source_id,
                    title=title,
                    text=hit.text,
                    locator=hit.locator,
                    score=hit.score,
                )
            )

        return results
