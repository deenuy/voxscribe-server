"""Document ingestion pipeline: parse, chunk, embed, store."""

from __future__ import annotations

import hashlib
from collections.abc import Callable
from pathlib import Path

from .chunker import chunk_csv, chunk_html, chunk_markdown, chunk_plain_text
from .embeddings import EmbeddingProvider
from .index import KnowledgeIndex
from .parsers import ParsedDocument, parse


def scan_folder(
    folder_path: str | Path,
    ignore_patterns: list[str] | None = None,
    max_file_size_mb: int = 100,
) -> list[Path]:
    """Scan folder for documents, respecting ignore rules.

    Default ignores: .git, node_modules, hidden files (.*), large files.
    """
    import fnmatch

    if ignore_patterns is None:
        ignore_patterns = [
            ".git",
            "node_modules",
            ".venv",
            ".env",
            ".*",
        ]

    folder = Path(folder_path)
    files = []

    for path in folder.rglob("*"):
        if not path.is_file():
            continue

        rel_path = path.relative_to(folder)
        if any(
            fnmatch.fnmatch(part, pattern)
            for pattern in ignore_patterns
            for part in rel_path.parts
        ):
            continue

        if path.stat().st_size > max_file_size_mb * 1024 * 1024:
            continue

        files.append(path)

    return files


def ingest_path(
    index: KnowledgeIndex,
    embedder: EmbeddingProvider,
    path: str | Path,
    on_progress: Callable[[str, int, int], None] | None = None,
) -> tuple[str, int]:
    """Ingest a file or folder into the index.

    Returns: (source_id, chunk_count)
    on_progress: called as (source_id, current, total)
    """
    path = Path(path)
    source_id = hashlib.sha256(str(path).encode()).hexdigest()[:16]

    if path.is_file():
        return _ingest_file(index, embedder, path, source_id, on_progress)
    else:
        return _ingest_folder(index, embedder, path, on_progress)


def _ingest_file(
    index: KnowledgeIndex,
    embedder: EmbeddingProvider,
    path: Path,
    source_id: str,
    on_progress: Callable[[str, int, int], None] | None = None,
) -> tuple[str, int]:
    """Ingest a single file."""
    parsed = parse(path)
    chunks = _chunk_parsed_document(parsed)

    if on_progress:
        on_progress(source_id, 0, len(chunks))

    texts = [chunk.text for chunk in chunks]
    embeddings = embedder.embed(texts)

    chunks_with_vecs = [
        (chunk.text, chunk.locator, emb)
        for chunk, emb in zip(chunks, embeddings, strict=True)
    ]

    index.add_source(
        source_id=source_id,
        filename=path.name,
        mime_type=parsed.mime_type,
        chunks_with_vecs=chunks_with_vecs,
    )

    if on_progress:
        on_progress(source_id, len(chunks), len(chunks))

    return source_id, len(chunks)


def _ingest_folder(
    index: KnowledgeIndex,
    embedder: EmbeddingProvider,
    folder: Path,
    on_progress: Callable[[str, int, int], None] | None = None,
) -> tuple[str, int]:
    """Ingest all files in a folder."""
    files = scan_folder(folder)
    total_chunks = 0
    folder_id = hashlib.sha256(str(folder).encode()).hexdigest()[:16]

    for file_path in files:
        try:
            source_id, count = _ingest_file(
                index, embedder, file_path, None, on_progress
            )
            total_chunks += count
        except Exception:
            pass

    return folder_id, total_chunks


def _chunk_parsed_document(parsed: ParsedDocument):
    """Chunk a parsed document based on its MIME type."""
    mime = (parsed.mime_type or "").lower()

    if "markdown" in mime or "md" in parsed.filename.lower():
        return chunk_markdown(parsed.text)
    elif "csv" in mime:
        return chunk_csv(parsed.text)
    elif "html" in mime:
        return chunk_html(parsed.text)
    else:
        return chunk_plain_text(parsed.text)
