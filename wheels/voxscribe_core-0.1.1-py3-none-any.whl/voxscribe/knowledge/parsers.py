"""Document parsers for different file types.

Supports: md, txt, csv, html, docx (via zipfile+xml), pdf/xlsx if optional
deps are installed. Returns ParsedDocument with text blocks and locators.
"""

from __future__ import annotations

import csv
import io
import re
import zipfile
from dataclasses import dataclass
from html.parser import HTMLParser
from pathlib import Path
from typing import Protocol


class MissingOptionalDependency(RuntimeError):
    """Raised when an optional dependency is missing."""

    pass


class UnsupportedFileType(RuntimeError):
    """Raised for unsupported file types."""

    pass


class ImageCaptioner(Protocol):
    """Optional provider for image captions."""

    def caption(self, image_path: str) -> str:
        """Return a caption for an image."""
        ...


@dataclass
class ParsedDocument:
    """Result of parsing a document."""

    filename: str
    mime_type: str
    text: str  # concatenated text of all blocks
    blocks: list[tuple[str, str]]  # (locator, text) pairs


def _get_mime_type(path: str | Path | bytes) -> str:
    """Infer MIME type from path or extension."""
    if isinstance(path, bytes):
        return "application/octet-stream"
    path_str = str(path).lower()
    ext_map = {
        ".md": "text/markdown",
        ".txt": "text/plain",
        ".csv": "text/csv",
        ".html": "text/html",
        ".htm": "text/html",
        ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        ".pdf": "application/pdf",
        ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".gif": "image/gif",
    }
    for ext, mime in ext_map.items():
        if path_str.endswith(ext):
            return mime
    return "application/octet-stream"


def parse(
    path_or_bytes: str | Path | bytes,
    mime_or_ext: str | None = None,
    image_captioner: ImageCaptioner | None = None,
) -> ParsedDocument:
    """Parse a document and return structured text with locators."""
    if isinstance(path_or_bytes, bytes):
        data = path_or_bytes
        mime = mime_or_ext or "application/octet-stream"
        filename = "document"
    else:
        path = Path(path_or_bytes)
        filename = path.name
        data = path.read_bytes()
        mime = mime_or_ext or _get_mime_type(path)

    mime_lower = (mime or "").lower()

    if "markdown" in mime_lower or mime_lower == "text/markdown" or filename.endswith(".md"):
        return _parse_markdown(data, filename)
    elif "plain" in mime_lower or mime_lower == "text/plain" or filename.endswith(".txt"):
        return _parse_text(data, filename)
    elif "csv" in mime_lower or filename.endswith(".csv"):
        return _parse_csv(data, filename)
    elif "html" in mime_lower or filename.endswith((".html", ".htm")):
        return _parse_html(data, filename)
    elif "docx" in mime_lower or filename.endswith(".docx"):
        return _parse_docx(data, filename)
    elif "pdf" in mime_lower or filename.endswith(".pdf"):
        return _parse_pdf(data, filename)
    elif "spreadsheet" in mime_lower or filename.endswith(".xlsx"):
        return _parse_xlsx(data, filename)
    elif "image" in mime_lower or filename.endswith(
        (".png", ".jpg", ".jpeg", ".gif", ".webp")
    ):
        return _parse_image(filename, image_captioner)
    else:
        raise UnsupportedFileType(f"Unsupported file type: {mime} ({filename})")


def _parse_markdown(data: bytes, filename: str) -> ParsedDocument:
    """Parse Markdown."""
    text = data.decode("utf-8", errors="replace")
    blocks = [(filename, text)]
    return ParsedDocument(
        filename=filename,
        mime_type="text/markdown",
        text=text,
        blocks=blocks,
    )


def _parse_text(data: bytes, filename: str) -> ParsedDocument:
    """Parse plain text."""
    text = data.decode("utf-8", errors="replace")
    blocks = [(filename, text)]
    return ParsedDocument(
        filename=filename,
        mime_type="text/plain",
        text=text,
        blocks=blocks,
    )


def _parse_csv(data: bytes, filename: str) -> ParsedDocument:
    """Parse CSV with header rows."""
    text_data = data.decode("utf-8", errors="replace")
    reader = csv.reader(io.StringIO(text_data))
    rows = list(reader)
    text = "\n".join(",".join(row) for row in rows)
    blocks = [(filename, text)]
    return ParsedDocument(
        filename=filename,
        mime_type="text/csv",
        text=text,
        blocks=blocks,
    )


def _parse_html(data: bytes, filename: str) -> ParsedDocument:
    """Parse HTML, extracting text from common tags."""

    class HTMLExtractor(HTMLParser):
        def __init__(self):
            super().__init__()
            self.text_parts = []
            self.current_tag = None

        def handle_starttag(self, tag, attrs):
            if tag in ("h1", "h2", "h3", "h4", "h5", "h6"):
                self.current_tag = tag

        def handle_data(self, data):
            text = data.strip()
            if text:
                self.text_parts.append(text)

        def handle_endtag(self, tag):
            if tag in ("p", "div", "h1", "h2", "h3", "h4", "h5", "h6"):
                self.text_parts.append("\n")

    html_text = data.decode("utf-8", errors="replace")
    extractor = HTMLExtractor()
    extractor.feed(html_text)
    text = "".join(extractor.text_parts)
    blocks = [(filename, text)]
    return ParsedDocument(
        filename=filename,
        mime_type="text/html",
        text=text,
        blocks=blocks,
    )


def _parse_docx(data: bytes, filename: str) -> ParsedDocument:
    """Parse DOCX (Office Open XML)."""
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            xml_content = zf.read("word/document.xml").decode("utf-8", errors="replace")
    except Exception:
        xml_content = ""

    text = re.sub(r"<[^>]+>", "", xml_content)
    text = re.sub(r"\s+", " ", text).strip()
    blocks = [(filename, text)]
    return ParsedDocument(
        filename=filename,
        mime_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        text=text,
        blocks=blocks,
    )


def _parse_pdf(data: bytes, filename: str) -> ParsedDocument:
    """Parse PDF. Requires pypdf extra."""
    try:
        from pypdf import PdfReader
    except ImportError as exc:
        raise MissingOptionalDependency(
            "PDF parsing requires pypdf. Install: uv add pypdf"
        ) from exc

    try:
        reader = PdfReader(io.BytesIO(data))
        blocks = []
        for page_num, page in enumerate(reader.pages, start=1):
            text = page.extract_text()
            blocks.append((f"p.{page_num}", text))
        full_text = "\n".join(text for _, text in blocks)
    except Exception:
        full_text = ""
        blocks = [(filename, "")]

    return ParsedDocument(
        filename=filename,
        mime_type="application/pdf",
        text=full_text,
        blocks=blocks,
    )


def _parse_xlsx(data: bytes, filename: str) -> ParsedDocument:
    """Parse XLSX. Requires openpyxl extra."""
    try:
        from openpyxl import load_workbook
    except ImportError as exc:
        raise MissingOptionalDependency(
            "XLSX parsing requires openpyxl. Install: uv add openpyxl"
        ) from exc

    try:
        wb = load_workbook(io.BytesIO(data))
        blocks = []
        for sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            rows = []
            for row in ws.iter_rows(values_only=True):
                row_text = "\t".join(str(v or "") for v in row)
                rows.append(row_text)
            sheet_text = "\n".join(rows)
            blocks.append((sheet_name, sheet_text))
        full_text = "\n".join(text for _, text in blocks)
    except Exception:
        full_text = ""
        blocks = [(filename, "")]

    return ParsedDocument(
        filename=filename,
        mime_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        text=full_text,
        blocks=blocks,
    )


def _parse_image(filename: str, captioner: ImageCaptioner | None) -> ParsedDocument:
    """Parse image (by filename and optional caption)."""
    caption = captioner.caption(filename) if captioner else ""
    text = f"{filename} {caption}".strip()
    blocks = [(filename, text)]
    return ParsedDocument(
        filename=filename,
        mime_type=_get_mime_type(filename),
        text=text,
        blocks=blocks,
    )
