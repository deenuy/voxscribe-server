"""Resource resolver: provides packaged resources with backward-compatible
fallback to file-system overrides in the current working directory.

Resources (config, prompts, lexicons, policies) are packaged at install time.
For development or local overrides, if a file exists at the legacy location
relative to the current working directory, it takes precedence."""

from __future__ import annotations

import sys
from pathlib import Path

# For Python 3.9+ with fallback to importlib_resources for earlier versions
if sys.version_info >= (3, 9):
    from importlib import resources as importlib_resources
else:
    try:
        import importlib_resources  # type: ignore[import-not-found]
    except ImportError:
        importlib_resources = None  # type: ignore[assignment]


def resolve(resource_path: str, *, legacy_path: str | None = None) -> Path:
    """Resolve a resource path.

    Resolution order (lowest priority -> highest):
    1. Packaged resource (voxscribe/resources_config/, voxscribe/resources_data/)
    2. Legacy file-system override (if legacy_path is provided and exists
       relative to cwd, such as config/config.local.yaml in the repo)

    Args:
        resource_path: Path relative to package resources, e.g.
            "resources_config/config.yaml" or "resources_data/prompts/ideascribe.md"
        legacy_path: Optional cwd-relative path for backward compatibility,
            e.g. "config/config.local.yaml"

    Returns:
        Path object to the resolved resource (either packaged or override)

    Raises:
        FileNotFoundError if the resource does not exist in either location.
    """
    # Check legacy override first (highest priority)
    if legacy_path is not None:
        legacy = Path(legacy_path)
        if legacy.is_file():
            return legacy

    # Try packaged resource
    parts = resource_path.split("/")
    if not parts or not parts[0]:
        raise ValueError(f"Invalid resource_path: {resource_path}")

    package_name = "voxscribe"
    sub_package = parts[0]  # e.g. "resources_config" or "resources_data"
    relative = Path("/".join(parts[1:])) if len(parts) > 1 else Path(".")

    try:
        if importlib_resources is None:
            raise ImportError("importlib.resources unavailable")

        # Try importlib.resources (Python 3.9+)
        try:
            # Python 3.9+
            from importlib.resources import files
            pkg_files = files(f"{package_name}.{sub_package}")
            for part in relative.parts:
                pkg_files = pkg_files / part
            pkg_path_str = str(pkg_files)
            # For a real installed wheel, we get a path we can use directly
            pkg_path = Path(pkg_path_str.split("::")[-1])  # Strip traversable info
        except (ImportError, AttributeError):
            # Fallback to older API
            if importlib_resources is None:
                raise ImportError("importlib.resources not available")
            pkg = importlib_resources.files(f"{package_name}.{sub_package}")
            as_file = importlib_resources.as_file(pkg)
            with as_file as base:
                pkg_path = base / relative

        if pkg_path.is_file():
            return pkg_path

        raise FileNotFoundError(f"Resource not found: {resource_path}")

    except Exception as e:
        # Fallback: try direct filesystem relative to voxscribe module
        voxscribe_dir = Path(__file__).resolve().parent
        pkg_path = voxscribe_dir / sub_package / relative
        if pkg_path.is_file():
            return pkg_path
        raise FileNotFoundError(
            f"Resource not found: {resource_path} (tried {pkg_path})"
        ) from e


def get_config_dir() -> Path:
    """Get the config directory path, checking for legacy cwd override first."""
    legacy = Path("config")
    if legacy.is_dir():
        return legacy
    # Packaged resources
    return resolve("resources_config/config.yaml").parent


def get_data_dir() -> Path:
    """Get the data directory path, checking for legacy cwd override first."""
    legacy = Path("data")
    if legacy.is_dir():
        return legacy
    # Packaged resources
    return resolve("resources_data/prompts/ideascribe.md").parent.parent
