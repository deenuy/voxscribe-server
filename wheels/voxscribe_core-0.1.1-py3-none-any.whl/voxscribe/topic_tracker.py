"""Topic tracking for long conversations: shift, resume, stack, primary
thread, unresolved intents, and idea-level repetition.

Content-word keyword profiles and overlap scores — no embeddings, no model.
The cost of a wrong topic call is suboptimal vocabulary biasing, never wrong
text, so crude-but-deterministic is the right trade. Explicit resume phrases
("back to", "where was I") lower the bar for matching a suspended topic,
because that is exactly what they are for in natural speech.
"""

from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass, field

from .models import RepetitionEvent, RepetitionKind, TopicEvent, TopicEventKind

_STOPWORDS = {
    "the",
    "a",
    "an",
    "and",
    "or",
    "but",
    "so",
    "to",
    "of",
    "in",
    "on",
    "at",
    "for",
    "with",
    "is",
    "are",
    "was",
    "were",
    "be",
    "been",
    "it",
    "its",
    "this",
    "that",
    "these",
    "those",
    "i",
    "we",
    "you",
    "they",
    "he",
    "she",
    "my",
    "our",
    "your",
    "their",
    "his",
    "her",
    "me",
    "us",
    "them",
    "do",
    "does",
    "did",
    "have",
    "has",
    "had",
    "will",
    "would",
    "should",
    "could",
    "can",
    "not",
    "no",
    "yes",
    "if",
    "when",
    "then",
    "than",
    "as",
    "by",
    "from",
    "about",
    "into",
    "over",
    "after",
    "before",
    "just",
    "also",
    "very",
    "really",
    "there",
    "here",
    "what",
    "which",
    "who",
    "how",
    "why",
    "all",
    "some",
    "any",
    "one",
    "two",
    "thing",
    "things",
    "way",
    "back",
    "important",
    "anyway",
    "well",
    "now",
    "like",
    "mean",
    "said",
    "told",
}

_RESUME_PHRASES = (
    "back to",
    "as i was saying",
    "where was i",
    "getting back",
    "anyway the",
)

_INTENT = re.compile(
    r"\b(?:the idea is|we should|i want to|need to|don't forget|"
    r"the important thing is|make sure|it should)\b(.{4,})",
    re.I,
)


def keywords(text: str, k: int = 12) -> list[str]:
    words = [w for w in re.findall(r"[a-z']+", text.lower()) if len(w) > 2]
    counts = Counter(w for w in words if w not in _STOPWORDS)
    return [w for w, _ in counts.most_common(k)]


def _overlap(a: list[str], b: Counter) -> float:
    if not a or not b:
        return 0.0
    a_set, b_set = set(a), set(b)
    return len(a_set & b_set) / len(a_set | b_set)


@dataclass
class Topic:
    topic_id: str
    keyword_counts: Counter = field(default_factory=Counter)
    turn_ids: list[str] = field(default_factory=list)
    engagements: int = 1  # 1 at creation, +1 per resume: "kept coming back"


@dataclass
class Intent:
    text: str
    turn_id: str
    topic_id: str
    resolved: bool = False


class TopicTracker:
    """One per session. observe_turn() is called only at commit boundaries,
    so this never runs on the per-chunk hot path."""

    def __init__(self, shift_threshold: float = 0.15, resume_threshold: float = 0.3):
        self.shift_threshold = shift_threshold
        self.resume_threshold = resume_threshold
        self.topics: dict[str, Topic] = {}
        self.active_id: str | None = None
        self.stack: list[str] = []  # suspended topic ids, most recent last
        self.intents: list[Intent] = []
        self._counter = 0

    def observe_turn(self, turn_id: str, text: str) -> tuple[str, list]:
        events: list = []
        turn_kw = keywords(text)
        lowered = text.lower()
        explicit_resume = any(p in lowered for p in _RESUME_PHRASES)

        if self.active_id is None:
            self._activate_new(turn_id, turn_kw)
        elif not turn_kw:
            # contentless turn ("and then we"): stays with the active topic
            self.topics[self.active_id].turn_ids.append(turn_id)
        else:
            active = self.topics[self.active_id]
            active_overlap = _overlap(turn_kw, active.keyword_counts)
            if active_overlap >= self.shift_threshold and not explicit_resume:
                active.keyword_counts.update(turn_kw)
                active.turn_ids.append(turn_id)
                if active_overlap >= 0.5:
                    events.append(self._idea_repetition(turn_kw, active))
            else:
                resumed = self._best_suspended(turn_kw)
                bar = 0.0 if explicit_resume else self.resume_threshold
                if resumed is not None and _overlap(turn_kw, resumed.keyword_counts) > bar:
                    self.stack.remove(resumed.topic_id)
                    self.stack.append(self.active_id)
                    self.active_id = resumed.topic_id
                    resumed.engagements += 1
                    events.append(
                        TopicEvent(
                            TopicEventKind.RESUME,
                            resumed.topic_id,
                            turn_kw,
                            resumed_from_turn_id=resumed.turn_ids[-1],
                        )
                    )
                    events.append(self._idea_repetition(turn_kw, resumed))
                    resumed.keyword_counts.update(turn_kw)
                    resumed.turn_ids.append(turn_id)
                else:
                    self.stack.append(self.active_id)
                    self._activate_new(turn_id, turn_kw)
                    events.append(TopicEvent(TopicEventKind.SHIFT, self.active_id, turn_kw))

        self._resolve_intents(turn_id, turn_kw)
        self._extract_intents(turn_id, text)
        return self.active_id or "", [e for e in events if e is not None]

    # ---- intents ----

    def _extract_intents(self, turn_id: str, text: str) -> None:
        for m in _INTENT.finditer(text):
            self.intents.append(
                Intent(m.group(0).strip().rstrip(".,"), turn_id, self.active_id or "")
            )

    def _resolve_intents(self, turn_id: str, turn_kw: list[str]) -> None:
        kw = set(turn_kw)
        for intent in self.intents:
            if intent.resolved or intent.turn_id == turn_id:
                continue
            if len(kw & set(keywords(intent.text))) >= 2:
                intent.resolved = True

    def unresolved_intents(self) -> list[Intent]:
        return [i for i in self.intents if not i.resolved]

    # ---- topics ----

    @property
    def primary_topic_id(self) -> str | None:
        """The thread of the session: the topic the speaker keeps coming back
        to (most engagements), then most turns, earliest topic winning ties.
        A long story detour can hold more turns than the original idea, but
        the idea is what gets resumed — that is the primary thread."""
        if not self.topics:
            return None
        return max(
            self.topics.values(),
            key=lambda t: (
                t.engagements,
                len(t.turn_ids),
                -int(t.topic_id.rsplit("-", 1)[-1]),
            ),
        ).topic_id

    def active_keywords(self, k: int = 12) -> list[str]:
        if self.active_id is None:
            return []
        return [w for w, _ in self.topics[self.active_id].keyword_counts.most_common(k)]

    def _activate_new(self, turn_id: str, turn_kw: list[str]) -> None:
        self._counter += 1
        topic = Topic(f"topic-{self._counter}", Counter(turn_kw), [turn_id])
        self.topics[topic.topic_id] = topic
        self.active_id = topic.topic_id

    def _best_suspended(self, turn_kw: list[str]) -> Topic | None:
        candidates = [self.topics[tid] for tid in self.stack]
        if not candidates:
            return None
        best = max(candidates, key=lambda t: _overlap(turn_kw, t.keyword_counts))
        return best if _overlap(turn_kw, best.keyword_counts) > 0 else None

    def _idea_repetition(self, turn_kw: list[str], topic: Topic) -> RepetitionEvent | None:
        shared = sorted(set(turn_kw) & set(topic.keyword_counts))
        if len(shared) < 2:
            return None
        return RepetitionEvent(
            kind=RepetitionKind.NEAR,
            phrase=" ".join(shared[:6]),
            count=2,
            collapsed=False,  # idea-level repetition is reported, never deleted
        )
